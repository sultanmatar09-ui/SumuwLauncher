package com.sumuw.launcher.core

import android.animation.TimeInterpolator
import android.view.View
import kotlin.math.cos
import kotlin.math.exp

/**
 * Pure Android SDK Spring Physics (120Hz-ready) without external dynamic-animation libraries.
 */
object SpringPhysics {
    class SpringInterpolator(
        private val dampingRatio: Float = 0.72f,
        private val stiffness: Float = 14f
    ) : TimeInterpolator {
        override fun getInterpolation(t: Float): Float {
            if (t <= 0f) return 0f
            if (t >= 1f) return 1f
            val decay = exp(-dampingRatio * stiffness * t)
            return (1f - decay * cos(stiffness * t)).coerceIn(0f, 1.15f)
        }
    }

    fun animateFolderOpen(view: View) {
        view.scaleX = 0.84f
        view.scaleY = 0.84f
        view.alpha = 0f
        view.animate()
            .scaleX(1f)
            .scaleY(1f)
            .alpha(1f)
            .setDuration(320L)
            .setInterpolator(SpringInterpolator(0.68f, 13f))
            .start()
    }

    fun animatePanelReveal(view: View, fromTranslationY: Float = 90f) {
        view.translationY = fromTranslationY
        view.alpha = 0f
        view.animate()
            .translationY(0f)
            .alpha(1f)
            .setDuration(280L)
            .setInterpolator(SpringInterpolator(0.76f, 12f))
            .start()
    }
}
