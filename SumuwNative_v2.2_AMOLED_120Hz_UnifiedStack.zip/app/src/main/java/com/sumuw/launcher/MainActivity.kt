package com.sumuw.launcher

import android.Manifest
import android.app.WallpaperManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.DragEvent
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.sumuw.launcher.core.GlassEngine
import com.sumuw.launcher.core.SpringPhysics
import com.sumuw.launcher.data.*
import com.sumuw.launcher.notifications.SumuwNotificationListener
import com.sumuw.launcher.search.SmartSearchEngine
import com.sumuw.launcher.tools.IslamicAndPracticalTools
import com.sumuw.launcher.ui.*
import com.sumuw.launcher.wallpaper.SumuwWallpaperService
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : android.app.Activity(), SensorEventListener {

    private lateinit var rootLayout: FrameLayout
    private lateinit var wallpaperImage: ImageView
    private lateinit var wallpaperScrim: View
    private lateinit var workspaceRow: LinearLayout
    private lateinit var sideDock: GlassCardView
    private lateinit var dockIconsCol: LinearLayout
    private lateinit var duoBatteryView: DuoBatteryDockView
    private lateinit var mainCanvas: LinearLayout

    // Capsules
    private lateinit var capsulesWrapper: LinearLayout
    private lateinit var timeTv: TextView
    private lateinit var hijriTv: TextView
    private lateinit var prayerMiniPill: TextView

    // ONE Unified Stacked Card (Slide 0: Matches, Slide 1: Breaking News, Slide 2: Prayer & Tasbih)
    private var activeStackSlide = 0
    private lateinit var stackDotsCol: LinearLayout
    private lateinit var stackMatchesSlide: LinearLayout
    private lateinit var stackNewsSlide: LinearLayout
    private lateinit var stackPrayerSlide: LinearLayout

    // Matches views inside Slide 0
    private lateinit var matchLeagueTabsRow: LinearLayout
    private lateinit var matchCounterTv: TextView
    private lateinit var matchHomeLogo: ImageView
    private lateinit var matchAwayLogo: ImageView
    private lateinit var matchHomeTv: TextView
    private lateinit var matchAwayTv: TextView
    private lateinit var matchCenterTimeTv: TextView
    private lateinit var matchChannelTv: TextView
    private lateinit var matchLeagueLabelTv: TextView
    private var allMatches: List<MatchItem> = emptyList()
    private var selectedLeagueFilter: String = "ALL"
    private var currentMatchIndex: Int = 0

    // Breaking News views inside Slide 1
    private lateinit var newsSourceBadge: TextView
    private lateinit var newsTickerTv: TextView
    private var newsList: List<NewsItem> = emptyList()
    private var newsIndex: Int = 0

    // Prayer & Tasbih views inside Slide 2
    private lateinit var stackPrayerTitleTv: TextView
    private lateinit var stackTasbihBtn: TextView

    private lateinit var searchContainer: GlassCardView
    private lateinit var searchInput: EditText
    private lateinit var searchResultsBox: LinearLayout
    private lateinit var favAppGrid: GridView
    private lateinit var overlayPanel: FrameLayout

    private var allApps: List<AppInfo> = emptyList()
    private lateinit var favAdapter: AppGridAdapter

    private var sensorManager: SensorManager? = null
    private var qiblaDegreeCallback: ((Float) -> Unit)? = null
    private var qiblaBearing: Float = 290f

    private val tickerHandler = Handler(Looper.getMainLooper())
    private val clockRunnable = object : Runnable {
        override fun run() {
            refreshTimeAndPrayer()
            tickerHandler.postDelayed(this, 25_000L)
        }
    }
    private val newsCycleRunnable = object : Runnable {
        override fun run() {
            advanceNewsTicker()
            tickerHandler.postDelayed(this, 8_000L)
        }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (::duoBatteryView.isInitialized) {
                duoBatteryView.refreshBatteryState()
            }
        }
    }

    private val backdropListener: () -> Unit = { refreshAllGlassViews() }
    private val notifListener: () -> Unit = {
        if (::favAdapter.isInitialized) favAdapter.notifyDataSetChanged()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        enable120HzDisplay()

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager

        buildUI()
        applySelectedWallpaper()

        GlassEngine.addListener(backdropListener)
        SumuwNotificationListener.addListener(notifListener)
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

        val dm = resources.displayMetrics
        GlassEngine.refreshBackdropAsync(this, dm.widthPixels, dm.heightPixels)
        loadInstalledAppsAsync()
        refreshTimeAndPrayer()
        loadLiveNewsAndMatches()

        tickerHandler.postDelayed(clockRunnable, 25_000L)
        tickerHandler.postDelayed(newsCycleRunnable, 8_000L)
    }

    private fun enable120HzDisplay() {
        try {
            val d = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) display else @Suppress("DEPRECATION") windowManager.defaultDisplay
            val currentMode = d?.mode
            val modes = d?.supportedModes
            if (currentMode != null && modes != null) {
                val bestMode = modes
                    .filter { it.physicalWidth == currentMode.physicalWidth && it.physicalHeight == currentMode.physicalHeight }
                    .maxByOrNull { it.refreshRate }
                if (bestMode != null && bestMode.modeId != currentMode.modeId) {
                    val lp = window.attributes
                    lp.preferredDisplayModeId = bestMode.modeId
                    window.attributes = lp
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.decorView.rootSurfaceControl?.let { sc ->
                    // SurfaceControl frame rate hint where supported by device HAL
                    runCatching {
                        val method = Surface::class.java.getMethod(
                            "setFrameRate",
                            Float::class.javaPrimitiveType,
                            Int::class.javaPrimitiveType
                        )
                        val holder = window.decorView.holder
                        holder?.surface?.let { surf ->
                            if (surf.isValid) method.invoke(surf, 120f, Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE)
                        }
                    }
                }
            }
        } catch (_: Throwable) {
        }
    }

    override fun onResume() {
        super.onResume()
        enable120HzDisplay()
        refreshTimeAndPrayer()
        if (::duoBatteryView.isInitialized) duoBatteryView.refreshBatteryState()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val dm = resources.displayMetrics
        GlassEngine.refreshBackdropAsync(this, dm.widthPixels, dm.heightPixels)
        refreshTimeAndPrayer()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> TouchGuard.onFingerDown()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> TouchGuard.onFingerUp()
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onDestroy() {
        tickerHandler.removeCallbacks(clockRunnable)
        tickerHandler.removeCallbacks(newsCycleRunnable)
        GlassEngine.removeListener(backdropListener)
        SumuwNotificationListener.removeListener(notifListener)
        runCatching { unregisterReceiver(batteryReceiver) }
        sensorManager?.unregisterListener(this)
        super.onDestroy()
    }

    private fun buildUI() {
        val d = resources.displayMetrics.density
        rootLayout = FrameLayout(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        // 1. Wallpaper Background + Scrim
        wallpaperImage = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        rootLayout.addView(wallpaperImage)

        wallpaperScrim = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        rootLayout.addView(wallpaperScrim)

        // 2. Main Workspace Row: Right-Side Floating Dock + Left Main Canvas
        workspaceRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding((10 * d).toInt(), (34 * d).toInt(), (10 * d).toInt(), (16 * d).toInt())
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // 2A. Right-Side Floating Glass Dock (Drop Target for pinning apps)
        sideDock = GlassCardView(this).apply {
            cornerRadiusDp = 28f
            layoutParams = LinearLayout.LayoutParams(
                (64 * d).toInt(),
                ViewGroup.LayoutParams.MATCH_PARENT
            ).apply {
                marginEnd = (10 * d).toInt()
            }
            setPadding((6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt(), (10 * d).toInt())
        }
        dockIconsCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        sideDock.addView(dockIconsCol)
        buildSideDockSkeleton()
        setupDockDragTarget()
        workspaceRow.addView(sideDock)

        // 2B. Left Main Canvas
        mainCanvas = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.MATCH_PARENT,
                1f
            )
        }

        buildCapsules()
        mainCanvas.addView(capsulesWrapper)

        // Smart Search Capsule
        searchContainer = GlassCardView(this).apply {
            cornerRadiusDp = 20f
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = (2 * d).toInt()
                bottomMargin = (8 * d).toInt()
            }
            setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
        }
        searchInput = EditText(this).apply {
            hint = "ابحث عن تطبيق، حاسبة، زكاة..."
            setHintTextColor(0xFFCBD5E1.toInt())
            setTextColor(Color.WHITE)
            background = null
            textSize = 13f
            isSingleLine = true
            typeface = Typeface.create("serif", Typeface.NORMAL)
        }
        searchContainer.addView(searchInput)
        mainCanvas.addView(searchContainer)

        searchResultsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(0, 0, 0, (6 * d).toInt())
        }
        mainCanvas.addView(searchResultsBox)

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                updateSearchResults(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        // Favorite Apps 4-column Grid (Drag from Grid -> Dock, Drop from Dock -> Grid)
        favAppGrid = GridView(this).apply {
            numColumns = 4
            verticalSpacing = (10 * d).toInt()
            horizontalSpacing = (4 * d).toInt()
            isVerticalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }
        favAdapter = AppGridAdapter(this, emptyList()) { launchApp(it) }
        favAppGrid.adapter = favAdapter
        setupGridDragAndLongPress()
        mainCanvas.addView(favAppGrid)

        workspaceRow.addView(mainCanvas)
        rootLayout.addView(workspaceRow)

        overlayPanel = FrameLayout(this).apply {
            visibility = View.GONE
            setBackgroundColor(Color.argb(150, 4, 8, 18))
            setOnClickListener { closeOverlay() }
        }
        rootLayout.addView(overlayPanel)

        setContentView(rootLayout)
        applyVisibilityStates()
    }

    private fun setupDockDragTarget() {
        sideDock.setOnDragListener { v, event ->
            when (event.action) {
                DragEvent.ACTION_DRAG_STARTED -> {
                    event.clipDescription?.label?.toString() == "GRID_APP"
                }
                DragEvent.ACTION_DRAG_ENTERED -> {
                    v.animate().scaleX(1.04f).scaleY(1.01f).setDuration(120).start()
                    true
                }
                DragEvent.ACTION_DRAG_EXITED, DragEvent.ACTION_DRAG_ENDED -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    true
                }
                DragEvent.ACTION_DROP -> {
                    val pkg = event.clipData?.getItemAt(0)?.text?.toString() ?: return@setOnDragListener false
                    val defaults = getDefaultDockPackages()
                    LauncherPrefs.addAppToDock(this, pkg, defaults)
                    populateSideDockPinnedApps()
                    refreshGridAppsExcludingDock()
                    Toast.makeText(this, "تم تثبيت التطبيق في الدوك", Toast.LENGTH_SHORT).show()
                    true
                }
                else -> true
            }
        }
    }

    private fun setupGridDragAndLongPress() {
        favAppGrid.setOnItemLongClickListener { _, view, position, _ ->
            val app = favAdapter.getItem(position) as? AppInfo ?: return@setOnItemLongClickListener false
            val clip = ClipData.newPlainText("GRID_APP", app.packageName)
            val shadow = View.DragShadowBuilder(view)
            view.startDragAndDrop(clip, shadow, app, 0)
            true
        }

        favAppGrid.setOnDragListener { _, event ->
            when (event.action) {
                DragEvent.ACTION_DRAG_STARTED -> {
                    event.clipDescription?.label?.toString() == "DOCK_APP"
                }
                DragEvent.ACTION_DROP -> {
                    val pkg = event.clipData?.getItemAt(0)?.text?.toString() ?: return@setOnDragListener false
                    val defaults = getDefaultDockPackages()
                    LauncherPrefs.removeAppFromDock(this, pkg, defaults)
                    populateSideDockPinnedApps()
                    refreshGridAppsExcludingDock()
                    Toast.makeText(this, "تمت إعادة التطبيق إلى الشاشة", Toast.LENGTH_SHORT).show()
                    true
                }
                else -> true
            }
        }
    }

    private fun buildCapsules() {
        val d = resources.displayMetrics.density
        capsulesWrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        // 1. Compact Top Row: Time + Hijri Capsule + Next Prayer Pill + Menu
        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (8 * d).toInt() }
        }

        val timePill = GlassCardView(this).apply {
            cornerRadiusDp = 22f
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.25f).apply {
                marginEnd = (6 * d).toInt()
            }
            setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (8 * d).toInt())
            setOnClickListener { showDisplayOptions() }
        }
        val timeInner = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        timeTv = TextView(this).apply {
            textSize = 22f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(0, 0, (8 * d).toInt(), 0)
        }
        hijriTv = TextView(this).apply {
            textSize = 11f
            setTextColor(0xFFE8C56E.toInt())
            typeface = Typeface.create("serif", Typeface.BOLD)
            maxLines = 2
        }
        timeInner.addView(timeTv)
        timeInner.addView(hijriTv)
        timePill.addView(timeInner)

        val prayerPillCard = GlassCardView(this).apply {
            cornerRadiusDp = 22f
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = (6 * d).toInt()
            }
            setPadding((10 * d).toInt(), (10 * d).toInt(), (10 * d).toInt(), (10 * d).toInt())
            setOnClickListener { showPrayerScheduleOverlay() }
        }
        prayerMiniPill = TextView(this).apply {
            textSize = 11.5f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface = Typeface.create("serif", Typeface.BOLD)
            maxLines = 1
        }
        prayerPillCard.addView(prayerMiniPill)

        val menuBtn = GlassCardView(this).apply {
            cornerRadiusDp = 20f
            layoutParams = LinearLayout.LayoutParams((42 * d).toInt(), (42 * d).toInt())
            setOnClickListener { showToolsMenu() }
        }
        val menuDots = TextView(this).apply {
            text = "•••"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }
        menuBtn.addView(menuDots)

        topRow.addView(timePill)
        topRow.addView(prayerPillCard)
        topRow.addView(menuBtn)
        capsulesWrapper.addView(topRow)

        // 2. ONE Unified Stacked Card (Matches + Breaking News + Prayer/Tasbih)
        val stackWrapper = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (8 * d).toInt() }
        }
        // Layered glass shadow card underneath
        val backLayer = GlassCardView(this).apply {
            cornerRadiusDp = 22f
            alpha = 0.55f
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (112 * d).toInt()
            ).apply {
                topMargin = (7 * d).toInt()
                marginStart = (10 * d).toInt()
                marginEnd = (10 * d).toInt()
            }
        }
        stackWrapper.addView(backLayer)

        val frontStackCard = GlassCardView(this).apply {
            cornerRadiusDp = 22f
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (5 * d).toInt() }
            setPadding((10 * d).toInt(), (10 * d).toInt(), (10 * d).toInt(), (10 * d).toInt())
        }

        val stackMainRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        // Content container (3 stacked slides)
        val slidesFrame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        // SLIDE 0: Matches (Roshn, EPL, UCL from ESPN)
        stackMatchesSlide = buildMatchesSlide()
        // SLIDE 1: Breaking News Ticker (Trusted Sources)
        stackNewsSlide = buildNewsSlide()
        // SLIDE 2: Prayer & Tasbih
        stackPrayerSlide = buildPrayerSlide()

        slidesFrame.addView(stackMatchesSlide)
        slidesFrame.addView(stackNewsSlide)
        slidesFrame.addView(stackPrayerSlide)

        // Left vertical 3-dot pager (like screenshot 12455.jpg!)
        stackDotsCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding((8 * d).toInt(), (6 * d).toInt(), (2 * d).toInt(), (6 * d).toInt())
            setOnClickListener {
                activeStackSlide = (activeStackSlide + 1) % 3
                renderActiveStackSlide()
            }
        }

        stackMainRow.addView(slidesFrame)
        stackMainRow.addView(stackDotsCol)
        frontStackCard.addView(stackMainRow)
        stackWrapper.addView(frontStackCard)
        capsulesWrapper.addView(stackWrapper)

        renderActiveStackSlide()
    }

    private fun buildMatchesSlide(): LinearLayout {
        val d = resources.displayMetrics.density
        val matchCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val topHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, (6 * d).toInt())
        }
        matchLeagueTabsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        buildLeagueTabs()

        val prevBtn = makePagerBtn("‹") { stepMatch(-1) }
        matchCounterTv = TextView(this).apply {
            text = "0/0"
            textSize = 10f
            setTextColor(0xFFCBD5E1.toInt())
            setPadding((4 * d).toInt(), 0, (4 * d).toInt(), 0)
        }
        val nextBtn = makePagerBtn("›") { stepMatch(1) }

        topHeader.addView(matchLeagueTabsRow)
        topHeader.addView(prevBtn)
        topHeader.addView(matchCounterTv)
        topHeader.addView(nextBtn)
        matchCol.addView(topHeader)

        val matchBody = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setOnClickListener { showAllMatchesSheet() }
        }

        val homeCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        matchHomeLogo = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            layoutParams = LinearLayout.LayoutParams((32 * d).toInt(), (32 * d).toInt())
        }
        matchHomeTv = TextView(this).apply {
            text = "—"
            textSize = 11.5f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface = Typeface.create("serif", Typeface.BOLD)
            maxLines = 1
        }
        homeCol.addView(matchHomeLogo)
        homeCol.addView(matchHomeTv)

        val centerCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.2f)
        }
        matchLeagueLabelTv = TextView(this).apply {
            text = "المباريات (ESPN)"
            textSize = 10f
            setTextColor(0xFFE8C56E.toInt())
        }
        matchCenterTimeTv = TextView(this).apply {
            text = "جاري التحميل..."
            textSize = 14f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        matchChannelTv = TextView(this).apply {
            text = "SSC / beIN"
            textSize = 10.5f
            setTextColor(0xFF93C5FD.toInt())
            gravity = Gravity.CENTER
        }
        centerCol.addView(matchLeagueLabelTv)
        centerCol.addView(matchCenterTimeTv)
        centerCol.addView(matchChannelTv)

        val awayCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        matchAwayLogo = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            layoutParams = LinearLayout.LayoutParams((32 * d).toInt(), (32 * d).toInt())
        }
        matchAwayTv = TextView(this).apply {
            text = "—"
            textSize = 11.5f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface = Typeface.create("serif", Typeface.BOLD)
            maxLines = 1
        }
        awayCol.addView(matchAwayLogo)
        awayCol.addView(matchAwayTv)

        matchBody.addView(homeCol)
        matchBody.addView(centerCol)
        matchBody.addView(awayCol)
        matchCol.addView(matchBody)
        return matchCol
    }

    private fun buildNewsSlide(): LinearLayout {
        val d = resources.displayMetrics.density
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, (4 * d).toInt(), 0, (4 * d).toInt())
            setOnClickListener { showBreakingNewsSheet() }
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, (8 * d).toInt())
        }
        val urgentBadge = TextView(this).apply {
            text = "● مباشر"
            textSize = 11f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("serif", Typeface.BOLD)
            setPadding((8 * d).toInt(), (3 * d).toInt(), (8 * d).toInt(), (3 * d).toInt())
            background = GradientDrawable().apply {
                cornerRadius = 10 * d
                setColor(0xFFDC2626.toInt())
            }
        }
        newsSourceBadge = TextView(this).apply {
            text = "سُمو"
            textSize = 11f
            setTextColor(0xFFE8C56E.toInt())
            setPadding((8 * d).toInt(), 0, (8 * d).toInt(), 0)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val nextNewsBtn = TextView(this).apply {
            text = "التالي ›"
            textSize = 11f
            setTextColor(0xFFCBD5E1.toInt())
            setOnClickListener { advanceNewsTicker() }
        }
        top.addView(urgentBadge)
        top.addView(newsSourceBadge)
        top.addView(nextNewsBtn)
        col.addView(top)

        newsTickerTv = TextView(this).apply {
            text = "جاري تحديث الأخبار العاجلة من المصادر الموثوقة..."
            textSize = 13.5f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("serif", Typeface.BOLD)
            isSingleLine = true
            ellipsize = TextUtils.TruncateAt.MARQUEE
            marqueeRepeatLimit = -1
            isSelected = true
        }
        col.addView(newsTickerTv)
        return col
    }

    private fun buildPrayerSlide(): LinearLayout {
        val d = resources.displayMetrics.density
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, (4 * d).toInt(), 0, (4 * d).toInt())
        }
        stackPrayerTitleTv = TextView(this).apply {
            text = "مواقيت الصلاة"
            textSize = 13.5f
            setTextColor(0xFFE8C56E.toInt())
            typeface = Typeface.create("serif", Typeface.BOLD)
            setPadding(0, 0, 0, (8 * d).toInt())
        }
        col.addView(stackPrayerTitleTv)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        stackTasbihBtn = TextView(this).apply {
            text = "مسبحة: ${LauncherPrefs.getTasbih(this@MainActivity)}"
            textSize = 12f
            setTextColor(Color.WHITE)
            setPadding((10 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
            background = GradientDrawable().apply {
                cornerRadius = 12 * d
                setColor(0x22FFFFFF)
            }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = (8 * d).toInt()
            }
            setOnClickListener {
                val next = LauncherPrefs.getTasbih(this@MainActivity) + 1
                LauncherPrefs.setTasbih(this@MainActivity, next)
                text = "مسبحة: $next"
            }
        }
        val qiblaBtn = TextView(this).apply {
            text = "القبلة 🧭"
            textSize = 12f
            setTextColor(0xFFE8C56E.toInt())
            setPadding((10 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
            background = GradientDrawable().apply {
                cornerRadius = 12 * d
                setColor(0x22D4AF37)
            }
            setOnClickListener { showQiblaCompass() }
        }
        row.addView(stackTasbihBtn)
        row.addView(qiblaBtn)
        col.addView(row)
        return col
    }

    private fun renderActiveStackSlide() {
        val d = resources.displayMetrics.density
        stackMatchesSlide.visibility = if (activeStackSlide == 0) View.VISIBLE else View.GONE
        stackNewsSlide.visibility = if (activeStackSlide == 1) View.VISIBLE else View.GONE
        stackPrayerSlide.visibility = if (activeStackSlide == 2) View.VISIBLE else View.GONE

        stackDotsCol.removeAllViews()
        for (i in 0..2) {
            val active = i == activeStackSlide
            val dot = View(this).apply {
                background = GradientDrawable().apply {
                    cornerRadius = 4 * d
                    setColor(if (active) Color.WHITE else 0x55FFFFFF)
                }
                layoutParams = LinearLayout.LayoutParams(
                    (4.5f * d).toInt(),
                    if (active) (16 * d).toInt() else (5 * d).toInt()
                ).apply {
                    topMargin = (2.5f * d).toInt()
                    bottomMargin = (2.5f * d).toInt()
                }
                setOnClickListener {
                    activeStackSlide = i
                    renderActiveStackSlide()
                }
            }
            stackDotsCol.addView(dot)
        }
    }

    private fun buildLeagueTabs() {
        val d = resources.displayMetrics.density
        matchLeagueTabsRow.removeAllViews()
        val tabs = listOf(
            "ALL" to "الكل",
            "ksa.1" to "روشن",
            "eng.1" to "الإنجليزي",
            "uefa.champions" to "الأبطال"
        )
        tabs.forEach { (key, label) ->
            val selected = key == selectedLeagueFilter
            val pill = TextView(this).apply {
                text = label
                textSize = 10f
                setTextColor(if (selected) 0xFF0F172A.toInt() else Color.WHITE)
                typeface = Typeface.create("serif", Typeface.BOLD)
                setPadding((7 * d).toInt(), (3 * d).toInt(), (7 * d).toInt(), (3 * d).toInt())
                background = GradientDrawable().apply {
                    cornerRadius = 10 * d
                    setColor(if (selected) 0xFFE8C56E.toInt() else 0x22FFFFFF)
                }
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = (4 * d).toInt() }
                setOnClickListener {
                    selectedLeagueFilter = key
                    currentMatchIndex = 0
                    buildLeagueTabs()
                    renderCurrentMatchCard()
                }
            }
            matchLeagueTabsRow.addView(pill)
        }
    }

    private fun makePagerBtn(symbol: String, onClick: () -> Unit): TextView {
        val d = resources.displayMetrics.density
        return TextView(this).apply {
            text = symbol
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(0xFFE8C56E.toInt())
            background = GradientDrawable().apply {
                cornerRadius = 10 * d
                setColor(0x22FFFFFF)
            }
            layoutParams = LinearLayout.LayoutParams((22 * d).toInt(), (22 * d).toInt())
            setOnClickListener { onClick() }
        }
    }

    private fun filteredMatches(): List<MatchItem> =
        if (selectedLeagueFilter == "ALL") allMatches
        else allMatches.filter { it.leagueKey == selectedLeagueFilter }

    private fun stepMatch(delta: Int) {
        val list = filteredMatches()
        if (list.isEmpty()) return
        currentMatchIndex = (currentMatchIndex + delta).mod(list.size)
        renderCurrentMatchCard()
    }

    private fun renderCurrentMatchCard() {
        val list = filteredMatches()
        if (list.isEmpty()) {
            matchCounterTv.text = "0/0"
            matchLeagueLabelTv.text = "مباريات اليوم"
            matchCenterTimeTv.text = "لا توجد مباريات حالياً"
            matchChannelTv.text = "اضغط للتحديث"
            matchHomeTv.text = "—"
            matchAwayTv.text = "—"
            matchHomeLogo.setImageDrawable(null)
            matchAwayLogo.setImageDrawable(null)
            return
        }
        val idx = currentMatchIndex.coerceIn(0, list.lastIndex)
        val m = list[idx]
        matchCounterTv.text = "${idx + 1}/${list.size}"
        matchLeagueLabelTv.text = "${m.leagueAr} • ${m.statusText}"
        matchCenterTimeTv.text = m.scoreOrTime
        matchCenterTimeTv.setTextColor(if (m.isLive) 0xFF4ADE80.toInt() else Color.WHITE)
        matchChannelTv.text = "📺 ${m.channel}"
        matchHomeTv.text = m.homeName
        matchAwayTv.text = m.awayName

        matchHomeLogo.setImageDrawable(null)
        matchAwayLogo.setImageDrawable(null)
        LiveDataFeeds.loadLogoAsync(m.homeLogoUrl) { bmp ->
            if (bmp != null) matchHomeLogo.setImageBitmap(bmp)
        }
        LiveDataFeeds.loadLogoAsync(m.awayLogoUrl) { bmp ->
            if (bmp != null) matchAwayLogo.setImageBitmap(bmp)
        }
    }

    private fun loadLiveNewsAndMatches() {
        LiveDataFeeds.fetchBreakingNewsAsync { items ->
            newsList = items
            newsIndex = 0
            advanceNewsTicker()
        }
        LiveDataFeeds.fetchAllLeaguesMatchesAsync { matches ->
            allMatches = matches
            currentMatchIndex = 0
            renderCurrentMatchCard()
        }
    }

    private fun advanceNewsTicker() {
        if (newsList.isEmpty()) return
        val item = newsList[newsIndex.mod(newsList.size)]
        newsSourceBadge.text = "${item.source} • حُدّثت الآن"
        newsTickerTv.text = item.title
        newsTickerTv.isSelected = true
        newsIndex = (newsIndex + 1).mod(newsList.size)
    }

    private fun buildSideDockSkeleton() {
        val d = resources.displayMetrics.density
        dockIconsCol.removeAllViews()

        // Top: Clean Segmented Circular Battery + Wi-Fi Ring
        duoBatteryView = DuoBatteryDockView(this).apply {
            contentDescription = "البطارية والاتصال"
            setOnClickListener {
                SpringPhysics.pressScale(this, true)
                postDelayed({ SpringPhysics.pressScale(this, false) }, 110)
                showToolsMenu()
            }
        }
        dockIconsCol.addView(duoBatteryView)

        val divider1 = View(this).apply {
            setBackgroundColor(0x33FFFFFF)
            layoutParams = LinearLayout.LayoutParams((28 * d).toInt(), (1 * d).toInt()).apply {
                topMargin = (6 * d).toInt()
                bottomMargin = (6 * d).toInt()
            }
        }
        dockIconsCol.addView(divider1)

        // Middle: Scrollable Pinned Apps in Dock (Drag out to Grid or tap + to add)
        val dockScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }
        val pinnedHolder = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            tag = "pinned_holder"
        }
        dockScroll.addView(pinnedHolder)
        dockIconsCol.addView(dockScroll)

        // Bottom: "+" Add to Dock + Wallpaper Studio + App Drawer
        val addDockBtn = makeDockActionBtn("+", "إضافة أو نقل تطبيق للدوك", Color.WHITE) {
            showPinToDockPicker()
        }
        (addDockBtn.layoutParams as LinearLayout.LayoutParams).topMargin = (6 * d).toInt()
        dockIconsCol.addView(addDockBtn)

        val wallpaperBtn = makeDockActionBtn("🎨", "خلفيات سُمو", 0xFFE8C56E.toInt()) {
            showWallpaperStudio()
        }
        (wallpaperBtn.layoutParams as LinearLayout.LayoutParams).topMargin = (6 * d).toInt()
        dockIconsCol.addView(wallpaperBtn)
    }

    private fun makeDockActionBtn(symbol: String, desc: String, color: Int, onClick: () -> Unit): TextView {
        val d = resources.displayMetrics.density
        return TextView(this).apply {
            text = symbol
            contentDescription = desc
            gravity = Gravity.CENTER
            textSize = 18f
            setTextColor(color)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            background = GradientDrawable().apply {
                cornerRadius = 18 * d
                setColor(0x22FFFFFF)
                setStroke((1 * d).toInt(), 0x33FFFFFF)
            }
            layoutParams = LinearLayout.LayoutParams((42 * d).toInt(), (42 * d).toInt())
            setOnClickListener {
                SpringPhysics.pressScale(this, true)
                postDelayed({ SpringPhysics.pressScale(this, false) }, 110)
                onClick()
            }
        }
    }

    private fun getDefaultDockPackages(): List<String> {
        val candidates = listOf(
            listOf("dialer", "phone", "contacts", "الهاتف"),
            listOf("messaging", "mms", "messages", "whatsapp", "الرسائل"),
            listOf("camera", "الكاميرا"),
            listOf("chrome", "browser", "sbrowser", "المتصفح"),
            listOf("settings", "الضبط", "الإعدادات")
        )
        val picked = ArrayList<String>()
        for (keywords in candidates) {
            val match = allApps.firstOrNull { app ->
                val p = app.packageName.lowercase()
                val l = app.label.lowercase()
                keywords.any { k -> p.contains(k) || l.contains(k) } && app.packageName !in picked
            }
            if (match != null) picked.add(match.packageName)
        }
        if (picked.size < 5) {
            allApps.filter { it.packageName !in picked }.take(5 - picked.size).forEach { picked.add(it.packageName) }
        }
        return picked
    }

    private fun populateSideDockPinnedApps() {
        val holder = dockIconsCol.findViewWithTag<LinearLayout>("pinned_holder") ?: return
        holder.removeAllViews()
        val d = resources.displayMetrics.density
        val savedPkgs = LauncherPrefs.getDockApps(this) ?: getDefaultDockPackages().also {
            LauncherPrefs.setDockApps(this, it)
        }
        val dockApps = savedPkgs.mapNotNull { pkg -> allApps.firstOrNull { it.packageName == pkg } }

        dockApps.forEach { app ->
            val iv = ImageView(this).apply {
                setImageDrawable(app.icon)
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding((5 * d).toInt(), (5 * d).toInt(), (5 * d).toInt(), (5 * d).toInt())
                background = GradientDrawable().apply {
                    cornerRadius = 15 * d
                    setColor(0x18FFFFFF)
                }
                layoutParams = LinearLayout.LayoutParams((44 * d).toInt(), (44 * d).toInt()).apply {
                    topMargin = (4 * d).toInt()
                    bottomMargin = (4 * d).toInt()
                }
                setOnClickListener {
                    SpringPhysics.pressScale(this, true)
                    postDelayed({
                        SpringPhysics.pressScale(this, false)
                        launchApp(app)
                    }, 90)
                }
                // Drag out from Dock to Grid smoothly
                setOnLongClickListener { view ->
                    val clip = ClipData.newPlainText("DOCK_APP", app.packageName)
                    val shadow = View.DragShadowBuilder(view)
                    view.startDragAndDrop(clip, shadow, app, 0)
                    true
                }
            }
            holder.addView(iv)
        }
    }

    private fun refreshGridAppsExcludingDock() {
        val dockSet = (LauncherPrefs.getDockApps(this) ?: emptyList()).toSet()
        favAdapter.updateApps(allApps.filter { it.packageName !in dockSet }.take(16))
    }

    private fun applySelectedWallpaper() {
        val selectedId = LauncherPrefs.getSelectedWallpaper(this)
        val item = SumuwWallpaperCatalog.findById(selectedId)
        if (item.drawableResId != null) {
            wallpaperImage.visibility = View.VISIBLE
            wallpaperImage.setImageResource(item.drawableResId)
        } else {
            wallpaperImage.visibility = View.GONE
        }
        val dim = LauncherPrefs.getWallpaperDim(this)
        wallpaperScrim.setBackgroundColor(Color.argb((dim * 255).toInt(), 4, 8, 18))
    }

    private fun refreshTimeAndPrayer() {
        val now = Date()
        timeTv.text = SimpleDateFormat("h:mm", Locale.US).format(now)

        val (hijri, _) = IslamicAndPracticalTools.getHijriAndGregorianDate()
        hijriTv.text = hijri

        val loc = getLastKnownLocation()
        val prayers = IslamicAndPracticalTools.computeTodayPrayerTimes(
            loc?.latitude ?: 21.5433,
            loc?.longitude ?: 39.1728
        )
        prayerMiniPill.text = "${prayers.nextPrayerName} ${prayers.nextPrayerTime}"
        if (::stackPrayerTitleTv.isInitialized) {
            stackPrayerTitleTv.text = "الصلاة القادمة: ${prayers.nextPrayerName} (${prayers.remainingText})"
        }
    }

    private fun loadInstalledAppsAsync() {
        GlassEngine.bgExecutor.execute {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolves = pm.queryIntentActivities(intent, 0)
            val usage = LauncherPrefs.getUsageCounts(this)
            val list = resolves
                .filter { it.activityInfo.packageName != packageName }
                .map { ri ->
                    AppInfo(
                        label = ri.loadLabel(pm).toString(),
                        packageName = ri.activityInfo.packageName,
                        icon = ri.loadIcon(pm),
                        launchCount = usage[ri.activityInfo.packageName] ?: 0
                    )
                }
                .sortedWith(compareByDescending<AppInfo> { it.launchCount }.thenBy { it.label })

            GlassEngine.mainHandler.post {
                allApps = list
                populateSideDockPinnedApps()
                refreshGridAppsExcludingDock()
            }
        }
    }

    private fun launchApp(app: AppInfo) {
        if (LauncherPrefs.isKidsMode(this)) {
            val allowed = setOf("com.android.calculator2", "com.google.android.calculator", "com.android.camera", "com.sec.android.app.camera")
            if (app.packageName !in allowed) {
                Toast.makeText(this, "وضع الأطفال مفعل: هذا التطبيق مقيد", Toast.LENGTH_SHORT).show()
                return
            }
        }
        val launchIntent = packageManager.getLaunchIntentForPackage(app.packageName) ?: return
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launchIntent)
        LauncherPrefs.recordAppLaunchAsync(this, app.packageName)
    }

    private fun updateSearchResults(query: String) {
        if (query.isBlank()) {
            searchResultsBox.visibility = View.GONE
            searchResultsBox.removeAllViews()
            return
        }
        searchResultsBox.visibility = View.VISIBLE
        searchResultsBox.removeAllViews()
        val d = resources.displayMetrics.density

        val smart = SmartSearchEngine.evaluate(this, query)
        for (res in smart.take(3)) {
            val card = GlassCardView(this).apply {
                cornerRadiusDp = 14f
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = (4 * d).toInt() }
                setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (8 * d).toInt())
                setOnClickListener { res.actionIntent?.let { startActivity(it) } }
            }
            val tv = TextView(this).apply {
                text = "${res.title} — ${res.subtitle}"
                textSize = 13f
                setTextColor(Color.WHITE)
            }
            card.addView(tv)
            searchResultsBox.addView(card)
        }

        val matchingApps = allApps.filter {
            it.label.contains(query, ignoreCase = true) || it.packageName.contains(query, ignoreCase = true)
        }.take(4)
        for (app in matchingApps) {
            val row = GlassCardView(this).apply {
                cornerRadiusDp = 14f
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = (4 * d).toInt() }
                setPadding((10 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
                setOnClickListener { launchApp(app) }
            }
            val ll = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val iv = ImageView(this).apply {
                setImageDrawable(app.icon)
                layoutParams = LinearLayout.LayoutParams((26 * d).toInt(), (26 * d).toInt()).apply {
                    marginEnd = (10 * d).toInt()
                }
            }
            val tv = TextView(this).apply {
                text = app.label
                textSize = 13.5f
                setTextColor(Color.WHITE)
            }
            ll.addView(iv)
            ll.addView(tv)
            row.addView(ll)
            searchResultsBox.addView(row)
        }
    }

    private fun refreshAllGlassViews() {
        fun invalidateTree(v: View) {
            if (v is GlassCardView) v.invalidate()
            if (v is ViewGroup) {
                for (i in 0 until v.childCount) invalidateTree(v.getChildAt(i))
            }
        }
        invalidateTree(rootLayout)
    }

    private fun applyVisibilityStates() {
        searchContainer.visibility = if (LauncherPrefs.isSearchBarVisible(this)) View.VISIBLE else View.GONE
        capsulesWrapper.visibility = if (LauncherPrefs.areCapsulesVisible(this)) View.VISIBLE else View.GONE
    }

    private fun openOverlay(title: String, populate: (LinearLayout) -> Unit) {
        val d = resources.displayMetrics.density
        overlayPanel.removeAllViews()
        overlayPanel.visibility = View.VISIBLE

        val scroll = ScrollView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            ).apply {
                setMargins((18 * d).toInt(), (42 * d).toInt(), (18 * d).toInt(), (36 * d).toInt())
            }
        }
        val box = GlassCardView(this).apply {
            cornerRadiusDp = 24f
            setPadding((18 * d).toInt(), (16 * d).toInt(), (18 * d).toInt(), (16 * d).toInt())
            setOnClickListener { /* consume */ }
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, (10 * d).toInt())
        }
        val header = TextView(this).apply {
            text = title
            textSize = 18f
            typeface = Typeface.create("serif", Typeface.BOLD)
            setTextColor(0xFFE8C56E.toInt())
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val closeX = TextView(this).apply {
            text = "✕"
            textSize = 16f
            setTextColor(0xFFCBD5E1.toInt())
            setPadding((10 * d).toInt(), (4 * d).toInt(), (10 * d).toInt(), (4 * d).toInt())
            setOnClickListener { closeOverlay() }
        }
        headerRow.addView(header)
        headerRow.addView(closeX)
        col.addView(headerRow)

        populate(col)

        box.addView(col)
        scroll.addView(box)
        overlayPanel.addView(scroll)
    }

    private fun closeOverlay() {
        sensorManager?.unregisterListener(this)
        qiblaDegreeCallback = null
        overlayPanel.visibility = View.GONE
        overlayPanel.removeAllViews()
    }

    private fun makeOverlayBtn(label: String, onClick: () -> Unit): TextView {
        val d = resources.displayMetrics.density
        return TextView(this).apply {
            text = label
            textSize = 14f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("serif", Typeface.BOLD)
            setPadding((14 * d).toInt(), (10 * d).toInt(), (14 * d).toInt(), (10 * d).toInt())
            background = GradientDrawable().apply {
                cornerRadius = 14 * d
                setColor(0x1EFFFFFF)
                setStroke((1 * d).toInt(), 0x33D4AF37)
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (6 * d).toInt() }
            setOnClickListener { onClick() }
        }
    }

    private fun showPinToDockPicker() {
        val dockSet = (LauncherPrefs.getDockApps(this) ?: emptyList()).toSet()
        openOverlay("إدارة تطبيقات الدوك (اضغط للإضافة أو الإزالة)") { col ->
            allApps.forEach { app ->
                val inDock = app.packageName in dockSet
                val label = if (inDock) "✓ في الدوك: ${app.label} (اضغط للإزالة)" else "+ إضافة للدوك: ${app.label}"
                col.addView(makeOverlayBtn(label) {
                    val defaults = getDefaultDockPackages()
                    if (inDock) LauncherPrefs.removeAppFromDock(this, app.packageName, defaults)
                    else LauncherPrefs.addAppToDock(this, app.packageName, defaults)
                    populateSideDockPinnedApps()
                    refreshGridAppsExcludingDock()
                    closeOverlay()
                })
            }
        }
    }

    private fun showBreakingNewsSheet() {
        openOverlay("الأخبار العاجلة — تحديث مباشر") { col ->
            col.addView(makeOverlayBtn("تحديث الأخبار الآن ↻") {
                loadLiveNewsAndMatches()
                closeOverlay()
            })
            newsList.forEach { n ->
                col.addView(makeOverlayBtn("[${n.source}] ${n.title}") {
                    if (n.link.isNotBlank()) {
                        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(n.link))) }
                    }
                    closeOverlay()
                })
            }
        }
    }

    private fun showAllMatchesSheet() {
        openOverlay("جدول المباريات (ESPN)") { col ->
            col.addView(makeOverlayBtn("تحديث النتائج والمباريات ↻") {
                loadLiveNewsAndMatches()
                closeOverlay()
            })
            val list = filteredMatches()
            if (list.isEmpty()) {
                col.addView(TextView(this).apply {
                    text = "لا توجد مباريات متاحة حالياً في هذا التصنيف"
                    setTextColor(Color.WHITE)
                    textSize = 14f
                })
            } else {
                list.forEach { m ->
                    col.addView(makeOverlayBtn("${m.leagueAr}: ${m.homeName} (${m.scoreOrTime}) ${m.awayName} • ${m.channel}") { })
                }
            }
        }
    }

    private fun showWallpaperStudio() {
        openOverlay("خلفيات سُمو و AMOLED") { col ->
            SumuwWallpaperPicker.populate(
                ctx = this,
                container = col,
                onWallpaperChanged = { applySelectedWallpaper() },
                onDimChanged = { alpha ->
                    wallpaperScrim.setBackgroundColor(Color.argb((alpha * 255).toInt(), 4, 8, 18))
                },
                onClose = { closeOverlay() }
            )
        }
    }

    private fun showPrayerScheduleOverlay() {
        val loc = getLastKnownLocation()
        val summary = IslamicAndPracticalTools.computeTodayPrayerTimes(
            loc?.latitude ?: 21.5433,
            loc?.longitude ?: 39.1728
        )
        openOverlay("مواقيت الصلاة اليوم") { col ->
            summary.allPrayers.forEach { p ->
                col.addView(makeOverlayBtn("${p.nameAr}    —    ${p.formattedTime()}") { })
            }
            col.addView(makeOverlayBtn("فتح بوصلة القبلة") { showQiblaCompass() })
        }
    }

    private fun showDisplayOptions() {
        openOverlay("خيارات العرض والكبسولات (120Hz)") { col ->
            val capVisible = LauncherPrefs.areCapsulesVisible(this)
            col.addView(makeOverlayBtn(if (capVisible) "إخفاء كبسولات سُمو" else "إظهار كبسولات سُمو") {
                LauncherPrefs.setCapsulesVisible(this, !capVisible)
                applyVisibilityStates()
                closeOverlay()
            })

            val searchVisible = LauncherPrefs.isSearchBarVisible(this)
            col.addView(makeOverlayBtn(if (searchVisible) "إخفاء شريط البحث" else "إظهار شريط البحث") {
                LauncherPrefs.setSearchBarVisible(this, !searchVisible)
                applyVisibilityStates()
                closeOverlay()
            })

            col.addView(makeOverlayBtn("خلفيات سُمو و AMOLED") { showWallpaperStudio() })

            col.addView(makeOverlayBtn("تعيين خلفية سُمو الحية للنظام") {
                val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                    putExtra(
                        WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                        android.content.ComponentName(this@MainActivity, SumuwWallpaperService::class.java)
                    )
                }
                startActivity(intent)
                closeOverlay()
            })

            col.addView(makeOverlayBtn("استعادة جميع الكبسولات والعناصر") {
                LauncherPrefs.restoreAllCards(this)
                applyVisibilityStates()
                closeOverlay()
            })
        }
    }

    private fun showToolsMenu() {
        openOverlay("مركز سُمو (البطارية ${duoBatteryView.phonePercent}%)") { col ->
            col.addView(makeOverlayBtn("خلفيات سُمو و AMOLED") { showWallpaperStudio() })
            col.addView(makeOverlayBtn("إدارة تطبيقات الدوك") { showPinToDockPicker() })
            col.addView(makeOverlayBtn("الأخبار العاجلة والمباريات") { showAllMatchesSheet() })
            col.addView(makeOverlayBtn("مواقيت الصلاة وبوصلة القبلة") { showPrayerScheduleOverlay() })
            col.addView(makeOverlayBtn("الختمة والمسبحة (${LauncherPrefs.getTasbih(this)})") { showKhatmaAndTasbih() })
            col.addView(makeOverlayBtn(if (LauncherPrefs.isHaramModeEnabled(this)) "إيقاف وضع الحرم التلقائي" else "تفعيل وضع الحرم التلقائي") {
                val enabled = !LauncherPrefs.isHaramModeEnabled(this)
                LauncherPrefs.setHaramModeEnabled(this, enabled)
                Toast.makeText(this, if (enabled) "تم تفعيل وضع الحرم" else "تم إيقاف وضع الحرم", Toast.LENGTH_SHORT).show()
                closeOverlay()
            })
            col.addView(makeOverlayBtn(if (LauncherPrefs.isKidsMode(this)) "إلغاء قفل وضع الأطفال (بصمة/رمز الجهاز)" else "تفعيل وضع الأطفال") {
                if (LauncherPrefs.isKidsMode(this)) {
                    IslamicAndPracticalTools.requestKidsModeUnlock(
                        this,
                        onUnlocked = {
                            Toast.makeText(this, "تم فتح قفل وضع الأطفال", Toast.LENGTH_SHORT).show()
                            closeOverlay()
                        },
                        onDeniedOrError = { err -> Toast.makeText(this, err, Toast.LENGTH_LONG).show() }
                    )
                } else {
                    LauncherPrefs.setKidsMode(this, true)
                    Toast.makeText(this, "تم تفعيل وضع الأطفال", Toast.LENGTH_SHORT).show()
                    closeOverlay()
                }
            })
            col.addView(makeOverlayBtn("السيارة وموقف الركن") { showCarAndParking() })
            col.addView(makeOverlayBtn("نسخ احتياطي JSON (حفظ ومشاركة)") {
                val json = LauncherPrefs.exportFullBackupJson(this)
                val share = Intent(Intent.ACTION_SEND).apply {
                    type = "application/json"
                    putExtra(Intent.EXTRA_TEXT, json)
                }
                startActivity(Intent.createChooser(share, "حفظ نسخة سُمو الاحتياطية"))
                closeOverlay()
            })
        }
    }

    private fun showQiblaCompass() {
        val loc = getLastKnownLocation()
        qiblaBearing = if (loc != null) {
            IslamicAndPracticalTools.computeQiblaBearing(loc.latitude, loc.longitude, loc.altitude)
        } else {
            IslamicAndPracticalTools.computeQiblaBearing(21.5433, 39.1728, 12.0)
        }

        openOverlay("بوصلة القبلة الدقيقة") { col ->
            val infoTv = TextView(this).apply {
                text = "جاري معايرة المستشعر...\nزاوية القبلة: ${qiblaBearing.toInt()}°"
                textSize = 16f
                setTextColor(Color.WHITE)
                typeface = Typeface.create("serif", Typeface.BOLD)
            }
            col.addView(infoTv)
            qiblaDegreeCallback = { azimuth ->
                val rot = IslamicAndPracticalTools.getScreenRotationDegrees(this)
                val corrected = (qiblaBearing - azimuth - rot + 360f) % 360f
                infoTv.text = "زاوية القبلة: ${qiblaBearing.toInt()}°\nاتجاه السهم نسبة للهاتف: ${corrected.toInt()}°"
            }
            @Suppress("DEPRECATION")
            sensorManager?.getDefaultSensor(Sensor.TYPE_ORIENTATION)?.let {
                sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
            }
        }
    }

    private fun showKhatmaAndTasbih() {
        openOverlay("الختمة والمسبحة") { col ->
            val tv = TextView(this).apply {
                setTextColor(Color.WHITE)
                textSize = 15f
                text = "التسبيحات: ${LauncherPrefs.getTasbih(this@MainActivity)}  |  صفحة الختمة: ${LauncherPrefs.getKhatmaPage(this@MainActivity)} / 604"
            }
            col.addView(tv)
            col.addView(makeOverlayBtn("+ تسبيحة (سبحان الله)") {
                val next = LauncherPrefs.getTasbih(this) + 1
                LauncherPrefs.setTasbih(this, next)
                tv.text = "التسبيحات: $next  |  صفحة الختمة: ${LauncherPrefs.getKhatmaPage(this)} / 604"
            })
            col.addView(makeOverlayBtn("+ صفحة ختمة") {
                val next = LauncherPrefs.getKhatmaPage(this) + 1
                LauncherPrefs.setKhatmaPage(this, next)
                tv.text = "التسبيحات: ${LauncherPrefs.getTasbih(this)}  |  صفحة الختمة: $next / 604"
            })
        }
    }

    private fun showCarAndParking() {
        openOverlay("وضع السيارة وموقف الركن") { col ->
            val (lat, lon, note) = LauncherPrefs.getParking(this)
            val statusTv = TextView(this).apply {
                setTextColor(Color.WHITE)
                textSize = 14f
                text = if (lat != null && lon != null) "الموقف المحفوظ: $lat, $lon ($note)" else "لم يُحفظ موقع ركن بعد"
            }
            col.addView(statusTv)
            col.addView(makeOverlayBtn("حفظ موقع الركن الحالي") {
                val loc = getLastKnownLocation()
                if (loc != null) {
                    LauncherPrefs.saveParking(this, loc.latitude, loc.longitude, "موقف سيارتي")
                    statusTv.text = "تم الحفظ: ${loc.latitude}, ${loc.longitude}"
                } else {
                    Toast.makeText(this, "يرجى تفعيل صلاحية الموقع", Toast.LENGTH_SHORT).show()
                }
            })
            if (lat != null && lon != null) {
                col.addView(makeOverlayBtn("فتح الموقف في الخرائط") {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lon?q=$lat,$lon(موقف الركن)")))
                })
            }
        }
    }

    private fun getLastKnownLocation(): android.location.Location? {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) return null
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return
        qiblaDegreeCallback?.invoke(event.values[0])
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
