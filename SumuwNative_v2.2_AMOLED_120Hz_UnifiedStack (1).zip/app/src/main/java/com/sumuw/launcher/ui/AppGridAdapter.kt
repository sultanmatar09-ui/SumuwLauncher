package com.sumuw.launcher.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.sumuw.launcher.core.GlassEngine
import com.sumuw.launcher.notifications.SumuwNotificationListener

data class AppInfo(
    val label: String,
    val packageName: String,
    val icon: Drawable,
    val launchCount: Int = 0
)

/**
 * Pure Android SDK Grid Adapter using strict ViewHolder pattern for 120Hz smooth scrolling.
 */
class AppGridAdapter(
    private val context: Context,
    private var items: List<AppInfo>,
    private val onAppClick: (AppInfo) -> Unit
) : BaseAdapter() {

    private class ViewHolder(
        val root: LinearLayout,
        val icon: ImageView,
        val badge: TextView,
        val label: TextView
    )

    fun updateApps(newItems: List<AppInfo>) = updateItems(newItems)

    fun updateItems(newItems: List<AppInfo>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun getCount(): Int = items.size
    override fun getItem(position: Int): AppInfo = items[position]
    override fun getItemId(position: Int): Long = items[position].packageName.hashCode().toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val density = context.resources.displayMetrics.density
        val holder: ViewHolder
        val view: View

        if (convertView == null) {
            val root = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                val pad = (6 * density).toInt()
                setPadding(pad, pad, pad, pad)
            }

            val iconBox = FrameLayout(context).apply {
                val sz = (56 * density).toInt()
                layoutParams = LinearLayout.LayoutParams(sz, sz)
            }

            val iv = ImageView(context).apply {
                val sz = (50 * density).toInt()
                layoutParams = FrameLayout.LayoutParams(sz, sz, Gravity.CENTER)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }

            val badgeTv = TextView(context).apply {
                val sz = (18 * density).toInt()
                layoutParams = FrameLayout.LayoutParams(sz, sz, Gravity.TOP or Gravity.END)
                gravity = Gravity.CENTER
                textSize = 10f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(0xFFEF4444.toInt())
                }
                visibility = View.GONE
            }

            iconBox.addView(iv)
            iconBox.addView(badgeTv)

            val tv = TextView(context).apply {
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = (4 * density).toInt() }
                gravity = Gravity.CENTER
                textSize = 11.5f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                typeface = Typeface.create("serif", Typeface.NORMAL) // Clear Naskh-style Arabic rendering
            }

            root.addView(iconBox)
            root.addView(tv)
            holder = ViewHolder(root, iv, badgeTv, tv)
            root.tag = holder
            view = root
        } else {
            view = convertView
            holder = convertView.tag as ViewHolder
        }

        val app = items[position]
        holder.icon.setImageDrawable(app.icon)
        holder.label.text = app.label
        holder.label.setTextColor(if (GlassEngine.isLightWallpaper) 0xFF0F172A.toInt() else 0xFFF8FAFC.toInt())

        val count = SumuwNotificationListener.badgeCounts[app.packageName] ?: 0
        if (count > 0) {
            holder.badge.visibility = View.VISIBLE
            holder.badge.text = if (count > 99) "99" else count.toString()
        } else {
            holder.badge.visibility = View.GONE
        }

        // Instant launch on tap without waiting for ripple/press end
        holder.root.setOnClickListener { onAppClick(app) }
        return view
    }
}
