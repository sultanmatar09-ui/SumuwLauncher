package com.sumuw.launcher.tools

import android.app.Activity
import android.app.KeyguardManager
import android.app.NotificationManager
import android.content.Context
import android.hardware.GeomagneticField
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.icu.util.IslamicCalendar
import android.icu.util.ULocale
import android.location.Location
import android.os.Build
import android.os.CancellationSignal
import android.view.Surface
import com.sumuw.launcher.data.LauncherPrefs
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.*

data class PrayerEntry(
    val nameAr: String,
    val minutesFromMidnight: Int
) {
    fun formattedTime(): String {
        val h24 = (minutesFromMidnight / 60).mod(24)
        val m = minutesFromMidnight.mod(60)
        val amPm = if (h24 < 12) "ص" else "م"
        val h12 = when {
            h24 == 0 -> 12
            h24 > 12 -> h24 - 12
            else -> h24
        }
        return String.format(Locale.US, "%d:%02d %s", h12, m, amPm)
    }
}

data class PrayerSummary(
    val allPrayers: List<PrayerEntry>,
    val nextPrayerName: String,
    val nextPrayerTime: String,
    val remainingText: String
)

/**
 * Islamic & Practical Tools:
 * - Umm al-Qura Hijri calendar formatting.
 * - Astronomical Umm al-Qura prayer times & next-prayer live countdown.
 * - Qibla bearing with GeomagneticField magnetic declination & screen rotation compensation.
 * - Haram Mode (Masjid al-Haram & Masjid an-Nabawi geofence) with DND state save/restore.
 * - Kids Mode lock backed strictly by KeyguardManager.isDeviceSecure + BiometricPrompt.
 */
object IslamicAndPracticalTools {

    private const val KAABA_LAT = 21.422487
    private const val KAABA_LON = 39.826206
    private const val NABAWI_LAT = 24.467210
    private const val NABAWI_LON = 39.611131

    private val HIJRI_MONTHS = arrayOf(
        "محرم", "صفر", "ربيع الأول", "ربيع الآخر",
        "جمادى الأولى", "جمادى الآخرة", "رجب", "شعبان",
        "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
    )

    private val ARABIC_DAYS = arrayOf(
        "الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"
    )

    fun getHijriAndGregorianDate(): Pair<String, String> {
        val now = Calendar.getInstance()
        val dayName = ARABIC_DAYS[(now.get(Calendar.DAY_OF_WEEK) - 1).coerceIn(0, 6)]

        val hijriStr = try {
            val uLoc = ULocale("ar@calendar=islamic-umalqura")
            val ic = IslamicCalendar(uLoc)
            ic.timeInMillis = now.timeInMillis
            val hDay = ic.get(IslamicCalendar.DAY_OF_MONTH)
            val hMonth = HIJRI_MONTHS[ic.get(IslamicCalendar.MONTH).coerceIn(0, 11)]
            val hYear = ic.get(IslamicCalendar.YEAR)
            "$dayName، $hDay $hMonth $hYear هـ"
        } catch (_: Throwable) {
            dayName
        }

        val gregFmt = SimpleDateFormat("d MMMM yyyy م", Locale("ar"))
        return hijriStr to gregFmt.format(Date(now.timeInMillis))
    }

    /**
     * Computes Umm al-Qura prayer times (Fajr 18.5°, Isha +90m after Maghrib)
     * for the given coordinates (defaults to Jeddah: 21.5433, 39.1728).
     */
    fun computeTodayPrayerTimes(lat: Double = 21.5433, lon: Double = 39.1728): PrayerSummary {
        val cal = Calendar.getInstance()
        val tzHours = TimeZone.getDefault().getOffset(cal.timeInMillis) / 3600000.0
        val y = cal.get(Calendar.YEAR)
        val m = cal.get(Calendar.MONTH) + 1
        val d = cal.get(Calendar.DAY_OF_MONTH)

        val jd = julianDay(y, m, d) - lon / (15.0 * 24.0)
        val t = (jd - 2451545.0) / 36525.0

        val g = Math.toRadians((357.529 + 35999.050 * t).mod(360.0))
        val q = (280.459 + 36000.770 * t).mod(360.0)
        val l = Math.toRadians((q + 1.915 * sin(g) + 0.020 * sin(2 * g)).mod(360.0))
        val e = Math.toRadians(23.439 - 0.00000036 * (jd - 2451545.0))

        val ra = Math.toDegrees(atan2(cos(e) * sin(l), cos(l))) / 15.0
        val decl = asin(sin(e) * sin(l))
        val eqt = q / 15.0 - fixHour(ra)

        val dhuhrHours = 12.0 + tzHours - lon / 15.0 - eqt
        val sunriseHours = dhuhrHours - sunAngleTime(lat, decl, 0.833)
        val sunsetHours = dhuhrHours + sunAngleTime(lat, decl, 0.833)
        val fajrHours = dhuhrHours - sunAngleTime(lat, decl, 18.5)
        val asrHours = dhuhrHours + asrTime(lat, decl, 1.0)
        val maghribHours = sunsetHours
        val ishaHours = maghribHours + 1.5 // Umm al-Qura: 90 minutes after Maghrib

        val entries = listOf(
            PrayerEntry("الفجر", (fajrHours * 60).roundToInt()),
            PrayerEntry("الشروق", (sunriseHours * 60).roundToInt()),
            PrayerEntry("الظهر", (dhuhrHours * 60).roundToInt()),
            PrayerEntry("العصر", (asrHours * 60).roundToInt()),
            PrayerEntry("المغرب", (maghribHours * 60).roundToInt()),
            PrayerEntry("العشاء", (ishaHours * 60).roundToInt())
        )

        val nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val next = entries.firstOrNull { it.minutesFromMidnight > nowMin }
        val (nextName, nextTime, diffMin) = if (next != null) {
            Triple(next.nameAr, next.formattedTime(), next.minutesFromMidnight - nowMin)
        } else {
            val fajr = entries.first()
            Triple(fajr.nameAr, fajr.formattedTime(), (24 * 60 - nowMin) + fajr.minutesFromMidnight)
        }

        val remH = diffMin / 60
        val remM = diffMin % 60
        val remStr = if (remH > 0) "بعد ${remH}س ${remM}د" else "بعد ${remM} دقيقة"

        return PrayerSummary(entries, nextName, nextTime, remStr)
    }

    private fun julianDay(year: Int, month: Int, day: Int): Double {
        var y = year
        var m = month
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    private fun fixHour(a: Double): Double {
        var v = a - 24.0 * floor(a / 24.0)
        if (v < 0) v += 24.0
        return v
    }

    private fun sunAngleTime(latDeg: Double, declRad: Double, angleDeg: Double): Double {
        val latRad = Math.toRadians(latDeg)
        val num = -sin(Math.toRadians(angleDeg)) - sin(latRad) * sin(declRad)
        val den = cos(latRad) * cos(declRad)
        val cosH = (num / den).coerceIn(-1.0, 1.0)
        return Math.toDegrees(acos(cosH)) / 15.0
    }

    private fun asrTime(latDeg: Double, declRad: Double, factor: Double): Double {
        val latRad = Math.toRadians(latDeg)
        val angle = -atan(1.0 / (factor + tan(abs(latRad - declRad))))
        val num = sin(angle) - sin(latRad) * sin(declRad)
        val den = cos(latRad) * cos(declRad)
        val cosH = (num / den).coerceIn(-1.0, 1.0)
        return Math.toDegrees(acos(cosH)) / 15.0
    }

    fun computeQiblaBearing(lat: Double, lon: Double, altitude: Double = 0.0): Float {
        val phiK = Math.toRadians(KAABA_LAT)
        val lambdaK = Math.toRadians(KAABA_LON)
        val phi = Math.toRadians(lat)
        val lambda = Math.toRadians(lon)

        val y = sin(lambdaK - lambda)
        val x = cos(phi) * tan(phiK) - sin(phi) * cos(lambdaK - lambda)
        val trueBearing = (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0

        val geoField = GeomagneticField(
            lat.toFloat(), lon.toFloat(), altitude.toFloat(), System.currentTimeMillis()
        )
        return ((trueBearing - geoField.declination + 360.0) % 360.0).toFloat()
    }

    fun getScreenRotationDegrees(context: Context): Float {
        @Suppress("DEPRECATION")
        val rot = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            context.display?.rotation ?: Surface.ROTATION_0
        } else {
            (context.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager).defaultDisplay.rotation
        }
        return when (rot) {
            Surface.ROTATION_90 -> 90f
            Surface.ROTATION_180 -> 180f
            Surface.ROTATION_270 -> 270f
            else -> 0f
        }
    }

    fun evaluateHaramGeofence(context: Context, location: Location): Boolean {
        if (!LauncherPrefs.isHaramModeEnabled(context)) return false
        val distHaram = FloatArray(1)
        Location.distanceBetween(location.latitude, location.longitude, KAABA_LAT, KAABA_LON, distHaram)
        val distNabawi = FloatArray(1)
        Location.distanceBetween(location.latitude, location.longitude, NABAWI_LAT, NABAWI_LON, distNabawi)

        val inside = distHaram[0] <= 850f || distNabawi[0] <= 750f
        val wasInside = LauncherPrefs.isHaramInside(context)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (nm.isNotificationPolicyAccessGranted) {
            if (inside && !wasInside) {
                LauncherPrefs.setSavedDndFilter(context, nm.currentInterruptionFilter)
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
                LauncherPrefs.setHaramInside(context, true)
            } else if (!inside && wasInside) {
                val prev = LauncherPrefs.getSavedDndFilter(context)
                if (prev != -1) {
                    nm.setInterruptionFilter(prev)
                }
                LauncherPrefs.setHaramInside(context, false)
            }
        }
        return inside
    }

    fun requestKidsModeUnlock(
        activity: Activity,
        onUnlocked: () -> Unit,
        onDeniedOrError: (String) -> Unit
    ) {
        val km = activity.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isDeviceSecure) {
            onDeniedOrError("يجب تفعيل قفل الشاشة في إعدادات الجهاز لاستخدام قفل وضع الأطفال")
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val builder = BiometricPrompt.Builder(activity)
                .setTitle("إلغاء قفل وضع الأطفال")
                .setSubtitle("تحقق بهوية الجهاز للمتابعة")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                builder.setAllowedAuthenticators(
                    BiometricManager.Authenticators.BIOMETRIC_STRONG or
                        BiometricManager.Authenticators.DEVICE_CREDENTIAL
                )
            } else {
                @Suppress("DEPRECATION")
                builder.setDeviceCredentialAllowed(true)
            }

            val prompt = builder.build()
            prompt.authenticate(
                CancellationSignal(),
                activity.mainExecutor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                        LauncherPrefs.setKidsMode(activity, false)
                        onUnlocked()
                    }

                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                        onDeniedOrError(errString?.toString() ?: "تعذر التحقق")
                    }

                    override fun onAuthenticationFailed() {
                        onDeniedOrError("فشل التحقق")
                    }
                }
            )
        } else {
            onDeniedOrError("يتطلب قفل المقاييس الحيوية أندرويد 9 فأعلى")
        }
    }
}
