package com.sumuw.launcher.notifications

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.sumuw.launcher.data.TouchGuard

/**
 * NotificationListenerService with:
 * - Real change counter (ignores ongoing music/download progress spam).
 * - TouchGuard deferral so badges/grid never mutate while user's finger is down.
 */
class SumuwNotificationListener : NotificationListenerService() {

    data class NotifSummary(
        val key: String,
        val packageName: String,
        val title: String,
        val text: String,
        val postTime: Long
    )

    companion object {
        @Volatile
        var badgeCounts: Map<String, Int> = emptyMap()
            private set

        @Volatile
        var activeSummaries: List<NotifSummary> = emptyList()
            private set

        @Volatile
        private var lastFingerprint: Int = 0

        private val listeners = mutableListOf<() -> Unit>()

        fun addListener(l: () -> Unit) {
            synchronized(listeners) { if (!listeners.contains(l)) listeners.add(l) }
        }

        fun removeListener(l: () -> Unit) {
            synchronized(listeners) { listeners.remove(l) }
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        recomputeIfChanged()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn != null && isNoisyOngoing(sbn)) return
        recomputeIfChanged()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn != null && isNoisyOngoing(sbn)) return
        recomputeIfChanged()
    }

    private fun isNoisyOngoing(sbn: StatusBarNotification): Boolean {
        val n = sbn.notification ?: return true
        val flags = n.flags
        val isOngoing = (flags and Notification.FLAG_ONGOING_EVENT) != 0
        val cat = n.category
        if (isOngoing && (cat == Notification.CATEGORY_TRANSPORT || cat == Notification.CATEGORY_PROGRESS || cat == Notification.CATEGORY_SERVICE)) {
            return true
        }
        return false
    }

    private fun recomputeIfChanged() {
        val active = runCatching { activeNotifications }.getOrNull() ?: return
        val counts = HashMap<String, Int>()
        val summaries = ArrayList<NotifSummary>()
        var fp = 17

        for (sbn in active) {
            if (isNoisyOngoing(sbn)) continue
            val pkg = sbn.packageName ?: continue
            counts[pkg] = (counts[pkg] ?: 0) + 1
            val extras = sbn.notification.extras
            val title = extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: pkg
            val text = extras?.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
            summaries.add(NotifSummary(sbn.key, pkg, title, text, sbn.postTime))
            fp = 31 * fp + pkg.hashCode() + title.hashCode()
        }

        if (fp == lastFingerprint) return
        lastFingerprint = fp
        badgeCounts = counts
        activeSummaries = summaries.sortedByDescending { it.postTime }

        TouchGuard.runWhenIdle {
            val copy = synchronized(listeners) { listeners.toList() }
            copy.forEach { it() }
        }
    }
}
