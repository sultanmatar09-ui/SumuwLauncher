package com.sumuw.launcher.data

import android.content.Context
import com.sumuw.launcher.core.GlassEngine
import org.json.JSONArray
import org.json.JSONObject

object TouchGuard {
    @Volatile
    var isFingerDown: Boolean = false
        private set

    private val pendingActions = mutableListOf<() -> Unit>()

    fun onFingerDown() {
        isFingerDown = true
    }

    fun onFingerUp() {
        isFingerDown = false
        val toRun = synchronized(pendingActions) {
            val copy = pendingActions.toList()
            pendingActions.clear()
            copy
        }
        toRun.forEach { GlassEngine.mainHandler.post(it) }
    }

    fun runWhenIdle(action: () -> Unit) {
        if (!isFingerDown) {
            GlassEngine.mainHandler.post(action)
        } else {
            synchronized(pendingActions) {
                pendingActions.add(action)
            }
        }
    }
}

enum class CardType(val titleAr: String) {
    PRAYER("مواقيت الصلاة"),
    WEATHER("الطقس والغبار"),
    NEWS("الأخبار العاجلة"),
    MATCHES("المباريات والقنوات"),
    CALENDAR("المواعيد القادمة"),
    BATTERY("البطارية والأداء"),
    WIDGET("ويدجت النظام")
}

object LauncherPrefs {
    private const val PREF = "sumuw_native_prefs"
    private const val KEY_HIDDEN_CARDS = "hidden_cards"
    private const val KEY_SHOW_SEARCH = "show_search_bar"
    private const val KEY_SHOW_CAPSULES = "show_sumuw_capsules"
    private const val KEY_SELECTED_WALLPAPER = "selected_wallpaper_id"
    private const val KEY_WALLPAPER_DIM = "wallpaper_dim_alpha"
    private const val KEY_USAGE_JSON = "usage_stats_json"
    private const val KEY_DOCK_APPS_JSON = "custom_dock_apps_json"
    private const val KEY_TASBIH = "tasbih_count"
    private const val KEY_KHATMA_PAGE = "khatma_page"
    private const val KEY_HARAM_MODE = "haram_mode_enabled"
    private const val KEY_HARAM_ACTIVE = "haram_currently_inside"
    private const val KEY_SAVED_DND = "saved_dnd_filter"
    private const val KEY_KIDS_MODE = "kids_mode_enabled"
    private const val KEY_PARKING_LAT = "parking_lat"
    private const val KEY_PARKING_LON = "parking_lon"
    private const val KEY_PARKING_NOTE = "parking_note"
    private const val KEY_PARKING_TIME = "parking_time"

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun isSearchBarVisible(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SHOW_SEARCH, true)
    fun setSearchBarVisible(ctx: Context, visible: Boolean) {
        prefs(ctx).edit().putBoolean(KEY_SHOW_SEARCH, visible).apply()
    }

    fun areCapsulesVisible(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SHOW_CAPSULES, true)
    fun setCapsulesVisible(ctx: Context, visible: Boolean) {
        prefs(ctx).edit().putBoolean(KEY_SHOW_CAPSULES, visible).apply()
    }

    fun getSelectedWallpaper(ctx: Context): String =
        prefs(ctx).getString(KEY_SELECTED_WALLPAPER, "amoled_gold") ?: "amoled_gold"

    fun setSelectedWallpaper(ctx: Context, id: String) {
        prefs(ctx).edit().putString(KEY_SELECTED_WALLPAPER, id).apply()
    }

    fun getWallpaperDim(ctx: Context): Float = prefs(ctx).getFloat(KEY_WALLPAPER_DIM, 0.18f)
    fun setWallpaperDim(ctx: Context, dim: Float) {
        prefs(ctx).edit().putFloat(KEY_WALLPAPER_DIM, dim.coerceIn(0f, 0.75f)).apply()
    }

    fun getDockApps(ctx: Context): List<String>? {
        val raw = prefs(ctx).getString(KEY_DOCK_APPS_JSON, null) ?: return null
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getString(it) }
        }.getOrNull()
    }

    fun setDockApps(ctx: Context, packages: List<String>) {
        val arr = JSONArray()
        packages.distinct().take(9).forEach { arr.put(it) }
        prefs(ctx).edit().putString(KEY_DOCK_APPS_JSON, arr.toString()).apply()
    }

    fun addAppToDock(ctx: Context, packageName: String, fallbackDefault: List<String>): List<String> {
        val current = (getDockApps(ctx) ?: fallbackDefault).toMutableList()
        if (!current.contains(packageName)) {
            if (current.size >= 9) current.removeAt(current.lastIndex)
            current.add(0, packageName)
        }
        setDockApps(ctx, current)
        return current
    }

    fun removeAppFromDock(ctx: Context, packageName: String, fallbackDefault: List<String>): List<String> {
        val current = (getDockApps(ctx) ?: fallbackDefault).toMutableList()
        current.remove(packageName)
        setDockApps(ctx, current)
        return current
    }

    fun getHiddenCards(ctx: Context): Set<String> =
        prefs(ctx).getStringSet(KEY_HIDDEN_CARDS, emptySet())?.toSet() ?: emptySet()

    fun hideCard(ctx: Context, type: CardType) {
        val current = getHiddenCards(ctx).toMutableSet()
        current.add(type.name)
        prefs(ctx).edit().putStringSet(KEY_HIDDEN_CARDS, current).apply()
    }

    fun restoreAllCards(ctx: Context) {
        prefs(ctx).edit()
            .putStringSet(KEY_HIDDEN_CARDS, emptySet())
            .putBoolean(KEY_SHOW_SEARCH, true)
            .putBoolean(KEY_SHOW_CAPSULES, true)
            .apply()
    }

    fun getVisibleCards(ctx: Context): List<CardType> {
        val hidden = getHiddenCards(ctx)
        return CardType.entries.filter { it.name !in hidden }
    }

    fun recordAppLaunchAsync(ctx: Context, packageName: String) {
        val appCtx = ctx.applicationContext
        GlassEngine.bgExecutor.execute {
            val p = prefs(appCtx)
            val raw = p.getString(KEY_USAGE_JSON, "{}") ?: "{}"
            val json = runCatching { JSONObject(raw) }.getOrDefault(JSONObject())
            val count = json.optInt(packageName, 0) + 1
            json.put(packageName, count)
            p.edit().putString(KEY_USAGE_JSON, json.toString()).apply()
        }
    }

    fun getUsageCounts(ctx: Context): Map<String, Int> {
        val raw = prefs(ctx).getString(KEY_USAGE_JSON, "{}") ?: "{}"
        val json = runCatching { JSONObject(raw) }.getOrDefault(JSONObject())
        val map = HashMap<String, Int>()
        val keys = json.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            map[k] = json.optInt(k, 0)
        }
        return map
    }

    fun getTasbih(ctx: Context): Int = prefs(ctx).getInt(KEY_TASBIH, 0)
    fun setTasbih(ctx: Context, v: Int) = prefs(ctx).edit().putInt(KEY_TASBIH, v).apply()

    fun getKhatmaPage(ctx: Context): Int = prefs(ctx).getInt(KEY_KHATMA_PAGE, 1)
    fun setKhatmaPage(ctx: Context, page: Int) = prefs(ctx).edit().putInt(KEY_KHATMA_PAGE, page.coerceIn(1, 604)).apply()

    fun isHaramModeEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_HARAM_MODE, true)
    fun setHaramModeEnabled(ctx: Context, enabled: Boolean) = prefs(ctx).edit().putBoolean(KEY_HARAM_MODE, enabled).apply()

    fun isHaramInside(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_HARAM_ACTIVE, false)
    fun setHaramInside(ctx: Context, inside: Boolean) = prefs(ctx).edit().putBoolean(KEY_HARAM_ACTIVE, inside).apply()

    fun getSavedDndFilter(ctx: Context): Int = prefs(ctx).getInt(KEY_SAVED_DND, -1)
    fun setSavedDndFilter(ctx: Context, filter: Int) = prefs(ctx).edit().putInt(KEY_SAVED_DND, filter).apply()

    fun isKidsMode(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_KIDS_MODE, false)
    fun setKidsMode(ctx: Context, enabled: Boolean) = prefs(ctx).edit().putBoolean(KEY_KIDS_MODE, enabled).apply()

    fun saveParking(ctx: Context, lat: Double, lon: Double, note: String) {
        prefs(ctx).edit()
            .putString(KEY_PARKING_LAT, lat.toString())
            .putString(KEY_PARKING_LON, lon.toString())
            .putString(KEY_PARKING_NOTE, note)
            .putLong(KEY_PARKING_TIME, System.currentTimeMillis())
            .apply()
    }

    fun getParking(ctx: Context): Triple<Double?, Double?, String> {
        val p = prefs(ctx)
        val lat = p.getString(KEY_PARKING_LAT, null)?.toDoubleOrNull()
        val lon = p.getString(KEY_PARKING_LON, null)?.toDoubleOrNull()
        val note = p.getString(KEY_PARKING_NOTE, "") ?: ""
        return Triple(lat, lon, note)
    }

    fun exportFullBackupJson(ctx: Context): String {
        val p = prefs(ctx)
        val root = JSONObject()
        root.put("version", 3)
        root.put("exportedAt", System.currentTimeMillis())
        root.put("showSearchBar", isSearchBarVisible(ctx))
        root.put("showCapsules", areCapsulesVisible(ctx))
        root.put("selectedWallpaper", getSelectedWallpaper(ctx))
        root.put("wallpaperDim", getWallpaperDim(ctx).toDouble())
        root.put("dockApps", JSONArray(getDockApps(ctx) ?: emptyList<String>()))
        root.put("hiddenCards", JSONArray(getHiddenCards(ctx).toList()))
        root.put("usageStats", runCatching { JSONObject(p.getString(KEY_USAGE_JSON, "{}") ?: "{}") }.getOrDefault(JSONObject()))
        root.put("tasbih", getTasbih(ctx))
        root.put("khatmaPage", getKhatmaPage(ctx))
        root.put("haramModeEnabled", isHaramModeEnabled(ctx))
        root.put("parkingNote", p.getString(KEY_PARKING_NOTE, "") ?: "")
        root.put("parkingLat", p.getString(KEY_PARKING_LAT, "") ?: "")
        root.put("parkingLon", p.getString(KEY_PARKING_LON, "") ?: "")
        return root.toString(2)
    }

    fun importFullBackupJson(ctx: Context, raw: String): Boolean {
        return try {
            val root = JSONObject(raw)
            val edit = prefs(ctx).edit()
            if (root.has("showSearchBar")) edit.putBoolean(KEY_SHOW_SEARCH, root.getBoolean("showSearchBar"))
            if (root.has("showCapsules")) edit.putBoolean(KEY_SHOW_CAPSULES, root.getBoolean("showCapsules"))
            if (root.has("selectedWallpaper")) edit.putString(KEY_SELECTED_WALLPAPER, root.getString("selectedWallpaper"))
            if (root.has("wallpaperDim")) edit.putFloat(KEY_WALLPAPER_DIM, root.getDouble("wallpaperDim").toFloat())
            if (root.has("dockApps")) edit.putString(KEY_DOCK_APPS_JSON, root.getJSONArray("dockApps").toString())
            if (root.has("hiddenCards")) {
                val arr = root.getJSONArray("hiddenCards")
                val set = HashSet<String>()
                for (i in 0 until arr.length()) set.add(arr.getString(i))
                edit.putStringSet(KEY_HIDDEN_CARDS, set)
            }
            if (root.has("usageStats")) edit.putString(KEY_USAGE_JSON, root.getJSONObject("usageStats").toString())
            if (root.has("tasbih")) edit.putInt(KEY_TASBIH, root.getInt("tasbih"))
            if (root.has("khatmaPage")) edit.putInt(KEY_KHATMA_PAGE, root.getInt("khatmaPage"))
            if (root.has("haramModeEnabled")) edit.putBoolean(KEY_HARAM_MODE, root.getBoolean("haramModeEnabled"))
            if (root.has("parkingNote")) edit.putString(KEY_PARKING_NOTE, root.getString("parkingNote"))
            if (root.has("parkingLat")) edit.putString(KEY_PARKING_LAT, root.getString("parkingLat"))
            if (root.has("parkingLon")) edit.putString(KEY_PARKING_LON, root.getString("parkingLon"))
            edit.apply()
            true
        } catch (_: Throwable) {
            false
        }
    }
}
