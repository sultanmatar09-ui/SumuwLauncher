package com.sumuw.launcher.ui

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.*
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.view.View
import android.widget.LinearLayout

/**
 * Segmented Circular Battery & Wi-Fi Dock Indicator:
 * Matches the clean single-ring layout:
 * - Battery % number centered at the top gap of the ring
 * - Segmented arc around the perimeter
 * - Wi-Fi signal arcs centered inside the ring
 */
class DuoBatteryDockView(context: Context) : View(context) {

    var phonePercent: Int = 100
        private set
    var isCharging: Boolean = false
        private set
    var isWifiConnected: Boolean = true
        private set

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = 0x33FFFFFF
    }
    private val activePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.WHITE
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }
    private val wifiPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.WHITE
    }
    private val rect = RectF()
    private val wifiRect = RectF()

    init {
        val d = resources.displayMetrics.density
        layoutParams = LinearLayout.LayoutParams((48 * d).toInt(), (48 * d).toInt())
        refreshBatteryState()
    }

    fun refreshBatteryState() {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (intent != null) {
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            if (level >= 0) phonePercent = (level * 100) / scale
            isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
        }
        isWifiConnected = checkWifiConnected()
        invalidate()
    }

    private fun checkWifiConnected(): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                ?: return true
            val net = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(net) ?: return false
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
        } catch (_: Throwable) {
            true
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = resources.displayMetrics.density
        val cx = width / 2f
        val cy = height / 2f + 1.5f * d
        val r = 19f * d

        trackPaint.strokeWidth = 2.6f * d
        activePaint.strokeWidth = 2.6f * d
        activePaint.color = when {
            isCharging -> 0xFF4ADE80.toInt()
            phonePercent <= 20 -> 0xFFEF4444.toInt()
            else -> Color.WHITE
        }

        // Top number (e.g. "73")
        textPaint.textSize = 10f * d
        val label = if (isCharging) "⚡$phonePercent" else "$phonePercent"
        canvas.drawText(label, cx, cy - r + 4.5f * d, textPaint)

        // Draw segmented arc (260° sweep leaving top gap for number, plus bottom dots)
        rect.set(cx - r, cy - r, cx + r, cy + r)
        val startAngle = -52f
        val totalSweep = 284f
        val activeSweep = (phonePercent / 100f) * totalSweep

        canvas.drawArc(rect, startAngle, totalSweep, false, trackPaint)
        canvas.drawArc(rect, startAngle, activeSweep, false, activePaint)

        // Center Wi-Fi Icon
        wifiPaint.strokeWidth = 1.9f * d
        wifiPaint.alpha = if (isWifiConnected) 245 else 90
        val wy = cy + 6f * d
        canvas.drawCircle(cx, wy, 1.8f * d, dotPaint.apply { alpha = wifiPaint.alpha })
        for (i in 1..3) {
            val wr = i * 4.2f * d
            wifiRect.set(cx - wr, wy - wr, cx + wr, wy + wr)
            canvas.drawArc(wifiRect, -135f, 90f, false, wifiPaint)
        }
    }
}
