package com.sumuw.launcher.search

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract
import com.sumuw.launcher.ui.AppInfo
import java.text.DecimalFormat
import kotlin.math.pow

/**
 * Instant Local SmartSearch:
 * - Arabic normalization (أ/إ/آ -> ا, ة -> ه, ى -> ي, strips tashkeel).
 * - Math expression evaluator.
 * - Unit & currency converter.
 * - Zakat calculator.
 * - Apps & Contacts search.
 */
object SmartSearchEngine {

    sealed class SearchResult {
        data class UtilityCard(val title: String, val value: String, val subtitle: String) : SearchResult()
        data class AppResult(val app: AppInfo) : SearchResult()
        data class ContactResult(val name: String, val phone: String) : SearchResult()
    }

    private val tashkeelRegex = Regex("[\u064B-\u065F\u0670]")

    fun normalizeArabic(input: String): String {
        return input
            .replace(tashkeelRegex, "")
            .replace('أ', 'ا')
            .replace('إ', 'ا')
            .replace('آ', 'ا')
            .replace('ة', 'ه')
            .replace('ى', 'ي')
            .lowercase()
            .trim()
    }

    fun search(ctx: Context, queryRaw: String, apps: List<AppInfo>): List<SearchResult> {
        val q = queryRaw.trim()
        if (q.isEmpty()) return emptyList()
        val results = ArrayList<SearchResult>()

        // 1. Zakat Calculator (e.g. "زكاة 100000" or "zakat 50000")
        val norm = normalizeArabic(q)
        if (norm.startsWith("زكاه ") || norm.startsWith("zakat ")) {
            val num = q.substringAfter(" ").trim().toDoubleOrNull()
            if (num != null && num > 0) {
                val zakat = num * 0.025
                val df = DecimalFormat("#,##0.##")
                results.add(
                    SearchResult.UtilityCard(
                        "حاسبة الزكاة (2.5%)",
                        "${df.format(zakat)} ريال",
                        "من أصل ${df.format(num)} (بشرط بلوغ النصاب وحولان الحول)"
                    )
                )
            }
        }

        // 2. Unit Converter (e.g. "100 km to mi", "50 usd to sar", "30 c to f")
        tryUnitConvert(norm)?.let { results.add(it) }

        // 3. Math Evaluator
        if (q.any { it in "+-*/^%" } || q.all { it.isDigit() || it in "+-*/().^% " }) {
            evalMath(q)?.let { valRes ->
                val df = DecimalFormat("#,##0.####")
                results.add(SearchResult.UtilityCard("الحاسبة الفورية", df.format(valRes), q))
            }
        }

        // 4. Apps Search (normalized)
        for (app in apps) {
            if (normalizeArabic(app.label).contains(norm) || app.packageName.lowercase().contains(norm)) {
                results.add(SearchResult.AppResult(app))
                if (results.size >= 16) break
            }
        }

        // 5. Contacts Search (if permission granted)
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            runCatching {
                val cursor = ctx.contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    arrayOf(
                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                        ContactsContract.CommonDataKinds.Phone.NUMBER
                    ),
                    null, null, null
                )
                cursor?.use {
                    var added = 0
                    while (it.moveToNext() && added < 5) {
                        val name = it.getString(0) ?: continue
                        val phone = it.getString(1) ?: continue
                        if (normalizeArabic(name).contains(norm) || phone.contains(q)) {
                            results.add(SearchResult.ContactResult(name, phone))
                            added++
                        }
                    }
                }
            }
        }

        return results
    }

    private fun tryUnitConvert(norm: String): SearchResult.UtilityCard? {
        val parts = norm.split(Regex("\\s+"))
        if (parts.size < 3) return null
        val v = parts[0].toDoubleOrNull() ?: return null
        val from = parts[1]
        val to = if (parts.size >= 4 && (parts[2] == "to" || parts[2] == "الي" || parts[2] == "في")) parts[3] else parts[2]
        val df = DecimalFormat("#,##0.##")
        return when {
            from in listOf("km", "كم") && to in listOf("mi", "ميل") ->
                SearchResult.UtilityCard("تحويل المسافة", "${df.format(v * 0.621371)} ميل", "$v كم")
            from in listOf("mi", "ميل") && to in listOf("km", "كم") ->
                SearchResult.UtilityCard("تحويل المسافة", "${df.format(v * 1.60934)} كم", "$v ميل")
            from in listOf("kg", "كجم") && to in listOf("lb", "رطل") ->
                SearchResult.UtilityCard("تحويل الوزن", "${df.format(v * 2.20462)} رطل", "$v كجم")
            from in listOf("usd", "دولار") && to in listOf("sar", "ريال") ->
                SearchResult.UtilityCard("تحويل العملة", "${df.format(v * 3.75)} ريال", "$v دولار")
            from in listOf("sar", "ريال") && to in listOf("usd", "دولار") ->
                SearchResult.UtilityCard("تحويل العملة", "${df.format(v / 3.75)} دولار", "$v ريال")
            from == "c" && to == "f" ->
                SearchResult.UtilityCard("تحويل الحرارة", "${df.format(v * 9.0 / 5.0 + 32.0)} °F", "$v °C")
            else -> null
        }
    }

    private fun evalMath(expr: String): Double? {
        return try {
            object {
                var pos = -1
                var ch = 0
                fun nextChar() { ch = if (++pos < expr.length) expr[pos].code else -1 }
                fun eat(charToEat: Int): Boolean {
                    while (ch == ' '.code) nextChar()
                    if (ch == charToEat) { nextChar(); return true }
                    return false
                }
                fun parse(): Double {
                    nextChar()
                    val x = parseExpression()
                    if (pos < expr.length) throw RuntimeException("Unexpected")
                    return x
                }
                fun parseExpression(): Double {
                    var x = parseTerm()
                    while (true) {
                        when {
                            eat('+'.code) -> x += parseTerm()
                            eat('-'.code) -> x -= parseTerm()
                            else -> return x
                        }
                    }
                }
                fun parseTerm(): Double {
                    var x = parseFactor()
                    while (true) {
                        when {
                            eat('*'.code) -> x *= parseFactor()
                            eat('/'.code) -> x /= parseFactor()
                            eat('%'.code) -> x %= parseFactor()
                            else -> return x
                        }
                    }
                }
                fun parseFactor(): Double {
                    if (eat('+'.code)) return parseFactor()
                    if (eat('-'.code)) return -parseFactor()
                    var x: Double
                    val startPos = pos
                    if (eat('('.code)) {
                        x = parseExpression()
                        if (!eat(')'.code)) throw RuntimeException("Missing )")
                    } else if ((ch in '0'.code..'9'.code) || ch == '.'.code) {
                        while ((ch in '0'.code..'9'.code) || ch == '.'.code) nextChar()
                        x = expr.substring(startPos, pos).toDouble()
                    } else {
                        throw RuntimeException("Unexpected")
                    }
                    if (eat('^'.code)) x = x.pow(parseFactor())
                    return x
                }
            }.parse()
        } catch (_: Throwable) {
            null
        }
    }
}
