package com.sumuw.launcher.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.RectF
import android.util.AttributeSet
import android.widget.FrameLayout
import com.sumuw.launcher.core.GlassEngine

/**
 * Native Glassmorphic Container View.
 * Uses GlassEngine's shared BitmapShader + adaptive frost tint + Specular Rim Gradient.
 */
class GlassCardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    private val rect = RectF()
    private val loc = IntArray(2)
    var cornerRadiusDp: Float = 22f

    init {
        setWillNotDraw(false)
    }

    override fun onDraw(canvas: Canvas) {
        val density = resources.displayMetrics.density
        val dm = resources.displayMetrics
        getLocationOnScreen(loc)
        rect.set(0f, 0f, width.toFloat(), height.toFloat())
        GlassEngine.drawGlassCard(
            canvas = canvas,
            rect = rect,
            cornerRadius = cornerRadiusDp * density,
            screenOffsetX = loc[0].toFloat(),
            screenOffsetY = loc[1].toFloat(),
            screenW = dm.widthPixels,
            screenH = dm.heightPixels,
            density = density
        )
        super.onDraw(canvas)
    }
}
