package com.sumuw.launcher.data

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import com.sumuw.launcher.core.GlassEngine
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

data class NewsItem(
    val title: String,
    val source: String,
    val link: String
)

data class MatchItem(
    val leagueKey: String,
    val leagueAr: String,
    val homeName: String,
    val awayName: String,
    val homeLogoUrl: String,
    val awayLogoUrl: String,
    val scoreOrTime: String,
    val statusText: String,
    val channel: String,
    val isLive: Boolean
)

object LiveDataFeeds {

    private val logoCache = LruCache<String, Bitmap>(64)

    private val ARABIC_CLUB_NAMES = mapOf(
        "Al Hilal" to "الهلال",
        "Al-Hilal" to "الهلال",
        "Al Nassr" to "النصر",
        "Al-Nassr" to "النصر",
        "Al Ittihad" to "الاتحاد",
        "Al-Ittihad" to "الاتحاد",
        "Al Ahli" to "الأهلي",
        "Al-Ahli" to "الأهلي",
        "Al Shabab" to "الشباب",
        "Al-Shabab" to "الشباب",
        "Al Ettifaq" to "الاتفاق",
        "Al Qadsiah" to "القادسية",
        "Al Taawoun" to "التعاون",
        "Chelsea" to "تشيلسي",
        "Arsenal" to "أرسنال",
        "Liverpool" to "ليفربول",
        "Manchester City" to "مانشستر سيتي",
        "Manchester United" to "مانشستر يونايتد",
        "Tottenham Hotspur" to "توتنهام",
        "Newcastle United" to "نيوكاسل",
        "Aston Villa" to "أستون فيلا",
        "Real Madrid" to "ريال مدريد",
        "Barcelona" to "برشلونة",
        "Bayern Munich" to "بايرن ميونخ",
        "Paris Saint-Germain" to "باريس سان جيرمان",
        "Inter Milan" to "إنتر ميلان",
        "AC Milan" to "ميلان",
        "Juventus" to "يوفنتوس",
        "Atletico Madrid" to "أتلتيكو مدريد"
    )

    private fun translateClub(name: String): String {
        for ((en, ar) in ARABIC_CLUB_NAMES) {
            if (name.contains(en, ignoreCase = true)) return ar
        }
        return name
    }

    fun fetchBreakingNewsAsync(onResult: (List<NewsItem>) -> Unit) {
        GlassEngine.bgExecutor.execute {
            val all = ArrayList<NewsItem>()
            val feeds = listOf(
                "الجزيرة" to "https://www.aljazeera.net/aljazeerarss/a7c186be-1baa-4bd4-9d80-a84db769f6ef/73d0e1b4-532f-45ef-b135-bfdff8b8cab9",
                "BBC عربي" to "https://feeds.bbci.co.uk/arabic/rss.xml",
                "العربية" to "https://www.alarabiya.net/feed/rss2/ar.xml"
            )
            for ((sourceName, feedUrl) in feeds) {
                try {
                    val xml = httpGet(feedUrl)
                    if (xml.isNotBlank()) {
                        all.addAll(parseRss(xml, sourceName).take(5))
                    }
                } catch (_: Throwable) {
                }
            }
            val finalList = if (all.isNotEmpty()) all else listOf(
                NewsItem("تعذر الاتصال بمصادر الأخبار حالياً — اضغط للتحديث", "سُمو", "")
            )
            GlassEngine.mainHandler.post { onResult(finalList) }
        }
    }

    private fun parseRss(xml: String, source: String): List<NewsItem> {
        val list = ArrayList<NewsItem>()
        val factory = XmlPullParserFactory.newInstance()
        val parser = factory.newPullParser()
        parser.setInput(StringReader(xml))
        var insideItem = false
        var title = ""
        var link = ""
        var tag = ""
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    tag = parser.name ?: ""
                    if (tag.equals("item", ignoreCase = true)) {
                        insideItem = true
                        title = ""
                        link = ""
                    }
                }
                XmlPullParser.TEXT -> {
                    if (insideItem) {
                        when {
                            tag.equals("title", ignoreCase = true) -> title += parser.text
                            tag.equals("link", ignoreCase = true) -> link += parser.text
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    if ((parser.name ?: "").equals("item", ignoreCase = true) && insideItem) {
                        val cleanTitle = title.trim().replace(Regex("\\s+"), " ")
                        if (cleanTitle.isNotBlank()) {
                            list.add(NewsItem(cleanTitle, source, link.trim()))
                        }
                        insideItem = false
                    }
                    tag = ""
                }
            }
            event = parser.next()
        }
        return list
    }

    fun fetchAllLeaguesMatchesAsync(onResult: (List<MatchItem>) -> Unit) {
        GlassEngine.bgExecutor.execute {
            val leagues = listOf(
                Triple("ksa.1", "دوري روشن", "SSC / الثمانية"),
                Triple("eng.1", "الدوري الإنجليزي", "beIN Sports"),
                Triple("uefa.champions", "أبطال أوروبا", "beIN Sports")
            )
            val allMatches = ArrayList<MatchItem>()
            for ((slug, leagueAr, defaultChannel) in leagues) {
                try {
                    val url = "https://site.api.espn.com/apis/site/v2/sports/soccer/$slug/scoreboard"
                    val raw = httpGet(url)
                    if (raw.isNotBlank()) {
                        allMatches.addAll(parseEspnScoreboard(raw, slug, leagueAr, defaultChannel))
                    }
                } catch (_: Throwable) {
                }
            }
            GlassEngine.mainHandler.post { onResult(allMatches) }
        }
    }

    private fun parseEspnScoreboard(
        raw: String,
        slug: String,
        leagueAr: String,
        defaultChannel: String
    ): List<MatchItem> {
        val list = ArrayList<MatchItem>()
        val root = JSONObject(raw)
        val events = root.optJSONArray("events") ?: return list
        val isoFmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        val isoFmtSec = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        val localTimeFmt = SimpleDateFormat("hh:mm a", Locale("ar"))

        for (i in 0 until events.length().coerceAtMost(8)) {
            val ev = events.getJSONObject(i)
            val dateStr = ev.optString("date", "")
            val comps = ev.optJSONArray("competitions") ?: continue
            if (comps.length() == 0) continue
            val comp = comps.getJSONObject(0)
            val competitors = comp.optJSONArray("competitors") ?: continue
            if (competitors.length() < 2) continue

            var homeObj = competitors.getJSONObject(0)
            var awayObj = competitors.getJSONObject(1)
            if (homeObj.optString("homeAway") == "away") {
                val tmp = homeObj
                homeObj = awayObj
                awayObj = tmp
            }

            val homeTeam = homeObj.optJSONObject("team") ?: JSONObject()
            val awayTeam = awayObj.optJSONObject("team") ?: JSONObject()
            val homeName = translateClub(homeTeam.optString("shortDisplayName", homeTeam.optString("displayName", "فريق 1")))
            val awayName = translateClub(awayTeam.optString("shortDisplayName", awayTeam.optString("displayName", "فريق 2")))
            val homeLogo = homeTeam.optString("logo", "")
            val awayLogo = awayTeam.optString("logo", "")

            val statusObj = comp.optJSONObject("status") ?: ev.optJSONObject("status")
            val typeObj = statusObj?.optJSONObject("type")
            val state = typeObj?.optString("state", "pre") ?: "pre"
            val clock = statusObj?.optString("displayClock", "") ?: ""

            val homeScore = homeObj.optString("score", "0")
            val awayScore = awayObj.optString("score", "0")

            val parsedDate = runCatching { isoFmt.parse(dateStr) }.getOrNull()
                ?: runCatching { isoFmtSec.parse(dateStr) }.getOrNull()
            val kickoffStr = if (parsedDate != null) localTimeFmt.format(parsedDate) else "--:--"

            val (scoreOrTime, statusText, isLive) = when (state) {
                "in" -> Triple("$homeScore - $awayScore", "مباشر $clock", true)
                "post" -> Triple("$homeScore - $awayScore", "انتهت", false)
                else -> Triple(kickoffStr, "قادمة", false)
            }

            var channel = defaultChannel
            val geoBroadcasts = comp.optJSONArray("geoBroadcasts")
            if (geoBroadcasts != null && geoBroadcasts.length() > 0) {
                val media = geoBroadcasts.getJSONObject(0).optJSONObject("media")
                val ch = media?.optString("shortName", "") ?: ""
                if (ch.isNotBlank() && slug == "eng.1") {
                    channel = "$defaultChannel ($ch)"
                }
            }

            list.add(
                MatchItem(
                    leagueKey = slug,
                    leagueAr = leagueAr,
                    homeName = homeName,
                    awayName = awayName,
                    homeLogoUrl = homeLogo,
                    awayLogoUrl = awayLogo,
                    scoreOrTime = scoreOrTime,
                    statusText = statusText,
                    channel = channel,
                    isLive = isLive
                )
            )
        }
        return list
    }

    fun loadLogoAsync(url: String, onLoaded: (Bitmap?) -> Unit) {
        if (url.isBlank()) {
            onLoaded(null)
            return
        }
        logoCache.get(url)?.let {
            onLoaded(it)
            return
        }
        GlassEngine.bgExecutor.execute {
            val bmp = try {
                val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 5000
                    readTimeout = 5000
                    setRequestProperty("User-Agent", "SumuwLauncher/2.1")
                }
                conn.inputStream.use { BitmapFactory.decodeStream(it) }
            } catch (_: Throwable) {
                null
            }
            if (bmp != null) logoCache.put(url, bmp)
            GlassEngine.mainHandler.post { onLoaded(bmp) }
        }
    }

    private fun httpGet(urlStr: String): String {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            connectTimeout = 7000
            readTimeout = 7000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "SumuwLauncher/2.1 (Android)")
        }
        return conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
    }
}
