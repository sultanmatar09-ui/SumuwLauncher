package com.sumuw.launcher.wallpaper

import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import java.util.Calendar
import kotlin.math.sin
import kotlin.random.Random

/**
 * Interactive Live Wallpaper Service:
 * - Sky gradient adapts smoothly to Prayer / Time-of-Day phases (Fajr, Dhuhr, Asr, Maghrib, Night).
 * - Weather particles: Rain, Storm/Lightning, Clouds, Dust, Night Stars.
 * - Page-swipe Parallax via onOffsetsChanged.
 * - Zero drawing when invisible or screen off to preserve battery.
 */
class SumuwWallpaperService : WallpaperService() {

    enum class WeatherEffect { CLEAR, RAIN, STORM, CLOUDY, DUST }

    companion object {
        private const val PREF_NAME = "sumuw_wallpaper_prefs"
        private const val KEY_WEATHER = "weather_effect"

        fun setWeatherEffect(context: Context, effect: WeatherEffect) {
            context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .edit().putString(KEY_WEATHER, effect.name).apply()
        }

        fun getWeatherEffect(context: Context): WeatherEffect {
            val name = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .getString(KEY_WEATHER, WeatherEffect.CLEAR.name)
            return runCatching { WeatherEffect.valueOf(name ?: "CLEAR") }.getOrDefault(WeatherEffect.CLEAR)
        }
    }

    private data class Particle(var x: Float, var y: Float, var speed: Float, var size: Float, var alpha: Int)

    override fun onCreateEngine(): Engine = SumuwEngine()

    inner class SumuwEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private var visible = false
        private var xOffset = 0.5f
        private var width = 0
        private var height = 0

        private val skyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val dunePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val lightningPaint = Paint()

        private val particles = ArrayList<Particle>(65)
        private var lightningAlpha = 0
        private var tick = 0f

        private val drawRunnable = object : Runnable {
            override fun run() {
                if (!visible) return
                drawFrame()
                handler.postDelayed(this, 16L) // ~60-120fps paced
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            this.width = width
            this.height = height
            initParticles()
            if (visible) drawFrame()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            this.visible = visible
            handler.removeCallbacks(drawRunnable)
            if (visible) {
                handler.post(drawRunnable)
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(drawRunnable)
            super.onSurfaceDestroyed(holder)
        }

        override fun onOffsetsChanged(
            xOffset: Float, yOffset: Float,
            xOffsetStep: Float, yOffsetStep: Float,
            xPixelOffset: Int, yPixelOffset: Int
        ) {
            this.xOffset = xOffset
        }

        private fun initParticles() {
            particles.clear()
            if (width <= 0 || height <= 0) return
            for (i in 0 until 60) {
                particles.add(
                    Particle(
                        x = Random.nextFloat() * width,
                        y = Random.nextFloat() * height,
                        speed = 2f + Random.nextFloat() * 10f,
                        size = 1.5f + Random.nextFloat() * 3.5f,
                        alpha = 60 + Random.nextInt(160)
                    )
                )
            }
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas() ?: return
                if (width == 0 || height == 0) {
                    width = canvas.width
                    height = canvas.height
                    initParticles()
                }
                tick += 0.04f
                val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                val weather = getWeatherEffect(applicationContext)

                // 1. Sky Gradient by Prayer / Time of day
                val skyColors = when (hour) {
                    in 4..6 -> intArrayOf(0xFF141B33.toInt(), 0xFF473768.toInt(), 0xFFD98A6C.toInt()) // Fajr
                    in 7..14 -> intArrayOf(0xFF0E2944.toInt(), 0xFF1C4E78.toInt(), 0xFF4484B0.toInt()) // Dhuhr
                    in 15..16 -> intArrayOf(0xFF1B3352.toInt(), 0xFF496A88.toInt(), 0xFFC89D6C.toInt()) // Asr
                    in 17..19 -> intArrayOf(0xFF191636.toInt(), 0xFF6B2D52.toInt(), 0xFFDF795E.toInt()) // Maghrib
                    else -> intArrayOf(0xFF060913.toInt(), 0xFF0D1526.toInt(), 0xFF1A2538.toInt()) // Night
                }
                skyPaint.shader = LinearGradient(
                    0f, 0f, 0f, height.toFloat(),
                    skyColors, null, Shader.TileMode.CLAMP
                )
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), skyPaint)

                // 2. Parallax Dunes / Horizon Silhouette
                val parallax = (xOffset - 0.5f) * 90f
                val path = Path().apply {
                    moveTo(-120f + parallax, height * 0.82f)
                    quadTo(width * 0.3f + parallax, height * 0.76f, width * 0.65f + parallax, height * 0.83f)
                    quadTo(width * 0.9f + parallax, height * 0.87f, width + 120f + parallax, height * 0.80f)
                    lineTo(width + 120f, height.toFloat())
                    lineTo(-120f, height.toFloat())
                    close()
                }
                dunePaint.color = Color.argb(95, 10, 14, 24)
                canvas.drawPath(path, dunePaint)

                // 3. Weather / Night Stars Particles
                val isNight = hour < 5 || hour >= 19
                for (p in particles) {
                    when (weather) {
                        WeatherEffect.RAIN, WeatherEffect.STORM -> {
                            particlePaint.color = Color.argb(p.alpha, 195, 225, 255)
                            particlePaint.strokeWidth = 2.2f
                            canvas.drawLine(p.x + parallax * 0.4f, p.y, p.x + parallax * 0.4f - 6f, p.y + 28f, particlePaint)
                            p.y += p.speed * 2.8f
                            p.x -= 2.5f
                        }
                        WeatherEffect.DUST -> {
                            particlePaint.color = Color.argb(p.alpha / 2, 224, 188, 138)
                            canvas.drawCircle(p.x + parallax * 0.3f, p.y, p.size * 1.4f, particlePaint)
                            p.x += p.speed * 0.9f
                            p.y += sin((tick + p.x * 0.01f).toDouble()).toFloat() * 1.2f
                        }
                        WeatherEffect.CLOUDY -> {
                            particlePaint.color = Color.argb(28, 255, 255, 255)
                            canvas.drawCircle(p.x + parallax * 0.25f, p.y * 0.55f, p.size * 14f, particlePaint)
                            p.x += p.speed * 0.25f
                        }
                        WeatherEffect.CLEAR -> {
                            if (isNight) {
                                val twinkle = ((sin((tick * 1.5f + p.x).toDouble()) + 1.0) * 0.5 * p.alpha).toInt()
                                particlePaint.color = Color.argb(twinkle, 255, 250, 230)
                                canvas.drawCircle(p.x + parallax * 0.15f, p.y * 0.65f, p.size * 0.7f, particlePaint)
                            }
                        }
                    }
                    if (p.y > height) { p.y = -20f; p.x = Random.nextFloat() * width }
                    if (p.x > width + 60f) p.x = -40f
                    if (p.x < -60f) p.x = width + 40f
                }

                // 4. Lightning Flash in Storm
                if (weather == WeatherEffect.STORM) {
                    if (lightningAlpha <= 0 && Random.nextInt(140) == 0) {
                        lightningAlpha = 160
                    }
                    if (lightningAlpha > 0) {
                        lightningPaint.color = Color.argb(lightningAlpha, 230, 242, 255)
                        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), lightningPaint)
                        lightningAlpha = (lightningAlpha - 18).coerceAtLeast(0)
                    }
                }
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas)
                    } catch (_: Throwable) {
                    }
                }
            }
        }
    }
}
