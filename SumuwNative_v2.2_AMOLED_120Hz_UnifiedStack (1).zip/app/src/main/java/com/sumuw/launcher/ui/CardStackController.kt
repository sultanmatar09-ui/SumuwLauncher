package com.sumuw.launcher.ui

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.os.BatteryManager
import android.view.Gravity
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import com.sumuw.launcher.core.GlassEngine
import com.sumuw.launcher.data.CardType
import com.sumuw.launcher.data.LauncherPrefs
import java.time.chrono.HijrahDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoField
import java.util.Locale

/**
 * Swipeable CardStack with VelocityTracker proper recycling,
 * generous News card height (no 2nd-line clipping), and per-card hide/delete.
 */
class CardStackController(
    private val context: Context,
    private val onCardsChanged: () -> Unit
) {
    private val density = context.resources.displayMetrics.density

    fun buildCardStackView(): View {
        val visible = LauncherPrefs.getVisibleCards(context)
        val scroll = object : HorizontalScrollView(context) {
            private var velocityTracker: VelocityTracker? = null

            override fun onTouchEvent(ev: MotionEvent): Boolean {
                if (velocityTracker == null) velocityTracker = VelocityTracker.obtain()
                velocityTracker?.addMovement(ev)
                return try {
                    if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                        velocityTracker?.computeCurrentVelocity(1000)
                        velocityTracker?.recycle()
                        velocityTracker = null
                    }
                    super.onTouchEvent(ev)
                } catch (t: Throwable) {
                    velocityTracker?.recycle()
                    velocityTracker = null
                    false
                }
            }
        }.apply {
            isHorizontalScrollBarEnabled = false
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            val pad = (12 * density).toInt()
            setPadding(pad, (4 * density).toInt(), pad, (6 * density).toInt())
        }

        val cardW = (context.resources.displayMetrics.widthPixels * 0.84f).toInt()
        for (type in visible) {
            val card = buildSingleCard(type, cardW)
            row.addView(card)
        }
        scroll.addView(row)
        return scroll
    }

    private fun buildSingleCard(type: CardType, widthPx: Int): View {
        val card = GlassCardView(context).apply {
            // News card gets extra height so 2nd line never clips
            val minH = if (type == CardType.NEWS) (142 * density).toInt() else (118 * density).toInt()
            layoutParams = LinearLayout.LayoutParams(widthPx, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = (10 * density).toInt()
            }
            minimumHeight = minH
            val p = (14 * density).toInt()
            setPadding(p, p, p, p)
        }

        val textColor = if (GlassEngine.isLightWallpaper) 0xFF0F172A.toInt() else 0xFFF8FAFC.toInt()
        val subColor = if (GlassEngine.isLightWallpaper) 0xFF334155.toInt() else 0xFFCBD5E1.toInt()

        val col = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val titleTv = TextView(context).apply {
            text = type.titleAr
            textSize = 13.5f
            typeface = Typeface.create("serif", Typeface.BOLD)
            setTextColor(0xFFD4AF37.toInt())
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        val hideBtn = TextView(context).apply {
            text = "✕"
            textSize = 13f
            setTextColor(subColor)
            setPadding((8 * density).toInt(), 0, (4 * density).toInt(), 0)
            setOnClickListener {
                LauncherPrefs.hideCard(context, type)
                onCardsChanged()
            }
        }

        header.addView(titleTv)
        header.addView(hideBtn)
        col.addView(header)

        val bodyTv = TextView(context).apply {
            textSize = 13.5f
            setTextColor(textColor)
            setLineSpacing(4f * density, 1.15f)
            typeface = Typeface.create("serif", Typeface.NORMAL)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (6 * density).toInt() }
            text = buildCardBody(type)
        }

        col.addView(bodyTv)
        card.addView(col)
        return card
    }

    private fun buildCardBody(type: CardType): String {
        return when (type) {
            CardType.PRAYER -> {
                val h = HijrahDate.now()
                val months = arrayOf(
                    "محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة",
                    "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
                )
                val m = months[(h.get(ChronoField.MONTH_OF_YEAR) - 1).coerceIn(0, 11)]
                val hijriStr = "${h.get(ChronoField.DAY_OF_MONTH)} $m ${h.get(ChronoField.YEAR)} هـ"
                "$hijriStr\nالفجر 05:18  •  الظهر 12:12  •  العصر 15:24\nالمغرب 17:44  •  العشاء 19:14"
            }
            CardType.WEATHER -> "جدة: 29° م  •  سماء صافية\nجودة الهواء: جيدة (PM2.5 منخفض) • رطوبة 54%"
            CardType.NEWS -> "متابعة التحديثات التقنية والاقتصادية المحلية والعالمية أولاً بأول.\nاضغط لفتح موجز الأخبار الكامل دون قص للسطر الثاني."
            CardType.MATCHES -> "الهلال × الاتحاد — 20:30 م (SSC 1 HD)\nريال مدريد × برشلونة — 23:00 م (beIN Sports 1)"
            CardType.CALENDAR -> "لا توجد مواعيد متعارضة الآن\nاسحب لليمين لعرض بقية البطاقات أو أضف حدثاً جديداً"
            CardType.BATTERY -> {
                val bm = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val level = bm?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val temp = (bm?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
                "الشحن: $level%  •  حرارة البطارية: ${temp}°C\nوضع الأداء: 120Hz متكيف (صفر استهلاك في الخلفية)"
            }
            CardType.WIDGET -> "مساحة ويدجت النظام المخصصة\nيمكنك ربط أي ويدجت خارجي أو إخفاء البطاقة من زر ✕"
        }
    }
}
