package com.sumuw.launcher.core

import android.app.WallpaperManager
import android.content.Context
import android.graphics.*
import android.graphics.drawable.BitmapDrawable
import android.os.Handler
import android.os.Looper
import java.util.Calendar
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

/**
 * Shared Glassmorphism & Background Worker Engine.
 * - All heavy work (blurring wallpaper, app scanning, JSON I/O) runs on ExecutorService.
 * - Exposes a shared blurred BitmapShader + adaptive light/dark flag + Specular Rim Gradient.
 */
object GlassEngine {
    val bgExecutor: ExecutorService = Executors.newFixedThreadPool(2)
    val mainHandler: Handler = Handler(Looper.getMainLooper())

    @Volatile
    var blurredBitmap: Bitmap? = null
        private set

    @Volatile
    var sharedShader: BitmapShader? = null
        private set

    @Volatile
    var isLightWallpaper: Boolean = false
        private set

    private val listeners = mutableListOf<() -> Unit>()

    fun addListener(listener: () -> Unit) {
        synchronized(listeners) {
            if (!listeners.contains(listener)) listeners.add(listener)
        }
    }

    fun removeListener(listener: () -> Unit) {
        synchronized(listeners) { listeners.remove(listener) }
    }

    fun refreshBackdropAsync(context: Context, screenWidth: Int, screenHeight: Int) {
        val appCtx = context.applicationContext
        bgExecutor.execute {
            val raw = extractWallpaperOrFallback(appCtx, max(1, screenWidth / 8), max(1, screenHeight / 8))
            val blurred = fastStackBlur(raw, 14)
            val luma = computeAverageLuminance(blurred)
            val shader = BitmapShader(blurred, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            blurredBitmap = blurred
            sharedShader = shader
            isLightWallpaper = luma > 0.62f

            mainHandler.post {
                val copy = synchronized(listeners) { listeners.toList() }
                copy.forEach { it() }
            }
        }
    }

    private fun extractWallpaperOrFallback(context: Context, w: Int, h: Int): Bitmap {
        try {
            val wm = WallpaperManager.getInstance(context)
            val drawable = wm.peekDrawable()
            if (drawable is BitmapDrawable && drawable.bitmap != null) {
                return Bitmap.createScaledBitmap(drawable.bitmap, w, h, true)
            }
        } catch (_: SecurityException) {
            // Live wallpaper or restricted storage: use time-of-day matching backdrop
        } catch (_: Throwable) {
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val colors = when (hour) {
            in 4..6 -> intArrayOf(0xFF1A1F3C.toInt(), 0xFF4A3B69.toInt(), 0xFFD98A6C.toInt()) // Fajr
            in 7..14 -> intArrayOf(0xFF0F2942.toInt(), 0xFF1D4E7A.toInt(), 0xFF3A7CA5.toInt()) // Dhuhr
            in 15..16 -> intArrayOf(0xFF1E3A5F.toInt(), 0xFF4B6B8A.toInt(), 0xFFC59B6D.toInt()) // Asr
            in 17..19 -> intArrayOf(0xFF1E1B3A.toInt(), 0xFF6A2E53.toInt(), 0xFFE07A5F.toInt()) // Maghrib
            else -> intArrayOf(0xFF070B14.toInt(), 0xFF0F172A.toInt(), 0xFF1E293B.toInt()) // Night
        }
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), colors, null, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        return bmp
    }

    private fun computeAverageLuminance(bmp: Bitmap): Float {
        var total = 0f
        var count = 0
        val stepX = max(1, bmp.width / 8)
        val stepY = max(1, bmp.height / 8)
        for (y in 0 until bmp.height step stepY) {
            for (x in 0 until bmp.width step stepX) {
                val px = bmp.getPixel(x, y)
                val r = Color.red(px) / 255f
                val g = Color.green(px) / 255f
                val b = Color.blue(px) / 255f
                total += (0.299f * r + 0.587f * g + 0.114f * b)
                count++
            }
        }
        return if (count == 0) 0f else total / count
    }

    /**
     * Draws a glassmorphic rounded card using the shared BitmapShader mapped to screen coordinates,
     * an adaptive frost tint, and a diagonal Specular Rim Gradient.
     */
    fun drawGlassCard(
        canvas: Canvas,
        rect: RectF,
        cornerRadius: Float,
        screenOffsetX: Float,
        screenOffsetY: Float,
        screenW: Int,
        screenH: Int,
        density: Float
    ) {
        val shader = sharedShader
        val light = isLightWallpaper

        if (shader != null && blurredBitmap != null && screenW > 0 && screenH > 0) {
            val bmp = blurredBitmap!!
            val matrix = Matrix()
            matrix.setScale(screenW.toFloat() / bmp.width, screenH.toFloat() / bmp.height)
            matrix.postTranslate(-screenOffsetX, -screenOffsetY)
            shader.setLocalMatrix(matrix)

            val blurPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                this.shader = shader
            }
            canvas.drawRoundRect(rect, cornerRadius, cornerRadius, blurPaint)
        }

        val tintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (light) Color.argb(135, 255, 255, 255) else Color.argb(58, 18, 24, 38)
        }
        canvas.drawRoundRect(rect, cornerRadius, cornerRadius, tintPaint)

        val rimStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1.2f * density
            val topCol = if (light) Color.argb(180, 255, 255, 255) else Color.argb(115, 255, 255, 255)
            val midCol = if (light) Color.argb(40, 255, 255, 255) else Color.argb(22, 255, 255, 255)
            val botCol = if (light) Color.argb(95, 200, 215, 235) else Color.argb(65, 148, 163, 184)
            this.shader = LinearGradient(
                rect.left, rect.top, rect.right, rect.bottom,
                intArrayOf(topCol, midCol, botCol),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRoundRect(rect, cornerRadius, cornerRadius, rimStroke)
    }

    /**
     * Pure-Kotlin fast StackBlur for small downscaled bitmaps (no RenderScript needed).
     */
    private fun fastStackBlur(sentBitmap: Bitmap, radius: Int): Bitmap {
        val bitmap = sentBitmap.copy(Bitmap.Config.ARGB_8888, true)
        if (radius < 1) return bitmap
        val w = bitmap.width
        val h = bitmap.height
        val pix = IntArray(w * h)
        bitmap.getPixels(pix, 0, w, 0, 0, w, h)

        val wm = w - 1
        val hm = h - 1
        val wh = w * h
        val div = radius + radius + 1
        val r = IntArray(wh)
        val g = IntArray(wh)
        val b = IntArray(wh)
        var rsum: Int
        var gsum: Int
        var bsum: Int
        var x: Int
        var y: Int
        var i: Int
        var p: Int
        var yp: Int
        var yi: Int
        val vmin = IntArray(max(w, h))
        var divsum = (div + 1) shr 1
        divsum *= divsum
        val dv = IntArray(256 * divsum)
        i = 0
        while (i < 256 * divsum) {
            dv[i] = i / divsum
            i++
        }
        yi = 0
        var yw = 0
        val stack = Array(div) { IntArray(3) }
        var stackpointer: Int
        var stackstart: Int
        var sir: IntArray
        var rbs: Int
        val r1 = radius + 1
        var routsum: Int
        var goutsum: Int
        var boutsum: Int
        var rinsum: Int
        var ginsum: Int
        var binsum: Int

        y = 0
        while (y < h) {
            bsum = 0; gsum = 0; rsum = 0
            boutsum = 0; goutsum = 0; routsum = 0
            binsum = 0; ginsum = 0; rinsum = 0
            i = -radius
            while (i <= radius) {
                p = pix[yi + min(wm, max(i, 0))]
                sir = stack[i + radius]
                sir[0] = (p and 0xff0000) shr 16
                sir[1] = (p and 0x00ff00) shr 8
                sir[2] = p and 0x0000ff
                rbs = r1 - kotlin.math.abs(i)
                rsum += sir[0] * rbs; gsum += sir[1] * rbs; bsum += sir[2] * rbs
                if (i > 0) {
                    rinsum += sir[0]; ginsum += sir[1]; binsum += sir[2]
                } else {
                    routsum += sir[0]; goutsum += sir[1]; boutsum += sir[2]
                }
                i++
            }
            stackpointer = radius
            x = 0
            while (x < w) {
                r[yi] = dv[rsum]; g[yi] = dv[gsum]; b[yi] = dv[bsum]
                rsum -= routsum; gsum -= goutsum; bsum -= boutsum
                stackstart = stackpointer - radius + div
                sir = stack[stackstart % div]
                routsum -= sir[0]; goutsum -= sir[1]; boutsum -= sir[2]
                if (y == 0) vmin[x] = min(x + radius + 1, wm)
                p = pix[yw + vmin[x]]
                sir[0] = (p and 0xff0000) shr 16
                sir[1] = (p and 0x00ff00) shr 8
                sir[2] = p and 0x0000ff
                rinsum += sir[0]; ginsum += sir[1]; binsum += sir[2]
                rsum += rinsum; gsum += ginsum; bsum += binsum
                stackpointer = (stackpointer + 1) % div
                sir = stack[stackpointer % div]
                routsum += sir[0]; goutsum += sir[1]; boutsum += sir[2]
                rinsum -= sir[0]; ginsum -= sir[1]; binsum -= sir[2]
                yi++
                x++
            }
            yw += w
            y++
        }
        x = 0
        while (x < w) {
            bsum = 0; gsum = 0; rsum = 0
            boutsum = 0; goutsum = 0; routsum = 0
            binsum = 0; ginsum = 0; rinsum = 0
            yp = -radius * w
            i = -radius
            while (i <= radius) {
                yi = max(0, yp) + x
                sir = stack[i + radius]
                sir[0] = r[yi]; sir[1] = g[yi]; sir[2] = b[yi]
                rbs = r1 - kotlin.math.abs(i)
                rsum += r[yi] * rbs; gsum += g[yi] * rbs; bsum += b[yi] * rbs
                if (i > 0) {
                    rinsum += sir[0]; ginsum += sir[1]; binsum += sir[2]
                } else {
                    routsum += sir[0]; goutsum += sir[1]; boutsum += sir[2]
                }
                if (i < hm) yp += w
                i++
            }
            yi = x
            stackpointer = radius
            y = 0
            while (y < h) {
                pix[yi] = (-0x1000000 and pix[yi]) or (dv[rsum] shl 16) or (dv[gsum] shl 8) or dv[bsum]
                rsum -= routsum; gsum -= goutsum; bsum -= boutsum
                stackstart = stackpointer - radius + div
                sir = stack[stackstart % div]
                routsum -= sir[0]; goutsum -= sir[1]; boutsum -= sir[2]
                if (x == 0) vmin[y] = min(y + r1, hm) * w
                p = x + vmin[y]
                sir[0] = r[p]; sir[1] = g[p]; sir[2] = b[p]
                rinsum += sir[0]; ginsum += sir[1]; binsum += sir[2]
                rsum += rinsum; gsum += ginsum; bsum += binsum
                stackpointer = (stackpointer + 1) % div
                sir = stack[stackpointer]
                routsum += sir[0]; goutsum += sir[1]; boutsum += sir[2]
                rinsum -= sir[0]; ginsum -= sir[1]; binsum -= sir[2]
                yi += w
                y++
            }
            x++
        }
        bitmap.setPixels(pix, 0, w, 0, 0, w, h)
        return bitmap
    }
}
