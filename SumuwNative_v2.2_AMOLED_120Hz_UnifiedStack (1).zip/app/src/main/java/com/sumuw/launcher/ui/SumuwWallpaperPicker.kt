package com.sumuw.launcher.ui

import android.app.WallpaperManager
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.sumuw.launcher.R
import com.sumuw.launcher.data.LauncherPrefs

data class SumuwWallpaperItem(
    val id: String,
    val titleAr: String,
    val subtitleAr: String,
    val drawableResId: Int?
)

object SumuwWallpaperCatalog {
    val items: List<SumuwWallpaperItem> = listOf(
        SumuwWallpaperItem(
            id = "amoled_gold",
            titleAr = "AMOLED ذهب خالص",
            subtitleAr = "أسود نقي #000000 لشاشات OLED وخطوط ذهبية",
            drawableResId = R.drawable.wp_sumuw_amoled_gold
        ),
        SumuwWallpaperItem(
            id = "amoled_sapphire",
            titleAr = "AMOLED هلال ياقوتي",
            subtitleAr = "أسود نقي لشاشات OLED وتوهج أزرق وفضي",
            drawableResId = R.drawable.wp_sumuw_amoled_sapphire
        ),
        SumuwWallpaperItem(
            id = "royal_silk",
            titleAr = "حرير سُمو الملكي",
            subtitleAr = "أوبسيديان داكن وتموجات ذهب 24",
            drawableResId = R.drawable.wp_sumuw_royal_silk
        ),
        SumuwWallpaperItem(
            id = "najd_dunes",
            titleAr = "كثبان نجد عند الغسق",
            subtitleAr = "سماء نيلية وأفق كهرماني دافئ",
            drawableResId = R.drawable.wp_sumuw_najd_dunes
        ),
        SumuwWallpaperItem(
            id = "emerald_glass",
            titleAr = "زمرد وبرونز",
            subtitleAr = "زجاج زمردي وزخارف هندسية عربية",
            drawableResId = R.drawable.wp_sumuw_emerald_glass
        ),
        SumuwWallpaperItem(
            id = "system",
            titleAr = "خلفية النظام الحالية",
            subtitleAr = "استخدام خلفية أندرويد المثبتة على جهازك",
            drawableResId = null
        )
    )

    fun findById(id: String): SumuwWallpaperItem =
        items.firstOrNull { it.id == id } ?: items.first()
}

object SumuwWallpaperPicker {

    fun populate(
        ctx: Context,
        container: LinearLayout,
        onWallpaperChanged: () -> Unit,
        onDimChanged: (Float) -> Unit,
        onClose: () -> Unit
    ) {
        val d = ctx.resources.displayMetrics.density
        val currentId = LauncherPrefs.getSelectedWallpaper(ctx)

        val grid = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val rows = SumuwWallpaperCatalog.items.chunked(2)
        rows.forEach { pair ->
            val rowLayout = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = (10 * d).toInt() }
            }
            pair.forEachIndexed { idx, item ->
                val isSelected = item.id == currentId
                val card = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding((8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt())
                    background = GradientDrawable().apply {
                        cornerRadius = 16 * d
                        setColor(if (isSelected) 0x33D4AF37 else 0x1AFFFFFF)
                        setStroke(
                            if (isSelected) (2 * d).toInt() else (1 * d).toInt(),
                            if (isSelected) 0xFFD4AF37.toInt() else 0x33FFFFFF
                        )
                    }
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                        if (idx == 0 && pair.size > 1) marginEnd = (8 * d).toInt()
                    }
                    setOnClickListener {
                        LauncherPrefs.setSelectedWallpaper(ctx, item.id)
                        onWallpaperChanged()
                        onClose()
                    }
                }

                val preview = ImageView(ctx).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        (120 * d).toInt()
                    ).apply { bottomMargin = (6 * d).toInt() }
                    clipToOutline = true
                    outlineProvider = object : android.view.ViewOutlineProvider() {
                        override fun getOutline(view: View, outline: android.graphics.Outline) {
                            outline.setRoundRect(0, 0, view.width, view.height, 12 * d)
                        }
                    }
                    if (item.drawableResId != null) {
                        val opts = BitmapFactory.Options().apply { inSampleSize = 4 }
                        setImageBitmap(BitmapFactory.decodeResource(ctx.resources, item.drawableResId, opts))
                    } else {
                        setBackgroundColor(0xFF1E293B.toInt())
                    }
                }
                card.addView(preview)

                val titleTv = TextView(ctx).apply {
                    text = if (isSelected) "✓ ${item.titleAr}" else item.titleAr
                    textSize = 12.5f
                    setTextColor(if (isSelected) 0xFFE8C56E.toInt() else Color.WHITE)
                    typeface = Typeface.create("serif", Typeface.BOLD)
                }
                card.addView(titleTv)

                val subTv = TextView(ctx).apply {
                    text = item.subtitleAr
                    textSize = 10f
                    setTextColor(0xFFB8C4D4.toInt())
                    maxLines = 2
                }
                card.addView(subTv)

                if (item.drawableResId != null) {
                    val setSysBtn = TextView(ctx).apply {
                        text = "تعيين كخلفية للهاتف"
                        textSize = 10.5f
                        gravity = Gravity.CENTER
                        setTextColor(0xFFE8C56E.toInt())
                        setPadding((6 * d).toInt(), (5 * d).toInt(), (6 * d).toInt(), (5 * d).toInt())
                        background = GradientDrawable().apply {
                            cornerRadius = 10 * d
                            setColor(0x22D4AF37)
                            setStroke((1 * d).toInt(), 0x66D4AF37)
                        }
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { topMargin = (6 * d).toInt() }
                        setOnClickListener {
                            try {
                                WallpaperManager.getInstance(ctx).setResource(item.drawableResId)
                                Toast.makeText(ctx, "تم تعيين «${item.titleAr}» كخلفية للهاتف", Toast.LENGTH_SHORT).show()
                            } catch (e: Throwable) {
                                Toast.makeText(ctx, "تعذر تعيين خلفية النظام: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                    card.addView(setSysBtn)
                }

                rowLayout.addView(card)
            }
            grid.addView(rowLayout)
        }

        container.addView(grid)

        val dimLabel = TextView(ctx).apply {
            text = "تعتيم الخلفية لوضوح الكبسولات (${(LauncherPrefs.getWallpaperDim(ctx) * 100).toInt()}%)"
            textSize = 12.5f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("serif", Typeface.BOLD)
            setPadding(0, (8 * d).toInt(), 0, (4 * d).toInt())
        }
        container.addView(dimLabel)

        val seekBar = SeekBar(ctx).apply {
            max = 75
            progress = (LauncherPrefs.getWallpaperDim(ctx) * 100).toInt()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    val alpha = progress / 100f
                    dimLabel.text = "تعتيم الخلفية لوضوح الكبسولات ($progress%)"
                    LauncherPrefs.setWallpaperDim(ctx, alpha)
                    onDimChanged(alpha)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        container.addView(seekBar)
    }
}
