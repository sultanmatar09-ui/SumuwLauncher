package com.sumuw.launcher

import android.Manifest
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.sumuw.launcher.core.GlassEngine
import com.sumuw.launcher.core.SpringPhysics
import com.sumuw.launcher.data.LauncherPrefs
import com.sumuw.launcher.data.TouchGuard
import com.sumuw.launcher.notifications.SumuwNotificationListener
import com.sumuw.launcher.search.SmartSearchEngine
import com.sumuw.launcher.tools.IslamicAndPracticalTools
import com.sumuw.launcher.ui.AppGridAdapter
import com.sumuw.launcher.ui.AppInfo
import com.sumuw.launcher.ui.CardStackController
import com.sumuw.launcher.ui.GlassCardView
import com.sumuw.launcher.wallpaper.SumuwWallpaperService

class MainActivity : android.app.Activity(), SensorEventListener {

    private lateinit var rootLayout: FrameLayout
    private lateinit var mainCol: LinearLayout
    private lateinit var searchContainer: GlassCardView
    private lateinit var searchInput: EditText
    private lateinit var searchResultsBox: LinearLayout
    private lateinit var cardStackContainer: FrameLayout
    private lateinit var appGrid: GridView
    private lateinit var dockContainer: GlassCardView
    private lateinit var overlayPanel: FrameLayout

    private var allApps: List<AppInfo> = emptyList()
    private lateinit var gridAdapter: AppGridAdapter
    private lateinit var cardStackController: CardStackController

    private var sensorManager: SensorManager? = null
    private var qiblaDegreeCallback: ((Float) -> Unit)? = null
    private var qiblaBearing: Float = 290f

    private val backdropListener: () -> Unit = {
        refreshAllGlassViews()
    }

    private val notifListener: () -> Unit = {
        if (::gridAdapter.isInitialized) {
            gridAdapter.notifyDataSetChanged()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        cardStackController = CardStackController(this) { rebuildCardStack() }

        buildUI()
        GlassEngine.addListener(backdropListener)
        SumuwNotificationListener.addListener(notifListener)

        val dm = resources.displayMetrics
        GlassEngine.refreshBackdropAsync(this, dm.widthPixels, dm.heightPixels)
        loadInstalledAppsAsync()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val dm = resources.displayMetrics
        GlassEngine.refreshBackdropAsync(this, dm.widthPixels, dm.heightPixels)
        rebuildCardStack()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> TouchGuard.onFingerDown()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> TouchGuard.onFingerUp()
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onDestroy() {
        GlassEngine.removeListener(backdropListener)
        SumuwNotificationListener.removeListener(notifListener)
        sensorManager?.unregisterListener(this)
        super.onDestroy()
    }

    private fun buildUI() {
        val d = resources.displayMetrics.density
        rootLayout = FrameLayout(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, (32 * d).toInt(), 0, (16 * d).toInt())
        }

        mainCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // 1. Top Header Bar (Title + Tools / Control Center / Display Options)
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((16 * d).toInt(), (4 * d).toInt(), (16 * d).toInt(), (6 * d).toInt())
        }
        val titleTv = TextView(this).apply {
            text = "سُمو"
            textSize = 20f
            typeface = Typeface.create("serif", Typeface.BOLD)
            setTextColor(0xFFD4AF37.toInt())
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val toolsBtn = makeTopChip("الأدوات") { showToolsMenu() }
        val notifBtn = makeTopChip("الإشعارات") { showNotificationShade() }
        val displayBtn = makeTopChip("خيارات العرض") { showDisplayOptions() }
        topBar.addView(titleTv)
        topBar.addView(notifBtn)
        topBar.addView(toolsBtn)
        topBar.addView(displayBtn)
        mainCol.addView(topBar)

        // 2. Smart Search Bar (Hideable)
        searchContainer = GlassCardView(this).apply {
            cornerRadiusDp = 18f
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins((14 * d).toInt(), (4 * d).toInt(), (14 * d).toInt(), (6 * d).toInt())
            }
            setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
        }
        searchInput = EditText(this).apply {
            hint = "ابحث عن تطبيق، جهة اتصال، حاسبة، زكاة 100000..."
            setHintTextColor(0xFFCBD5E1.toInt())
            setTextColor(Color.WHITE)
            background = null
            textSize = 14f
            isSingleLine = true
            typeface = Typeface.create("serif", Typeface.NORMAL)
        }
        searchContainer.addView(searchInput)
        mainCol.addView(searchContainer)

        searchResultsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding((14 * d).toInt(), 0, (14 * d).toInt(), (6 * d).toInt())
        }
        mainCol.addView(searchResultsBox)

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                updateSearchResults(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        // 3. CardStack Container (Auto-collapses if all cards hidden)
        cardStackContainer = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        mainCol.addView(cardStackContainer)

        // 4. App Grid (Automatically expands into freed space!)
        appGrid = GridView(this).apply {
            numColumns = 4
            verticalSpacing = (8 * d).toInt()
            horizontalSpacing = (4 * d).toInt()
            isVerticalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            ).apply {
                setMargins((10 * d).toInt(), (4 * d).toInt(), (10 * d).toInt(), (4 * d).toInt())
            }
        }
        gridAdapter = AppGridAdapter(this, emptyList()) { launchApp(it) }
        appGrid.adapter = gridAdapter
        mainCol.addView(appGrid)

        // 5. Fixed Bottom Dock
        dockContainer = GlassCardView(this).apply {
            cornerRadiusDp = 24f
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (64 * d).toInt()
            ).apply {
                setMargins((14 * d).toInt(), (4 * d).toInt(), (14 * d).toInt(), (4 * d).toInt())
            }
        }
        buildDockContent()
        mainCol.addView(dockContainer)

        rootLayout.addView(mainCol)

        // 6. Overlay Panel for Control Center / Tools / Notifications
        overlayPanel = FrameLayout(this).apply {
            visibility = View.GONE
            setBackgroundColor(Color.argb(130, 0, 0, 0))
            setOnClickListener { closeOverlay() }
        }
        rootLayout.addView(overlayPanel)

        setContentView(rootLayout)
        applyVisibilityStates()
        rebuildCardStack()
    }

    private fun makeTopChip(label: String, onClick: () -> Unit): TextView {
        val d = resources.displayMetrics.density
        return TextView(this).apply {
            text = label
            textSize = 12f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("serif", Typeface.BOLD)
            setPadding((10 * d).toInt(), (5 * d).toInt(), (10 * d).toInt(), (5 * d).toInt())
            setOnClickListener { onClick() }
        }
    }

    private fun buildDockContent() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        val items = listOf(
            "الهاتف" to { startActivity(Intent(Intent.ACTION_DIAL)) },
            "القبلة" to { showQiblaCompass() },
            "المسبحة" to { showKhatmaAndTasbih() },
            "السيارة" to { showCarAndParking() },
            "التحكم" to { showControlCenter() }
        )
        for ((title, action) in items) {
            val tv = TextView(this).apply {
                text = title
                textSize = 12.5f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                typeface = Typeface.create("serif", Typeface.BOLD)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                setOnClickListener { action() }
            }
            row.addView(tv)
        }
        dockContainer.removeAllViews()
        dockContainer.addView(row)
    }

    private fun applyVisibilityStates() {
        searchContainer.visibility = if (LauncherPrefs.isSearchBarVisible(this)) View.VISIBLE else View.GONE
        val visibleCards = LauncherPrefs.getVisibleCards(this)
        cardStackContainer.visibility = if (visibleCards.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun rebuildCardStack() {
        applyVisibilityStates()
        cardStackContainer.removeAllViews()
        if (LauncherPrefs.getVisibleCards(this).isNotEmpty()) {
            cardStackContainer.addView(cardStackController.buildCardStackView())
        }
    }

    private fun refreshAllGlassViews() {
        searchContainer.invalidate()
        dockContainer.invalidate()
        rebuildCardStack()
        gridAdapter.notifyDataSetChanged()
    }

    private fun loadInstalledAppsAsync() {
        GlassEngine.bgExecutor.execute {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
            val resolved = pm.queryIntentActivities(intent, 0)
            val usage = LauncherPrefs.getUsageCounts(this)
            val list = resolved
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    AppInfo(
                        label = it.loadLabel(pm).toString(),
                        packageName = it.activityInfo.packageName,
                        icon = it.loadIcon(pm)
                    )
                }
                .sortedWith(compareByDescending<AppInfo> { usage[it.packageName] ?: 0 }.thenBy { it.label })

            GlassEngine.mainHandler.post {
                allApps = list
                gridAdapter.updateItems(list)
            }
        }
    }

    private fun launchApp(app: AppInfo) {
        if (LauncherPrefs.isKidsMode(this)) {
            Toast.makeText(this, "وضع الأطفال مفعّل — افتح القفل من الأدوات", Toast.LENGTH_SHORT).show()
            return
        }
        val launchIntent = packageManager.getLaunchIntentForPackage(app.packageName) ?: return
        LauncherPrefs.recordAppLaunchAsync(this, app.packageName)
        startActivity(launchIntent)
    }

    private fun updateSearchResults(query: String) {
        searchResultsBox.removeAllViews()
        if (query.isBlank()) {
            searchResultsBox.visibility = View.GONE
            return
        }
        val res = SmartSearchEngine.search(this, query, allApps)
        if (res.isEmpty()) {
            searchResultsBox.visibility = View.GONE
            return
        }
        searchResultsBox.visibility = View.VISIBLE
        val d = resources.displayMetrics.density
        for (item in res.take(6)) {
            val card = GlassCardView(this).apply {
                cornerRadiusDp = 14f
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = (6 * d).toInt() }
                setPadding((12 * d).toInt(), (10 * d).toInt(), (12 * d).toInt(), (10 * d).toInt())
            }
            val tv = TextView(this).apply {
                setTextColor(Color.WHITE)
                textSize = 13.5f
                typeface = Typeface.create("serif", Typeface.NORMAL)
                when (item) {
                    is SmartSearchEngine.SearchResult.UtilityCard -> {
                        text = "${item.title}: ${item.value}\n${item.subtitle}"
                    }
                    is SmartSearchEngine.SearchResult.AppResult -> {
                        text = "فتح تطبيق: ${item.app.label}"
                        setOnClickListener { launchApp(item.app) }
                    }
                    is SmartSearchEngine.SearchResult.ContactResult -> {
                        text = "اتصال: ${item.name} (${item.phone})"
                        setOnClickListener {
                            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${item.phone}")))
                        }
                    }
                }
            }
            card.addView(tv)
            searchResultsBox.addView(card)
        }
    }

    private fun openOverlay(title: String, buildBody: (LinearLayout) -> Unit) {
        val d = resources.displayMetrics.density
        overlayPanel.removeAllViews()
        val sheet = GlassCardView(this).apply {
            cornerRadiusDp = 24f
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            ).apply {
                setMargins((12 * d).toInt(), (40 * d).toInt(), (12 * d).toInt(), (18 * d).toInt())
            }
            setPadding((18 * d).toInt(), (16 * d).toInt(), (18 * d).toInt(), (18 * d).toInt())
            setOnClickListener { /* consume */ }
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val header = TextView(this).apply {
            text = title
            textSize = 18f
            setTextColor(0xFFD4AF37.toInt())
            typeface = Typeface.create("serif", Typeface.BOLD)
            setPadding(0, 0, 0, (10 * d).toInt())
        }
        col.addView(header)
        buildBody(col)
        sheet.addView(col)
        overlayPanel.addView(sheet)
        overlayPanel.visibility = View.VISIBLE
        SpringPhysics.animatePanelReveal(sheet, 140f)
    }

    private fun closeOverlay() {
        qiblaDegreeCallback = null
        sensorManager?.unregisterListener(this)
        overlayPanel.visibility = View.GONE
    }

    private fun makeOverlayBtn(text: String, onClick: () -> Unit): TextView {
        val d = resources.displayMetrics.density
        return TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("serif", Typeface.BOLD)
            setPadding((10 * d).toInt(), (10 * d).toInt(), (10 * d).toInt(), (10 * d).toInt())
            setOnClickListener { onClick() }
        }
    }

    private fun showDisplayOptions() {
        openOverlay("خيارات العرض والتخصيص") { col ->
            val searchVisible = LauncherPrefs.isSearchBarVisible(this)
            col.addView(makeOverlayBtn(if (searchVisible) "إخفاء شريط البحث الرئيسي" else "إظهار شريط البحث الرئيسي") {
                LauncherPrefs.setSearchBarVisible(this, !searchVisible)
                applyVisibilityStates()
                closeOverlay()
            })
            col.addView(makeOverlayBtn("استعادة جميع البطاقات وشريط البحث") {
                LauncherPrefs.restoreAllCards(this)
                rebuildCardStack()
                closeOverlay()
            })
            col.addView(makeOverlayBtn("تفعيل خلفية سُمو الحية التفاعلية") {
                val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                    putExtra(
                        WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                        ComponentName(this@MainActivity, SumuwWallpaperService::class.java)
                    )
                }
                startActivity(intent)
                closeOverlay()
            })
        }
    }

    private fun showControlCenter() {
        openOverlay("مركز التحكم السريع") { col ->
            col.addView(makeOverlayBtn("طقس الخلفية: صافي / نجوم") {
                SumuwWallpaperService.setWeatherEffect(this, SumuwWallpaperService.WeatherEffect.CLEAR)
                closeOverlay()
            })
            col.addView(makeOverlayBtn("طقس الخلفية: مطر متحرك") {
                SumuwWallpaperService.setWeatherEffect(this, SumuwWallpaperService.WeatherEffect.RAIN)
                closeOverlay()
            })
            col.addView(makeOverlayBtn("طقس الخلفية: عاصفة وبرق") {
                SumuwWallpaperService.setWeatherEffect(this, SumuwWallpaperService.WeatherEffect.STORM)
                closeOverlay()
            })
            col.addView(makeOverlayBtn("طقس الخلفية: غبار") {
                SumuwWallpaperService.setWeatherEffect(this, SumuwWallpaperService.WeatherEffect.DUST)
                closeOverlay()
            })
            col.addView(makeOverlayBtn("إعدادات النظام") {
                startActivity(Intent(Settings.ACTION_SETTINGS))
                closeOverlay()
            })
        }
    }

    private fun showNotificationShade() {
        openOverlay("لوحة الإشعارات المدمجة") { col ->
            val items = SumuwNotificationListener.activeSummaries
            if (items.isEmpty()) {
                col.addView(makeOverlayBtn("لا توجد إشعارات — اضغط لمنح صلاحية الإشعارات") {
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    closeOverlay()
                })
            } else {
                for (n in items.take(6)) {
                    col.addView(makeOverlayBtn("• ${n.title}: ${n.text}") {
                        packageManager.getLaunchIntentForPackage(n.packageName)?.let { startActivity(it) }
                        closeOverlay()
                    })
                }
            }
        }
    }

    private fun showToolsMenu() {
        openOverlay("الأدوات الإسلامية والعملية") { col ->
            col.addView(makeOverlayBtn("بوصلة القبلة (مع الانحراف المغناطيسي)") { showQiblaCompass() })
            col.addView(makeOverlayBtn("وضع الحرم التلقائي (حفظ واستعادة عدم الإزعاج)") {
                val enabled = !LauncherPrefs.isHaramModeEnabled(this)
                LauncherPrefs.setHaramModeEnabled(this, enabled)
                Toast.makeText(this, if (enabled) "تم تفعيل وضع الحرم" else "تم إيقاف وضع الحرم", Toast.LENGTH_SHORT).show()
                closeOverlay()
            })
            col.addView(makeOverlayBtn("الختمة والمسبحة") { showKhatmaAndTasbih() })
            col.addView(makeOverlayBtn(if (LauncherPrefs.isKidsMode(this)) "إلغاء قفل وضع الأطفال (بصمة/رمز الجهاز)" else "تفعيل وضع الأطفال") {
                if (LauncherPrefs.isKidsMode(this)) {
                    IslamicAndPracticalTools.requestKidsModeUnlock(
                        this,
                        onUnlocked = {
                            Toast.makeText(this, "تم فتح قفل وضع الأطفال", Toast.LENGTH_SHORT).show()
                            closeOverlay()
                        },
                        onDeniedOrError = { err ->
                            Toast.makeText(this, err, Toast.LENGTH_LONG).show()
                        }
                    )
                } else {
                    LauncherPrefs.setKidsMode(this, true)
                    Toast.makeText(this, "تم تفعيل وضع الأطفال", Toast.LENGTH_SHORT).show()
                    closeOverlay()
                }
            })
            col.addView(makeOverlayBtn("السيارة وموقف الركن") { showCarAndParking() })
            col.addView(makeOverlayBtn("نسخ احتياطي JSON (حفظ ومشاركة)") {
                val json = LauncherPrefs.exportFullBackupJson(this)
                val share = Intent(Intent.ACTION_SEND).apply {
                    type = "application/json"
                    putExtra(Intent.EXTRA_TEXT, json)
                }
                startActivity(Intent.createChooser(share, "حفظ نسخة سُمو الاحتياطية"))
                closeOverlay()
            })
        }
    }

    private fun showQiblaCompass() {
        val loc = getLastKnownLocation()
        qiblaBearing = if (loc != null) {
            IslamicAndPracticalTools.computeQiblaBearing(loc.latitude, loc.longitude, loc.altitude)
        } else {
            IslamicAndPracticalTools.computeQiblaBearing(21.5433, 39.1728, 12.0) // Jeddah default
        }

        openOverlay("بوصلة القبلة الدقيقة") { col ->
            val infoTv = TextView(this).apply {
                text = "جاري معايرة المستشعر..."
                textSize = 16f
                setTextColor(Color.WHITE)
                typeface = Typeface.create("serif", Typeface.BOLD)
            }
            col.addView(infoTv)
            qiblaDegreeCallback = { azimuth ->
                val rot = IslamicAndPracticalTools.getScreenRotationDegrees(this)
                val corrected = (qiblaBearing - azimuth - rot + 360f) % 360f
                infoTv.text = "زاوية القبلة: ${qiblaBearing.toInt()}°\nاتجاه السهم نسبة للهاتف: ${corrected.toInt()}°"
            }
            @Suppress("DEPRECATION")
            sensorManager?.getDefaultSensor(Sensor.TYPE_ORIENTATION)?.let {
                sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
            }
        }
    }

    private fun showKhatmaAndTasbih() {
        openOverlay("الختمة والمسبحة") { col ->
            val tv = TextView(this).apply {
                setTextColor(Color.WHITE)
                textSize = 15f
                text = "التسبيحات: ${LauncherPrefs.getTasbih(this@MainActivity)}  |  صفحة الختمة: ${LauncherPrefs.getKhatmaPage(this@MainActivity)} / 604"
            }
            col.addView(tv)
            col.addView(makeOverlayBtn("+ تسبيحة (سبحان الله)") {
                val next = LauncherPrefs.getTasbih(this) + 1
                LauncherPrefs.setTasbih(this, next)
                tv.text = "التسبيحات: $next  |  صفحة الختمة: ${LauncherPrefs.getKhatmaPage(this)} / 604"
            })
            col.addView(makeOverlayBtn("+ صفحة ختمة") {
                val next = LauncherPrefs.getKhatmaPage(this) + 1
                LauncherPrefs.setKhatmaPage(this, next)
                tv.text = "التسبيحات: ${LauncherPrefs.getTasbih(this)}  |  صفحة الختمة: $next / 604"
            })
        }
    }

    private fun showCarAndParking() {
        openOverlay("وضع السيارة وموقف الركن") { col ->
            val (lat, lon, note) = LauncherPrefs.getParking(this)
            val statusTv = TextView(this).apply {
                setTextColor(Color.WHITE)
                textSize = 14f
                text = if (lat != null && lon != null) "الموقف المحفوظ: $lat, $lon ($note)" else "لم يُحفظ موقع ركن بعد"
            }
            col.addView(statusTv)
            col.addView(makeOverlayBtn("حفظ موقع الركن الحالي") {
                val loc = getLastKnownLocation()
                if (loc != null) {
                    LauncherPrefs.saveParking(this, loc.latitude, loc.longitude, "موقف سيارتي")
                    statusTv.text = "تم الحفظ: ${loc.latitude}, ${loc.longitude}"
                } else {
                    Toast.makeText(this, "يرجى تفعيل صلاحية الموقع", Toast.LENGTH_SHORT).show()
                }
            })
            if (lat != null && lon != null) {
                col.addView(makeOverlayBtn("فتح الموقف في الخرائط") {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lon?q=$lat,$lon(موقف الركن)")))
                })
            }
        }
    }

    private fun getLastKnownLocation(): android.location.Location? {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) return null
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return
        qiblaDegreeCallback?.invoke(event.values[0])
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
