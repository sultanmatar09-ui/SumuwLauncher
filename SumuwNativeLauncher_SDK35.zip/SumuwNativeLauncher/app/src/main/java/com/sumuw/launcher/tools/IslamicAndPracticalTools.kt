package com.sumuw.launcher.tools

import android.app.Activity
import android.app.KeyguardManager
import android.app.NotificationManager
import android.content.Context
import android.hardware.GeomagneticField
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.location.Location
import android.os.Build
import android.os.CancellationSignal
import android.view.Surface
import com.sumuw.launcher.data.LauncherPrefs
import kotlin.math.*

/**
 * Islamic & Practical Tools:
 * - Qibla bearing with GeomagneticField magnetic declination & screen rotation compensation.
 * - Haram Mode (Masjid al-Haram & Masjid an-Nabawi geofence) with DND state save/restore.
 * - Kids Mode lock backed strictly by KeyguardManager.isDeviceSecure + BiometricPrompt (zero error bypass).
 */
object IslamicAndPracticalTools {

    private const val KAABA_LAT = 21.422487
    private const val KAABA_LON = 39.826206
    private const val NABAWI_LAT = 24.467210
    private const val NABAWI_LON = 39.611131

    fun computeQiblaBearing(lat: Double, lon: Double, altitude: Double = 0.0): Float {
        val phiK = Math.toRadians(KAABA_LAT)
        val lambdaK = Math.toRadians(KAABA_LON)
        val phi = Math.toRadians(lat)
        val lambda = Math.toRadians(lon)

        val y = sin(lambdaK - lambda)
        val x = cos(phi) * tan(phiK) - sin(phi) * cos(lambdaK - lambda)
        val trueBearing = (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0

        val geoField = GeomagneticField(
            lat.toFloat(), lon.toFloat(), altitude.toFloat(), System.currentTimeMillis()
        )
        return ((trueBearing - geoField.declination + 360.0) % 360.0).toFloat()
    }

    fun getScreenRotationDegrees(context: Context): Float {
        @Suppress("DEPRECATION")
        val rot = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            context.display?.rotation ?: Surface.ROTATION_0
        } else {
            (context.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager).defaultDisplay.rotation
        }
        return when (rot) {
            Surface.ROTATION_90 -> 90f
            Surface.ROTATION_180 -> 180f
            Surface.ROTATION_270 -> 270f
            else -> 0f
        }
    }

    /**
     * Checks whether the user is inside Masjid al-Haram (850m) or Masjid an-Nabawi (750m).
     * Saves previous DND filter on entry and restores exact previous filter on exit.
     */
    fun evaluateHaramGeofence(context: Context, location: Location): Boolean {
        if (!LauncherPrefs.isHaramModeEnabled(context)) return false
        val distHaram = FloatArray(1)
        Location.distanceBetween(location.latitude, location.longitude, KAABA_LAT, KAABA_LON, distHaram)
        val distNabawi = FloatArray(1)
        Location.distanceBetween(location.latitude, location.longitude, NABAWI_LAT, NABAWI_LON, distNabawi)

        val inside = distHaram[0] <= 850f || distNabawi[0] <= 750f
        val wasInside = LauncherPrefs.isHaramInside(context)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (nm.isNotificationPolicyAccessGranted) {
            if (inside && !wasInside) {
                LauncherPrefs.setSavedDndFilter(context, nm.currentInterruptionFilter)
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
                LauncherPrefs.setHaramInside(context, true)
            } else if (!inside && wasInside) {
                val prev = LauncherPrefs.getSavedDndFilter(context)
                if (prev != -1) {
                    nm.setInterruptionFilter(prev)
                }
                LauncherPrefs.setHaramInside(context, false)
            }
        }
        return inside
    }

    /**
     * Unlocks Kids Mode ONLY after verified device security authentication.
     * Zero bypass on error, cancellation, or unavailable hardware.
     */
    fun requestKidsModeUnlock(
        activity: Activity,
        onUnlocked: () -> Unit,
        onDeniedOrError: (String) -> Unit
    ) {
        val km = activity.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isDeviceSecure) {
            onDeniedOrError("يجب تفعيل قفل الشاشة في إعدادات الجهاز لاستخدام قفل وضع الأطفال")
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val builder = BiometricPrompt.Builder(activity)
                .setTitle("إلغاء قفل وضع الأطفال")
                .setSubtitle("تحقق بهوية الجهاز للمتابعة")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                builder.setAllowedAuthenticators(
                    BiometricManager.Authenticators.BIOMETRIC_STRONG or
                        BiometricManager.Authenticators.DEVICE_CREDENTIAL
                )
            } else {
                @Suppress("DEPRECATION")
                builder.setDeviceCredentialAllowed(true)
            }

            val prompt = builder.build()
            prompt.authenticate(
                CancellationSignal(),
                activity.mainExecutor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                        LauncherPrefs.setKidsMode(activity, false)
                        onUnlocked()
                    }

                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                        onDeniedOrError(errString?.toString() ?: "تعذر التحقق")
                    }

                    override fun onAuthenticationFailed() {
                        onDeniedOrError("فشل التحقق")
                    }
                }
            )
        } else {
            onDeniedOrError("يتطلب قفل المقاييس الحيوية أندرويد 9 فأعلى")
        }
    }
}
