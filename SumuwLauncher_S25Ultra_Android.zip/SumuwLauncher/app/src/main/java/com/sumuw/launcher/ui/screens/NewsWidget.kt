package com.sumuw.launcher.ui.screens

import android.content.Intent
import android.net.Uri
import android.util.Xml
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sumuw.launcher.ui.theme.GlassSurface
import com.sumuw.launcher.ui.theme.TitaniumBorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.net.HttpURLConnection
import java.net.URL

data class NewsSource(val name: String, val rssUrl: String)
data class NewsHeadline(val title: String, val link: String, val source: String)

private val arabicSources = listOf(
    NewsSource("الكل", ""),
    NewsSource("العربية", "https://www.alarabiya.net/feed/rss2/ar.xml"),
    NewsSource("الجزيرة", "https://www.aljazeera.net/aljazeerarss/a7c186be-1baa-4bd4-9d80-a84db7698ef4/73d0e1b4-532f-45ef-b135-bfdff8b8cab9"),
    NewsSource("سكاي نيوز", "https://www.skynewsarabia.com/rss")
)

suspend fun fetchArabicRss(source: NewsSource): List<NewsHeadline> = withContext(Dispatchers.IO) {
    val targets = if (source.rssUrl.isEmpty()) arabicSources.drop(1) else listOf(source)
    val results = mutableListOf<NewsHeadline>()

    for (src in targets) {
        runCatching {
            val conn = (URL(src.rssUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 5000
                readTimeout = 5000
                setRequestProperty("User-Agent", "SumuwLauncher/1.0")
            }
            conn.inputStream.use { stream ->
                val parser = Xml.newPullParser()
                parser.setInput(stream, "UTF-8")
                var eventType = parser.eventType
                var insideItem = false
                var title = ""
                var link = ""
                while (eventType != XmlPullParser.END_DOCUMENT && results.size < 8) {
                    val tag = parser.name
                    when (eventType) {
                        XmlPullParser.START_TAG -> {
                            if (tag == "item") insideItem = true
                            else if (insideItem && tag == "title") title = parser.nextText().trim()
                            else if (insideItem && tag == "link") link = parser.nextText().trim()
                        }
                        XmlPullParser.END_TAG -> {
                            if (tag == "item" && title.isNotBlank()) {
                                results.add(NewsHeadline(title, link, src.name))
                                insideItem = false
                                title = ""
                                link = ""
                            }
                        }
                    }
                    eventType = parser.next()
                }
            }
            conn.disconnect()
        }
    }
    results
}

@Composable
fun BreakingNewsWidget(accentColor: Color) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedSourceIdx by remember { mutableIntStateOf(0) }
    var headlines by remember { mutableStateOf<List<NewsHeadline>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    fun loadNews() {
        scope.launch {
            isLoading = true
            val fetched = fetchArabicRss(arabicSources[selectedSourceIdx])
            headlines = fetched.ifEmpty {
                listOf(
                    NewsHeadline("تحديث الأخبار العاجلة يتطلب اتصالاً بالإنترنت — اضغط للتحديث", "", "النظام")
                )
            }
            isLoading = false
        }
    }

    LaunchedEffect(selectedSourceIdx) { loadNews() }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(GlassSurface)
            .border(1.dp, TitaniumBorder, RoundedCornerShape(22.dp))
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFEF4444))
                )
                Text("الأخبار العاجلة", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            IconButton(onClick = { loadNews() }, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Rounded.Refresh, contentDescription = "تحديث الأخبار", tint = accentColor, modifier = Modifier.size(18.dp))
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            arabicSources.forEachIndexed { idx, src ->
                val selected = idx == selectedSourceIdx
                Text(
                    text = src.name,
                    fontSize = 10.sp,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                    color = if (selected) Color.Black else Color.White.copy(alpha = 0.75f),
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (selected) accentColor else Color.White.copy(alpha = 0.08f))
                        .clickable { selectedSourceIdx = idx }
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }

        if (isLoading) {
            Text("جاري جلب آخر العناوين...", color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                headlines.take(3).forEach { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.White.copy(alpha = 0.04f))
                            .clickable(enabled = item.link.isNotBlank()) {
                                runCatching {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.link)))
                                }
                            }
                            .padding(horizontal = 10.dp, vertical = 7.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = item.title,
                            color = Color.White.copy(alpha = 0.92f),
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = item.source,
                            color = accentColor,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}
