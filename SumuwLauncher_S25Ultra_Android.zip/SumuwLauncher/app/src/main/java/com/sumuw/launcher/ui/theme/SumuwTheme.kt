package com.sumuw.launcher.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

enum class SumuwAccent(val label: String, val color: Color) {
    TITANIUM_GOLD("ذهب تيتانيوم", Color(0xFFD4AF37)),
    ROYAL_EMERALD("زمردي ملكي", Color(0xFF10B981)),
    SAPPHIRE_BLUE("ياقوتي", Color(0xFF38BDF8)),
    CRIMSON_RUBY("عقيقي", Color(0xFFF43F5E))
}

val ObsidianBlack = Color(0xFF030305)
val GlassSurface = Color(0x940E1016)
val TitaniumBorder = Color(0x22FFFFFF)

@Composable
fun SumuwTheme(
    accent: SumuwAccent = SumuwAccent.TITANIUM_GOLD,
    content: @Composable () -> Unit
) {
    val scheme = darkColorScheme(
        primary = accent.color,
        background = ObsidianBlack,
        surface = GlassSurface,
        onPrimary = Color.Black,
        onBackground = Color.White,
        onSurface = Color.White
    )
    MaterialTheme(
        colorScheme = scheme,
        content = content
    )
}
