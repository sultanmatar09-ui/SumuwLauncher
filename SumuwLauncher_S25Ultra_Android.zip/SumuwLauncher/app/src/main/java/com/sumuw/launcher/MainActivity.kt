package com.sumuw.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import com.sumuw.launcher.ui.screens.SumuwLauncherRoot
import com.sumuw.launcher.ui.theme.SumuwAccent
import com.sumuw.launcher.ui.theme.SumuwTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            var accentIndex by remember { mutableIntStateOf(0) }
            val accents = SumuwAccent.entries
            val currentAccent = accents[accentIndex % accents.size]

            SumuwTheme(accent = currentAccent) {
                SumuwLauncherRoot(
                    accent = currentAccent,
                    onCycleAccent = { accentIndex++ }
                )
            }
        }
    }
}
