package com.sumuw.launcher.ui.screens

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.provider.Settings
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun BatteryWifiCornerBadge(
    currentTime: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var batteryPct by remember { mutableIntStateOf(58) }
    var wifiConnected by remember { mutableStateOf(true) }
    var wifiLevel by remember { mutableIntStateOf(4) }

    LaunchedEffect(Unit) {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

        while (true) {
            val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            if (pct in 0..100) batteryPct = pct

            val network = cm.activeNetwork
            val caps = cm.getNetworkCapabilities(network)
            val isWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
            wifiConnected = isWifi
            if (isWifi) {
                @Suppress("DEPRECATION")
                val rssi = wm.connectionInfo?.rssi ?: -55
                wifiLevel = WifiManager.calculateSignalLevel(rssi, 5).coerceIn(1, 4)
            } else {
                wifiLevel = 0
            }
            delay(5000L)
        }
    }

    // Matches the exact micro top-right corner placement & size in iPhone Duo
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clip(CircleShape)
            .clickable {
                runCatching {
                    context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
            .padding(2.dp)
    ) {
        Text(
            text = currentTime,
            color = Color.White,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(2.dp))
        Box(
            modifier = Modifier.size(34.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val strokePx = 2.2.dp.toPx()
                val diameter = size.minDimension - strokePx * 1.4f
                val topLeft = Offset((size.width - diameter) / 2f, (size.height - diameter) / 2f)
                val arcSize = Size(diameter, diameter)

                val totalSweep = 220f
                val startAngle = 125f

                drawArc(
                    color = Color.White.copy(alpha = 0.28f),
                    startAngle = 125f,
                    sweepAngle = 110f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokePx, cap = StrokeCap.Round)
                )
                drawArc(
                    color = Color.White.copy(alpha = 0.28f),
                    startAngle = 305f,
                    sweepAngle = 110f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokePx, cap = StrokeCap.Round)
                )

                val activeSweep = (batteryPct / 100f) * totalSweep
                val leftActive = activeSweep.coerceAtMost(110f)
                if (leftActive > 0f) {
                    drawArc(
                        color = Color.White,
                        startAngle = startAngle,
                        sweepAngle = leftActive,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokePx, cap = StrokeCap.Round)
                    )
                }
                val rightActive = (activeSweep - 110f).coerceAtLeast(0f).coerceAtMost(110f)
                if (rightActive > 0f) {
                    drawArc(
                        color = Color.White,
                        startAngle = 305f,
                        sweepAngle = rightActive,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokePx, cap = StrokeCap.Round)
                    )
                }

                val center = Offset(topLeft.x + diameter / 2f, topLeft.y + diameter / 2f)
                val radius = diameter / 2f
                val dotAngles = listOf(114f, 102f, 90f, 78f, 66f)
                val activeDots = if (wifiConnected) (wifiLevel + 1).coerceIn(1, 5) else 0
                dotAngles.forEachIndexed { idx, deg ->
                    val rad = Math.toRadians(deg.toDouble())
                    val dx = center.x + (radius * cos(rad)).toFloat()
                    val dy = center.y + (radius * sin(rad)).toFloat()
                    drawCircle(
                        color = if (idx < activeDots) Color.White else Color.White.copy(alpha = 0.28f),
                        radius = 1.1.dp.toPx(),
                        center = Offset(dx, dy)
                    )
                }
            }

            Text(
                text = "$batteryPct",
                color = Color.White,
                fontSize = 7.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .offset(y = (-1).dp)
            )

            Icon(
                imageVector = if (wifiConnected) Icons.Rounded.Wifi else Icons.Rounded.WifiOff,
                contentDescription = "حالة الواي فاي",
                tint = Color.White.copy(alpha = if (wifiConnected) 0.9f else 0.4f),
                modifier = Modifier
                    .size(12.dp)
                    .offset(y = 2.dp)
            )
        }
    }
}
