package com.sumuw.launcher.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sumuw.launcher.ui.theme.GlassSurface
import com.sumuw.launcher.ui.theme.TitaniumBorder

data class MatchFixture(
    val league: String,
    val home: String,
    val away: String,
    val timeKsa: String,
    val channel: String
)

private val leaguesList = listOf(
    "الكل",
    "دوري روشن",
    "دوري أبطال أوروبا",
    "الإنجليزي",
    "الإسباني"
)

private val clubsList = listOf(
    "الهلال", "ريال مدريد", "النصر", "الاتحاد", "الأهلي",
    "برشلونة", "مانشستر سيتي", "ليفربول", "أرسنال"
)

private val sampleFixtures = listOf(
    MatchFixture("دوري روشن", "الهلال", "الاتحاد", "20:00 م", "SSC 1 HD"),
    MatchFixture("دوري روشن", "النصر", "الأهلي", "17:45 م", "SSC EXTRA 1"),
    MatchFixture("الإسباني", "ريال مدريد", "أتلتيكو مدريد", "23:00 م", "beIN Sports 1"),
    MatchFixture("الإنجليزي", "ليفربول", "مانشستر سيتي", "19:30 م", "beIN Sports 1"),
    MatchFixture("دوري أبطال أوروبا", "ريال مدريد", "أرسنال", "23:00 م", "beIN Sports 2"),
    MatchFixture("الإسباني", "برشلونة", "إشبيلية", "20:30 م", "beIN Sports 3")
)

@Composable
fun TodayMatchesWidget(accentColor: Color) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("sumuw_matches", Context.MODE_PRIVATE) }

    var selectedLeague by remember { mutableStateOf("الكل") }
    var showClubPicker by remember { mutableStateOf(false) }
    var onlyFollowed by remember { mutableStateOf(false) }

    var followedClubs by remember {
        mutableStateOf(
            prefs.getStringSet("followed_clubs", setOf("الهلال", "ريال مدريد"))
                ?: setOf("الهلال", "ريال مدريد")
        )
    }

    fun toggleClub(club: String) {
        val next = followedClubs.toMutableSet()
        if (next.contains(club)) next.remove(club) else next.add(club)
        followedClubs = next
        prefs.edit().putStringSet("followed_clubs", next).apply()
    }

    val visibleMatches = sampleFixtures.filter { match ->
        val leagueOk = selectedLeague == "الكل" || match.league == selectedLeague
        val clubOk = !onlyFollowed || followedClubs.contains(match.home) || followedClubs.contains(match.away)
        leagueOk && clubOk
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(GlassSurface)
            .border(1.dp, TitaniumBorder, RoundedCornerShape(22.dp))
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("مباريات اليوم", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = if (onlyFollowed) "أنديتي فقط ★" else "كل الأندية",
                    color = if (onlyFollowed) accentColor else Color.White.copy(alpha = 0.7f),
                    fontSize = 10.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White.copy(alpha = 0.08f))
                        .clickable { onlyFollowed = !onlyFollowed }
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                )
                Text(
                    text = if (showClubPicker) "تم" else "تحديد الأندية",
                    color = accentColor,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White.copy(alpha = 0.08f))
                        .clickable { showClubPicker = !showClubPicker }
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }

        if (showClubPicker) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                clubsList.forEach { club ->
                    val followed = followedClubs.contains(club)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (followed) accentColor.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.06f))
                            .border(
                                1.dp,
                                if (followed) accentColor else Color.Transparent,
                                RoundedCornerShape(10.dp)
                            )
                            .clickable { toggleClub(club) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = if (followed) Icons.Rounded.Star else Icons.Rounded.StarOutline,
                            contentDescription = null,
                            tint = if (followed) accentColor else Color.White.copy(alpha = 0.6f),
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(club, color = Color.White, fontSize = 10.sp)
                    }
                }
            }
        }

        // Leagues Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            leaguesList.forEach { league ->
                val selected = league == selectedLeague
                Text(
                    text = league,
                    fontSize = 10.sp,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                    color = if (selected) Color.Black else Color.White.copy(alpha = 0.75f),
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (selected) accentColor else Color.White.copy(alpha = 0.08f))
                        .clickable { selectedLeague = league }
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (visibleMatches.isEmpty()) {
                Text("لا توجد مباريات مطابقة للخيارات المحددة اليوم", color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
            } else {
                visibleMatches.take(3).forEach { m ->
                    val isFav = followedClubs.contains(m.home) || followedClubs.contains(m.away)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isFav) accentColor.copy(alpha = 0.12f) else Color.White.copy(alpha = 0.04f))
                            .border(
                                width = if (isFav) 1.dp else 0.dp,
                                color = if (isFav) accentColor.copy(alpha = 0.45f) else Color.Transparent,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .padding(horizontal = 10.dp, vertical = 7.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${m.home}  ×  ${m.away}",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = if (isFav) FontWeight.Bold else FontWeight.Medium
                            )
                            Text(
                                text = "${m.league} • ${m.channel}",
                                color = Color.White.copy(alpha = 0.65f),
                                fontSize = 10.sp
                            )
                        }
                        Text(
                            text = m.timeKsa,
                            color = accentColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
