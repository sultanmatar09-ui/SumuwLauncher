package com.sumuw.launcher.ui.screens

import android.content.Context
import android.icu.text.SimpleDateFormat as IcuDateFormat
import android.icu.util.IslamicUmalquraCalendar
import android.os.BatteryManager
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sumuw.launcher.ui.theme.GlassSurface
import com.sumuw.launcher.ui.theme.TitaniumBorder
import kotlinx.coroutines.delay
import java.util.Locale

@Composable
fun SmartStackWidget(accentColor: Color) {
    val context = LocalContext.current
    var activeCard by remember { mutableIntStateOf(0) }
    var focusSeconds by remember { mutableIntStateOf(25 * 60) }
    var focusRunning by remember { mutableStateOf(false) }

    LaunchedEffect(focusRunning) {
        while (focusRunning && focusSeconds > 0) {
            delay(1000L)
            focusSeconds--
        }
        if (focusSeconds == 0) focusRunning = false
    }

    val hijriDate = remember {
        val cal = IslamicUmalquraCalendar()
        IcuDateFormat("d MMMM yyyy هـ", Locale("ar")).apply {
            calendar = cal
        }.format(cal.time)
    }

    val batteryPct = remember {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(GlassSurface)
            .border(1.dp, TitaniumBorder, RoundedCornerShape(22.dp))
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("الهجري", "البطارية", "التركيز").forEachIndexed { idx, title ->
                    val selected = activeCard == idx
                    Text(
                        text = title,
                        fontSize = 11.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                        color = if (selected) accentColor else Color.White.copy(alpha = 0.55f),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (selected) Color.White.copy(alpha = 0.1f) else Color.Transparent)
                            .clickable { activeCard = idx }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
            Text("Smart Stack", fontSize = 10.sp, color = Color.White.copy(alpha = 0.45f))
        }

        Spacer(modifier = Modifier.height(10.dp))

        when (activeCard) {
            0 -> {
                Text(hijriDate, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text("تقويم أم القرى • جدة", color = Color.White.copy(alpha = 0.65f), fontSize = 11.sp)
            }
            1 -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("طاقة Samsung S25 Ultra", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                        Text("$batteryPct%", color = accentColor, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("شاشة AMOLED 120Hz", color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
                }
            }
            else -> {
                val m = (focusSeconds / 60).toString().padStart(2, '0')
                val s = (focusSeconds % 60).toString().padStart(2, '0')
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("$m:$s", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                    Row {
                        TextButton(onClick = { focusRunning = !focusRunning }) {
                            Text(if (focusRunning) "إيقاف" else "ابدأ", color = accentColor)
                        }
                        TextButton(onClick = {
                            focusRunning = false
                            focusSeconds = 25 * 60
                        }) {
                            Text("إعادة", color = Color.White.copy(alpha = 0.7f))
                        }
                    }
                }
            }
        }
    }
}
