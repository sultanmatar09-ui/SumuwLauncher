package com.sumuw.launcher.ui.screens

import android.graphics.Bitmap
import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.sumuw.launcher.R
import com.sumuw.launcher.data.AppRepository
import com.sumuw.launcher.data.InstalledApp
import com.sumuw.launcher.ui.theme.GlassSurface
import com.sumuw.launcher.ui.theme.ObsidianBlack
import com.sumuw.launcher.ui.theme.SumuwAccent
import com.sumuw.launcher.ui.theme.TitaniumBorder
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

data class SumuwWallpaper(
    val title: String,
    @DrawableRes val resId: Int?
)

@Composable
fun SumuwLauncherRoot(
    accent: SumuwAccent,
    onCycleAccent: () -> Unit
) {
    val context = LocalContext.current
    val apps = remember { AppRepository.loadLaunchableApps(context) }
    val wallpapers = remember {
        listOf(
            SumuwWallpaper("ذهب تيتانيوم", R.drawable.wp_titanium_gold),
            SumuwWallpaper("زخرفة عربية", R.drawable.wp_arabian_geo),
            SumuwWallpaper("حرير ياقوتي", R.drawable.wp_platinum_sapphire),
            SumuwWallpaper("شفق زمردي", R.drawable.wp_emerald_aurora),
            SumuwWallpaper("كثبان ليلية", R.drawable.wp_desert_twilight),
            SumuwWallpaper("أسود نقي", null)
        )
    }

    var selectedWpIdx by remember { mutableIntStateOf(0) }
    var showDrawer by remember { mutableStateOf(false) }
    var showWallpapers by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var currentTime by remember { mutableStateOf("") }
    var currentDate by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        val timeFmt = SimpleDateFormat("HH:mm", Locale.ENGLISH)
        val dateFmt = SimpleDateFormat("EEEE، d MMMM", Locale("ar"))
        while (true) {
            val now = Date()
            currentTime = timeFmt.format(now)
            currentDate = dateFmt.format(now)
            delay(1000L)
        }
    }

    val pagerState = rememberPagerState(pageCount = { 2 })

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
    ) {
        // Wallpaper Background
        wallpapers[selectedWpIdx].resId?.let { resId ->
            Image(
                painter = painterResource(id = resId),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.35f),
                                Color.Black.copy(alpha = 0.18f),
                                Color.Black.copy(alpha = 0.78f)
                            )
                        )
                    )
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Bar with Micro Battery & Wi-Fi Corner Badge (top-right)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "سُمو • S25 Ultra",
                        color = accent.color,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    IconButton(onClick = { showWallpapers = !showWallpapers }) {
                        Icon(Icons.Rounded.Image, contentDescription = "الخلفيات", tint = Color.White)
                    }
                    IconButton(onClick = onCycleAccent) {
                        Icon(Icons.Rounded.Palette, contentDescription = "تبديل السمة", tint = accent.color)
                    }
                }
                BatteryWifiCornerBadge(currentTime = currentTime)
            }

            // Optional Wallpaper Strip
            if (showWallpapers) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    wallpapers.forEachIndexed { idx, wp ->
                        val active = idx == selectedWpIdx
                        Box(
                            modifier = Modifier
                                .width(72.dp)
                                .height(92.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color.Black)
                                .border(
                                    width = if (active) 2.dp else 1.dp,
                                    color = if (active) accent.color else TitaniumBorder,
                                    shape = RoundedCornerShape(14.dp)
                                )
                                .clickable { selectedWpIdx = idx },
                            contentAlignment = Alignment.BottomCenter
                        ) {
                            wp.resId?.let { id ->
                                Image(
                                    painter = painterResource(id = id),
                                    contentDescription = wp.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Text(
                                text = wp.title,
                                color = Color.White,
                                fontSize = 9.sp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.Black.copy(alpha = 0.65f))
                                    .padding(vertical = 3.dp, horizontal = 4.dp),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            HorizontalPager(
                state = pagerState,
                modifier = Modifier.weight(1f)
            ) { page ->
                if (page == 0) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Hero Clock Card
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(24.dp))
                                .background(GlassSurface)
                                .border(1.dp, TitaniumBorder, RoundedCornerShape(24.dp))
                                .padding(18.dp)
                        ) {
                            Text(
                                text = currentTime,
                                color = Color.White,
                                fontSize = 44.sp,
                                fontWeight = FontWeight.Light
                            )
                            Text(
                                text = currentDate,
                                color = Color.White.copy(alpha = 0.78f),
                                fontSize = 13.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        SmartStackWidget(accentColor = accent.color)
                        Spacer(modifier = Modifier.height(14.dp))

                        LazyVerticalGrid(
                            columns = GridCells.Fixed(4),
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(apps.take(12)) { app ->
                                AppTileItem(app = app) {
                                    AppRepository.launchApp(context, app.packageName)
                                }
                            }
                        }
                    }
                } else {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        BreakingNewsWidget(accentColor = accent.color)
                        TodayMatchesWidget(accentColor = accent.color)
                        SPenCanvasWidget(accentColor = accent.color)
                    }
                }
            }

            // Glass Dock
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(GlassSurface)
                    .border(1.dp, TitaniumBorder, RoundedCornerShape(28.dp))
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilledIconButton(
                    onClick = { showDrawer = true },
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = accent.color)
                ) {
                    Icon(Icons.Rounded.Apps, contentDescription = "درج التطبيقات", tint = Color.Black)
                }
            }
        }

        // App Drawer Overlay
        if (showDrawer) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xEB050609))
                    .systemBarsPadding()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("درج التطبيقات", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    TextButton(onClick = { showDrawer = false }) {
                        Text("إغلاق", color = accent.color)
                    }
                }
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("ابحث عن تطبيق...") },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp)
                )
                val filtered = apps.filter { it.label.contains(searchQuery, ignoreCase = true) }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filtered) { app ->
                        AppTileItem(app = app) {
                            showDrawer = false
                            AppRepository.launchApp(context, app.packageName)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AppTileItem(app: InstalledApp, onClick: () -> Unit) {
    val bitmap: Bitmap = remember(app.packageName) {
        app.icon.toBitmap(width = 128, height = 128)
    }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(GlassSurface)
                .border(1.dp, TitaniumBorder, RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = app.label,
                modifier = Modifier.size(36.dp)
            )
        }
        Spacer(modifier = Modifier.height(5.dp))
        Text(
            text = app.label,
            color = Color.White.copy(alpha = 0.9f),
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
