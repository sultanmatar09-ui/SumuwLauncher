# سُمو لانشر (Sumuw Launcher) — Samsung Galaxy S25 Ultra

مشروع لانشر أندرويد أصيل مبني بلغة **Kotlin** و **Jetpack Compose** مع دعم كامل للغة العربية (RTL)، وشاشات AMOLED، ولوحة S Pen الفورية.

## خطوات البناء والتثبيت على S25 Ultra
1. افتح المجلد `SumuwLauncher` في **Android Studio** (إصدار Koala أو أحدث).
2. انتظر مزامنة **Gradle** ثم وصّل جهاز **Samsung Galaxy S25 Ultra** مع تفعيل تصحيح أخطاء USB (أو أنشئ ملف APK عبر `Build > Build Bundle(s) / APK(s) > Build APK(s)`).
3. بعد التثبيت، اضغط زر الرئيسية واختر **سُمو لانشر** كتطبيق الشاشة الرئيسية الافتراضي.
