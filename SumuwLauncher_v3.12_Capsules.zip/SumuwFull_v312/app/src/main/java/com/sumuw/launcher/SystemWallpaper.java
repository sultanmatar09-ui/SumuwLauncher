package com.sumuw.launcher;

import android.app.WallpaperManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import java.io.File;

/**
 * Makes the wallpaper chosen in Sara Home the phone's own wallpaper too (home and lock screen), so the
 * lock screen, the recent-apps screen and every app's background match the launcher. It runs only when
 * the choice changed, off the main thread. With Sara's live wallpaper on, nothing is copied: the live
 * wallpaper already draws the same picture everywhere.
 */
final class SystemWallpaper {
    static final String ENABLED = "sync_system_wallpaper";
    private static final String STAMP = "system_wallpaper_stamp";

    interface Done {
        void applied(boolean ok);
    }

    private SystemWallpaper() {
    }

    /** What the copied wallpaper depends on: the style, the photo and its blur, and the screen size. */
    static String stamp(Context context, String id, int width, int height) {
        StringBuilder stamp = new StringBuilder(id).append('/').append(width).append('x').append(height);
        if (Wallpapers.PHOTO.equals(id)) {
            File photo = new File(context.getFilesDir(), Wallpapers.PHOTO_FILE);
            stamp.append('/').append(photo.lastModified()).append('/')
                    .append(context.getSharedPreferences("duo_home", 0).getInt("photo_blur", 0));
        }
        return stamp.toString();
    }

    /** Portrait size of the whole screen, in pixels. */
    static int[] screenSize(Context context) {
        DisplayMetrics metrics = new DisplayMetrics();
        WindowManager windows = context.getSystemService(WindowManager.class);
        if (windows != null) {
            windows.getDefaultDisplay().getRealMetrics(metrics);
        } else {
            metrics = context.getResources().getDisplayMetrics();
        }
        int a = Math.max(1, metrics.widthPixels);
        int b = Math.max(1, metrics.heightPixels);
        return new int[]{Math.min(a, b), Math.max(a, b)};
    }

    /** Copies the launcher's wallpaper to the phone if it changed since the last copy. */
    static void syncIfNeeded(final Context context, final Done done) {
        final SharedPreferences prefs = context.getSharedPreferences("duo_home", 0);
        if (!prefs.getBoolean(ENABLED, true)) {
            return;
        }
        final String id = prefs.getString("wallpaper_style", Wallpapers.DEFAULT);
        if (Wallpapers.DEVICE.equals(id) || !Wallpapers.isKnown(id) || SaraWallpaper.onHome(context)) {
            return; // the phone's own picture, or the live wallpaper already shows Sara's
        }
        final int[] size = screenSize(context);
        // The lock screen may have a wallpaper of its own (chosen in the lock screen editor).
        final String lockId = LockScreen.wallpaper(prefs);
        // The size is left out: folding or unfolding a phone changes it, and setting the wallpaper again
        // makes Android recolour its theme, which restarts the open apps' screens (they seem to freeze).
        final String stamp = stamp(context, id, 0, 0) + "|lock:" + lockId;
        if (stamp.equals(prefs.getString(STAMP, ""))) {
            return;
        }
        final Context app = context.getApplicationContext();
        final Handler main = new Handler(Looper.getMainLooper());
        // The live wallpaper on the lock screen alone: the picture goes on the home screen only, never over it.
        final boolean keepLock = SaraWallpaper.onLock(context);
        new Thread(() -> {
            boolean ok = keepLock || lockId.equals(id) ? apply(app, id, size[0], size[1], keepLock)
                    : applyBoth(app, id, lockId, size[0], size[1]);
            if (ok) {
                prefs.edit().putString(STAMP, stamp).apply();
            }
            if (done != null) {
                main.post(() -> done.applied(ok));
            }
        }, "system-wallpaper").start();
    }

    /** Draws the wallpaper at screen size and sets it on the home and lock screens. */
    static boolean apply(Context context, String id, int width, int height) {
        return apply(context, id, width, height, false);
    }

    static boolean apply(Context context, String id, int width, int height, boolean homeOnly) {
        try {
            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            Drawable art = Wallpapers.create(context, id);
            art.setBounds(0, 0, width, height);
            art.draw(new Canvas(bitmap));
            WallpaperManager manager = WallpaperManager.getInstance(context);
            manager.setBitmap(bitmap, null, true, homeOnly ? WallpaperManager.FLAG_SYSTEM
                    : WallpaperManager.FLAG_SYSTEM | WallpaperManager.FLAG_LOCK);
            return true;
        } catch (Exception | OutOfMemoryError e) {
            return false;
        }
    }

    /** Home's picture on the home screen and the lock screen's own on the lock screen. */
    static boolean applyBoth(Context context, String homeId, String lockId, int width, int height) {
        try {
            WallpaperManager manager = WallpaperManager.getInstance(context);
            manager.setBitmap(draw(context, homeId, width, height), null, true, WallpaperManager.FLAG_SYSTEM);
            manager.setBitmap(draw(context, lockId, width, height), null, true, WallpaperManager.FLAG_LOCK);
            return true;
        } catch (Exception | OutOfMemoryError e) {
            return false;
        }
    }

    private static Bitmap draw(Context context, String id, int width, int height) {
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Drawable art = Wallpapers.create(context, id);
        art.setBounds(0, 0, width, height);
        art.draw(new Canvas(bitmap));
        return bitmap;
    }

    /** Forget the last copy, so the next check copies again (after turning the option back on). */
    static void reset(Context context) {
        context.getSharedPreferences("duo_home", 0).edit().remove(STAMP).apply();
    }
}
