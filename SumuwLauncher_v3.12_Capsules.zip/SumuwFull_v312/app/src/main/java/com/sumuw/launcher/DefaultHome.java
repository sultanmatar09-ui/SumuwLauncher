package com.sumuw.launcher;

import android.app.Activity;
import android.app.role.RoleManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.provider.Settings;

/**
 * Whether Sara Home is the phone's Home app. If it isn't, the Home button, closing all recent apps
 * and some system screens still go back to the phone's own launcher, so the user is asked once
 * with Android's own question.
 */
final class DefaultHome {
    static final int REQUEST = 7303;

    private DefaultHome() {
    }

    static boolean isDefault(Context context) {
        if (Build.VERSION.SDK_INT >= 29) {
            RoleManager roles = context.getSystemService(RoleManager.class);
            if (roles != null && roles.isRoleAvailable(RoleManager.ROLE_HOME)) {
                return roles.isRoleHeld(RoleManager.ROLE_HOME);
            }
        }
        try {
            ResolveInfo home = context.getPackageManager().resolveActivity(
                    new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY);
            return home != null && home.activityInfo != null && context.getPackageName().equals(home.activityInfo.packageName);
        } catch (Exception e) {
            return true; // can't tell: don't nag
        }
    }

    /** Android's own "use Sara Home as your Home app?" question; the settings page where that isn't offered. */
    static void ask(Activity activity) {
        if (Build.VERSION.SDK_INT >= 29) {
            RoleManager roles = activity.getSystemService(RoleManager.class);
            if (roles != null && roles.isRoleAvailable(RoleManager.ROLE_HOME) && !roles.isRoleHeld(RoleManager.ROLE_HOME)) {
                try {
                    activity.startActivityForResult(roles.createRequestRoleIntent(RoleManager.ROLE_HOME), REQUEST);
                    return;
                } catch (Exception ignored) {
                    // fall through to the settings page
                }
            }
        }
        openSettings(activity);
    }

    /** Settings → Default apps → Home app. Used when the question was turned down or isn't available. */
    static void openSettings(Activity activity) {
        try {
            activity.startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
        } catch (Exception e) {
            try {
                activity.startActivity(new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS));
            } catch (Exception ignored) {
            }
        }
    }
}
