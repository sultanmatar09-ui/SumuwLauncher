package com.sumuw.launcher;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Drawable;

/**
 * One shape for every icon: the phone's own, a circle, a squircle, a rounded square, a teardrop or an
 * arch. Adaptive icons (nearly all apps since Android 8) are cut to it from their two layers; older
 * icons, icon-pack icons and the user's own pictures stay as they are.
 */
final class IconShapes {
    static final String PREF = "icon_shape";
    static final String SYSTEM = "system";
    static final String[] SHAPES = {SYSTEM, "circle", "squircle", "rounded", "square", "cookie4", "cookie7", "teardrop", "arch"};

    private IconShapes() {
    }

    static int name(String shape) {
        switch (shape) {
            case "circle":
                return R.string.shape_circle;
            case "squircle":
                return R.string.shape_squircle;
            case "rounded":
                return R.string.shape_rounded;
            case "teardrop":
                return R.string.shape_teardrop;
            case "arch":
                return R.string.shape_arch;
            case "square":
                return R.string.shape_square;
            case "cookie4":
                return R.string.shape_cookie4;
            case "cookie7":
                return R.string.shape_cookie7;
            default:
                return R.string.shape_system;
        }
    }

    /** The outline in a box. */
    static Path path(String shape, RectF b) {
        Path path = new Path();
        float w = b.width();
        float h = b.height();
        switch (shape) {
            case "circle":
                path.addOval(b, Path.Direction.CW);
                break;
            case "squircle": {
                // A superellipse |x|^4 + |y|^4 = 1, as on iOS-like icons.
                float cx = b.centerX();
                float cy = b.centerY();
                for (int i = 0; i <= 96; i++) {
                    double t = 2 * Math.PI * i / 96;
                    double c = Math.cos(t);
                    double s = Math.sin(t);
                    float x = cx + (float) (Math.signum(c) * Math.pow(Math.abs(c), 0.5) * w / 2);
                    float y = cy + (float) (Math.signum(s) * Math.pow(Math.abs(s), 0.5) * h / 2);
                    if (i == 0) {
                        path.moveTo(x, y);
                    } else {
                        path.lineTo(x, y);
                    }
                }
                path.close();
                break;
            }
            case "rounded":
                path.addRoundRect(b, w * 0.24f, h * 0.24f, Path.Direction.CW);
                break;
            case "square":
                // Nearly square, with just enough rounding not to look cut (Android 16's square).
                path.addRoundRect(b, w * 0.09f, h * 0.09f, Path.Direction.CW);
                break;
            case "cookie4":
                cookie(path, b, 4, 0.085f, Math.PI / 4);
                break;
            case "cookie7":
                cookie(path, b, 7, 0.065f, -Math.PI / 2);
                break;
            case "teardrop": {
                // Round on three corners, a soft point at the bottom end (right in left-to-right).
                float r = w / 2f;
                float small = w * 0.12f;
                path.addRoundRect(b, new float[]{r, r, r, r, small, small, r, r}, Path.Direction.CW);
                break;
            }
            case "arch": {
                // A round top like an arch, square-ish at the bottom.
                float r = w / 2f;
                float small = w * 0.14f;
                path.addRoundRect(b, new float[]{r, r, r, r, small, small, small, small}, Path.Direction.CW);
                break;
            }
            default:
                path.addRoundRect(b, w * 0.30f, h * 0.30f, Path.Direction.CW);
                break;
        }
        return path;
    }

    /**
     * A "cookie" (Material's scalloped shape): a circle whose edge swells into soft lobes, the way
     * Android 16 offers four- and seven-sided ones. The radius follows a cosine, so every lobe is round.
     */
    static void cookie(Path path, RectF b, int lobes, float depth, double turn) {
        float cx = b.centerX();
        float cy = b.centerY();
        float outer = Math.min(b.width(), b.height()) / 2f;
        int steps = 180;
        for (int i = 0; i <= steps; i++) {
            double t = 2 * Math.PI * i / steps;
            double r = outer * (1 - depth + depth * Math.cos(lobes * (t - turn)));
            float x = cx + (float) (Math.cos(t) * r);
            float y = cy + (float) (Math.sin(t) * r);
            if (i == 0) {
                path.moveTo(x, y);
            } else {
                path.lineTo(x, y);
            }
        }
        path.close();
        // Lobes at the corners reach less far across: stretch it to fill the icon's box like the other shapes.
        RectF drawn = new RectF();
        path.computeBounds(drawn, true);
        if (drawn.width() > 0 && drawn.height() > 0) {
            android.graphics.Matrix fit = new android.graphics.Matrix();
            fit.setRectToRect(drawn, b, android.graphics.Matrix.ScaleToFit.CENTER);
            path.transform(fit);
        }
    }

    /** The icon in this shape (the system shape leaves it as it is). */
    static Drawable apply(Drawable icon, String shape) {
        if (SYSTEM.equals(shape) || icon == null) {
            return icon;
        }
        return new Shaped(icon, shape);
    }

    /**
     * An adaptive icon drawn from its layers through the chosen outline; an old-style icon (one picture)
     * sits smaller on a white tile of that outline, as Pixel and One UI show them.
     */
    static final class Shaped extends Drawable {
        final Drawable source;
        final String shape;
        private final Paint tile = new Paint(Paint.ANTI_ALIAS_FLAG);

        Shaped(Drawable source, String shape) {
            this.source = source;
            this.shape = shape;
            tile.setColor(0xFFFAFAFA);
        }

        @Override
        public void draw(Canvas canvas) {
            Rect b = getBounds();
            canvas.save();
            Path outline = path(shape, new RectF(b));
            canvas.clipPath(outline);
            if (source instanceof AdaptiveIconDrawable) {
                AdaptiveIconDrawable adaptive = (AdaptiveIconDrawable) source;
                // The layers are 108 units with the 72 in the middle showing: let them spill past the bounds.
                int extra = Math.round(b.width() * (108f / 72f - 1f) / 2f);
                Rect layer = new Rect(b.left - extra, b.top - extra, b.right + extra, b.bottom + extra);
                Drawable back = adaptive.getBackground();
                Drawable front = adaptive.getForeground();
                if (back != null) {
                    back.setBounds(layer);
                    back.draw(canvas);
                }
                if (front != null) {
                    front.setBounds(layer);
                    front.draw(canvas);
                }
            } else {
                canvas.drawPath(outline, tile);
                int inset = Math.round(b.width() * 0.16f);
                Rect old = source.copyBounds();
                source.setBounds(b.left + inset, b.top + inset, b.right - inset, b.bottom - inset);
                source.draw(canvas);
                source.setBounds(old);
            }
            canvas.restore();
        }

        @Override
        public int getIntrinsicWidth() {
            return source.getIntrinsicWidth();
        }

        @Override
        public int getIntrinsicHeight() {
            return source.getIntrinsicHeight();
        }

        @Override
        public void setAlpha(int alpha) {
            source.setAlpha(alpha);
            tile.setAlpha(alpha);
        }

        @Override
        public void setColorFilter(ColorFilter filter) {
            source.setColorFilter(filter);
        }

        @Override
        public int getOpacity() {
            return PixelFormat.TRANSLUCENT;
        }
    }
}
