package com.sumuw.launcher;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import java.util.Calendar;
import java.util.List;

/**
 * Evening-before reminders for the white days, Arafah, Ashura, Ramadan and the two Eids.
 * One alarm is scheduled at a time; each reminder schedules the next. Also re-arms after a reboot.
 */
public class ReminderReceiver extends BroadcastReceiver {
    static final String ACTION_REMIND = "com.sumuw.launcher.REMIND";
    private static final String CHANNEL = "occasions";
    private static final int REMINDER_HOUR = 20;
    private static final int REMINDER_MINUTE = 30;

    static final String ACTION_PRAYER = "com.sumuw.launcher.PRAYER";
    static final String ACTION_MATCH = "com.sumuw.launcher.MATCH";
    static final String ACTION_WATCH = "com.sumuw.launcher.MATCH_WATCH";
    static final String ACTION_WEATHER = "com.sumuw.launcher.WEATHER_CHECK";
    static final String ACTION_KHATMA = "com.sumuw.launcher.KHATMA";
    private static final String MATCH_CHANNEL = "matches";
    private static final String PRAYER_CHANNEL = "prayers";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (ACTION_REMIND.equals(intent.getAction())) {
            notify(context, intent.getIntExtra("kind", -1));
        } else if (ACTION_PRAYER.equals(intent.getAction())) {
            notifyPrayer(context, intent.getIntExtra("prayer", -1), intent.getLongExtra("at", 0L));
        } else if (ACTION_MATCH.equals(intent.getAction())) {
            notifyMatch(context, intent);
        } else if (ACTION_WATCH.equals(intent.getAction())) {
            watch(context, goAsync());
            return; // the watch arms the next alarms itself when it's done
        } else if (ACTION_WEATHER.equals(intent.getAction())) {
            checkWeather(context, goAsync());
            return;
        } else if (Breaker.ACTION.equals(intent.getAction())) {
            Breaker.remind(context, intent.getStringExtra("label"));
            return;
        } else if (ACTION_KHATMA.equals(intent.getAction())) {
            notifyKhatma(context);
            scheduleKhatma(context);
            return;
        }
        schedule(context);
    }

    /** Minutes before each prayer for the alert; 0 when it is off. */
    static int prayerAlertMinutes(SharedPreferences prefs) {
        return prefs.getBoolean("prayer_on", true) ? prefs.getInt("prayer_alert_min", 0) : 0;
    }

    /** Arms one alarm a few minutes before the next prayer; each alert arms the next. */
    static void schedulePrayer(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("duo_home", 0);
        AlarmManager alarms = context.getSystemService(AlarmManager.class);
        if (alarms == null) {
            return;
        }
        Intent base = new Intent(context, ReminderReceiver.class).setAction(ACTION_PRAYER);
        PendingIntent existing = PendingIntent.getBroadcast(context, 3, base, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_NO_CREATE);
        if (existing != null) {
            alarms.cancel(existing);
        }
        int minutes = prayerAlertMinutes(prefs);
        if (minutes <= 0) {
            prefs.edit().remove("prayer_alert_next").apply();
            return;
        }
        long now = System.currentTimeMillis();
        long from = now;
        for (int tries = 0; tries < 4; tries++) {
            long[] next = Prayers.next(prefs, from);
            long alertAt = next[1] - minutes * 60000L;
            if (alertAt > now + 15000L) {
                Intent intent = new Intent(base).putExtra("prayer", (int) next[0]).putExtra("at", next[1]);
                PendingIntent pending = PendingIntent.getBroadcast(context, 3, intent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
                boolean exact = Build.VERSION.SDK_INT < 31 || alarms.canScheduleExactAlarms();
                if (exact) {
                    alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, alertAt, pending);
                } else {
                    alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, alertAt, pending);
                }
                prefs.edit().putLong("prayer_alert_next", alertAt).apply();
                return;
            }
            from = next[1] + 1000L;
        }
    }

    /**
     * Arms one alarm before the next match of a favourite club (from the card's saved list); the alert
     * arms the next one, and every refresh of the list arms it again in case a kick-off moved.
     */
    static void scheduleMatch(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("duo_home", 0);
        AlarmManager alarms = context.getSystemService(AlarmManager.class);
        if (alarms == null) {
            return;
        }
        Intent base = new Intent(context, ReminderReceiver.class).setAction(ACTION_MATCH);
        PendingIntent existing = PendingIntent.getBroadcast(context, 5, base, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_NO_CREATE);
        if (existing != null) {
            alarms.cancel(existing);
        }
        int minutes = Matches.alertMinutes(prefs);
        prefs.edit().remove("match_alert_next").apply();
        if (minutes <= 0 || Matches.teamIds(prefs).isEmpty()) {
            return;
        }
        long now = System.currentTimeMillis();
        Matches.Match next = Matches.nextFavourite(prefs, now + minutes * 60000L + 15000L);
        if (next == null) {
            return;
        }
        long alertAt = next.time - minutes * 60000L;
        Intent intent = new Intent(base).putExtra("id", next.id).putExtra("home", next.home).putExtra("away", next.away)
                .putExtra("at", next.time).putExtra("league", next.league);
        PendingIntent pending = PendingIntent.getBroadcast(context, 5, intent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        boolean exact = Build.VERSION.SDK_INT < 31 || alarms.canScheduleExactAlarms();
        if (exact) {
            alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, alertAt, pending);
        } else {
            alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, alertAt, pending);
        }
        prefs.edit().putLong("match_alert_next", alertAt).putString("match_alert_id", next.id).apply();
    }

    // ---------------------------------------------------------------- goals

    static boolean goalAlerts(SharedPreferences prefs) {
        return prefs.getBoolean("match_goal_alerts", true);
    }

    /**
     * While a favourite club plays, Sara Home looks at the score every two minutes even with the screen
     * off; otherwise the next look is at its next kick-off. {@code at} 0 means "work it out".
     */
    static void scheduleWatch(Context context, long at) {
        SharedPreferences prefs = context.getSharedPreferences("duo_home", 0);
        AlarmManager alarms = context.getSystemService(AlarmManager.class);
        if (alarms == null) {
            return;
        }
        Intent base = new Intent(context, ReminderReceiver.class).setAction(ACTION_WATCH);
        PendingIntent existing = PendingIntent.getBroadcast(context, 7, base, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_NO_CREATE);
        if (existing != null) {
            alarms.cancel(existing);
        }
        if (!goalAlerts(prefs) || Matches.teamIds(prefs).isEmpty()) {
            prefs.edit().remove("match_watch_next").apply();
            return;
        }
        long now = System.currentTimeMillis();
        if (at <= 0) {
            at = favouritePlaying(prefs, now) ? now + 2 * 60000L : 0L;
            Matches.Match next = Matches.nextFavourite(prefs, now);
            if (at == 0L && next != null) {
                at = next.time + 60000L;
            }
        }
        if (at <= 0) {
            prefs.edit().remove("match_watch_next").apply();
            return;
        }
        PendingIntent pending = PendingIntent.getBroadcast(context, 7, base, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        boolean exact = Build.VERSION.SDK_INT < 31 || alarms.canScheduleExactAlarms();
        if (exact) {
            alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending);
        } else {
            alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending);
        }
        prefs.edit().putLong("match_watch_next", at).apply();
    }

    /** A favourite club's match is on, or kicked off less than two and a half hours ago and isn't marked over. */
    static boolean favouritePlaying(SharedPreferences prefs, long now) {
        java.util.Set<String> favourites = Matches.teamIds(prefs);
        for (Matches.Match match : Matches.cached(prefs)) {
            if (match.involves(favourites) && !match.finished() && match.time <= now + 60000L && match.time > now - 150 * 60000L) {
                return true;
            }
        }
        return false;
    }

    private static void watch(final Context context, final PendingResult result) {
        new Thread(() -> {
            try {
                SharedPreferences prefs = context.getSharedPreferences("duo_home", 0);
                long now = System.currentTimeMillis();
                java.util.Set<String> favourites = Matches.teamIds(prefs);
                java.util.LinkedHashSet<String> leagues = new java.util.LinkedHashSet<>();
                for (Matches.Match match : Matches.cached(prefs)) {
                    if (match.involves(favourites) && match.time < now + 15 * 60000L && match.time > now - 4 * 3600000L) {
                        leagues.add(match.league);
                    }
                }
                if (!leagues.isEmpty()) {
                    List<Matches.Match> fresh = Matches.fetch(leagues, now);
                    checkScores(context, fresh);
                    // Fold the fresh ones into the saved list.
                    java.util.LinkedHashMap<String, Matches.Match> merged = new java.util.LinkedHashMap<>();
                    for (Matches.Match match : Matches.cached(prefs)) {
                        merged.put(match.id, match);
                    }
                    for (Matches.Match match : fresh) {
                        merged.put(match.id, match);
                    }
                    java.util.ArrayList<Matches.Match> all = new java.util.ArrayList<>(merged.values());
                    Matches.sort(all);
                    Matches.store(prefs, all, prefs.getLong("matches_time", now));
                }
            } catch (Exception ignored) {
                // offline: try again at the next look
            } finally {
                try {
                    scheduleWatch(context, 0L);
                } catch (Exception ignored) {
                }
                result.finish();
            }
        }).start();
    }

    /**
     * Compares fresh scores of the favourite clubs' matches with the last ones told, and tells the new:
     * a goal (with the score and the minute) or the final result. Also used by Home's own refresh.
     */
    static void checkScores(Context context, List<Matches.Match> fresh) {
        SharedPreferences prefs = context.getSharedPreferences("duo_home", 0);
        if (!goalAlerts(prefs) || !canNotify(context)) {
            return;
        }
        java.util.Set<String> favourites = Matches.teamIds(prefs);
        org.json.JSONObject told;
        try {
            told = new org.json.JSONObject(prefs.getString("match_told", "{}"));
        } catch (Exception e) {
            told = new org.json.JSONObject();
        }
        boolean changed = false;
        for (Matches.Match match : fresh) {
            if (!match.involves(favourites) || !(match.live || match.finished()) || !match.hasScore()) {
                continue;
            }
            String now = match.homeScore + "-" + match.awayScore + "-" + (match.finished() ? "post" : "in");
            String before = told.optString(match.id, "");
            if (now.equals(before)) {
                continue;
            }
            try {
                told.put(match.id, now);
            } catch (Exception ignored) {
            }
            changed = true;
            if (before.isEmpty() && !match.finished() && "0-0-in".equals(now)) {
                continue; // just kicked off, nothing to tell yet
            }
            int homeBefore = 0;
            int awayBefore = 0;
            boolean overBefore = false;
            if (!before.isEmpty()) {
                String[] parts = before.split("-");
                try {
                    homeBefore = Integer.parseInt(parts[0]);
                    awayBefore = Integer.parseInt(parts[1]);
                    overBefore = parts.length > 2 && "post".equals(parts[2]);
                } catch (Exception ignored) {
                }
            }
            int homeNow;
            int awayNow;
            try {
                homeNow = Integer.parseInt(match.homeScore);
                awayNow = Integer.parseInt(match.awayScore);
            } catch (NumberFormatException e) {
                continue;
            }
            if (match.finished() && !overBefore) {
                notifyScore(context, match, null);
            } else if (homeNow > homeBefore || awayNow > awayBefore) {
                notifyScore(context, match, homeNow > homeBefore ? match.home : match.away);
            }
        }
        if (changed) {
            prefs.edit().putString("match_told", told.toString()).apply();
        }
    }

    /** "⚽ هدف للهلال" / "الهلال ٢ – ١ النصر · ٦٧'"; or "انتهت: ..." when {@code scorer} is null. */
    private static void notifyScore(Context context, Matches.Match match, String scorer) {
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (manager == null) {
            return;
        }
        manager.createNotificationChannel(new NotificationChannel(MATCH_CHANNEL, context.getString(R.string.match_channel), NotificationManager.IMPORTANCE_HIGH));
        boolean arabic = "ar".equals(java.util.Locale.getDefault().getLanguage());
        String line = Matches.arabic(match.home) + " " + digits(match.homeScore, arabic) + " – " + digits(match.awayScore, arabic) + " "
                + Matches.arabic(match.away);
        String title = scorer == null ? context.getString(R.string.match_final_title)
                : context.getString(R.string.match_goal_title, Matches.arabic(scorer));
        String body = scorer == null || match.clock.isEmpty() ? line : line + context.getString(R.string.list_separator) + "\u2066" + digits(match.clock, arabic) + "\u2069";
        Intent open = new Intent(context, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent content = PendingIntent.getActivity(context, 8, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification notification = new Notification.Builder(context, MATCH_CHANNEL)
                .setSmallIcon(R.drawable.ic_notify)
                .setContentTitle(title)
                .setContentText(body)
                .setContentIntent(content)
                .setAutoCancel(true)
                .setOnlyAlertOnce(false)
                .setTimeoutAfter(6 * 3600000L)
                .build();
        manager.notify(800 + Math.abs(match.id.hashCode() % 100), notification);
    }

    private static String digits(String text, boolean arabic) {
        if (!arabic) {
            return text;
        }
        StringBuilder out = new StringBuilder();
        for (char c : text.toCharArray()) {
            out.append(c >= '0' && c <= '9' ? (char) ('٠' + (c - '0')) : c);
        }
        return out.toString();
    }

    // ---------------------------------------------------------------- dust and rain

    /** Every three hours, a look at the coming hours' rain and dust (when weather alerts are on). */
    static void scheduleWeather(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("duo_home", 0);
        AlarmManager alarms = context.getSystemService(AlarmManager.class);
        if (alarms == null) {
            return;
        }
        Intent base = new Intent(context, ReminderReceiver.class).setAction(ACTION_WEATHER);
        PendingIntent existing = PendingIntent.getBroadcast(context, 9, base, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_NO_CREATE);
        if (existing != null) {
            alarms.cancel(existing);
        }
        if (!Weather.alertsOn(prefs)) {
            return;
        }
        PendingIntent pending = PendingIntent.getBroadcast(context, 9, base, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 3 * 3600000L, pending);
    }

    private static void checkWeather(final Context context, final PendingResult result) {
        new Thread(() -> {
            try {
                SharedPreferences prefs = context.getSharedPreferences("duo_home", 0);
                if (Weather.alertsOn(prefs)) {
                    double[] place = Places.here(prefs); // the last fix taken while Home was open
                    Weather.Now now = Weather.fetch(place[0], place[1]);
                    Weather.store(prefs, now);
                    Weather.storePlace(prefs, place[0], place[1]);
                    Weather.Alert alert = Weather.alert(now, Weather.fetchDust(place[0], place[1]), System.currentTimeMillis());
                    Weather.storeAlert(prefs, alert);
                    notifyWeather(context, alert);
                }
            } catch (Exception ignored) {
            } finally {
                try {
                    scheduleWeather(context);
                } catch (Exception ignored) {
                }
                result.finish();
            }
        }).start();
    }

    /** The khatma's daily reminder at the chosen time, while a khatma is going and today's portion isn't read. */
    static void scheduleKhatma(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("duo_home", 0);
        AlarmManager alarms = context.getSystemService(AlarmManager.class);
        if (alarms == null) {
            return;
        }
        Intent base = new Intent(context, ReminderReceiver.class).setAction(ACTION_KHATMA);
        PendingIntent existing = PendingIntent.getBroadcast(context, 11, base, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_NO_CREATE);
        if (existing != null) {
            alarms.cancel(existing);
        }
        int at = Khatma.remindAt(prefs);
        if (!Khatma.active(prefs) || Khatma.doneHalves(prefs) >= 60 || at < 0) {
            return;
        }
        java.util.Calendar next = java.util.Calendar.getInstance();
        next.set(java.util.Calendar.HOUR_OF_DAY, at / 60);
        next.set(java.util.Calendar.MINUTE, at % 60);
        next.set(java.util.Calendar.SECOND, 0);
        next.set(java.util.Calendar.MILLISECOND, 0);
        if (next.getTimeInMillis() <= System.currentTimeMillis() + 30000L) {
            next.add(java.util.Calendar.DAY_OF_YEAR, 1);
        }
        PendingIntent pending = PendingIntent.getBroadcast(context, 11, base, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pending);
    }

    /** "وردك اليوم: الجزء ١٢" — only when today's portion isn't marked read yet. */
    static void notifyKhatma(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("duo_home", 0);
        long now = System.currentTimeMillis();
        if (!Khatma.active(prefs) || Khatma.doneHalves(prefs) >= 60 || !canNotify(context)
                || Khatma.doneHalves(prefs) >= Khatma.dueHalves(prefs, now)) {
            return;
        }
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (manager == null) {
            return;
        }
        manager.createNotificationChannel(new NotificationChannel("khatma", context.getString(R.string.card_khatma), NotificationManager.IMPORTANCE_DEFAULT));
        Intent quran = Khatma.quranApp(context);
        Intent open = quran != null ? quran : new Intent(context, HomeActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent content = PendingIntent.getActivity(context, 12, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String text = context.getString(R.string.khatma_notify, Khatma.portion(context, prefs));
        Notification notification = new Notification.Builder(context, "khatma")
                .setSmallIcon(R.drawable.ic_notify)
                .setContentTitle(context.getString(R.string.card_khatma))
                .setContentText(text)
                .setContentIntent(content)
                .setAutoCancel(true)
                .build();
        manager.notify(950, notification);
    }

    /** Once per kind (rain, dust) every twelve hours at most. */
    static void notifyWeather(Context context, Weather.Alert alert) {
        if (alert == null || !canNotify(context)) {
            return;
        }
        SharedPreferences prefs = context.getSharedPreferences("duo_home", 0);
        long last = prefs.getLong("wx_alert_told_" + alert.kind, 0L);
        long now = System.currentTimeMillis();
        if (now - last < 12 * 3600000L) {
            return;
        }
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (manager == null) {
            return;
        }
        manager.createNotificationChannel(new NotificationChannel("weather", context.getString(R.string.weather_channel), NotificationManager.IMPORTANCE_DEFAULT));
        Intent open = new Intent(context, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent content = PendingIntent.getActivity(context, 10, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String text = Weather.alertText(context, alert);
        Notification notification = new Notification.Builder(context, "weather")
                .setSmallIcon(R.drawable.ic_notify)
                .setContentTitle(context.getString(alert.kind.equals("dust") ? R.string.wx_alert_dust_title : R.string.wx_alert_rain_title))
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(content)
                .setAutoCancel(true)
                .setTimeoutAfter(Math.max(3600000L, alert.until - now))
                .build();
        manager.notify(alert.kind.equals("dust") ? 901 : 902, notification);
        prefs.edit().putLong("wx_alert_told_" + alert.kind, now).apply();
    }

    /** "الهلال × النصر", "تبدأ بعد ١٥ د، ٨:٣٠ م على ثمانية · دوري روشن السعودي". */
    static void notifyMatch(Context context, Intent intent) {
        long at = intent.getLongExtra("at", 0L);
        String home = intent.getStringExtra("home");
        String away = intent.getStringExtra("away");
        if (at <= 0 || home == null || away == null || !canNotify(context)) {
            return;
        }
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (manager == null) {
            return;
        }
        manager.createNotificationChannel(new NotificationChannel(MATCH_CHANNEL, context.getString(R.string.match_channel), NotificationManager.IMPORTANCE_HIGH));
        String league = intent.getStringExtra("league");
        String teams = Matches.arabic(home) + " × " + Matches.arabic(away);
        String time = android.text.format.DateFormat.getTimeFormat(context).format(new java.util.Date(at));
        String channel = league == null ? "" : Matches.channel(league);
        String body = context.getString(R.string.match_alert_body, Prayers.countdown(context, Math.max(60000L, at - System.currentTimeMillis())), time)
                + (channel.length() == 0 ? "" : context.getString(R.string.list_separator) + context.getString(R.string.match_alert_channel, channel))
                + (league == null ? "" : context.getString(R.string.list_separator) + Matches.leagueName(league));
        Intent search = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com/search?q="
                + android.net.Uri.encode(Matches.arabic(home) + " ضد " + Matches.arabic(away)))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent content = PendingIntent.getActivity(context, 6, search, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification notification = new Notification.Builder(context, MATCH_CHANNEL)
                .setSmallIcon(R.drawable.ic_notify)
                .setContentTitle(teams)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setContentIntent(content)
                .setAutoCancel(true)
                .setTimeoutAfter(Math.max(60000L, at - System.currentTimeMillis() + 2 * 3600000L))
                .build();
        String id = intent.getStringExtra("id");
        manager.notify(300 + Math.abs((id == null ? teams : id).hashCode() % 500), notification);
    }

    private static void notifyPrayer(Context context, int prayer, long at) {
        if (prayer < 0 || at <= 0 || !canNotify(context)) {
            return;
        }
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (manager == null) {
            return;
        }
        SharedPreferences prefs = context.getSharedPreferences("duo_home", 0);
        manager.createNotificationChannel(new NotificationChannel(PRAYER_CHANNEL, context.getString(R.string.prayer_channel), NotificationManager.IMPORTANCE_HIGH));
        Intent open = new Intent(context, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent content = PendingIntent.getActivity(context, 4, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String title = context.getString(Prayers.NAMES[prayer]) + " " + Prayers.countdown(context, Math.max(60000L, at - System.currentTimeMillis()));
        Notification notification = new Notification.Builder(context, PRAYER_CHANNEL)
                .setSmallIcon(R.drawable.ic_notify)
                .setContentTitle(title)
                .setContentText(context.getString(R.string.prayer_alert_body, Prayers.timeText(context, prefs, at)))
                .setContentIntent(content)
                .setAutoCancel(true)
                .setTimeoutAfter(Math.max(60000L, at - System.currentTimeMillis() + 10 * 60000L))
                .build();
        manager.notify(200, notification);
    }

    static boolean enabled(SharedPreferences prefs) {
        return prefs.getBoolean("reminders_on", true);
    }

    static boolean canNotify(Context context) {
        return Build.VERSION.SDK_INT < 33
                || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    /** Arms the alarm for the next occasion's eve, or clears it when reminders are off. */
    static void schedule(Context context) {
        try {
            scheduleMatch(context);
            scheduleWatch(context, 0L);
        } catch (Exception ignored) {
        }
        try {
            scheduleWeather(context);
        } catch (Exception ignored) {
        }
        try {
            schedulePrayer(context);
        } catch (Exception ignored) {
        }
        try {
            scheduleKhatma(context);
        } catch (Exception ignored) {
        }
        SharedPreferences prefs = context.getSharedPreferences("duo_home", 0);
        AlarmManager alarms = context.getSystemService(AlarmManager.class);
        if (alarms == null) {
            return;
        }
        Intent base = new Intent(context, ReminderReceiver.class).setAction(ACTION_REMIND);
        PendingIntent existing = PendingIntent.getBroadcast(context, 1, base, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_NO_CREATE);
        if (existing != null) {
            alarms.cancel(existing);
        }
        if (!enabled(prefs)) {
            return;
        }
        long now = System.currentTimeMillis();
        List<HijriEvents.Occasion> coming = HijriEvents.upcoming(now, 12);
        for (HijriEvents.Occasion occasion : coming) {
            if (occasion.kind == HijriEvents.NEW_YEAR) {
                continue;
            }
            Calendar eve = Calendar.getInstance();
            eve.setTimeInMillis(occasion.start);
            eve.add(Calendar.DAY_OF_MONTH, -1);
            eve.set(Calendar.HOUR_OF_DAY, REMINDER_HOUR);
            eve.set(Calendar.MINUTE, REMINDER_MINUTE);
            if (eve.getTimeInMillis() <= now) {
                continue;
            }
            Intent intent = new Intent(base).putExtra("kind", occasion.kind);
            PendingIntent pending = PendingIntent.getBroadcast(context, 1, intent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, eve.getTimeInMillis(), pending);
            prefs.edit().putLong("reminder_next", eve.getTimeInMillis()).putInt("reminder_kind", occasion.kind).apply();
            return;
        }
    }

    static int titleRes(int kind) {
        switch (kind) {
            case HijriEvents.ASHURA:
                return R.string.remind_ashura_title;
            case HijriEvents.ARAFAH:
                return R.string.remind_arafah_title;
            case HijriEvents.RAMADAN:
                return R.string.remind_ramadan_title;
            case HijriEvents.EID_FITR:
                return R.string.remind_eid_fitr_title;
            case HijriEvents.EID_ADHA:
                return R.string.remind_eid_adha_title;
            default:
                return R.string.remind_white_title;
        }
    }

    static int bodyRes(int kind) {
        switch (kind) {
            case HijriEvents.ASHURA:
                return R.string.remind_ashura_body;
            case HijriEvents.ARAFAH:
                return R.string.remind_arafah_body;
            case HijriEvents.WHITE_DAYS:
                return R.string.remind_white_body;
            default:
                return R.string.remind_announcement_body;
        }
    }

    private static void notify(Context context, int kind) {
        if (kind < 0 || !canNotify(context)) {
            return;
        }
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (manager == null) {
            return;
        }
        manager.createNotificationChannel(new NotificationChannel(CHANNEL, context.getString(R.string.reminder_channel), NotificationManager.IMPORTANCE_DEFAULT));
        Intent open = new Intent(context, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent content = PendingIntent.getActivity(context, 2, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification notification = new Notification.Builder(context, CHANNEL)
                .setSmallIcon(R.drawable.ic_notify)
                .setContentTitle(context.getString(titleRes(kind)))
                .setContentText(context.getString(bodyRes(kind)))
                .setStyle(new Notification.BigTextStyle().bigText(context.getString(bodyRes(kind))))
                .setContentIntent(content)
                .setAutoCancel(true)
                .build();
        manager.notify(100 + kind, notification);
    }
}
