package com.sumuw.launcher;

import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/** League tables from ESPN's standings service, kept for three hours. */
final class Standings {
    static final long REFRESH_MS = 3L * 3600000L;
    /** The leagues that have a table (cups and the Asian and European competitions don't, in one list). */
    static final String[] LEAGUES = {"ksa.1", "eng.1", "esp.1", "ita.1", "ger.1", "fra.1", "ned.1", "por.1", "tur.1"};

    static final class Row {
        final int rank;
        final String teamId;
        final String name;
        final int played;
        final int won;
        final int drawn;
        final int lost;
        final String difference;
        final int points;
        final String logo;

        Row(int rank, String teamId, String name, int played, int won, int drawn, int lost, String difference, int points, String logo) {
            this.rank = rank;
            this.teamId = teamId;
            this.name = name;
            this.played = played;
            this.won = won;
            this.drawn = drawn;
            this.lost = lost;
            this.difference = difference;
            this.points = points;
            this.logo = logo;
        }
    }

    private Standings() {
    }

    static boolean hasTable(String league) {
        for (String one : LEAGUES) {
            if (one.equals(league)) {
                return true;
            }
        }
        return false;
    }

    /** The table worth showing: the league of the first favourite club with one, else the first chosen league with one. */
    static String league(SharedPreferences prefs) {
        for (Matches.Team team : Matches.teams(prefs)) {
            if (hasTable(team.league)) {
                return team.league;
            }
        }
        for (String league : Matches.leagues(prefs)) {
            if (hasTable(league)) {
                return league;
            }
        }
        return "ksa.1";
    }

    static List<Row> fetch(String league) throws Exception {
        return parse(Matches.get("https://site.api.espn.com/apis/v2/sports/soccer/" + league + "/standings"));
    }

    static List<Row> parse(String json) throws Exception {
        ArrayList<Row> rows = new ArrayList<>();
        JSONObject root = new JSONObject(json);
        JSONArray children = root.optJSONArray("children");
        JSONObject standings = children != null && children.length() > 0 ? children.getJSONObject(0).optJSONObject("standings")
                : root.optJSONObject("standings");
        JSONArray entries = standings == null ? null : standings.optJSONArray("entries");
        for (int i = 0; entries != null && i < entries.length(); i++) {
            JSONObject entry = entries.getJSONObject(i);
            JSONObject team = entry.optJSONObject("team");
            if (team == null) {
                continue;
            }
            int rank = 0;
            int played = 0;
            int won = 0;
            int drawn = 0;
            int lost = 0;
            int points = 0;
            String difference = "";
            JSONArray stats = entry.optJSONArray("stats");
            for (int s = 0; stats != null && s < stats.length(); s++) {
                JSONObject stat = stats.getJSONObject(s);
                String name = stat.optString("name");
                int value = (int) Math.round(stat.optDouble("value", 0));
                switch (name) {
                    case "rank":
                        rank = value;
                        break;
                    case "gamesPlayed":
                        played = value;
                        break;
                    case "wins":
                        won = value;
                        break;
                    case "ties":
                        drawn = value;
                        break;
                    case "losses":
                        lost = value;
                        break;
                    case "points":
                        points = value;
                        break;
                    case "pointDifferential":
                        difference = stat.optString("displayValue", String.valueOf(value));
                        break;
                    default:
                        break;
                }
            }
            JSONArray logos = team.optJSONArray("logos");
            String logo = logos != null && logos.length() > 0 ? logos.getJSONObject(0).optString("href", "") : "";
            rows.add(new Row(rank == 0 ? i + 1 : rank, team.optString("id"), team.optString("displayName", team.optString("name", "")),
                    played, won, drawn, lost, difference, points, logo));
        }
        Collections.sort(rows, (a, b) -> Integer.compare(a.rank, b.rank));
        return rows;
    }

    static void store(SharedPreferences prefs, String league, List<Row> rows, long when) {
        JSONArray array = new JSONArray();
        try {
            for (Row row : rows) {
                array.put(new JSONObject().put("r", row.rank).put("i", row.teamId).put("n", row.name).put("p", row.played)
                        .put("w", row.won).put("d", row.drawn).put("l", row.lost).put("gd", row.difference).put("pts", row.points)
                        .put("logo", row.logo));
            }
        } catch (Exception ignored) {
        }
        prefs.edit().putString("table_" + league, array.toString()).putLong("table_time_" + league, when).apply();
    }

    static List<Row> cached(SharedPreferences prefs, String league) {
        ArrayList<Row> rows = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(prefs.getString("table_" + league, "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject o = array.getJSONObject(i);
                rows.add(new Row(o.optInt("r"), o.optString("i"), o.optString("n"), o.optInt("p"), o.optInt("w"), o.optInt("d"),
                        o.optInt("l"), o.optString("gd"), o.optInt("pts"), o.optString("logo")));
            }
        } catch (Exception ignored) {
        }
        return rows;
    }

    static boolean stale(SharedPreferences prefs, String league, long now) {
        return now - prefs.getLong("table_time_" + league, 0L) > REFRESH_MS;
    }

    /** The top rows, plus the favourite clubs' rows further down, in table order. */
    static List<Row> excerpt(List<Row> rows, java.util.Set<String> favourites, int top) {
        ArrayList<Row> shown = new ArrayList<>();
        for (Row row : rows) {
            if (shown.size() < top || favourites.contains(row.teamId)) {
                shown.add(row);
            }
        }
        // Too long now? Keep the favourites, drop from the bottom of the top part.
        while (shown.size() > top + 1) {
            for (int i = shown.size() - 1; i >= 0; i--) {
                if (!favourites.contains(shown.get(i).teamId)) {
                    shown.remove(i);
                    break;
                }
            }
            if (shown.size() > top + 1 && allFavourites(shown, favourites)) {
                break;
            }
        }
        return shown;
    }

    private static boolean allFavourites(List<Row> rows, java.util.Set<String> favourites) {
        for (Row row : rows) {
            if (!favourites.contains(row.teamId)) {
                return false;
            }
        }
        return true;
    }
}
