package com.sumuw.launcher;

import android.accessibilityservice.AccessibilityService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.provider.Settings;
import android.view.accessibility.AccessibilityEvent;
import java.util.Locale;

/**
 * Lets Sara Home lock the screen on a double tap and open the notification shade, the two things Android
 * only allows through an accessibility service. It reads no screen content and listens to no other app
 * (its events are limited to Sara Home itself); the user turns it on once in the system's settings.
 */
public class LockService extends AccessibilityService {
    private static LockService instance;

    @Override
    protected void onServiceConnected() {
        instance = this;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
    }

    static boolean running() {
        return instance != null;
    }

    /** Locks the phone like the power button. Needs Android 9 and the service turned on. */
    static boolean lockScreen() {
        return Build.VERSION.SDK_INT >= 28 && instance != null
                && instance.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN);
    }

    /**
     * Turns the service off when double tap to lock is turned off. While any accessibility service is on,
     * Android tells every app so, and some apps (built with Flutter or React Native, banks, games) do
     * extra work on every frame for it and can stutter or freeze; so it stays on only while it's used.
     */
    static boolean release() {
        if (instance == null || Build.VERSION.SDK_INT < 24) {
            return false;
        }
        try {
            instance.disableSelf();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    static boolean showNotifications() {
        return instance != null && instance.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS);
    }

    /** Whether the user switched it on in the system's accessibility settings. */
    static boolean enabled(Context context) {
        String list = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (list == null) {
            return false;
        }
        ComponentName me = new ComponentName(context, LockService.class);
        String all = list.toLowerCase(Locale.ROOT);
        return all.contains(me.flattenToString().toLowerCase(Locale.ROOT))
                || all.contains(me.flattenToShortString().toLowerCase(Locale.ROOT));
    }
}
