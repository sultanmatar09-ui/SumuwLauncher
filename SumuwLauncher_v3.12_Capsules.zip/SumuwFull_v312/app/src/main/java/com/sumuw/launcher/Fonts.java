package com.sumuw.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Build;

/**
 * Sara Home's font: Arabic Naskh (Noto Naskh Arabic UI, bundled) by default, or the phone's own font.
 * Latin letters and symbols the Naskh font lacks come from the phone's font either way.
 */
final class Fonts {
    static final String PREF = "font_style";
    static final String NASKH = "naskh";
    static final String SYSTEM = "system";

    private static Typeface naskh;
    private static boolean useNaskh = true;

    private Fonts() {
    }

    static String style(SharedPreferences prefs) {
        return SYSTEM.equals(prefs.getString(PREF, NASKH)) ? SYSTEM : NASKH;
    }

    /** Reads the choice and loads the font once; call it when a screen or the wallpaper starts, and after a change. */
    static void init(Context context) {
        useNaskh = NASKH.equals(style(context.getSharedPreferences("duo_home", 0)));
        if (useNaskh && naskh == null) {
            try {
                naskh = context.getResources().getFont(R.font.naskh);
            } catch (Exception e) {
                naskh = null; // the phone's font, rather than nothing
            }
        }
    }

    static boolean naskh() {
        return useNaskh && naskh != null;
    }

    static Typeface base() {
        return naskh() ? naskh : Typeface.DEFAULT;
    }

    /** The font at a weight: 400 normal, 500 medium, 600 and up bold (Naskh has 400 and 700). */
    static Typeface of(int weight) {
        Typeface base = base();
        if (Build.VERSION.SDK_INT >= 28) {
            return Typeface.create(base, weight, false);
        }
        if (weight >= 600) {
            return Typeface.create(base, Typeface.BOLD);
        }
        return weight >= 500 && !naskh() ? Typeface.create("sans-serif-medium", Typeface.NORMAL) : base;
    }

    /** The theme for an activity: the Naskh one sets the font of dialogs and system widgets too. */
    static int theme(boolean settings) {
        if (!naskh()) {
            return settings ? R.style.SettingsTheme : R.style.AppTheme;
        }
        return settings ? R.style.SettingsTheme_Naskh : R.style.AppTheme_Naskh;
    }
}
