package com.sumuw.launcher;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import java.util.Locale;

/**
 * Battery, Wi-Fi and mobile signal in one round gauge: the ring is the battery (open at the bottom,
 * filling clockwise from the lower left), the percentage sits in a gap at the top, the Wi-Fi symbol is
 * in the middle, and five dots along the bottom opening show the mobile signal.
 */
final class StatusRing extends Drawable {
    private static final int GREEN = 0xFF34C759;
    private static final int YELLOW = 0xFFFFCC00;
    private static final int RED = 0xFFFF3B30;
    private static final float START = 135f;   // lower left
    private static final float SWEEP = 270f;   // to lower right, leaving the bottom open
    private static final float TOP = 270f;     // twelve o'clock in Android's angle system

    private final int color;
    private final int faint;
    private final int size;
    private int level = -1;
    private boolean charging;
    private boolean saver;
    private boolean wifiConnected;
    private int wifiLevel;        // 0..3
    private int signalLevel = -1; // 0..4, -1 when unknown or no SIM
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dots = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();

    StatusRing(int color, int sizePx) {
        this.color = color;
        this.faint = (((int) (((color >>> 24) & 0xFF) * 0.28f)) << 24) | (color & 0x00FFFFFF);
        this.size = sizePx;
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeCap(Paint.Cap.ROUND);
        text.setTypeface(Fonts.of(700));
        text.setTextAlign(Paint.Align.CENTER);
    }

    void setBattery(int level, boolean charging, boolean saver) {
        this.level = level;
        this.charging = charging;
        this.saver = saver;
        invalidateSelf();
    }

    void setWifi(boolean connected, int level) {
        this.wifiConnected = connected;
        this.wifiLevel = Math.max(0, Math.min(3, level));
        invalidateSelf();
    }

    private boolean network = true;

    /** Without network (on the lock screen): a battery ring with the percentage in the middle. */
    void setNetworkVisible(boolean visible) {
        network = visible;
        invalidateSelf();
    }

    void setSignal(int level) {
        this.signalLevel = level;
        invalidateSelf();
    }

    int fillColor() {
        if (charging) {
            return GREEN;
        }
        if (saver) {
            return YELLOW;
        }
        return level >= 0 && level <= 20 ? RED : color;
    }

    /** How many of the five dots are lit for a 0..4 signal level. */
    static int litDots(int signalLevel) {
        return signalLevel < 0 ? 0 : Math.round(signalLevel * 5f / 4f);
    }

    @Override
    public void draw(Canvas canvas) {
        Rect b = getBounds();
        float s = Math.min(b.width(), b.height());
        float cx = b.exactCenterX();
        float cy = b.exactCenterY();
        float radius = s * 0.40f;
        float stroke = s * 0.075f;
        oval.set(cx - radius, cy - radius, cx + radius, cy + radius);
        ring.setStrokeWidth(stroke);

        if (!network) {
            drawBatteryOnly(canvas, cx, cy, s, radius, stroke);
            return;
        }
        // The percentage sits in a gap at the top of the ring.
        String digits = level < 0 ? "" : String.format(Locale.getDefault(), "%d", level);
        text.setTextSize(s * 0.24f);
        float gap = 0f;
        if (digits.length() > 0) {
            float half = text.measureText(digits) / 2f + stroke * 1.2f;
            gap = (float) Math.toDegrees(Math.asin(Math.min(1f, half / radius)));
        }
        float leftEnd = TOP - gap;   // end of the left-hand part of the ring
        float rightStart = TOP + gap; // start of the right-hand part
        float end = START + SWEEP;

        ring.setColor(faint);
        canvas.drawArc(oval, START, leftEnd - START, false, ring);
        canvas.drawArc(oval, rightStart, end - rightStart, false, ring);

        if (level > 0) {
            float progress = START + SWEEP * Math.min(100, level) / 100f;
            ring.setColor(fillColor());
            canvas.drawArc(oval, START, Math.max(0.5f, Math.min(progress, leftEnd) - START), false, ring);
            if (progress > rightStart) {
                canvas.drawArc(oval, rightStart, progress - rightStart, false, ring);
            }
        }

        if (digits.length() > 0) {
            text.setColor(color);
            float baseline = cy - radius - (text.ascent() + text.descent()) / 2f;
            canvas.drawText(digits, cx, baseline, text);
        }

        // Wi-Fi: a dot and three arcs, lit up to the signal strength.
        float dotY = cy + s * 0.105f;
        ring.setStrokeWidth(s * 0.046f);
        float[] radii = {s * 0.082f, s * 0.148f, s * 0.214f};
        for (int i = 0; i < radii.length; i++) {
            boolean lit = wifiConnected && i < wifiLevel;
            ring.setColor(lit ? color : faint);
            float r = radii[i];
            oval.set(cx - r, dotY - r, cx + r, dotY + r);
            canvas.drawArc(oval, 225f, 90f, false, ring);
        }
        dots.setColor(wifiConnected ? color : faint);
        canvas.drawCircle(cx, dotY, s * 0.035f, dots);

        // Mobile signal: five dots spread across the opening at the bottom.
        int lit = litDots(signalLevel);
        for (int i = 0; i < 5; i++) {
            double angle = Math.toRadians(120 - i * 15); // from lower left to lower right
            float x = cx + (float) Math.cos(angle) * radius;
            float y = cy + (float) Math.sin(angle) * radius;
            dots.setColor(i < lit ? color : faint);
            canvas.drawCircle(x, y, s * 0.036f, dots);
        }
    }

    private void drawBatteryOnly(Canvas canvas, float cx, float cy, float s, float radius, float stroke) {
        ring.setColor(faint);
        canvas.drawArc(oval, START, SWEEP, false, ring);
        if (level > 0) {
            ring.setColor(fillColor());
            canvas.drawArc(oval, START, Math.max(0.5f, SWEEP * Math.min(100, level) / 100f), false, ring);
        }
        if (level >= 0) {
            text.setColor(color);
            text.setTextSize(s * 0.27f);
            canvas.drawText(String.format(Locale.getDefault(), "%d", level), cx, cy - (text.ascent() + text.descent()) / 2f, text);
        }
        if (charging) {
            // a small bolt in the opening at the bottom
            dots.setColor(GREEN);
            android.graphics.Path bolt = new android.graphics.Path();
            float u = s / 24f;
            float by = cy + radius - u * 1.2f;
            bolt.moveTo(cx + u * 0.6f, by - u * 2.2f);
            bolt.lineTo(cx - u * 1.2f, by + u * 0.3f);
            bolt.lineTo(cx, by + u * 0.3f);
            bolt.lineTo(cx - u * 0.6f, by + u * 2.4f);
            bolt.lineTo(cx + u * 1.2f, by - u * 0.2f);
            bolt.lineTo(cx, by - u * 0.2f);
            bolt.close();
            canvas.drawPath(bolt, dots);
        }
    }

    @Override
    public int getIntrinsicWidth() {
        return size;
    }

    @Override
    public int getIntrinsicHeight() {
        return size;
    }

    @Override
    public void setAlpha(int alpha) {
        text.setAlpha(alpha);
    }

    @Override
    public void setColorFilter(ColorFilter colorFilter) {
        ring.setColorFilter(colorFilter);
        dots.setColorFilter(colorFilter);
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }
}
