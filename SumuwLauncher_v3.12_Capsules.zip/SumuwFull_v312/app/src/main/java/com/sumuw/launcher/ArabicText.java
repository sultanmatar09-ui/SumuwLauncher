package com.sumuw.launcher;

import java.text.Normalizer;
import java.util.Locale;

/**
 * Search helpers that treat Arabic spelling variants as equal, so typing
 * "اذاعه" finds "إذاعة" and "واتس اب" finds "واتساب".
 */
final class ArabicText {
    private ArabicText() {
    }

    /** Lower-cases, strips diacritics/tashkeel/tatweel and unifies common Arabic letter variants. */
    static String normalize(CharSequence input) {
        if (input == null || input.length() == 0) {
            return "";
        }
        // NFD splits أ إ آ ؤ ئ into a base letter plus a hamza/madda mark, and é into e + accent.
        String decomposed = Normalizer.normalize(input, Normalizer.Form.NFD);
        StringBuilder out = new StringBuilder(decomposed.length());
        boolean pendingSpace = false;
        for (int i = 0; i < decomposed.length(); i++) {
            char c = decomposed.charAt(i);
            int type = Character.getType(c);
            if (type == Character.NON_SPACING_MARK || type == Character.ENCLOSING_MARK
                    || type == Character.FORMAT || c == 'ـ') {
                continue; // tashkeel, hamza/madda marks, accents, RLM/LRM/ZWNJ, tatweel
            }
            switch (c) {
                case 'ٱ': // ٱ
                case 'آ': // آ
                case 'أ': // أ
                case 'إ': // إ
                    c = 'ا';
                    break;
                case 'ة': // ة
                    c = 'ه';
                    break;
                case 'ى': // ى
                case 'ئ': // ئ
                case 'ی': // ی
                    c = 'ي';
                    break;
                case 'ؤ': // ؤ
                    c = 'و';
                    break;
                case 'ک': // ک
                    c = 'ك';
                    break;
                default:
                    break;
            }
            if (c >= '٠' && c <= '٩') {
                c = (char) ('0' + (c - '٠'));
            } else if (c >= '۰' && c <= '۹') {
                c = (char) ('0' + (c - '۰'));
            }
            if (!Character.isLetterOrDigit(c)) {
                pendingSpace = out.length() > 0;
                continue;
            }
            if (pendingSpace) {
                out.append(' ');
                pendingSpace = false;
            }
            out.append(Character.toLowerCase(c));
        }
        return out.toString().toLowerCase(Locale.ROOT);
    }

    /**
     * Where the query shows up in the label as it is written, as {start, end} in the label's own
     * characters, or null. Each character is normalized on its own, so "أ" in the name still lines up
     * with "ا" typed, and the marks the search ignores (tashkeel) are skipped.
     */
    static int[] matchRange(String label, String query) {
        String wanted = normalize(query);
        if (label == null || wanted.isEmpty()) {
            return null;
        }
        StringBuilder flat = new StringBuilder(label.length());
        int[] origin = new int[label.length() * 2 + 2];
        boolean space = false;
        for (int i = 0; i < label.length(); i++) {
            char c = label.charAt(i);
            String one = normalize(String.valueOf(c));
            if (one.isEmpty()) {
                space = space || (!Character.isLetterOrDigit(c) && Character.getType(c) != Character.NON_SPACING_MARK && flat.length() > 0);
                continue;
            }
            if (space) {
                origin[flat.length()] = i;
                flat.append(' ');
                space = false;
            }
            for (int k = 0; k < one.length() && flat.length() < origin.length - 1; k++) {
                origin[flat.length()] = i;
                flat.append(one.charAt(k));
            }
        }
        int at = flat.indexOf(wanted);
        if (at < 0) {
            String compact = wanted.replace(" ", "");
            at = compact.isEmpty() ? -1 : flat.indexOf(compact);
            if (at < 0) {
                return null;
            }
            wanted = compact;
        }
        int start = origin[at];
        int end = origin[at + wanted.length() - 1] + 1;
        while (end < label.length() && Character.getType(label.charAt(end)) == Character.NON_SPACING_MARK) {
            end++; // keep a letter's marks with it
        }
        return new int[]{start, end};
    }

    /**
     * Ranks how well a normalized label matches a normalized query.
     * Lower is better; -1 means no match.
     */
    static int matchScore(String label, String packageName, String query) {
        if (query.length() == 0) {
            return 0;
        }
        boolean contained = false;
        int from = 0;
        while (true) {
            int at = label.indexOf(query, from);
            if (at < 0) {
                break;
            }
            if (at == 0) {
                return 0; // label starts with the query
            }
            if (label.charAt(at - 1) == ' ') {
                return 1; // a word inside the label starts with the query
            }
            contained = true;
            from = at + 1;
        }
        if (contained) {
            return 2;
        }
        String compactQuery = query.replace(" ", "");
        String compactLabel = label.replace(" ", "");
        if (compactQuery.length() > 0 && compactLabel.contains(compactQuery)) {
            return 3;
        }
        if (packageName != null && compactQuery.length() >= 2
                && packageName.toLowerCase(Locale.ROOT).contains(compactQuery)) {
            return 4;
        }
        if (compactQuery.length() >= 3 && isSubsequence(compactQuery, compactLabel)) {
            return 5;
        }
        return -1;
    }

    private static boolean isSubsequence(String needle, String haystack) {
        int n = 0;
        for (int h = 0; h < haystack.length() && n < needle.length(); h++) {
            if (haystack.charAt(h) == needle.charAt(n)) {
                n++;
            }
        }
        return n == needle.length();
    }
}
