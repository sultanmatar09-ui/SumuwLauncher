package com.sumuw.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.text.TextUtils;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Icons the user picked for single apps: a picture of their own (cut to a rounded square like the other
 * icons) or one icon out of an installed icon pack. They are saved as small PNG files in the app's own
 * storage, so they stay put when the pack or the photo is gone, and they win over packs and themed icons.
 */
final class CustomIcons {
    static final String PREF = "custom_icons";
    static final int SIZE = 192;

    private CustomIcons() {
    }

    static Set<String> keys(SharedPreferences prefs) {
        LinkedHashSet<String> keys = new LinkedHashSet<>();
        for (String part : prefs.getString(PREF, "").split("\\|")) {
            if (part.length() > 0) {
                keys.add(part);
            }
        }
        return keys;
    }

    private static void saveKeys(SharedPreferences prefs, Set<String> keys) {
        prefs.edit().putString(PREF, TextUtils.join("|", keys)).apply();
    }

    static File file(Context context, String key) {
        File folder = new File(context.getFilesDir(), "icons");
        String safe = key.replaceAll("[^A-Za-z0-9._-]", "_");
        return new File(folder, safe + "_" + Integer.toHexString(key.hashCode()) + ".png");
    }

    static boolean has(SharedPreferences prefs, String key) {
        return keys(prefs).contains(key);
    }

    /** The saved icon, or null. */
    static Drawable load(Context context, String key) {
        File file = file(context, key);
        if (!file.exists()) {
            return null;
        }
        Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
        return bitmap == null ? null : new BitmapDrawable(context.getResources(), bitmap);
    }

    /** A picture from the phone, cropped to its middle square and given the rounded icon shape. */
    static boolean saveFromPicture(Context context, Uri uri, String key) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (InputStream in = context.getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(in, null, bounds);
            }
            int shortest = Math.min(bounds.outWidth, bounds.outHeight);
            if (shortest <= 0) {
                return false;
            }
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 1;
            while (shortest / (options.inSampleSize * 2) >= SIZE) {
                options.inSampleSize *= 2;
            }
            Bitmap picture;
            try (InputStream in = context.getContentResolver().openInputStream(uri)) {
                picture = BitmapFactory.decodeStream(in, null, options);
            }
            if (picture == null) {
                return false;
            }
            return save(context, key, rounded(picture));
        } catch (Exception | OutOfMemoryError e) {
            return false;
        }
    }

    /** An icon from a pack, drawn as it is (packs give their icons their own shape). */
    static boolean saveFromDrawable(Context context, Drawable drawable, String key) {
        try {
            Bitmap bitmap = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            Drawable copy = drawable.getConstantState() != null ? drawable.getConstantState().newDrawable().mutate() : drawable;
            copy.setBounds(0, 0, SIZE, SIZE);
            copy.draw(canvas);
            return save(context, key, bitmap);
        } catch (Exception | OutOfMemoryError e) {
            return false;
        }
    }

    static void clear(Context context, SharedPreferences prefs, String key) {
        Set<String> keys = keys(prefs);
        keys.remove(key);
        saveKeys(prefs, keys);
        File file = file(context, key);
        if (file.exists() && !file.delete()) {
            file.deleteOnExit();
        }
    }

    private static boolean save(Context context, String key, Bitmap bitmap) throws Exception {
        File file = file(context, key);
        File folder = file.getParentFile();
        if (folder != null && !folder.exists() && !folder.mkdirs()) {
            return false;
        }
        File temp = new File(file.getPath() + ".tmp");
        try (FileOutputStream out = new FileOutputStream(temp)) {
            if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                return false;
            }
        }
        if (!temp.renameTo(file)) {
            return false;
        }
        SharedPreferences prefs = context.getSharedPreferences("duo_home", 0);
        Set<String> keys = keys(prefs);
        keys.add(key);
        saveKeys(prefs, keys);
        return true;
    }

    /** Centre square of the picture inside a rounded square with the corner of One UI's icons. */
    static Bitmap rounded(Bitmap picture) {
        int side = Math.min(picture.getWidth(), picture.getHeight());
        float scale = SIZE / (float) side;
        Matrix matrix = new Matrix();
        matrix.setScale(scale, scale);
        matrix.postTranslate(-(picture.getWidth() - side) / 2f * scale, -(picture.getHeight() - side) / 2f * scale);
        BitmapShader shader = new BitmapShader(picture, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
        shader.setLocalMatrix(matrix);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        paint.setShader(shader);
        Bitmap out = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out);
        // Same inset as adaptive icons drawn by the system, so the picture isn't bigger than its neighbours.
        float inset = SIZE * 0.04f;
        RectF shape = new RectF(inset, inset, SIZE - inset, SIZE - inset);
        float radius = shape.width() * 0.30f;
        canvas.drawRoundRect(shape, radius, radius, paint);
        return out;
    }

    /** A word to look for in a pack: "twitter" for com.twitter.android, "whatsapp" for com.whatsapp. */
    static String searchHint(String packageName) {
        String[] parts = packageName.toLowerCase(java.util.Locale.ROOT).split("\\.");
        String[] skip = {"com", "org", "net", "android", "app", "apps", "mobile", "www", "co", "io", "me", "lite", "free"};
        String best = "";
        for (String part : parts) {
            boolean common = false;
            for (String word : skip) {
                if (word.equals(part)) {
                    common = true;
                    break;
                }
            }
            if (!common && part.length() > best.length()) {
                best = part;
            }
        }
        return best;
    }
}
