package com.sumuw.launcher;

import android.content.ClipDescription;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * What was just copied, offered at the top of the search: a phone number to call or message on
 * WhatsApp, a link to open, an e-mail address to write to, a parcel number to track. It reads the
 * clipboard only when something new was copied in the last ten minutes, and only when search opens,
 * so Android's "pasted from your clipboard" note comes up once per copy, not every time.
 */
final class ClipSuggest {
    static final String PHONE = "phone";
    static final String LINK = "link";
    static final String EMAIL = "email";
    static final String PARCEL = "parcel";
    static final String TEXT = "text";

    private static final Pattern SAUDI_MOBILE = Pattern.compile("^(?:\\+?966|00966|0)?5\\d{8}$");
    private static final Pattern ANY_PHONE = Pattern.compile("^\\+\\d{8,15}$");
    private static final Pattern EMAIL_ADDRESS = Pattern.compile("^[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+$");
    /** Saudi Post and the world's posts: two letters, nine digits, two letters. */
    private static final Pattern POST_PARCEL = Pattern.compile("^[A-Z]{2}\\d{9}[A-Z]{2}$");
    /** SMSA, Aramex, DHL and the like: a long run of digits that isn't a phone. */
    private static final Pattern COURIER_PARCEL = Pattern.compile("^\\d{10,14}$");

    private ClipSuggest() {
    }

    /** The copied text and what it is. */
    static final class Clip {
        final String kind;
        final String text;

        Clip(String kind, String text) {
            this.kind = kind;
            this.text = text;
        }
    }

    /** The kind of a copied text, or null when it isn't worth offering (empty, or very long). */
    static Clip classify(String raw) {
        if (raw == null) {
            return null;
        }
        String text = raw.trim();
        if (text.isEmpty() || text.length() > 300) {
            return null;
        }
        String digits = SmartSearch.plain(text).replaceAll("[\\s\\-()]", "");
        if (SAUDI_MOBILE.matcher(digits).matches() || ANY_PHONE.matcher(digits).matches()) {
            return new Clip(PHONE, digits);
        }
        if (text.matches("(?i)^(https?://|www\\.)\\S+$")) {
            return new Clip(LINK, text);
        }
        if (EMAIL_ADDRESS.matcher(text).matches()) {
            return new Clip(EMAIL, text);
        }
        String upper = text.replace(" ", "").toUpperCase(Locale.ROOT);
        if (POST_PARCEL.matcher(upper).matches() || COURIER_PARCEL.matcher(digits).matches()) {
            return new Clip(PARCEL, upper.matches("\\d+") ? digits : upper);
        }
        return text.length() <= 80 && !text.contains("\n") ? new Clip(TEXT, text) : null;
    }

    /** International form for WhatsApp: 0551234567 → 966551234567. */
    static String international(String phone) {
        String digits = phone.replace("+", "");
        if (digits.startsWith("00")) {
            digits = digits.substring(2);
        }
        if (digits.startsWith("05") && digits.length() == 10) {
            return "966" + digits.substring(1);
        }
        if (digits.startsWith("5") && digits.length() == 9) {
            return "966" + digits;
        }
        return digits;
    }

    static Intent call(String phone) {
        return new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phone));
    }

    static Intent whatsapp(String phone) {
        return new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + international(phone)));
    }

    static Intent open(String link) {
        String lower = link.toLowerCase(java.util.Locale.ROOT);
        Intent web = web(lower.startsWith("http://") || lower.startsWith("https://") ? link : "https://" + link);
        return web != null ? web : new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(link)));
    }

    /**
     * A web page to open from text that came from outside (a feed, the clipboard): only http and https,
     * and only by apps that open web links (browsable), never a file, an app's private page or a script.
     */
    static Intent web(String link) {
        if (link == null) {
            return null;
        }
        Uri uri = Uri.parse(link.trim());
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(java.util.Locale.ROOT);
        if (!(scheme.equals("http") || scheme.equals("https")) || uri.getHost() == null || uri.getHost().isEmpty()) {
            return null;
        }
        return new Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE);
    }

    static Intent email(String address) {
        return new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + address));
    }

    /** A web search for the number: the couriers' own pages come first for their numbers. */
    static Intent track(String number) {
        return new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode("تتبع شحنة " + number)));
    }

    /**
     * The new copy, if there is one: copied less than ten minutes ago and not offered before. Reading
     * the description alone doesn't trigger Android's note; the text is read only when it is new.
     */
    static Clip fresh(Context context, android.content.SharedPreferences prefs) {
        try {
            ClipboardManager clipboard = context.getSystemService(ClipboardManager.class);
            if (clipboard == null || !clipboard.hasPrimaryClip()) {
                return null;
            }
            ClipDescription description = clipboard.getPrimaryClipDescription();
            if (description == null || !(description.hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN)
                    || description.hasMimeType(ClipDescription.MIMETYPE_TEXT_HTML))) {
                return null;
            }
            long copied = Build.VERSION.SDK_INT >= 26 ? description.getTimestamp() : 0L;
            long now = System.currentTimeMillis();
            // Wall-clock time on phones; a clock since boot on some builds (and in tests): compare like with like.
            long clock = copied > 0 && copied < 1500000000000L ? android.os.SystemClock.elapsedRealtime() : now;
            if (copied > 0 && (copied <= prefs.getLong("clip_offered", 0L) || clock - copied > 10 * 60000L)) {
                return null;
            }
            CharSequence text = clipboard.getPrimaryClip().getItemAt(0).coerceToText(context);
            Clip clip = classify(text == null ? null : text.toString());
            if (clip != null) {
                prefs.edit().putLong("clip_seen", copied > 0 ? copied : now).apply();
            }
            return clip;
        } catch (Exception e) {
            return null;
        }
    }

    /** The user acted on it or closed it: don't offer the same copy again. */
    static void done(android.content.SharedPreferences prefs) {
        prefs.edit().putLong("clip_offered", prefs.getLong("clip_seen", System.currentTimeMillis())).apply();
    }
}
