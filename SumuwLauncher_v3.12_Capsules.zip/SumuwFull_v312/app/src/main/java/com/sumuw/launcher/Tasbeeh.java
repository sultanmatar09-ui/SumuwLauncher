package com.sumuw.launcher;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * The tasbeeh counter from the control centre: tap the big circle to count; a light tick on each, a
 * buzz at each thirty-three and a longer one at a hundred. The count stays until reset.
 */
final class Tasbeeh {
    static final String PREF = "tasbeeh_count";

    private Tasbeeh() {
    }

    /** 33, 66, 99 buzz short; 100 and every hundred buzz long; others tick. */
    static int feel(int count) {
        if (count > 0 && count % 100 == 0) {
            return 2;
        }
        if (count > 0 && count % 100 % 33 == 0) {
            return 1;
        }
        return 0;
    }

    static void show(final HomeActivity home) {
        final SharedPreferences prefs = home.getSharedPreferences("duo_home", 0);
        LinearLayout box = new LinearLayout(home);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(home.dp(20.0f), home.dp(12.0f), home.dp(20.0f), home.dp(8.0f));
        final TextView count = new TextView(home);
        count.setTypeface(home.font(700));
        count.setTextSize(52);
        count.setTextColor(Color.WHITE);
        count.setGravity(Gravity.CENTER);
        int accent = home.accent;
        count.setBackground(home.pill(accent, 110));
        box.addView(count, new LinearLayout.LayoutParams(home.dp(200.0f), home.dp(200.0f)));
        final TextView rounds = new TextView(home);
        rounds.setTypeface(home.font(500));
        rounds.setTextSize(14);
        rounds.setGravity(Gravity.CENTER);
        rounds.setPadding(0, home.dp(14.0f), 0, 0);
        box.addView(rounds, new LinearLayout.LayoutParams(-1, -2));
        final Runnable show = () -> {
            int n = prefs.getInt(PREF, 0);
            count.setText(home.localDigits(String.valueOf(n)));
            rounds.setText(home.getString(R.string.tasbeeh_rounds, home.localDigits(String.valueOf(n / 33)),
                    home.localDigits(String.valueOf(n % 33))));
            count.setContentDescription(home.getString(R.string.tasbeeh_tap) + home.getString(R.string.list_separator)
                    + home.localDigits(String.valueOf(n)));
        };
        show.run();
        count.setOnClickListener(v -> {
            int n = prefs.getInt(PREF, 0) + 1;
            prefs.edit().putInt(PREF, n).apply();
            show.run();
            int feel = feel(n);
            if (feel == 0) {
                v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
            } else {
                buzz(home, feel == 2 ? 450L : 160L);
            }
            v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(60L)
                    .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(90L).start()).start();
        });
        new AlertDialog.Builder(home)
                .setTitle(home.getString(R.string.cc_tasbeeh))
                .setView(box)
                .setPositiveButton(home.getString(R.string.done), null)
                .setNeutralButton(home.getString(R.string.tasbeeh_reset), (dialog, which) -> prefs.edit().putInt(PREF, 0).apply())
                .show();
    }

    private static void buzz(HomeActivity home, long ms) {
        try {
            Vibrator vibrator = home.getSystemService(Vibrator.class);
            if (vibrator == null || !vibrator.hasVibrator()) {
                return;
            }
            if (Build.VERSION.SDK_INT >= 26) {
                vibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vibrator.vibrate(ms);
            }
        } catch (Exception ignored) {
        }
    }
}
