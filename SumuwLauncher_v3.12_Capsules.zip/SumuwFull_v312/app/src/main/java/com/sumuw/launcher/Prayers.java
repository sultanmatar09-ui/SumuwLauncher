package com.sumuw.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Date;

/** Today's prayer times and the next prayer, from the place and method chosen in Settings. */
final class Prayers {
    static final int[] NAMES = {R.string.prayer_fajr, R.string.prayer_sunrise, R.string.prayer_dhuhr,
            R.string.prayer_asr, R.string.prayer_maghrib, R.string.prayer_isha};

    private Prayers() {
    }

    static long[] timesFor(SharedPreferences prefs, long day) {
        double[] place = Places.latLng(prefs);
        return PrayerTimes.forDay(day, place[0], place[1], Places.zone(prefs), method(prefs),
                prefs.getBoolean("asr_hanafi", false), HijriEvents.isRamadan(day));
    }

    /** {index, time} of the next prayer (sunrise is not a prayer); after Isha it is tomorrow's Fajr. */
    static long[] next(SharedPreferences prefs, long now) {
        long[] times = timesFor(prefs, now);
        for (int i = 0; i < times.length; i++) {
            if (i != PrayerTimes.SUNRISE && times[i] > now) {
                return new long[]{i, times[i]};
            }
        }
        return new long[]{PrayerTimes.FAJR, timesFor(prefs, now + 86400000L)[PrayerTimes.FAJR]};
    }

    static String timeText(Context context, SharedPreferences prefs, long when) {
        java.text.DateFormat format = android.text.format.DateFormat.getTimeFormat(context);
        format.setTimeZone(Places.zone(prefs));
        return format.format(new Date(when));
    }

    /** The prayer method set, or for "auto" (the default) the one used in the country of the phone's location. */
    static String method(SharedPreferences prefs) {
        String chosen = prefs.getString("prayer_method", "auto");
        return "auto".equals(chosen) ? methodFor(Places.country(prefs)) : chosen;
    }

    /** Umm al-Qura in Saudi Arabia and the Gulf, Egypt's method around Egypt and the Levant, Karachi's in South Asia, ISNA in North America, else the Muslim World League. */
    static String methodFor(String country) {
        switch (country) {
            case "SA":
            case "AE":
            case "KW":
            case "QA":
            case "BH":
            case "OM":
            case "YE":
                return "umm_al_qura";
            case "EG":
            case "SD":
            case "LY":
            case "SY":
            case "LB":
            case "IQ":
            case "PS":
            case "JO":
                return "egypt";
            case "PK":
            case "IN":
            case "BD":
            case "AF":
                return "karachi";
            case "US":
            case "CA":
                return "isna";
            default:
                return "mwl";
        }
    }

    static String countdown(Context context, long millis) {
        long minutes = Math.max(1L, (millis + 59999L) / 60000L);
        if (minutes < 60) {
            return context.getString(R.string.in_minutes, minutes);
        }
        if (minutes % 60 == 0) {
            return context.getString(R.string.in_hours, minutes / 60); // "بعد ١ س", not "بعد ١ س ٠ د"
        }
        return context.getString(R.string.in_hours_minutes, minutes / 60, minutes % 60);
    }

    /** "العصر بعد ٢٥ د" when it is close, otherwise "العصر ٢:٤٥ م". */
    static String nextText(Context context, SharedPreferences prefs, long now) {
        long[] next = next(prefs, now);
        long left = next[1] - now;
        return context.getString(NAMES[(int) next[0]]) + " "
                + (left <= 2 * 3600000L ? countdown(context, left) : timeText(context, prefs, next[1]));
    }
}
