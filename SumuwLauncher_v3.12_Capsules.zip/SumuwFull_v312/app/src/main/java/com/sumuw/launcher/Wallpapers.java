package com.sumuw.launcher;

import android.app.WallpaperColors;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import java.util.Random;

/**
 * Built-in wallpapers, drawn in code so they stay sharp on any screen and add almost nothing to the APK.
 * Shapes use fractions of the screen size, so the same art works on phones, foldables and tablets.
 */
final class Wallpapers {
    static final String DEVICE = "device";
    /** A photo the user picked; kept in the app's own storage as wallpaper_photo.jpg. */
    static final String PHOTO = "photo";
    static final String PHOTO_FILE = "wallpaper_photo.jpg";
    static final String DEFAULT = "dusk";
    static final String[] IDS = {"dusk", "dunes", "wave", "oasis", "pearl", "fajr", "stars", "palms", "sea", "geometry", "graphite",
            "lavender", "sand", DEVICE};

    private Wallpapers() {
    }

    static int nameRes(String id) {
        switch (id) {
            case "dunes":
                return R.string.wallpaper_dunes;
            case "wave":
                return R.string.wallpaper_wave;
            case "oasis":
                return R.string.wallpaper_oasis;
            case "pearl":
                return R.string.wallpaper_pearl;
            case "fajr":
                return R.string.wallpaper_fajr;
            case "stars":
                return R.string.wallpaper_stars;
            case "palms":
                return R.string.wallpaper_palms;
            case "sea":
                return R.string.wallpaper_sea;
            case "geometry":
                return R.string.wallpaper_geometry;
            case "graphite":
                return R.string.wallpaper_graphite;
            case "lavender":
                return R.string.wallpaper_lavender;
            case "sand":
                return R.string.wallpaper_sand;
            case DEVICE:
                return R.string.wallpaper_device;
            case PHOTO:
                return R.string.wallpaper_photo;
            default:
                return R.string.wallpaper_dusk;
        }
    }

    static boolean isKnown(String id) {
        if (PHOTO.equals(id)) {
            return true;
        }
        for (String known : IDS) {
            if (known.equals(id)) {
                return true;
            }
        }
        return false;
    }

    /** Light wallpapers get dark text; everything else gets white text. */
    static boolean isDark(String id) {
        return !"pearl".equals(id) && !"lavender".equals(id) && !"sand".equals(id);
    }

    static Drawable create(String id) {
        return new Art(id);
    }

    // ---------------------------------------------------------------- the user's own photo

    private static Bitmap photo;
    private static String photoStamp;

    static boolean hasPhoto(Context context) {
        return new File(context.getFilesDir(), PHOTO_FILE).exists();
    }

    /** The wallpaper drawable for any id, including the user's photo (blurred as chosen in Settings). */
    static Drawable create(Context context, String id) {
        if (PHOTO.equals(id)) {
            Bitmap bitmap = photo(context);
            if (bitmap != null) {
                return new PhotoArt(bitmap, isDark(context, id));
            }
            id = DEFAULT;
        }
        return create(id);
    }

    static boolean isDark(Context context, String id) {
        if (PHOTO.equals(id)) {
            return !hasPhoto(context) || context.getSharedPreferences("duo_home", 0).getBoolean("photo_dark", true);
        }
        return isDark(id);
    }

    static Bitmap blurred(Context context, String id, int width, int height) {
        return blurredArt(create(context, id), width, height);
    }

    /** Loads the photo once and keeps it; blur levels 1 to 3 shrink it, blur it and let drawing scale it back up. */
    static synchronized Bitmap photo(Context context) {
        File file = new File(context.getFilesDir(), PHOTO_FILE);
        if (!file.exists()) {
            return null;
        }
        int blur = context.getSharedPreferences("duo_home", 0).getInt("photo_blur", 0);
        String stamp = file.lastModified() + "/" + blur;
        if (photo != null && stamp.equals(photoStamp)) {
            return photo;
        }
        try {
            Bitmap full = BitmapFactory.decodeFile(file.getPath());
            if (full == null) {
                return null;
            }
            if (blur > 0) {
                int divide = blur == 1 ? 6 : blur == 2 ? 12 : 24;
                int w = Math.max(8, full.getWidth() / divide);
                int h = Math.max(8, full.getHeight() / divide);
                Bitmap small = Bitmap.createScaledBitmap(full, w, h, true);
                small = small.copy(Bitmap.Config.ARGB_8888, true);
                int[] pixels = new int[w * h];
                small.getPixels(pixels, 0, w, 0, 0, w, h);
                int[] scratch = new int[pixels.length];
                for (int pass = 0; pass < 2; pass++) {
                    boxBlur(pixels, scratch, w, h, 2, true);
                    boxBlur(scratch, pixels, w, h, 2, false);
                }
                small.setPixels(pixels, 0, w, 0, 0, w, h);
                full = small;
            }
            photo = full;
            photoStamp = stamp;
            return photo;
        } catch (OutOfMemoryError | RuntimeException e) {
            return null;
        }
    }

    /**
     * Copies a picked image into the app (at most 2048 px on its long side, turned upright), and works out
     * whether it is dark and which colour suits it. Returns false if it can't be read.
     */
    static boolean importPhoto(Context context, Uri uri) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (InputStream in = context.getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(in, null, bounds);
            }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
                return false;
            }
            int sample = 1;
            while (Math.max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 2048) {
                sample *= 2;
            }
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = sample;
            Bitmap bitmap;
            try (InputStream in = context.getContentResolver().openInputStream(uri)) {
                bitmap = BitmapFactory.decodeStream(in, null, options);
            }
            if (bitmap == null) {
                return false;
            }
            int degrees = 0;
            try (InputStream in = context.getContentResolver().openInputStream(uri)) {
                android.media.ExifInterface exif = new android.media.ExifInterface(in);
                int orientation = exif.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1);
                degrees = orientation == 6 ? 90 : orientation == 3 ? 180 : orientation == 8 ? 270 : 0;
            } catch (Exception ignored) {
            }
            if (degrees != 0) {
                Matrix turn = new Matrix();
                turn.postRotate(degrees);
                bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), turn, true);
            }
            File file = new File(context.getFilesDir(), PHOTO_FILE);
            try (FileOutputStream out = new FileOutputStream(file)) {
                bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out);
            }
            Bitmap tiny = Bitmap.createScaledBitmap(bitmap, 24, 24, true);
            double light = 0;
            for (int x = 0; x < 24; x++) {
                for (int y = 0; y < 24; y++) {
                    int c = tiny.getPixel(x, y);
                    light += (0.2126 * Color.red(c) + 0.7152 * Color.green(c) + 0.0722 * Color.blue(c)) / 255.0;
                }
            }
            boolean dark = light / (24 * 24) < 0.6;
            context.getSharedPreferences("duo_home", 0).edit()
                    .putBoolean("photo_dark", dark)
                    .putInt("photo_accent", accentOf(tiny))
                    .apply();
            synchronized (Wallpapers.class) {
                photo = null;
                photoStamp = null;
            }
            return true;
        } catch (Exception | OutOfMemoryError e) {
            return false;
        }
    }

    /** The most colourful hue in a small picture, made calm enough for white text on it. */
    private static int accentOf(Bitmap tiny) {
        float[] best = null;
        float bestScore = -1;
        float[] hsv = new float[3];
        for (int x = 0; x < tiny.getWidth(); x++) {
            for (int y = 0; y < tiny.getHeight(); y++) {
                Color.colorToHSV(tiny.getPixel(x, y), hsv);
                float score = hsv[1] * (0.4f + hsv[2]);
                if (score > bestScore) {
                    bestScore = score;
                    best = hsv.clone();
                }
            }
        }
        return best == null || best[1] < 0.15f ? Color.rgb(101, 103, 191) : calm(Color.HSVToColor(best));
    }

    /** Keeps an accent readable behind white text: some colour, not too light, not too dark. */
    static int calm(int color) {
        float[] hsv = new float[3];
        Color.colorToHSV(color, hsv);
        hsv[1] = Math.max(0.35f, Math.min(0.75f, hsv[1]));
        hsv[2] = Math.max(0.52f, Math.min(0.72f, hsv[2]));
        return Color.HSVToColor(hsv);
    }

    /** "Automatic" accent: from the photo, from the phone's wallpaper, or a colour that suits each built-in style. */
    static int accentFor(Context context, String id) {
        SharedPreferences prefs = context.getSharedPreferences("duo_home", 0);
        switch (id) {
            case PHOTO:
                return prefs.getInt("photo_accent", Color.rgb(101, 103, 191));
            case DEVICE:
                if (Build.VERSION.SDK_INT >= 27) {
                    try {
                        WallpaperColors colors = WallpaperManager.getInstance(context).getWallpaperColors(WallpaperManager.FLAG_SYSTEM);
                        if (colors != null) {
                            android.graphics.Color pick = colors.getSecondaryColor() != null ? colors.getSecondaryColor() : colors.getPrimaryColor();
                            float[] hsv = new float[3];
                            Color.colorToHSV(colors.getPrimaryColor().toArgb(), hsv);
                            if (hsv[1] >= 0.2f) {
                                pick = colors.getPrimaryColor();
                            }
                            return calm(pick.toArgb());
                        }
                    } catch (Exception ignored) {
                    }
                }
                return Color.rgb(101, 103, 191);
            case "dunes":
                return Color.rgb(196, 122, 58);
            case "wave":
                return Color.rgb(58, 112, 196);
            case "oasis":
                return Color.rgb(46, 139, 116);
            case "pearl":
                return Color.rgb(101, 103, 191);
            case "fajr":
                return Color.rgb(214, 112, 98);
            case "stars":
                return Color.rgb(92, 120, 214);
            case "palms":
                return Color.rgb(222, 102, 86);
            case "sea":
                return Color.rgb(34, 150, 170);
            case "geometry":
                return Color.rgb(196, 152, 72);
            case "graphite":
                return Color.rgb(120, 132, 160);
            case "lavender":
                return Color.rgb(128, 96, 190);
            case "sand":
                return Color.rgb(170, 110, 60);
            default:
                return Color.rgb(126, 87, 194);
        }
    }

    /** The photo, filling the screen without stretching (cropped from the middle). */
    private static final class PhotoArt extends Drawable {
        private final Bitmap bitmap;
        private final boolean dark;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
        private final Rect from = new Rect();

        PhotoArt(Bitmap bitmap, boolean dark) {
            this.bitmap = bitmap;
            this.dark = dark;
        }

        @Override
        public void draw(Canvas canvas) {
            Rect b = getBounds();
            if (b.width() <= 0 || b.height() <= 0) {
                return;
            }
            float scale = Math.max(b.width() / (float) bitmap.getWidth(), b.height() / (float) bitmap.getHeight());
            int w = Math.round(b.width() / scale);
            int h = Math.round(b.height() / scale);
            int left = (bitmap.getWidth() - w) / 2;
            int top = (bitmap.getHeight() - h) / 2;
            from.set(left, top, left + w, top + h);
            canvas.drawBitmap(bitmap, from, b, paint);
            if (dark) {
                canvas.drawColor(0x1F000000); // a touch darker, so white labels stay readable on bright spots
            }
        }

        @Override
        public void setAlpha(int alpha) {
            paint.setAlpha(alpha);
        }

        @Override
        public void setColorFilter(ColorFilter filter) {
            paint.setColorFilter(filter);
        }

        @Override
        public int getOpacity() {
            return PixelFormat.OPAQUE;
        }
    }

    /** Renders the wallpaper small and blurs it; glass surfaces sample this to look frosted. */
    static Bitmap blurred(String id, int width, int height) {
        return blurredArt(create(id), width, height);
    }

    /** The blurred glass of any drawable (the art with the hour's light on it). */
    static Bitmap blurredOf(Drawable art, int width, int height) {
        return blurredArt(art, width, height);
    }

    private static Bitmap blurredArt(Drawable art, int width, int height) {
        int w = Math.max(8, width / 12);
        int h = Math.max(8, height / 12);
        Bitmap small = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        art.setBounds(0, 0, w, h);
        art.draw(new Canvas(small));
        int[] pixels = new int[w * h];
        small.getPixels(pixels, 0, w, 0, 0, w, h);
        int[] scratch = new int[pixels.length];
        for (int pass = 0; pass < 3; pass++) {
            boxBlur(pixels, scratch, w, h, 3, true);
            boxBlur(scratch, pixels, w, h, 3, false);
        }
        small.setPixels(pixels, 0, w, 0, 0, w, h);
        return small;
    }

    private static void boxBlur(int[] in, int[] out, int w, int h, int radius, boolean horizontal) {
        int span = radius * 2 + 1;
        for (int line = 0; line < (horizontal ? h : w); line++) {
            for (int i = 0; i < (horizontal ? w : h); i++) {
                int a = 0;
                int r = 0;
                int g = 0;
                int b = 0;
                for (int k = -radius; k <= radius; k++) {
                    int j = Math.max(0, Math.min((horizontal ? w : h) - 1, i + k));
                    int c = horizontal ? in[line * w + j] : in[j * w + line];
                    a += c >>> 24;
                    r += (c >> 16) & 0xFF;
                    g += (c >> 8) & 0xFF;
                    b += c & 0xFF;
                }
                int value = ((a / span) << 24) | ((r / span) << 16) | ((g / span) << 8) | (b / span);
                if (horizontal) {
                    out[line * w + i] = value;
                } else {
                    out[i * w + line] = value;
                }
            }
        }
    }

    private static final class Art extends Drawable {
        private final String id;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);

        Art(String id) {
            this.id = id;
        }

        @Override
        public void draw(Canvas canvas) {
            Rect b = getBounds();
            float w = b.width();
            float h = b.height();
            if (w <= 0 || h <= 0) {
                return;
            }
            canvas.save();
            canvas.translate(b.left, b.top);
            canvas.clipRect(0, 0, w, h);
            switch (id) {
                case "dunes":
                    drawDunes(canvas, w, h);
                    break;
                case "wave":
                    drawWave(canvas, w, h);
                    break;
                case "oasis":
                    drawOasis(canvas, w, h);
                    break;
                case "pearl":
                    drawPearl(canvas, w, h);
                    break;
                case "fajr":
                    drawFajr(canvas, w, h);
                    break;
                case "stars":
                    drawStars(canvas, w, h);
                    break;
                case "palms":
                    drawPalms(canvas, w, h);
                    break;
                case "sea":
                    drawSea(canvas, w, h);
                    break;
                case "geometry":
                    drawGeometry(canvas, w, h);
                    break;
                case "graphite":
                    drawGraphite(canvas, w, h);
                    break;
                case "lavender":
                    drawLavender(canvas, w, h);
                    break;
                case "sand":
                    drawSand(canvas, w, h);
                    break;
                default:
                    drawDusk(canvas, w, h);
                    break;
            }
            canvas.restore();
        }

        // Deep violet evening with coral and magenta light, the default.
        private void drawDusk(Canvas c, float w, float h) {
            vertical(c, w, h, new int[]{0xFF120F2B, 0xFF26164A, 0xFF3A1A4F}, new float[]{0f, 0.55f, 1f});
            blob(c, w * 0.98f, h * 0.06f, w * 0.95f, 0xFFE0508F, 0.62f);
            blob(c, w * 0.02f, h * 0.40f, w * 0.85f, 0xFFFF8A5B, 0.42f);
            blob(c, w * 0.75f, h * 0.80f, w * 0.95f, 0xFF3D5AFE, 0.50f);
            blob(c, w * 0.15f, h * 1.02f, w * 0.75f, 0xFFB13CC9, 0.45f);
            softRibbon(c, w, h, new float[]{0.64f, 0.48f, 0.44f, 0.28f}, 0.16f, 0x66FFB38A, 0x00E0508F);
        }

        // Najd at night: a crescent, stars, and layered dunes catching the last glow.
        private void drawDunes(Canvas c, float w, float h) {
            vertical(c, w, h, new int[]{0xFF0A1130, 0xFF1A1D4A, 0xFF4B2F5E, 0xFF5E3A5C}, new float[]{0f, 0.45f, 0.70f, 0.80f});
            blob(c, w * 0.62f, h * 0.71f, w * 0.95f, 0xFFFF8E6E, 0.30f);
            blob(c, w * 0.15f, h * 0.68f, w * 0.65f, 0xFFB24D8A, 0.22f);
            Random random = new Random(7);
            paint.setShader(null);
            for (int i = 0; i < 90; i++) {
                float x = random.nextFloat() * w;
                float y = random.nextFloat() * h * 0.62f;
                float r = w * (0.0012f + random.nextFloat() * 0.0022f);
                paint.setColor(Color.argb((int) (70 + random.nextFloat() * 170), 255, 248, 235));
                c.drawCircle(x, y, r, paint);
            }
            float mx = w * 0.40f;
            float my = h * 0.042f;
            float mr = w * 0.030f;
            blob(c, mx, my, mr * 5f, 0xFFFFE9C4, 0.16f);
            // A true crescent: the moon disc minus an offset disc, so no fake sky patch shows.
            Path moon = new Path();
            moon.addCircle(mx, my, mr, Path.Direction.CW);
            Path bite = new Path();
            bite.addCircle(mx + mr * 0.45f, my - mr * 0.22f, mr * 0.86f, Path.Direction.CW);
            moon.op(bite, Path.Op.DIFFERENCE);
            paint.setShader(null);
            paint.setColor(0xFFF6E7C8);
            c.drawPath(moon, paint);
            dune(c, w, h, 0.74f, 0.70f, 0.655f, 0.70f, 0xFF5A4072, 0xFF3A2B52);
            dune(c, w, h, 0.81f, 0.28f, 0.725f, 0.85f, 0xFF45305F, 0xFF2A1D40);
            dune(c, w, h, 0.87f, 0.80f, 0.795f, 0.91f, 0xFF33244B, 0xFF1E1530);
            dune(c, w, h, 0.95f, 0.42f, 0.880f, 0.975f, 0xFF231834, 0xFF120C1E);
        }

        // Flowing colour ribbons on deep navy, closest to stock One UI wallpapers.
        private void drawWave(Canvas c, float w, float h) {
            vertical(c, w, h, new int[]{0xFF080D21, 0xFF0F1738, 0xFF0B1029}, new float[]{0f, 0.6f, 1f});
            blob(c, w * 0.15f, h * 0.18f, w * 0.9f, 0xFF6A5BFF, 0.35f);
            blob(c, w * 0.95f, h * 0.50f, w * 0.9f, 0xFFFF5BA7, 0.28f);
            blob(c, w * 0.25f, h * 0.85f, w * 0.9f, 0xFF33D1C4, 0.26f);
            softRibbon(c, w, h, new float[]{0.24f, 0.10f, 0.40f, 0.22f}, 0.24f, 0xB06A5BFF, 0xB0B05BFF);
            softRibbon(c, w, h, new float[]{0.48f, 0.34f, 0.62f, 0.46f}, 0.26f, 0x99FF5BA7, 0x99FF9A5B);
            softRibbon(c, w, h, new float[]{0.72f, 0.58f, 0.84f, 0.66f}, 0.24f, 0x9933D1C4, 0x995B8CFF);
            vertical(c, w, h, new int[]{0x00000000, 0x00000000, 0x59060A1C}, new float[]{0f, 0.55f, 1f});
        }

        // Palm-shade greens and water blues.
        private void drawOasis(Canvas c, float w, float h) {
            vertical(c, w, h, new int[]{0xFF041E1E, 0xFF083030, 0xFF0B2A33}, new float[]{0f, 0.5f, 1f});
            blob(c, w * 0.08f, h * 0.12f, w * 0.85f, 0xFF1FBF8F, 0.50f);
            blob(c, w * 0.98f, h * 0.48f, w * 0.85f, 0xFF2BB7D0, 0.45f);
            blob(c, w * 0.62f, h * 0.28f, w * 0.60f, 0xFF0E6B5C, 0.55f);
            blob(c, w * 0.35f, h * 1.00f, w * 0.75f, 0xFFC8E26A, 0.30f);
            blob(c, w * 0.10f, h * 0.70f, w * 0.55f, 0xFF127A8A, 0.40f);
            softRibbon(c, w, h, new float[]{0.56f, 0.42f, 0.60f, 0.38f}, 0.14f, 0x4DD8FFF1, 0x0028B7A0);
        }

        // Soft iridescent light, the original Duo Home mood.
        private void drawPearl(Canvas c, float w, float h) {
            vertical(c, w, h, new int[]{0xFFEDEFFA, 0xFFF6F0F6, 0xFFFAF1F2}, new float[]{0f, 0.5f, 1f});
            blob(c, w * 0.05f, h * 0.05f, w * 0.95f, 0xFFB9B4F2, 0.85f);
            blob(c, w * 1.00f, h * 0.35f, w * 0.85f, 0xFFFFC9B6, 0.80f);
            blob(c, w * 0.15f, h * 0.75f, w * 0.85f, 0xFFB4DFF2, 0.80f);
            blob(c, w * 0.90f, h * 0.98f, w * 0.75f, 0xFFC6EEDA, 0.85f);
            softRibbon(c, w, h, new float[]{0.60f, 0.46f, 0.50f, 0.34f}, 0.16f, 0x99FFFFFF, 0x00FFFFFF);
        }

        // Dawn over the desert: the night still above, rose and apricot light low on the horizon.
        private void drawFajr(Canvas c, float w, float h) {
            vertical(c, w, h, new int[]{0xFF0E1236, 0xFF2B2358, 0xFF6A3A6E, 0xFFA8566E, 0xFFD98A6A},
                    new float[]{0f, 0.32f, 0.58f, 0.76f, 0.86f});
            stars(c, w, h * 0.34f, 40, 11, 0.55f);
            blob(c, w * 0.62f, h * 0.86f, w * 0.85f, 0xFFFFC07A, 0.55f);
            blob(c, w * 0.62f, h * 0.86f, w * 0.30f, 0xFFFFE2B0, 0.55f);
            blob(c, w * 0.10f, h * 0.70f, w * 0.70f, 0xFFB24D8A, 0.25f);
            dune(c, w, h, 0.86f, 0.30f, 0.835f, 0.875f, 0xFF7A4560, 0xFF4E2E48);
            dune(c, w, h, 0.91f, 0.75f, 0.880f, 0.935f, 0xFF4F2F4A, 0xFF2C1B2E);
            dune(c, w, h, 0.97f, 0.40f, 0.940f, 0.985f, 0xFF2E1C30, 0xFF170E19);
        }

        // A clear desert night: the Milky Way across the sky over a dark dune.
        private void drawStars(Canvas c, float w, float h) {
            vertical(c, w, h, new int[]{0xFF03050F, 0xFF07102A, 0xFF0F1A3E, 0xFF1A1C3C}, new float[]{0f, 0.40f, 0.78f, 1f});
            // The band: soft glows along a gentle curve from the lower left to the upper right.
            float[][] glow = {{0.02f, 0.66f, 0.40f, 0.20f}, {0.22f, 0.52f, 0.46f, 0.24f}, {0.45f, 0.38f, 0.50f, 0.26f},
                    {0.68f, 0.24f, 0.46f, 0.22f}, {0.92f, 0.10f, 0.42f, 0.18f}};
            int[] tints = {0xFF6F7CFF, 0xFFB79CFF, 0xFFFFD9C7, 0xFFB79CFF, 0xFF6F7CFF};
            for (int i = 0; i < glow.length; i++) {
                blob(c, w * glow[i][0], h * glow[i][1], w * glow[i][2], tints[i], glow[i][3]);
            }
            stars(c, w, h * 0.80f, 170, 21, 0.9f);
            // Many faint stars crowd along the band.
            Random random = new Random(9);
            paint.setShader(null);
            for (int i = 0; i < 420; i++) {
                float t = random.nextFloat();
                float x = w * (0.02f + 0.90f * t);
                float y = h * (0.66f - 0.56f * t + (float) random.nextGaussian() * 0.045f);
                float r = w * (0.0007f + random.nextFloat() * 0.0016f);
                paint.setColor(Color.argb((int) (50 + random.nextFloat() * 150), 245, 240, 255));
                c.drawCircle(x + (float) random.nextGaussian() * w * 0.04f, y, r, paint);
            }
            // A few bright stars with a soft halo.
            for (int i = 0; i < 9; i++) {
                float x = random.nextFloat() * w;
                float y = random.nextFloat() * h * 0.70f;
                blob(c, x, y, w * 0.022f, 0xFFE8EEFF, 0.35f);
                paint.setShader(null);
                paint.setColor(0xFFFFFFFF);
                c.drawCircle(x, y, w * 0.0032f, paint);
            }
            dune(c, w, h, 0.90f, 0.62f, 0.860f, 0.930f, 0xFF161430, 0xFF0A0918);
            dune(c, w, h, 0.96f, 0.25f, 0.925f, 0.980f, 0xFF0C0B1C, 0xFF05050D);
        }

        // Sunset behind palm trees.
        private void drawPalms(Canvas c, float w, float h) {
            vertical(c, w, h, new int[]{0xFF1B1035, 0xFF4A1F55, 0xFF9C3A62, 0xFFE0705A, 0xFFF4A65E},
                    new float[]{0f, 0.30f, 0.56f, 0.76f, 0.86f});
            blob(c, w * 0.50f, h * 0.84f, w * 0.80f, 0xFFFFC27A, 0.55f);
            paint.setShader(null);
            paint.setColor(0x66FFE3B0);
            c.drawCircle(w * 0.50f, h * 0.835f, w * 0.13f, paint);
            stars(c, w, h * 0.28f, 30, 13, 0.5f);
            // The ground, then the palms in front of it.
            Path ground = new Path();
            ground.moveTo(0, h * 0.88f);
            ground.cubicTo(w * 0.30f, h * 0.865f, w * 0.65f, h * 0.895f, w, h * 0.875f);
            ground.lineTo(w, h);
            ground.lineTo(0, h);
            ground.close();
            paint.setColor(Color.BLACK);
            paint.setShader(new LinearGradient(0, h * 0.86f, 0, h, 0xFF2A1430, 0xFF12081A, Shader.TileMode.CLAMP));
            c.drawPath(ground, paint);
            palm(c, w * 0.10f, h * 0.90f, h * 0.36f, 0.20f, 0xFF1A0C22);
            palm(c, w * 0.24f, h * 0.905f, h * 0.24f, -0.10f, 0xFF231030);
            palm(c, w * 0.88f, h * 0.89f, h * 0.30f, -0.22f, 0xFF1A0C22);
        }

        // The Red Sea: turquoise shallows into deep blue, with light rippling near the surface.
        private void drawSea(Canvas c, float w, float h) {
            vertical(c, w, h, new int[]{0xFF0F6E7E, 0xFF0B4A6E, 0xFF082F55, 0xFF051B36}, new float[]{0f, 0.30f, 0.65f, 1f});
            blob(c, w * 0.25f, h * 0.02f, w * 0.95f, 0xFF5FE3D6, 0.45f);
            blob(c, w * 0.95f, h * 0.30f, w * 0.70f, 0xFF2BB7D0, 0.30f);
            blob(c, w * 0.10f, h * 0.80f, w * 0.80f, 0xFF1A3F9A, 0.35f);
            softRibbon(c, w, h, new float[]{0.18f, 0.12f, 0.24f, 0.16f}, 0.10f, 0x55B8FFF4, 0x2266E0FF);
            softRibbon(c, w, h, new float[]{0.36f, 0.30f, 0.42f, 0.33f}, 0.12f, 0x3399F0FF, 0x1A5CC8FF);
            softRibbon(c, w, h, new float[]{0.58f, 0.52f, 0.66f, 0.56f}, 0.14f, 0x264FB8FF, 0x1A2E7BD9);
            // Light dancing near the surface.
            Random random = new Random(3);
            paint.setShader(null);
            for (int i = 0; i < 40; i++) {
                float x = random.nextFloat() * w;
                float y = random.nextFloat() * h * 0.30f;
                paint.setColor(Color.argb((int) (14 + random.nextFloat() * 30), 220, 255, 250));
                c.drawOval(x, y, x + w * (0.02f + random.nextFloat() * 0.05f), y + w * (0.006f + random.nextFloat() * 0.01f), paint);
            }
        }

        // Eight-pointed stars, as on old doors and mashrabiya, in faint gold on deep teal.
        private void drawGeometry(Canvas c, float w, float h) {
            vertical(c, w, h, new int[]{0xFF0B2B33, 0xFF0B1F33, 0xFF0A1428}, new float[]{0f, 0.55f, 1f});
            blob(c, w * 0.20f, h * 0.20f, w * 0.85f, 0xFF1C7A72, 0.35f);
            blob(c, w * 0.90f, h * 0.70f, w * 0.85f, 0xFF2A3D8F, 0.30f);
            Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(Math.max(1f, w * 0.0024f));
            float step = w / 3.2f;
            float r = step * 0.42f;
            for (float y = -step / 2f; y < h + step; y += step) {
                for (float x = -step / 2f; x < w + step; x += step) {
                    // Brighter near the top, fading downwards, so the icons sit on calm ground.
                    float fade = Math.max(0f, 1f - y / (h * 0.95f));
                    line.setColor(Color.argb((int) (30 + 55 * fade), 226, 190, 120));
                    star8(c, x, y, r, line);
                    line.setColor(Color.argb((int) (16 + 30 * fade), 226, 190, 120));
                    star8(c, x + step / 2f, y + step / 2f, r * 0.38f, line);
                }
            }
            vertical(c, w, h, new int[]{0x00000000, 0x33050A18, 0x8C050A18}, new float[]{0f, 0.6f, 1f});
        }

        // Graphite: near black with a soft sheen, easy on the eyes and on OLED screens.
        private void drawGraphite(Canvas c, float w, float h) {
            vertical(c, w, h, new int[]{0xFF121316, 0xFF0B0C0E, 0xFF050506}, new float[]{0f, 0.6f, 1f});
            blob(c, w * 0.85f, h * 0.05f, w * 1.0f, 0xFF4A5268, 0.30f);
            blob(c, w * 0.05f, h * 0.65f, w * 0.75f, 0xFF3A3F55, 0.18f);
            // A soft diagonal sheen, like light across brushed metal.
            paint.setColor(Color.BLACK);
            paint.setShader(new LinearGradient(0, h * 0.05f, w, h * 0.42f, new int[]{0x00FFFFFF, 0x14FFFFFF, 0x00FFFFFF},
                    new float[]{0.2f, 0.5f, 0.8f}, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, paint);
        }

        // Lavender: soft lilac and pink light, a light wallpaper with dark text.
        private void drawLavender(Canvas c, float w, float h) {
            vertical(c, w, h, new int[]{0xFFEDE6FA, 0xFFF3EAF8, 0xFFF8EEF4}, new float[]{0f, 0.5f, 1f});
            blob(c, w * 0.10f, h * 0.10f, w * 0.95f, 0xFFC4B2F2, 0.80f);
            blob(c, w * 0.95f, h * 0.42f, w * 0.85f, 0xFFF2B8DA, 0.65f);
            blob(c, w * 0.25f, h * 0.88f, w * 0.85f, 0xFFB8C6F4, 0.70f);
            softRibbon(c, w, h, new float[]{0.52f, 0.40f, 0.46f, 0.30f}, 0.16f, 0x8CFFFFFF, 0x00FFFFFF);
        }

        // Sand: warm light dunes at midday, a light wallpaper with dark text.
        private void drawSand(Canvas c, float w, float h) {
            vertical(c, w, h, new int[]{0xFFF6EBDD, 0xFFF1DFC8, 0xFFE9CFB0}, new float[]{0f, 0.55f, 1f});
            blob(c, w * 0.85f, h * 0.06f, w * 0.80f, 0xFFFFF4E0, 0.85f);
            dune(c, w, h, 0.62f, 0.66f, 0.565f, 0.68f, 0xFFF0D5B3, 0xFFE6C39A);
            dune(c, w, h, 0.74f, 0.30f, 0.665f, 0.80f, 0xFFEBC9A0, 0xFFDDB083);
            dune(c, w, h, 0.86f, 0.78f, 0.795f, 0.90f, 0xFFE2B98D, 0xFFD2A070);
            dune(c, w, h, 0.95f, 0.40f, 0.900f, 0.975f, 0xFFD8AA7C, 0xFFC48F60);
        }

        /** Small stars scattered over the top {@code height} of the screen. */
        private void stars(Canvas c, float w, float height, int count, int seed, float brightness) {
            Random random = new Random(seed);
            paint.setShader(null);
            for (int i = 0; i < count; i++) {
                float x = random.nextFloat() * w;
                float y = random.nextFloat() * height;
                float fade = 1f - y / Math.max(1f, height) * 0.7f;
                float r = w * (0.0010f + random.nextFloat() * 0.0020f);
                paint.setColor(Color.argb((int) ((60 + random.nextFloat() * 180) * brightness * fade), 255, 250, 238));
                c.drawCircle(x, y, r, paint);
            }
        }

        /** An eight-pointed star: two squares, one turned by 45 degrees, and a small circle in the middle. */
        private void star8(Canvas c, float x, float y, float r, Paint line) {
            Path star = new Path();
            for (int k = 0; k < 16; k++) {
                double angle = Math.PI / 8 * k - Math.PI / 2;
                float radius = k % 2 == 0 ? r : r * 0.62f;
                float px = x + (float) Math.cos(angle) * radius;
                float py = y + (float) Math.sin(angle) * radius;
                if (k == 0) {
                    star.moveTo(px, py);
                } else {
                    star.lineTo(px, py);
                }
            }
            star.close();
            c.drawPath(star, line);
            c.drawCircle(x, y, r * 0.30f, line);
        }

        /** A palm silhouette: a gently curved trunk and drooping fronds from the crown. */
        private void palm(Canvas c, float baseX, float baseY, float height, float lean, int color) {
            float topX = baseX + lean * height;
            float topY = baseY - height;
            Paint trunk = new Paint(Paint.ANTI_ALIAS_FLAG);
            trunk.setColor(color);
            trunk.setStyle(Paint.Style.STROKE);
            trunk.setStrokeCap(Paint.Cap.ROUND);
            trunk.setStrokeWidth(height * 0.050f);
            Path stem = new Path();
            stem.moveTo(baseX, baseY);
            stem.cubicTo(baseX + lean * height * 0.15f, baseY - height * 0.40f, topX - lean * height * 0.30f, topY + height * 0.30f, topX, topY);
            c.drawPath(stem, trunk);
            trunk.setStrokeWidth(height * 0.036f);
            Path upper = new Path();
            upper.moveTo(topX - lean * height * 0.30f, topY + height * 0.30f);
            upper.lineTo(topX, topY);
            c.drawPath(upper, trunk);
            Paint leaf = new Paint(Paint.ANTI_ALIAS_FLAG);
            leaf.setColor(color);
            float[] angles = {-172f, -150f, -128f, -104f, -80f, -56f, -32f, -10f, 160f, 18f};
            for (float degrees : angles) {
                double a = Math.toRadians(degrees);
                float length = height * (0.42f + 0.10f * (float) Math.abs(Math.cos(a)));
                float tipX = topX + (float) Math.cos(a) * length;
                // Fronds rise from the crown, then bend down under their weight.
                float tipY = topY + (float) Math.sin(a) * length * 0.55f + length * 0.42f;
                float midX = topX + (float) Math.cos(a) * length * 0.55f;
                float midY = topY + (float) Math.sin(a) * length * 0.70f - length * 0.05f;
                float nx = (tipY - topY);
                float ny = -(tipX - topX);
                float norm = (float) Math.sqrt(nx * nx + ny * ny);
                float wide = length * 0.07f;
                nx = nx / Math.max(1f, norm) * wide;
                ny = ny / Math.max(1f, norm) * wide;
                Path frond = new Path();
                frond.moveTo(topX, topY);
                frond.quadTo(midX + nx, midY + ny, tipX, tipY);
                frond.quadTo(midX - nx * 0.6f, midY - ny * 0.6f + wide * 0.8f, topX, topY + wide * 0.4f);
                frond.close();
                c.drawPath(frond, leaf);
            }
            c.drawCircle(topX, topY, height * 0.028f, leaf);
        }

        private void vertical(Canvas c, float w, float h, int[] colors, float[] stops) {
            paint.setColor(Color.BLACK); // full alpha: a colour set before (a faint star) would dim the shader
            paint.setShader(new LinearGradient(0, 0, 0, h, colors, stops, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, paint);
        }

        private void blob(Canvas c, float x, float y, float radius, int color, float strength) {
            int core = Color.argb((int) (255 * strength), Color.red(color), Color.green(color), Color.blue(color));
            int mid = Color.argb((int) (255 * strength * 0.45f), Color.red(color), Color.green(color), Color.blue(color));
            int edge = Color.argb(0, Color.red(color), Color.green(color), Color.blue(color));
            paint.setColor(Color.BLACK);
            paint.setShader(new RadialGradient(x, y, radius, new int[]{core, mid, edge}, new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(x, y, radius, paint);
        }

        /** A ribbon with feathered edges: thinner, fainter copies stacked on the same centre line. */
        private void softRibbon(Canvas c, float w, float h, float[] y, float thickness, int startColor, int endColor) {
            final int layers = 12;
            for (int k = 0; k < layers; k++) {
                float fraction = 1f - k / (float) layers;
                float shift = thickness * (1f - fraction) / 2f;
                float[] shifted = {y[0] + shift, y[1] + shift, y[2] + shift, y[3] + shift};
                ribbon(c, w, h, shifted, thickness * fraction, scaleAlpha(startColor, 1.8f / layers), scaleAlpha(endColor, 1.8f / layers));
            }
        }

        private static int scaleAlpha(int color, float factor) {
            int alpha = Math.min(255, (int) (Color.alpha(color) * factor));
            return (alpha << 24) | (color & 0x00FFFFFF);
        }

        /** A band between two parallel curves crossing the screen; y values are fractions of the height. */
        private void ribbon(Canvas c, float w, float h, float[] y, float thickness, int startColor, int endColor) {
            float t = thickness * h;
            Path path = new Path();
            path.moveTo(-0.1f * w, y[0] * h);
            path.cubicTo(0.30f * w, y[1] * h, 0.70f * w, y[2] * h, 1.1f * w, y[3] * h);
            path.lineTo(1.1f * w, y[3] * h + t);
            path.cubicTo(0.70f * w, y[2] * h + t * 0.6f, 0.30f * w, y[1] * h + t * 1.3f, -0.1f * w, y[0] * h + t);
            path.close();
            paint.setColor(Color.BLACK);
            paint.setShader(new LinearGradient(0, 0, w, 0, startColor, endColor, Shader.TileMode.CLAMP));
            c.drawPath(path, paint);
        }

        /** One dune: a gentle windward slope up to the crest, then a steeper slip face. */
        private void dune(Canvas c, float w, float h, float startY, float crestX, float crestY, float endY, int light, int dark) {
            Path path = new Path();
            float cx = crestX * w;
            path.moveTo(0, startY * h);
            path.cubicTo(cx * 0.45f, startY * h, cx * 0.70f, crestY * h, cx, crestY * h);
            path.cubicTo(cx + (w - cx) * 0.25f, crestY * h, cx + (w - cx) * 0.55f, endY * h, w, endY * h);
            path.lineTo(w, h);
            path.lineTo(0, h);
            path.close();
            paint.setColor(Color.BLACK);
            paint.setShader(new LinearGradient(0, crestY * h, 0, h, light, dark, Shader.TileMode.CLAMP));
            c.drawPath(path, paint);
            Paint ridge = new Paint(Paint.ANTI_ALIAS_FLAG);
            ridge.setStyle(Paint.Style.STROKE);
            ridge.setStrokeWidth(Math.max(1f, w * 0.0025f));
            ridge.setColor(0x26FFD9C2);
            Path crest = new Path();
            crest.moveTo(cx * 0.35f, startY * h - (startY - crestY) * h * 0.25f);
            crest.cubicTo(cx * 0.62f, crestY * h + (startY - crestY) * h * 0.2f, cx * 0.80f, crestY * h, cx, crestY * h);
            c.drawPath(crest, ridge);
        }

        @Override
        public void setAlpha(int alpha) {
            paint.setAlpha(alpha);
        }

        @Override
        public void setColorFilter(ColorFilter colorFilter) {
            paint.setColorFilter(colorFilter);
        }

        @Override
        public int getOpacity() {
            return PixelFormat.OPAQUE;
        }
    }
}
