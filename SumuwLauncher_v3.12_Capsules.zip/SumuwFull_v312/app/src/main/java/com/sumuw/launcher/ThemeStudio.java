package com.sumuw.launcher;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Theme studio: the look of Sara (wallpaper, colour, font, icons, the lock screen's clock and card) saved
 * under a name, switched in one tap, and shared as a short code that another phone can paste in.
 *
 * Only the look travels: no apps, folders, places or anything personal. A theme made with a photo of the
 * user's own takes the default wallpaper elsewhere, since the photo stays on the phone.
 */
final class ThemeStudio {
    static final String SAVED = "themes";
    /** Shared codes start with this, so a pasted code is recognised and anything else is turned down. */
    static final String PREFIX = "sumuw-theme:";

    /** What a theme holds, and of what type. */
    static final String[] STRING_KEYS = {"wallpaper_style", Fonts.PREF, "icon_pack", IconShapes.PREF, IconTint.PREF,
            AdaptiveClock.PREF, LockScreen.CLOCK_SIZE, LockScreen.CLOCK_SIDE, LockScreen.CLOCK_COLOR, LockScreen.LINE};
    static final String[] INT_KEYS = {"accent", "photo_blur", LockScreen.DIM, LockScreen.CARD_STYLE, SaraWallpaper.POSITION, "dock_columns"};
    static final String[] BOOLEAN_KEYS = {"accent_auto", "hide_labels", Ambience.PREF_DAY, Ambience.PREF_WEATHER, Ambience.PREF_OCCASIONS,
            "grid_dense", "app_drawer"};

    static final class Theme {
        final String name;
        final JSONObject values;
        /** A ready-made theme that comes with Sara (it can't be deleted). */
        final boolean builtIn;

        Theme(String name, JSONObject values, boolean builtIn) {
            this.name = name;
            this.values = values;
            this.builtIn = builtIn;
        }
    }

    private ThemeStudio() {
    }

    /** The look as it is now. */
    static JSONObject capture(SharedPreferences prefs) {
        JSONObject values = new JSONObject();
        try {
            for (String key : STRING_KEYS) {
                if (prefs.contains(key)) {
                    values.put(key, prefs.getString(key, ""));
                }
            }
            for (String key : INT_KEYS) {
                if (prefs.contains(key)) {
                    values.put(key, prefs.getInt(key, 0));
                }
            }
            for (String key : BOOLEAN_KEYS) {
                if (prefs.contains(key)) {
                    values.put(key, prefs.getBoolean(key, false));
                }
            }
        } catch (Exception ignored) {
        }
        return values;
    }

    /** Puts a theme on: only the keys it knows, each checked for its type, so a bad code can't break anything. */
    static void apply(SharedPreferences prefs, JSONObject values) {
        SharedPreferences.Editor edit = prefs.edit();
        for (String key : STRING_KEYS) {
            String value = values.optString(key, null);
            if (value == null || !values.has(key)) {
                continue;
            }
            if ("wallpaper_style".equals(key) && (!Wallpapers.isKnown(value) || (Wallpapers.PHOTO.equals(value)
                    && !Wallpapers.PHOTO.equals(prefs.getString(key, ""))))) {
                value = Wallpapers.DEFAULT; // someone else's photo isn't on this phone
            }
            if (value.length() > 120) {
                continue;
            }
            edit.putString(key, value);
        }
        for (String key : INT_KEYS) {
            if (values.has(key)) {
                edit.putInt(key, values.optInt(key));
            }
        }
        for (String key : BOOLEAN_KEYS) {
            if (values.has(key)) {
                edit.putBoolean(key, values.optBoolean(key));
            }
        }
        edit.putBoolean("themed_icons", IconTint.THEMED.equals(values.optString(IconTint.PREF, "")));
        edit.putInt("config_stamp", prefs.getInt("config_stamp", 0) + 1);
        edit.apply();
    }

    static List<Theme> saved(SharedPreferences prefs) {
        ArrayList<Theme> list = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(prefs.getString(SAVED, "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject one = array.getJSONObject(i);
                list.add(new Theme(one.getString("name"), one.getJSONObject("values"), false));
            }
        } catch (Exception ignored) {
        }
        return list;
    }

    /** Saves the current look under a name; the same name replaces the older one. */
    static void save(SharedPreferences prefs, String name, JSONObject values) {
        List<Theme> list = saved(prefs);
        JSONArray array = new JSONArray();
        try {
            JSONObject mine = new JSONObject().put("name", name).put("values", values);
            array.put(mine);
            for (Theme theme : list) {
                if (!theme.name.equals(name) && array.length() < 20) {
                    array.put(new JSONObject().put("name", theme.name).put("values", theme.values));
                }
            }
        } catch (Exception ignored) {
        }
        prefs.edit().putString(SAVED, array.toString()).apply();
    }

    static void delete(SharedPreferences prefs, String name) {
        JSONArray array = new JSONArray();
        try {
            for (Theme theme : saved(prefs)) {
                if (!theme.name.equals(name)) {
                    array.put(new JSONObject().put("name", theme.name).put("values", theme.values));
                }
            }
        } catch (Exception ignored) {
        }
        prefs.edit().putString(SAVED, array.toString()).apply();
    }

    /** A code to send: the prefix, then the theme in base64 (safe to paste anywhere). */
    static String code(String name, JSONObject values) {
        try {
            String json = new JSONObject().put("v", 1).put("name", name).put("values", values).toString();
            return PREFIX + Base64.encodeToString(json.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP | Base64.URL_SAFE);
        } catch (Exception e) {
            return PREFIX;
        }
    }

    /** Reads a pasted code (the code may sit inside a longer message); null when there isn't a theme in it. */
    static Theme read(String text) {
        if (text == null) {
            return null;
        }
        int at = text.indexOf(PREFIX);
        String usedPrefix = PREFIX;
        if (at < 0) { at = text.indexOf("sara-theme:"); usedPrefix = "sara-theme:"; }
        if (at < 0) {
            return null;
        }
        String rest = text.substring(at + usedPrefix.length()).trim();
        int end = 0;
        while (end < rest.length() && "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_=".indexOf(rest.charAt(end)) >= 0) {
            end++;
        }
        if (end == 0 || end > 20000) {
            return null;
        }
        try {
            String json = new String(Base64.decode(rest.substring(0, end), Base64.URL_SAFE), StandardCharsets.UTF_8);
            JSONObject all = new JSONObject(json);
            JSONObject values = all.getJSONObject("values");
            JSONObject clean = new JSONObject();
            for (Iterator<String> keys = values.keys(); keys.hasNext(); ) {
                String key = keys.next();
                if (known(key)) {
                    clean.put(key, values.get(key));
                }
            }
            if (clean.length() == 0) {
                return null;
            }
            String name = all.optString("name", "").trim();
            return new Theme(name.length() > 40 ? name.substring(0, 40) : name, clean, false);
        } catch (Exception e) {
            return null;
        }
    }

    static boolean known(String key) {
        for (String[] group : new String[][]{STRING_KEYS, INT_KEYS, BOOLEAN_KEYS}) {
            for (String one : group) {
                if (one.equals(key)) {
                    return true;
                }
            }
        }
        return false;
    }

    /** Three ready looks to start from. */
    static List<Theme> builtIn(android.content.Context context) {
        ArrayList<Theme> list = new ArrayList<>();
        list.add(preset(context.getString(R.string.theme_riyadh_night), "dusk", Color.rgb(101, 103, 191), "squircle", IconTint.NORMAL, 1));
        list.add(preset(context.getString(R.string.theme_desert), "dunes", Color.rgb(194, 91, 125), "cookie4", IconTint.TINTED, 0));
        list.add(preset(context.getString(R.string.theme_pearl), "pearl", Color.rgb(58, 137, 118), "circle", IconTint.THEMED, 2));
        return list;
    }

    private static Theme preset(String name, String wallpaper, int accent, String shape, String style, int card) {
        JSONObject values = new JSONObject();
        try {
            values.put("wallpaper_style", wallpaper).put("accent", accent).put("accent_auto", false).put(IconShapes.PREF, shape)
                    .put(IconTint.PREF, style).put(LockScreen.CARD_STYLE, card);
        } catch (Exception ignored) {
        }
        return new Theme(name, values, true);
    }
}
