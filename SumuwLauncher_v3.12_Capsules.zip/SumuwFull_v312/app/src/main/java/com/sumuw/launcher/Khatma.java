package com.sumuw.launcher;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import java.util.List;
import java.util.Locale;

/**
 * A plan to read the whole Quran in a set number of days (30 by default: a juz a day), the day's
 * portion, what is done, and a daily reminder. The reading itself opens the Quran app on the phone.
 */
final class Khatma {
    static final String PREF_START = "khatma_start";
    static final String PREF_DAYS = "khatma_days";
    static final String PREF_DONE = "khatma_done";
    static final String PREF_REMIND = "khatma_remind";
    static final int[] PLANS = {10, 15, 30, 60};

    private Khatma() {
    }

    static boolean active(SharedPreferences prefs) {
        return prefs.contains(PREF_START);
    }

    static int days(SharedPreferences prefs) {
        return Math.max(1, prefs.getInt(PREF_DAYS, 30));
    }

    /** Ajza' read so far, in halves (0..60), so a 60-day plan can count half a juz. */
    static int doneHalves(SharedPreferences prefs) {
        return Math.max(0, Math.min(60, prefs.getInt(PREF_DONE, 0)));
    }

    /** Halves of a juz per day: 30 days → 2, 60 days → 1, 10 days → 6. */
    static int halvesPerDay(SharedPreferences prefs) {
        return Math.max(1, Math.round(60f / days(prefs)));
    }

    static void start(SharedPreferences prefs, int days, long now) {
        prefs.edit().putLong(PREF_START, Countdowns.startOfDay(now).getTimeInMillis()).putInt(PREF_DAYS, days).putInt(PREF_DONE, 0).apply();
    }

    static void stop(SharedPreferences prefs) {
        prefs.edit().remove(PREF_START).remove(PREF_DONE).apply();
    }

    /** Marks the day's portion read; returns true when the whole Quran is done. */
    static boolean readToday(SharedPreferences prefs) {
        int done = Math.min(60, doneHalves(prefs) + halvesPerDay(prefs));
        prefs.edit().putInt(PREF_DONE, done).apply();
        return done >= 60;
    }

    /** Where the plan says you should be by the end of today, in halves. */
    static int dueHalves(SharedPreferences prefs, long now) {
        int day = Math.max(0, Countdowns.daysUntil(now, prefs.getLong(PREF_START, now))) + 1;
        return Math.min(60, day * halvesPerDay(prefs));
    }

    /** The next juz to read (1..30). */
    static int nextJuz(SharedPreferences prefs) {
        return Math.min(30, doneHalves(prefs) / 2 + 1);
    }

    /** "الجزء ١٢" or "الجزء ١٢ – ١٤", the portion still to read today. */
    static String portion(Context context, SharedPreferences prefs) {
        java.text.NumberFormat number = java.text.NumberFormat.getIntegerInstance();
        int from = nextJuz(prefs);
        int to = Math.min(30, (doneHalves(prefs) + halvesPerDay(prefs) + 1) / 2);
        if (halvesPerDay(prefs) == 1) {
            return context.getString(doneHalves(prefs) % 2 == 0 ? R.string.khatma_half_first : R.string.khatma_half_second, number.format(from));
        }
        return to > from ? context.getString(R.string.khatma_juz_range, number.format(from), number.format(to))
                : context.getString(R.string.khatma_juz, number.format(from));
    }

    /** A Quran app on the phone: by package or name ("quran", "mushaf", "القرآن", "مصحف"), else null. */
    static Intent quranApp(Context context) {
        PackageManager pm = context.getPackageManager();
        List<ResolveInfo> all = pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0);
        for (ResolveInfo info : all) {
            String pkg = info.activityInfo.packageName.toLowerCase(Locale.ROOT);
            String label = String.valueOf(info.loadLabel(pm));
            if (pkg.contains("quran") || pkg.contains("mushaf") || pkg.contains("moshaf") || label.contains("القرآن") || label.contains("مصحف")
                    || label.toLowerCase(Locale.ROOT).contains("quran")) {
                return new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                        .setClassName(info.activityInfo.packageName, info.activityInfo.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            }
        }
        return null;
    }

    /** Minutes after midnight for the daily reminder; -1 when off. Default 21:00. */
    static int remindAt(SharedPreferences prefs) {
        return prefs.getInt(PREF_REMIND, 21 * 60);
    }
}
