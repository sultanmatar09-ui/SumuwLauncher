package com.sumuw.launcher;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

/** Small line icons drawn in code, so they match the text colour and need no image files. */
final class Glyphs extends Drawable {
    static final int INFO = 0;
    static final int DOCK_ADD = 1;
    static final int DOCK_REMOVE = 2;
    static final int HIDE = 3;
    static final int ARRANGE = 4;
    static final int UNINSTALL = 5;
    static final int OPEN = 6;
    static final int SHARE = 7;
    static final int SETTINGS = 8;
    static final int LOCATION = 9;
    static final int BELL = 10;
    static final int CALENDAR = 11;
    static final int FOLDER = 12;
    static final int WIDGET = 13;
    static final int CLOSE = 14;
    static final int CHECK = 15;
    static final int SORT = 16;
    static final int SPARK = 17;
    static final int WIFI = 18;
    static final int MIC = 19;
    static final int LOCK = 20;
    static final int EYE = 21;
    static final int EYE_OFF = 22;
    static final int PLAY = 23;
    static final int PAUSE = 24;
    static final int PREV = 25;
    static final int NEXT = 26;
    static final int FLASH = 27;
    static final int BLUETOOTH = 28;
    static final int MOON = 29;
    static final int VIBRATE = 30;
    static final int SUN = 31;
    static final int SEND = 32;
    static final int SHADE = 33;
    static final int CHEVRON_UP = 34;
    static final int AIRPLANE = 35;
    static final int ROTATE_LOCK = 36;
    static final int TIMER = 37;
    static final int CALCULATOR = 38;
    static final int CAMERA = 39;
    static final int SPEAKER = 40;
    static final int SPEAKER_LOUD = 41;
    static final int CHEVRON_LEFT = 42;
    static final int CHEVRON_RIGHT = 43;
    static final int DATA = 44;
    static final int HOTSPOT = 45;
    static final int NFC = 46;
    static final int SAVER = 47;
    static final int ALARM = 48;
    static final int NOTE = 49;
    static final int TROPHY = 50;
    static final int KAABA = 51;
    static final int PHONE = 52;
    static final int LINK = 53;
    static final int SEARCH = 54;
    static final int BEADS = 55;
    static final int MUSIC = 56;
    static final int APPS = 57;
    static final int PALETTE = 58;
    static final int HOURGLASS = 59;
    static final int IMPORT = 60;
    static final int NAVIGATE = 61;
    static final int BAG = 62;

    private final int type;
    private final int size;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF oval = new RectF();

    Glyphs(int type, int color, int sizePx) {
        this.type = type;
        this.size = sizePx;
        paint.setColor(color);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setStrokeWidth(Math.max(1.5f, sizePx * 0.085f));
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        float s = Math.min(b.width(), b.height());
        float x = b.left + (b.width() - s) / 2f;
        float y = b.top + (b.height() - s) / 2f;
        c.save();
        c.translate(x, y);
        float u = s / 24f; // draw on a 24-unit grid
        path.reset();
        switch (type) {
            case INFO:
                c.drawCircle(12 * u, 12 * u, 9 * u, paint);
                c.drawLine(12 * u, 11 * u, 12 * u, 16.5f * u, paint);
                dot(c, 12 * u, 7.8f * u, u);
                break;
            case DOCK_ADD:
            case DOCK_REMOVE:
                oval.set(4 * u, 3 * u, 20 * u, 21 * u);
                c.drawRoundRect(oval, 4 * u, 4 * u, paint);
                c.drawLine(8.5f * u, 12 * u, 15.5f * u, 12 * u, paint);
                if (type == DOCK_ADD) {
                    c.drawLine(12 * u, 8.5f * u, 12 * u, 15.5f * u, paint);
                }
                break;
            case HIDE:
                path.moveTo(3 * u, 12 * u);
                path.cubicTo(6 * u, 6.5f * u, 18 * u, 6.5f * u, 21 * u, 12 * u);
                path.cubicTo(18 * u, 17.5f * u, 6 * u, 17.5f * u, 3 * u, 12 * u);
                c.drawPath(path, paint);
                c.drawCircle(12 * u, 12 * u, 2.6f * u, paint);
                c.drawLine(4.5f * u, 20 * u, 19.5f * u, 4 * u, paint);
                break;
            case ARRANGE:
                for (int i = 0; i < 2; i++) {
                    for (int j = 0; j < 2; j++) {
                        oval.set((4 + i * 9) * u, (4 + j * 9) * u, (11 + i * 9) * u, (11 + j * 9) * u);
                        c.drawRoundRect(oval, 2 * u, 2 * u, paint);
                    }
                }
                break;
            case UNINSTALL:
                c.drawLine(4 * u, 6.5f * u, 20 * u, 6.5f * u, paint);
                c.drawLine(9.5f * u, 6.5f * u, 9.5f * u, 4 * u, paint);
                c.drawLine(9.5f * u, 4 * u, 14.5f * u, 4 * u, paint);
                c.drawLine(14.5f * u, 4 * u, 14.5f * u, 6.5f * u, paint);
                path.moveTo(6 * u, 6.5f * u);
                path.lineTo(7 * u, 20 * u);
                path.lineTo(17 * u, 20 * u);
                path.lineTo(18 * u, 6.5f * u);
                c.drawPath(path, paint);
                c.drawLine(10.3f * u, 10 * u, 10.3f * u, 16.5f * u, paint);
                c.drawLine(13.7f * u, 10 * u, 13.7f * u, 16.5f * u, paint);
                break;
            case OPEN:
                path.moveTo(13 * u, 4 * u);
                path.lineTo(20 * u, 4 * u);
                path.lineTo(20 * u, 11 * u);
                c.drawPath(path, paint);
                c.drawLine(20 * u, 4 * u, 11 * u, 13 * u, paint);
                path.reset();
                path.moveTo(17 * u, 14 * u);
                path.lineTo(17 * u, 20 * u);
                path.lineTo(4 * u, 20 * u);
                path.lineTo(4 * u, 7 * u);
                path.lineTo(10 * u, 7 * u);
                c.drawPath(path, paint);
                break;
            case SHARE:
                c.drawCircle(17.5f * u, 5.5f * u, 2.5f * u, paint);
                c.drawCircle(6.5f * u, 12 * u, 2.5f * u, paint);
                c.drawCircle(17.5f * u, 18.5f * u, 2.5f * u, paint);
                c.drawLine(8.7f * u, 10.7f * u, 15.3f * u, 6.8f * u, paint);
                c.drawLine(8.7f * u, 13.3f * u, 15.3f * u, 17.2f * u, paint);
                break;
            case SETTINGS:
                c.drawCircle(12 * u, 12 * u, 3 * u, paint);
                for (int i = 0; i < 8; i++) {
                    double a = Math.PI / 4 * i;
                    c.drawLine((float) (12 + Math.cos(a) * 6) * u, (float) (12 + Math.sin(a) * 6) * u,
                            (float) (12 + Math.cos(a) * 9) * u, (float) (12 + Math.sin(a) * 9) * u, paint);
                }
                c.drawCircle(12 * u, 12 * u, 6 * u, paint);
                break;
            case LOCATION:
                path.moveTo(12 * u, 21 * u);
                path.cubicTo(6 * u, 14.5f * u, 5 * u, 12 * u, 5 * u, 9.5f * u);
                path.cubicTo(5 * u, 5.4f * u, 8.2f * u, 3 * u, 12 * u, 3 * u);
                path.cubicTo(15.8f * u, 3 * u, 19 * u, 5.4f * u, 19 * u, 9.5f * u);
                path.cubicTo(19 * u, 12 * u, 18 * u, 14.5f * u, 12 * u, 21 * u);
                c.drawPath(path, paint);
                c.drawCircle(12 * u, 9.5f * u, 2.5f * u, paint);
                break;
            case BELL:
                path.moveTo(6 * u, 16.5f * u);
                path.lineTo(6 * u, 11 * u);
                path.cubicTo(6 * u, 7.2f * u, 8.6f * u, 4.5f * u, 12 * u, 4.5f * u);
                path.cubicTo(15.4f * u, 4.5f * u, 18 * u, 7.2f * u, 18 * u, 11 * u);
                path.lineTo(18 * u, 16.5f * u);
                c.drawPath(path, paint);
                c.drawLine(4 * u, 16.5f * u, 20 * u, 16.5f * u, paint);
                c.drawLine(10.5f * u, 19.5f * u, 13.5f * u, 19.5f * u, paint);
                break;
            case CALENDAR:
                oval.set(4 * u, 5 * u, 20 * u, 20 * u);
                c.drawRoundRect(oval, 3 * u, 3 * u, paint);
                c.drawLine(4 * u, 9.5f * u, 20 * u, 9.5f * u, paint);
                c.drawLine(8.5f * u, 3 * u, 8.5f * u, 6.5f * u, paint);
                c.drawLine(15.5f * u, 3 * u, 15.5f * u, 6.5f * u, paint);
                break;
            case FOLDER:
                path.moveTo(3 * u, 7 * u);
                path.lineTo(3 * u, 19 * u);
                path.lineTo(21 * u, 19 * u);
                path.lineTo(21 * u, 8.5f * u);
                path.lineTo(11.5f * u, 8.5f * u);
                path.lineTo(9.5f * u, 5.5f * u);
                path.lineTo(3 * u, 5.5f * u);
                path.close();
                c.drawPath(path, paint);
                break;
            case WIDGET:
                oval.set(3 * u, 3 * u, 21 * u, 13 * u);
                c.drawRoundRect(oval, 3 * u, 3 * u, paint);
                oval.set(3 * u, 15.5f * u, 10.5f * u, 21 * u);
                c.drawRoundRect(oval, 2 * u, 2 * u, paint);
                oval.set(13.5f * u, 15.5f * u, 21 * u, 21 * u);
                c.drawRoundRect(oval, 2 * u, 2 * u, paint);
                break;
            case CLOSE:
                c.drawLine(6 * u, 6 * u, 18 * u, 18 * u, paint);
                c.drawLine(18 * u, 6 * u, 6 * u, 18 * u, paint);
                break;
            case CHECK:
                path.moveTo(5 * u, 12.5f * u);
                path.lineTo(10 * u, 17.5f * u);
                path.lineTo(19.5f * u, 7 * u);
                c.drawPath(path, paint);
                break;
            case SORT:
                // three lines getting shorter, and an arrow pointing down beside them
                c.drawLine(3.5f * u, 7 * u, 13.5f * u, 7 * u, paint);
                c.drawLine(3.5f * u, 12 * u, 11 * u, 12 * u, paint);
                c.drawLine(3.5f * u, 17 * u, 8.5f * u, 17 * u, paint);
                c.drawLine(18 * u, 5 * u, 18 * u, 19 * u, paint);
                path.moveTo(15 * u, 16 * u);
                path.lineTo(18 * u, 19 * u);
                path.lineTo(21 * u, 16 * u);
                c.drawPath(path, paint);
                break;
            case SPARK: {
                // a four-pointed sparkle, filled
                Paint.Style style = paint.getStyle();
                paint.setStyle(Paint.Style.FILL);
                path.moveTo(12 * u, 2.5f * u);
                path.quadTo(13.2f * u, 10.8f * u, 21.5f * u, 12 * u);
                path.quadTo(13.2f * u, 13.2f * u, 12 * u, 21.5f * u);
                path.quadTo(10.8f * u, 13.2f * u, 2.5f * u, 12 * u);
                path.quadTo(10.8f * u, 10.8f * u, 12 * u, 2.5f * u);
                path.close();
                c.drawPath(path, paint);
                paint.setStyle(style);
                break;
            }
            case LOCK:
                oval.set(5 * u, 10.5f * u, 19 * u, 20.5f * u);
                c.drawRoundRect(oval, 2.5f * u, 2.5f * u, paint);
                oval.set(8 * u, 3.5f * u, 16 * u, 14 * u);
                c.drawArc(oval, 180, 180, false, paint);
                c.drawLine(8 * u, 8.75f * u, 8 * u, 10.5f * u, paint);
                c.drawLine(16 * u, 8.75f * u, 16 * u, 10.5f * u, paint);
                dot(c, 12 * u, 15.5f * u, u * 1.3f);
                break;
            case EYE:
            case EYE_OFF:
                path.moveTo(2.5f * u, 12 * u);
                path.quadTo(12 * u, 2.5f * u, 21.5f * u, 12 * u);
                path.quadTo(12 * u, 21.5f * u, 2.5f * u, 12 * u);
                path.close();
                c.drawPath(path, paint);
                c.drawCircle(12 * u, 12 * u, 3.2f * u, paint);
                if (type == EYE_OFF) {
                    c.drawLine(4 * u, 4 * u, 20 * u, 20 * u, paint);
                }
                break;
            case PLAY:
            case PAUSE:
            case PREV:
            case NEXT: {
                Paint.Style style = paint.getStyle();
                paint.setStyle(Paint.Style.FILL);
                if (type == PLAY) {
                    path.moveTo(8 * u, 5 * u);
                    path.lineTo(19 * u, 12 * u);
                    path.lineTo(8 * u, 19 * u);
                    path.close();
                    c.drawPath(path, paint);
                } else if (type == PAUSE) {
                    oval.set(6.5f * u, 5 * u, 10 * u, 19 * u);
                    c.drawRoundRect(oval, u, u, paint);
                    oval.set(14 * u, 5 * u, 17.5f * u, 19 * u);
                    c.drawRoundRect(oval, u, u, paint);
                } else {
                    boolean next = type == NEXT;
                    float tip = next ? 16 : 8;
                    float base = next ? 6 : 18;
                    path.moveTo(base * u, 6 * u);
                    path.lineTo(tip * u, 12 * u);
                    path.lineTo(base * u, 18 * u);
                    path.close();
                    c.drawPath(path, paint);
                    oval.set((next ? 16.5f : 5.5f) * u, 6 * u, (next ? 18.5f : 7.5f) * u, 18 * u);
                    c.drawRect(oval, paint);
                }
                paint.setStyle(style);
                break;
            }
            case FLASH:
                path.moveTo(8 * u, 3.5f * u);
                path.lineTo(16 * u, 3.5f * u);
                path.lineTo(16 * u, 7 * u);
                path.lineTo(14 * u, 10.5f * u);
                path.lineTo(14 * u, 20.5f * u);
                path.lineTo(10 * u, 20.5f * u);
                path.lineTo(10 * u, 10.5f * u);
                path.lineTo(8 * u, 7 * u);
                path.close();
                c.drawPath(path, paint);
                c.drawLine(8 * u, 7 * u, 16 * u, 7 * u, paint);
                c.drawLine(12 * u, 13 * u, 12 * u, 15.5f * u, paint);
                break;
            case BLUETOOTH:
                path.moveTo(7 * u, 7.5f * u);
                path.lineTo(16.5f * u, 16 * u);
                path.lineTo(12 * u, 20.5f * u);
                path.lineTo(12 * u, 3.5f * u);
                path.lineTo(16.5f * u, 8 * u);
                path.lineTo(7 * u, 16.5f * u);
                c.drawPath(path, paint);
                break;
            case MOON:
                path.moveTo(15.5f * u, 3.8f * u);
                path.cubicTo(8.5f * u, 3.8f * u, 4.5f * u, 9.5f * u, 5.2f * u, 14 * u);
                path.cubicTo(6 * u, 19 * u, 12.5f * u, 22 * u, 18.5f * u, 17.5f * u);
                path.cubicTo(12 * u, 17.5f * u, 9.5f * u, 9.5f * u, 15.5f * u, 3.8f * u);
                path.close();
                c.drawPath(path, paint);
                break;
            case VIBRATE:
                oval.set(8 * u, 4 * u, 16 * u, 20 * u);
                c.drawRoundRect(oval, 2 * u, 2 * u, paint);
                c.drawLine(4.5f * u, 8.5f * u, 4.5f * u, 15.5f * u, paint);
                c.drawLine(19.5f * u, 8.5f * u, 19.5f * u, 15.5f * u, paint);
                c.drawLine(2 * u, 10.5f * u, 2 * u, 13.5f * u, paint);
                c.drawLine(22 * u, 10.5f * u, 22 * u, 13.5f * u, paint);
                break;
            case SUN:
                c.drawCircle(12 * u, 12 * u, 4 * u, paint);
                for (int i = 0; i < 8; i++) {
                    double angle = Math.PI / 4 * i;
                    float cos = (float) Math.cos(angle);
                    float sin = (float) Math.sin(angle);
                    c.drawLine(12 * u + cos * 7 * u, 12 * u + sin * 7 * u, 12 * u + cos * 9.5f * u, 12 * u + sin * 9.5f * u, paint);
                }
                break;
            case SEND:
                path.moveTo(4 * u, 4.5f * u);
                path.lineTo(20.5f * u, 12 * u);
                path.lineTo(4 * u, 19.5f * u);
                path.lineTo(6.5f * u, 12 * u);
                path.close();
                c.drawPath(path, paint);
                c.drawLine(6.5f * u, 12 * u, 12 * u, 12 * u, paint);
                break;
            case SHADE:
                oval.set(4 * u, 4 * u, 20 * u, 20 * u);
                c.drawRoundRect(oval, 3 * u, 3 * u, paint);
                c.drawLine(4 * u, 9 * u, 20 * u, 9 * u, paint);
                path.moveTo(9 * u, 13 * u);
                path.lineTo(12 * u, 16 * u);
                path.lineTo(15 * u, 13 * u);
                c.drawPath(path, paint);
                break;
            case CHEVRON_UP:
                path.moveTo(6 * u, 15 * u);
                path.lineTo(12 * u, 9 * u);
                path.lineTo(18 * u, 15 * u);
                c.drawPath(path, paint);
                break;
            case MIC:
                oval.set(9 * u, 3 * u, 15 * u, 14.5f * u);
                c.drawRoundRect(oval, 3 * u, 3 * u, paint);
                oval.set(5.5f * u, 5 * u, 18.5f * u, 17.5f * u);
                c.drawArc(oval, 0, 180, false, paint);
                c.drawLine(12 * u, 17.5f * u, 12 * u, 21 * u, paint);
                break;
            case WIFI:
                oval.set(2.5f * u, 6 * u, 21.5f * u, 25 * u);
                c.drawArc(oval, 225, 90, false, paint);
                oval.set(6.5f * u, 10 * u, 17.5f * u, 21 * u);
                c.drawArc(oval, 225, 90, false, paint);
                dot(c, 12 * u, 18.5f * u, u * 1.3f);
                break;
            case AIRPLANE:
                path.moveTo(12 * u, 2.8f * u);
                path.lineTo(13.4f * u, 4.6f * u);
                path.lineTo(13.4f * u, 9.4f * u);
                path.lineTo(21 * u, 14 * u);
                path.lineTo(21 * u, 15.8f * u);
                path.lineTo(13.4f * u, 13.4f * u);
                path.lineTo(13.4f * u, 18.2f * u);
                path.lineTo(15.8f * u, 20 * u);
                path.lineTo(15.8f * u, 21.3f * u);
                path.lineTo(12 * u, 20.2f * u);
                path.lineTo(8.2f * u, 21.3f * u);
                path.lineTo(8.2f * u, 20 * u);
                path.lineTo(10.6f * u, 18.2f * u);
                path.lineTo(10.6f * u, 13.4f * u);
                path.lineTo(3 * u, 15.8f * u);
                path.lineTo(3 * u, 14 * u);
                path.lineTo(10.6f * u, 9.4f * u);
                path.lineTo(10.6f * u, 4.6f * u);
                path.close();
                c.drawPath(path, paint);
                break;
            case ROTATE_LOCK:
                oval.set(3 * u, 3 * u, 21 * u, 21 * u);
                c.drawArc(oval, -60, 300, false, paint);
                path.moveTo(16.2f * u, 3.6f * u);
                path.lineTo(16.5f * u, 4.2f * u);
                path.lineTo(15.2f * u, 6.4f * u);
                c.drawPath(path, paint);
                oval.set(9 * u, 11.5f * u, 15 * u, 16.5f * u);
                c.drawRoundRect(oval, 1.2f * u, 1.2f * u, paint);
                oval.set(10.2f * u, 8.2f * u, 13.8f * u, 13 * u);
                c.drawArc(oval, 180, 180, false, paint);
                break;
            case TIMER:
                c.drawCircle(12 * u, 13.5f * u, 7.5f * u, paint);
                c.drawLine(10 * u, 3 * u, 14 * u, 3 * u, paint);
                c.drawLine(12 * u, 3 * u, 12 * u, 6 * u, paint);
                c.drawLine(12 * u, 13.5f * u, 12 * u, 9.5f * u, paint);
                c.drawLine(18 * u, 6.5f * u, 19.3f * u, 7.8f * u, paint);
                break;
            case CALCULATOR:
                oval.set(5 * u, 2.5f * u, 19 * u, 21.5f * u);
                c.drawRoundRect(oval, 2.5f * u, 2.5f * u, paint);
                oval.set(8 * u, 5.5f * u, 16 * u, 9.5f * u);
                c.drawRoundRect(oval, 1 * u, 1 * u, paint);
                for (int row = 0; row < 2; row++) {
                    for (int col = 0; col < 3; col++) {
                        dot(c, (8.8f + col * 3.2f) * u, (13.5f + row * 3.6f) * u, u * 1.1f);
                    }
                }
                break;
            case CAMERA:
                oval.set(3 * u, 7 * u, 21 * u, 19.5f * u);
                c.drawRoundRect(oval, 2.5f * u, 2.5f * u, paint);
                path.moveTo(8.5f * u, 7 * u);
                path.lineTo(10 * u, 4.6f * u);
                path.lineTo(14 * u, 4.6f * u);
                path.lineTo(15.5f * u, 7 * u);
                c.drawPath(path, paint);
                c.drawCircle(12 * u, 13.2f * u, 3.5f * u, paint);
                break;
            case SPEAKER:
            case SPEAKER_LOUD:
                path.moveTo(3.5f * u, 9.5f * u);
                path.lineTo(7.5f * u, 9.5f * u);
                path.lineTo(12.5f * u, 5 * u);
                path.lineTo(12.5f * u, 19 * u);
                path.lineTo(7.5f * u, 14.5f * u);
                path.lineTo(3.5f * u, 14.5f * u);
                path.close();
                c.drawPath(path, paint);
                if (type == SPEAKER_LOUD) {
                    oval.set(10 * u, 8 * u, 18 * u, 16 * u);
                    c.drawArc(oval, -50, 100, false, paint);
                    oval.set(9 * u, 4.5f * u, 22 * u, 19.5f * u);
                    c.drawArc(oval, -50, 100, false, paint);
                }
                break;
            case CHEVRON_LEFT:
                path.moveTo(15 * u, 6 * u);
                path.lineTo(9 * u, 12 * u);
                path.lineTo(15 * u, 18 * u);
                c.drawPath(path, paint);
                break;
            case CHEVRON_RIGHT:
                path.moveTo(9 * u, 6 * u);
                path.lineTo(15 * u, 12 * u);
                path.lineTo(9 * u, 18 * u);
                c.drawPath(path, paint);
                break;
            case DATA:
                c.drawLine(8 * u, 4 * u, 8 * u, 20 * u, paint);
                path.moveTo(4.5f * u, 7.5f * u);
                path.lineTo(8 * u, 4 * u);
                path.lineTo(11.5f * u, 7.5f * u);
                c.drawLine(16 * u, 4 * u, 16 * u, 20 * u, paint);
                path.moveTo(12.5f * u, 16.5f * u);
                path.lineTo(16 * u, 20 * u);
                path.lineTo(19.5f * u, 16.5f * u);
                c.drawPath(path, paint);
                break;
            case HOTSPOT:
                dot(c, 12 * u, 13 * u, u * 1.4f);
                oval.set(7.5f * u, 8.5f * u, 16.5f * u, 17.5f * u);
                c.drawArc(oval, 135, 270, false, paint);
                oval.set(3.5f * u, 4.5f * u, 20.5f * u, 21.5f * u);
                c.drawArc(oval, 135, 270, false, paint);
                break;
            case NFC:
                oval.set(4 * u, 4 * u, 20 * u, 20 * u);
                c.drawRoundRect(oval, 4 * u, 4 * u, paint);
                path.moveTo(9 * u, 16 * u);
                path.lineTo(9 * u, 8 * u);
                path.lineTo(15 * u, 16 * u);
                path.lineTo(15 * u, 8 * u);
                c.drawPath(path, paint);
                break;
            case SAVER:
                oval.set(6 * u, 4.5f * u, 18 * u, 21 * u);
                c.drawRoundRect(oval, 2.5f * u, 2.5f * u, paint);
                c.drawLine(10 * u, 3 * u, 14 * u, 3 * u, paint);
                c.drawLine(12 * u, 9.5f * u, 12 * u, 16 * u, paint);
                c.drawLine(8.8f * u, 12.7f * u, 15.2f * u, 12.7f * u, paint);
                break;
            case ALARM:
                c.drawCircle(12 * u, 13 * u, 7.5f * u, paint);
                c.drawLine(12 * u, 13 * u, 12 * u, 9 * u, paint);
                c.drawLine(12 * u, 13 * u, 14.8f * u, 14.6f * u, paint);
                c.drawLine(3.5f * u, 6 * u, 6.5f * u, 3.5f * u, paint);
                c.drawLine(20.5f * u, 6 * u, 17.5f * u, 3.5f * u, paint);
                break;
            case NOTE:
                oval.set(5 * u, 3 * u, 19 * u, 21 * u);
                c.drawRoundRect(oval, 2.5f * u, 2.5f * u, paint);
                c.drawLine(8.5f * u, 8.5f * u, 15.5f * u, 8.5f * u, paint);
                c.drawLine(8.5f * u, 12 * u, 15.5f * u, 12 * u, paint);
                c.drawLine(8.5f * u, 15.5f * u, 12.5f * u, 15.5f * u, paint);
                break;
            case TROPHY:
                path.moveTo(7 * u, 4 * u);
                path.lineTo(17 * u, 4 * u);
                path.lineTo(17 * u, 9 * u);
                path.cubicTo(17 * u, 12.5f * u, 14.5f * u, 14.5f * u, 12 * u, 14.5f * u);
                path.cubicTo(9.5f * u, 14.5f * u, 7 * u, 12.5f * u, 7 * u, 9 * u);
                path.close();
                c.drawPath(path, paint);
                c.drawLine(12 * u, 14.5f * u, 12 * u, 18 * u, paint);
                c.drawLine(8.5f * u, 20 * u, 15.5f * u, 20 * u, paint);
                oval.set(3.5f * u, 5 * u, 8.5f * u, 10.5f * u);
                c.drawArc(oval, 90, 180, false, paint);
                oval.set(15.5f * u, 5 * u, 20.5f * u, 10.5f * u);
                c.drawArc(oval, 270, 180, false, paint);
                break;
            case PHONE:
                path.moveTo(7 * u, 3.5f * u);
                path.lineTo(10 * u, 3.5f * u);
                path.lineTo(11.5f * u, 8 * u);
                path.lineTo(9.5f * u, 9.8f * u);
                path.cubicTo(10.6f * u, 12 * u, 12 * u, 13.4f * u, 14.2f * u, 14.5f * u);
                path.lineTo(16 * u, 12.5f * u);
                path.lineTo(20.5f * u, 14 * u);
                path.lineTo(20.5f * u, 17 * u);
                path.cubicTo(20.5f * u, 19 * u, 19 * u, 20.5f * u, 17 * u, 20.5f * u);
                path.cubicTo(10 * u, 20 * u, 4 * u, 14 * u, 3.5f * u, 7 * u);
                path.cubicTo(3.5f * u, 5 * u, 5 * u, 3.5f * u, 7 * u, 3.5f * u);
                path.close();
                c.drawPath(path, paint);
                break;
            case LINK:
                oval.set(3 * u, 8.5f * u, 12.5f * u, 15.5f * u);
                c.drawRoundRect(oval, 3.5f * u, 3.5f * u, paint);
                oval.set(11.5f * u, 8.5f * u, 21 * u, 15.5f * u);
                c.drawRoundRect(oval, 3.5f * u, 3.5f * u, paint);
                break;
            case SEARCH:
                c.drawCircle(10.5f * u, 10.5f * u, 6 * u, paint);
                c.drawLine(15 * u, 15 * u, 20 * u, 20 * u, paint);
                break;
            case MUSIC: {
                // Two eighth notes joined by a beam.
                Paint.Style style = paint.getStyle();
                paint.setStyle(Paint.Style.FILL);
                oval.set(4 * u, 15 * u, 9.5f * u, 19.5f * u);
                c.drawOval(oval, paint);
                oval.set(13.5f * u, 13 * u, 19 * u, 17.5f * u);
                c.drawOval(oval, paint);
                paint.setStyle(style);
                c.drawLine(9 * u, 17 * u, 9 * u, 6 * u, paint);
                c.drawLine(18.5f * u, 15 * u, 18.5f * u, 4 * u, paint);
                c.drawLine(9 * u, 6 * u, 18.5f * u, 4 * u, paint);
                c.drawLine(9 * u, 9 * u, 18.5f * u, 7 * u, paint);
                break;
            }
            case BEADS: {
                // A loop of prayer beads and its tassel.
                for (int k = 0; k < 11; k++) {
                    double angle = Math.PI * 2 * k / 12 - Math.PI / 2 + Math.PI / 12;
                    float bx = 12 * u + (float) Math.cos(angle) * 7 * u;
                    float by = 10 * u + (float) Math.sin(angle) * 6.5f * u;
                    c.drawCircle(bx, by, 1.3f * u, paint);
                }
                c.drawLine(12 * u, 16.5f * u, 12 * u, 21 * u, paint);
                c.drawLine(12 * u, 21 * u, 10 * u, 22 * u, paint);
                c.drawLine(12 * u, 21 * u, 14 * u, 22 * u, paint);
                break;
            }
            case APPS: {
                Paint.Style style = paint.getStyle();
                paint.setStyle(Paint.Style.FILL);
                for (int i = 0; i < 3; i++) {
                    for (int j = 0; j < 3; j++) {
                        c.drawCircle((6 + i * 6) * u, (6 + j * 6) * u, 1.9f * u, paint);
                    }
                }
                paint.setStyle(style);
                break;
            }
            case PALETTE:
                path.moveTo(12 * u, 3 * u);
                path.cubicTo(5 * u, 3 * u, 2.5f * u, 9 * u, 3.5f * u, 13.5f * u);
                path.cubicTo(4.5f * u, 18.5f * u, 9 * u, 21 * u, 12.5f * u, 21 * u);
                path.cubicTo(14.5f * u, 21 * u, 14.5f * u, 18.5f * u, 13.5f * u, 17.5f * u);
                path.cubicTo(12.5f * u, 16.5f * u, 13 * u, 14.5f * u, 15 * u, 14.5f * u);
                path.lineTo(17.5f * u, 14.5f * u);
                path.cubicTo(20 * u, 14.5f * u, 21.5f * u, 12.5f * u, 21 * u, 10 * u);
                path.cubicTo(20 * u, 5.5f * u, 16.5f * u, 3 * u, 12 * u, 3 * u);
                c.drawPath(path, paint);
                dot(c, 7.5f * u, 11.5f * u, u);
                dot(c, 10 * u, 7 * u, u);
                dot(c, 15 * u, 7.5f * u, u);
                break;
            case HOURGLASS:
                c.drawLine(6 * u, 3.5f * u, 18 * u, 3.5f * u, paint);
                c.drawLine(6 * u, 20.5f * u, 18 * u, 20.5f * u, paint);
                path.moveTo(7.5f * u, 3.5f * u);
                path.cubicTo(7.5f * u, 9 * u, 12 * u, 10 * u, 12 * u, 12 * u);
                path.cubicTo(12 * u, 14 * u, 7.5f * u, 15 * u, 7.5f * u, 20.5f * u);
                path.moveTo(16.5f * u, 3.5f * u);
                path.cubicTo(16.5f * u, 9 * u, 12 * u, 10 * u, 12 * u, 12 * u);
                path.cubicTo(12 * u, 14 * u, 16.5f * u, 15 * u, 16.5f * u, 20.5f * u);
                c.drawPath(path, paint);
                break;
            case IMPORT:
                c.drawLine(12 * u, 3.5f * u, 12 * u, 14.5f * u, paint);
                c.drawLine(7.5f * u, 10 * u, 12 * u, 14.5f * u, paint);
                c.drawLine(16.5f * u, 10 * u, 12 * u, 14.5f * u, paint);
                path.moveTo(4 * u, 14 * u);
                path.lineTo(4 * u, 20 * u);
                path.lineTo(20 * u, 20 * u);
                path.lineTo(20 * u, 14 * u);
                c.drawPath(path, paint);
                break;
            case NAVIGATE:
                path.moveTo(12 * u, 3 * u);
                path.lineTo(19.5f * u, 20.5f * u);
                path.lineTo(12 * u, 16.5f * u);
                path.lineTo(4.5f * u, 20.5f * u);
                path.close();
                c.drawPath(path, paint);
                break;
            case BAG:
                oval.set(4.5f * u, 8 * u, 19.5f * u, 21 * u);
                c.drawRoundRect(oval, 2.5f * u, 2.5f * u, paint);
                path.moveTo(8.5f * u, 10.5f * u);
                path.lineTo(8.5f * u, 7 * u);
                path.cubicTo(8.5f * u, 2.5f * u, 15.5f * u, 2.5f * u, 15.5f * u, 7 * u);
                path.lineTo(15.5f * u, 10.5f * u);
                c.drawPath(path, paint);
                break;
            case KAABA:
                oval.set(5 * u, 6 * u, 19 * u, 20 * u);
                c.drawRect(oval, paint);
                c.drawLine(5 * u, 10 * u, 19 * u, 10 * u, paint);
                break;
            default:
                break;
        }
        c.restore();
    }

    private void dot(Canvas c, float cx, float cy, float u) {
        Paint.Style style = paint.getStyle();
        paint.setStyle(Paint.Style.FILL);
        c.drawCircle(cx, cy, 1.25f * u, paint);
        paint.setStyle(style);
    }

    @Override
    public int getIntrinsicWidth() {
        return size;
    }

    @Override
    public int getIntrinsicHeight() {
        return size;
    }

    @Override
    public void setAlpha(int alpha) {
        paint.setAlpha(alpha);
    }

    @Override
    public void setColorFilter(ColorFilter colorFilter) {
        paint.setColorFilter(colorFilter);
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }
}
