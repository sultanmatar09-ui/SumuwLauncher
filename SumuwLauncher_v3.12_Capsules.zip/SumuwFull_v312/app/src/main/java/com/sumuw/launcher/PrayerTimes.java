package com.sumuw.launcher;

import java.util.Calendar;
import java.util.TimeZone;

/**
 * Prayer times from the sun's position (the method published by PrayTimes.org), with the
 * Umm al-Qura convention used in Saudi Arabia as the default: Fajr at 18.5°, Isha 90 minutes
 * after Maghrib (120 in Ramadan).
 */
final class PrayerTimes {
    static final int FAJR = 0;
    static final int SUNRISE = 1;
    static final int DHUHR = 2;
    static final int ASR = 3;
    static final int MAGHRIB = 4;
    static final int ISHA = 5;

    static final String[] METHODS = {"umm_al_qura", "mwl", "egypt", "karachi", "isna"};

    static final class City {
        final String id;
        final String name;
        final double lat;
        final double lng;

        City(String id, String name, double lat, double lng) {
            this.id = id;
            this.name = name;
            this.lat = lat;
            this.lng = lng;
        }
    }

    /** Saudi cities, all on Asia/Riyadh time. */
    static final City[] CITIES = {
            new City("riyadh", "الرياض", 24.7136, 46.6753),
            new City("makkah", "مكة المكرمة", 21.4225, 39.8262),
            new City("madinah", "المدينة المنورة", 24.4672, 39.6111),
            new City("jeddah", "جدة", 21.4858, 39.1925),
            new City("dammam", "الدمام", 26.4207, 50.0888),
            new City("khobar", "الخبر", 26.2172, 50.1971),
            new City("taif", "الطائف", 21.2703, 40.4158),
            new City("abha", "أبها", 18.2164, 42.5053),
            new City("khamis", "خميس مشيط", 18.3061, 42.7290),
            new City("tabuk", "تبوك", 28.3835, 36.5662),
            new City("buraydah", "بريدة", 26.3592, 43.9818),
            new City("hail", "حائل", 27.5114, 41.7208),
            new City("hofuf", "الأحساء", 25.3833, 49.5864),
            new City("jubail", "الجبيل", 27.0046, 49.6460),
            new City("yanbu", "ينبع", 24.0895, 38.0618),
            new City("jazan", "جازان", 16.8892, 42.5511),
            new City("najran", "نجران", 17.5656, 44.2289),
            new City("baha", "الباحة", 20.0129, 41.4677),
            new City("arar", "عرعر", 30.9753, 41.0381),
            new City("sakaka", "سكاكا", 29.9697, 40.2064),
    };

    private PrayerTimes() {
    }

    static City city(String id) {
        for (City city : CITIES) {
            if (city.id.equals(id)) {
                return city;
            }
        }
        return CITIES[0];
    }

    /**
     * The six times for the calendar day of {@code day} in {@code zone}, as epoch milliseconds.
     *
     * @param hanafi Asr when an object's shadow is twice its length (otherwise once)
     * @param ramadan Umm al-Qura moves Isha to two hours after Maghrib during Ramadan
     */
    static long[] forDay(long day, double lat, double lng, TimeZone zone, String method, boolean hanafi, boolean ramadan) {
        Calendar local = Calendar.getInstance(zone);
        local.setTimeInMillis(day);
        int year = local.get(Calendar.YEAR);
        int month = local.get(Calendar.MONTH) + 1;
        int date = local.get(Calendar.DAY_OF_MONTH);
        double jDate = julian(year, month, date) - lng / (15.0 * 24.0);

        double fajrAngle;
        double ishaAngle = 0;
        int ishaMinutes = 0;
        switch (method) {
            case "mwl":
                fajrAngle = 18;
                ishaAngle = 17;
                break;
            case "egypt":
                fajrAngle = 19.5;
                ishaAngle = 17.5;
                break;
            case "karachi":
                fajrAngle = 18;
                ishaAngle = 18;
                break;
            case "isna":
                fajrAngle = 15;
                ishaAngle = 15;
                break;
            default:
                fajrAngle = 18.5;
                ishaMinutes = ramadan ? 120 : 90;
                break;
        }

        // First pass from rough guesses, second pass from the first pass (as PrayTimes does).
        double[] t = {5, 6, 12, 13, 18, 18};
        for (int pass = 0; pass < 2; pass++) {
            double[] portion = new double[6];
            for (int i = 0; i < 6; i++) {
                portion[i] = t[i] / 24.0;
            }
            double fajr = sunAngleTime(jDate, lat, fajrAngle, portion[FAJR], true);
            double sunrise = sunAngleTime(jDate, lat, 0.833, portion[SUNRISE], true);
            double dhuhr = midDay(jDate, portion[DHUHR]);
            double asr = asrTime(jDate, lat, hanafi ? 2 : 1, portion[ASR]);
            double sunset = sunAngleTime(jDate, lat, 0.833, portion[MAGHRIB], false);
            double isha = ishaMinutes > 0 ? sunset + ishaMinutes / 60.0 : sunAngleTime(jDate, lat, ishaAngle, portion[ISHA], false);
            t = new double[]{fajr, sunrise, dhuhr, asr, sunset, isha};
        }

        Calendar midnight = Calendar.getInstance(zone);
        midnight.clear();
        midnight.set(year, month - 1, date, 0, 0, 0);
        long base = midnight.getTimeInMillis();
        double offset = zone.getOffset(base + 12L * 3600000L) / 3600000.0;
        long[] result = new long[6];
        for (int i = 0; i < 6; i++) {
            double hours = t[i] + offset - lng / 15.0;
            long minutes = Math.round(hours * 60.0);
            result[i] = base + minutes * 60000L;
        }
        return result;
    }

    // ---------------------------------------------------------------- astronomy

    private static double julian(int year, int month, int day) {
        if (month <= 2) {
            year -= 1;
            month += 12;
        }
        double a = Math.floor(year / 100.0);
        double b = 2 - a + Math.floor(a / 4.0);
        return Math.floor(365.25 * (year + 4716)) + Math.floor(30.6001 * (month + 1)) + day + b - 1524.5;
    }

    /** Returns {declination, equation of time} for a Julian date. */
    private static double[] sunPosition(double jd) {
        double d = jd - 2451545.0;
        double g = fixAngle(357.529 + 0.98560028 * d);
        double q = fixAngle(280.459 + 0.98564736 * d);
        double l = fixAngle(q + 1.915 * dsin(g) + 0.020 * dsin(2 * g));
        double e = 23.439 - 0.00000036 * d;
        double ra = darctan2(dcos(e) * dsin(l), dcos(l)) / 15.0;
        double eqt = q / 15.0 - fixHour(ra);
        double decl = darcsin(dsin(e) * dsin(l));
        return new double[]{decl, eqt};
    }

    private static double midDay(double jDate, double portion) {
        double eqt = sunPosition(jDate + portion)[1];
        return fixHour(12 - eqt);
    }

    private static double sunAngleTime(double jDate, double lat, double angle, double portion, boolean beforeNoon) {
        double decl = sunPosition(jDate + portion)[0];
        double noon = midDay(jDate, portion);
        double cos = (-dsin(angle) - dsin(decl) * dsin(lat)) / (dcos(decl) * dcos(lat));
        cos = Math.max(-1, Math.min(1, cos));
        double t = darccos(cos) / 15.0;
        return noon + (beforeNoon ? -t : t);
    }

    private static double asrTime(double jDate, double lat, double factor, double portion) {
        double decl = sunPosition(jDate + portion)[0];
        double angle = -darccot(factor + dtan(Math.abs(lat - decl)));
        return sunAngleTime(jDate, lat, angle, portion, false);
    }

    private static double dsin(double d) {
        return Math.sin(Math.toRadians(d));
    }

    private static double dcos(double d) {
        return Math.cos(Math.toRadians(d));
    }

    private static double dtan(double d) {
        return Math.tan(Math.toRadians(d));
    }

    private static double darcsin(double x) {
        return Math.toDegrees(Math.asin(x));
    }

    private static double darccos(double x) {
        return Math.toDegrees(Math.acos(x));
    }

    private static double darctan2(double y, double x) {
        return Math.toDegrees(Math.atan2(y, x));
    }

    private static double darccot(double x) {
        return Math.toDegrees(Math.atan(1 / x));
    }

    private static double fixAngle(double a) {
        a = a - 360.0 * Math.floor(a / 360.0);
        return a < 0 ? a + 360.0 : a;
    }

    private static double fixHour(double a) {
        a = a - 24.0 * Math.floor(a / 24.0);
        return a < 0 ? a + 24.0 : a;
    }
}
