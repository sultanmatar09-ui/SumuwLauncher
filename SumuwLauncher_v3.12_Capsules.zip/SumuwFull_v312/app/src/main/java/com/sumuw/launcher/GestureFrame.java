package com.sumuw.launcher;

import android.content.Context;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;

/**
 * Holds the app grid and watches gestures over the whole of it, including ones that start on an
 * icon: a sideways swipe turns the page, pulling down at the top opens the notifications (or search),
 * swiping up opens search, and pinching with
 * two fingers switches between the roomy and the compact grid. Taps and long presses still reach
 * the icons, because the frame only takes over once a gesture is clear.
 */
final class GestureFrame extends FrameLayout {
    interface Callback {
        /** dx > 0 is a swipe to the right. */
        void onSwipe(float dx);

        void onPullDown();

        boolean canPullDown();

        /** Swiping up (on the pages, where the grid doesn't scroll). */
        boolean canPushUp();

        void onPushUp();

        /** scale < 1 when the fingers moved together. */
        void onPinch(float scale);

        /** True when the pages follow the finger: then onSwipeDrag and onSwipeEnd come instead of onSwipe. */
        default boolean tracksSwipe() {
            return false;
        }

        default void onSwipeDrag(float dx) {
        }

        /** The finger let go (or the gesture was cancelled, with dx 0): settle on a page. */
        default void onSwipeEnd(float dx, float velocityX) {
        }

        /** True when the pull-down follows the finger: then onPullDrag and onPullEnd come instead of onPullDown. */
        default boolean tracksPull() {
            return false;
        }

        default void onPullDrag(float dy) {
        }

        default void onPullEnd(float dy, float velocityY) {
        }

        /** True when a swipe up follows the finger (the app drawer coming up): then onPushDrag and onPushEnd come. */
        default boolean tracksPush() {
            return false;
        }

        /** up is how far the finger has gone up, never below 0. */
        default void onPushDrag(float up) {
        }

        default void onPushEnd(float up, float velocityY) {
        }

        /** True when a swipe up that starts at this point belongs to the icon there (its own swipe-up action). */
        default boolean iconSwipeAt(float x, float y) {
            return false;
        }

        default void onIconSwipe(float x, float y) {
        }
    }

    private static final int NONE = 0;
    private static final int SWIPE = 1;
    private static final int PULL = 2;
    private static final int PINCH = 3;
    private static final int PUSH = 4;
    private static final int ICON = 5;

    private final int slop;
    private final float swipeMin;
    private final float pullMin;
    private final ScaleGestureDetector scaleDetector;
    private Callback callback;
    private float downX;
    private float downY;
    private int mode = NONE;
    private float scale = 1f;
    private boolean tracking;
    private android.view.VelocityTracker velocity;

    GestureFrame(Context context) {
        super(context);
        float density = context.getResources().getDisplayMetrics().density;
        slop = ViewConfiguration.get(context).getScaledTouchSlop();
        swipeMin = 42f * density;
        pullMin = 70f * density;
        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScaleBegin(ScaleGestureDetector detector) {
                scale = 1f;
                return true;
            }

            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                scale *= detector.getScaleFactor();
                return true;
            }
        });
    }

    void setCallback(Callback value) {
        callback = value;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event);
        track(event);
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                begin(event);
                return false;
            case MotionEvent.ACTION_POINTER_DOWN:
                stopTracking();
                mode = PINCH; // a second finger: the icons get a cancel, the pinch is ours
                return true;
            case MotionEvent.ACTION_MOVE:
                return decide(event.getX() - downX, event.getY() - downY);
            default:
                return false;
        }
    }

    private void begin(MotionEvent event) {
        downX = event.getX();
        downY = event.getY();
        mode = NONE;
        scale = 1f;
        tracking = false;
    }

    private void track(MotionEvent event) {
        if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
            if (velocity != null) {
                velocity.recycle();
            }
            velocity = android.view.VelocityTracker.obtain();
        }
        if (velocity != null) {
            velocity.addMovement(event);
        }
    }

    /** Whether the gesture is now clearly one of ours; a page swipe or a pull starts following the finger. */
    private boolean decide(float dx, float dy) {
        if (mode != NONE) {
            return true;
        }
        if (Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy) * 1.2f) {
            mode = SWIPE;
            tracking = callback != null && callback.tracksSwipe();
            // Start from where the finger is, less the slop, so the page doesn't jump.
            downX += Math.signum(dx) * slop;
            return true;
        }
        if (dy > slop && dy > Math.abs(dx) * 1.3f && callback != null && callback.canPullDown()) {
            mode = PULL;
            tracking = callback.tracksPull();
            downY += slop;
            return true;
        }
        if (-dy > slop && -dy > Math.abs(dx) * 1.3f && callback != null && callback.iconSwipeAt(downX, downY)) {
            mode = ICON;
            return true;
        }
        if (-dy > slop && -dy > Math.abs(dx) * 1.3f && callback != null && callback.canPushUp()) {
            mode = PUSH;
            tracking = callback.tracksPush();
            downY -= slop;
            return true;
        }
        return false;
    }

    private void stopTracking() {
        if (!tracking || callback == null) {
            tracking = false;
            return;
        }
        tracking = false;
        if (mode == SWIPE) {
            callback.onSwipeEnd(0f, 0f); // back where it was
        } else if (mode == PULL) {
            callback.onPullEnd(0f, 0f);
        } else if (mode == PUSH) {
            callback.onPushEnd(0f, 0f);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event);
        // Touches that no icon took come here from the start (DOWN included); the rest after an intercept.
        if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
            track(event);
        } else if (velocity != null) {
            velocity.addMovement(event);
        }
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                begin(event);
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                stopTracking();
                mode = PINCH;
                return true;
            case MotionEvent.ACTION_MOVE: {
                float dx = event.getX() - downX;
                float dy = event.getY() - downY;
                if (mode == NONE) {
                    decide(dx, dy);
                    dx = event.getX() - downX;
                    dy = event.getY() - downY;
                }
                if (tracking && callback != null) {
                    if (mode == SWIPE) {
                        callback.onSwipeDrag(dx);
                    } else if (mode == PULL) {
                        callback.onPullDrag(Math.max(0f, dy));
                    } else if (mode == PUSH) {
                        callback.onPushDrag(Math.max(0f, -dy));
                    }
                }
                return true;
            }
            case MotionEvent.ACTION_UP: {
                finish(event.getX() - downX, event.getY() - downY);
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                stopTracking();
                mode = NONE;
                recycleVelocity();
                return true;
            default:
                return true;
        }
    }

    private void recycleVelocity() {
        if (velocity != null) {
            velocity.recycle();
            velocity = null;
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        recycleVelocity();
        super.onDetachedFromWindow();
    }

    private void finish(float dx, float dy) {
        int was = mode;
        boolean followed = tracking;
        mode = NONE;
        tracking = false;
        if (callback == null) {
            return;
        }
        if (followed && (was == SWIPE || was == PULL || was == PUSH)) {
            float vx = 0f;
            float vy = 0f;
            if (velocity != null) {
                velocity.computeCurrentVelocity(1000);
                vx = velocity.getXVelocity();
                vy = velocity.getYVelocity();
            }
            if (was == SWIPE) {
                callback.onSwipeEnd(dx, vx);
            } else if (was == PUSH) {
                callback.onPushEnd(Math.max(0f, -dy), vy);
            } else {
                callback.onPullEnd(Math.max(0f, dy), vy);
            }
            recycleVelocity();
            return;
        }
        recycleVelocity();
        if (was == PINCH) {
            if (scale < 0.8f || scale > 1.25f) {
                callback.onPinch(scale);
            }
            return;
        }
        if (was == ICON || (was == NONE && -dy > swipeMin && -dy > Math.abs(dx) * 1.3f && callback.iconSwipeAt(downX, downY))) {
            if (-dy > swipeMin) {
                callback.onIconSwipe(downX, downY);
            }
            return;
        }
        if (Math.abs(dx) > swipeMin && Math.abs(dx) > Math.abs(dy) * 1.2f) {
            callback.onSwipe(dx);
        } else if (dy > pullMin && dy > Math.abs(dx) * 1.3f && callback.canPullDown()) {
            callback.onPullDown();
        } else if (-dy > pullMin && -dy > Math.abs(dx) * 1.3f && callback.canPushUp()) {
            callback.onPushUp();
        }
    }

    /** For tests: the same result as a finished one-finger gesture with these distances. */
    void simulate(float dx, float dy) {
        finish(dx, dy);
    }

    /** For tests: the same, starting at this point of the frame. */
    void simulateAt(float x, float y, float dx, float dy) {
        downX = x;
        downY = y;
        mode = NONE;
        finish(dx, dy);
    }
}
