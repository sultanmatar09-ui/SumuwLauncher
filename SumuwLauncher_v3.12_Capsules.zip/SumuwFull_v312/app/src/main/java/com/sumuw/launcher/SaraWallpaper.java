package com.sumuw.launcher;

import android.app.KeyguardManager;
import android.app.WallpaperInfo;
import android.app.WallpaperManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.service.wallpaper.WallpaperService;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.SurfaceHolder;
import android.view.View;
import java.util.Date;
import java.util.Locale;

/**
 * Sara Home's live wallpaper. It draws the same wallpaper as the home screen, and while the phone is
 * locked it adds the adaptive clock and a card with today's Hijri date, the next prayer and the battery. The lock itself stays
 * the system's own (fingerprint, face, PIN), so nothing about the phone's security changes.
 * It redraws once a minute and when the battery changes, and sleeps while the screen is off.
 */
public class SaraWallpaper extends WallpaperService {
    /** Where the card sits on the lock screen: 0 top, 1 middle, 2 bottom. */
    static final String POSITION = "lock_info_pos";

    static ComponentName component(Context context) {
        return new ComponentName(context, SaraWallpaper.class);
    }

    /** Sara's live wallpaper is on the home screen or on the lock screen. */
    static boolean active(Context context) {
        return onHome(context) || onLock(context);
    }

    /** On the home screen (Android's "system" wallpaper). */
    static boolean onHome(Context context) {
        try {
            WallpaperInfo info = WallpaperManager.getInstance(context).getWallpaperInfo();
            return info != null && component(context).equals(info.getComponent());
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * On the lock screen, where the card and the clock show. Android 14 and later (One UI 6) can give
     * the lock screen its own live wallpaper; before that the lock screen shows the home one unless it
     * has a picture of its own.
     */
    static boolean onLock(Context context) {
        WallpaperManager manager;
        try {
            manager = WallpaperManager.getInstance(context);
        } catch (Exception e) {
            return false;
        }
        if (Build.VERSION.SDK_INT >= 34) {
            try {
                WallpaperInfo lock = manager.getWallpaperInfo(WallpaperManager.FLAG_LOCK);
                if (lock != null) {
                    return component(context).equals(lock.getComponent());
                }
            } catch (Exception ignored) {
                // some phones don't answer for the lock screen alone: judge by the home screen below
            }
        }
        try {
            // No picture of the lock screen's own: it shows the home screen's (live) wallpaper.
            return onHome(context) && manager.getWallpaperId(WallpaperManager.FLAG_LOCK) < 0;
        } catch (Exception e) {
            return onHome(context);
        }
    }

    /** The engines drawing now (the lock screen, the system preview): options apply to them at once. */
    private static final java.util.Set<SaraEngine> ENGINES = java.util.Collections.newSetFromMap(new java.util.WeakHashMap<>());

    /** Draw again now, after an option changed in Sara's settings. */
    static void redrawAll() {
        for (SaraEngine engine : new java.util.ArrayList<>(ENGINES)) {
            engine.redrawSoon();
        }
    }

    /** Opens the system preview, where the user applies it to the lock screen (and home screen). */
    static Intent chooser(Context context) {
        return new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, component(context));
    }

    @Override
    public Engine onCreateEngine() {
        return new SaraEngine();
    }

    final class SaraEngine extends Engine {
        private final Handler handler = new Handler(Looper.getMainLooper());
        /** Any of Sara's settings changed (position, clock, wallpaper, font…): draw again with them. */
        private final SharedPreferences.OnSharedPreferenceChangeListener settingsChanged = (prefs, key) -> redrawSoon();

        void redrawSoon() {
            if (visible) {
                handler.removeCallbacks(redraw);
                handler.postDelayed(redraw, 60L);
            }
        }

        @Override
        public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);
            ENGINES.add(this);
        }
        private final Runnable redraw = new Runnable() {
            @Override
            public void run() {
                draw();
            }
        };
        private boolean visible;
        private float phase;
        private float offsetX;
        private boolean lastAnimated;
        private boolean registered;
        private int batteryLevel = -1;
        private boolean charging;
        private final BroadcastReceiver receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (Intent.ACTION_BATTERY_CHANGED.equals(intent.getAction())) {
                    readBattery(intent);
                }
                draw();
                // The lock screen appears and goes away around these events; look again a moment later.
                handler.removeCallbacks(redraw);
                handler.postDelayed(redraw, 450L);
            }
        };

        @Override
        public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            if (isVisible) {
                register();
                draw();
            } else {
                unregister();
                handler.removeCallbacks(redraw);
            }
        }

        @Override
        public void onOffsetsChanged(float xOffset, float yOffset, float xOffsetStep, float yOffsetStep, int xPixelOffset, int yPixelOffset) {
            offsetX = xOffset - 0.5f;
            if (visible) {
                draw();
            }
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            draw();
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            visible = false;
            unregister();
            handler.removeCallbacks(redraw);
            super.onSurfaceDestroyed(holder);
        }

        @Override
        public void onDestroy() {
            ENGINES.remove(this);
            unregister();
            handler.removeCallbacks(redraw);
            super.onDestroy();
        }

        private final Runnable notificationsChanged = new Runnable() {
            @Override
            public void run() {
                if (visible) {
                    handler.removeCallbacks(redraw);
                    handler.postDelayed(redraw, 120L);
                }
            }
        };

        private void register() {
            DotsService.wallpaperHook = notificationsChanged;
            if (registered) {
                return;
            }
            getSharedPreferences("duo_home", 0).registerOnSharedPreferenceChangeListener(settingsChanged);
            IntentFilter filter = new IntentFilter(Intent.ACTION_TIME_TICK);
            filter.addAction(Intent.ACTION_TIME_CHANGED);
            filter.addAction(Intent.ACTION_TIMEZONE_CHANGED);
            filter.addAction(Intent.ACTION_SCREEN_ON);
            filter.addAction(Intent.ACTION_SCREEN_OFF);
            filter.addAction(Intent.ACTION_USER_PRESENT);
            filter.addAction(Intent.ACTION_BATTERY_CHANGED);
            try {
                // System broadcasts only: no other app may send to this receiver (Android 13+ flag).
                readBattery(Build.VERSION.SDK_INT >= 33 ? registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
                        : registerReceiver(receiver, filter));
                registered = true;
            } catch (Exception ignored) {
            }
        }

        private void unregister() {
            if (DotsService.wallpaperHook == notificationsChanged) {
                DotsService.wallpaperHook = null;
            }
            if (registered) {
                getSharedPreferences("duo_home", 0).unregisterOnSharedPreferenceChangeListener(settingsChanged);
                try {
                    unregisterReceiver(receiver);
                } catch (Exception ignored) {
                }
                registered = false;
            }
        }

        private void readBattery(Intent intent) {
            if (intent == null) {
                return;
            }
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            if (level >= 0 && scale > 0) {
                batteryLevel = Math.round(level * 100f / scale);
            }
            int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            charging = status == BatteryManager.BATTERY_STATUS_CHARGING
                    || (status == BatteryManager.BATTERY_STATUS_FULL && intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0);
        }

        void draw() {
            Fonts.init(SaraWallpaper.this); // the lock screen card and clock in the same font as Home
            SurfaceHolder holder = getSurfaceHolder();
            Canvas canvas = null;
            try {
                canvas = holder.lockCanvas();
                if (canvas != null) {
                    boolean withCard = isPreview() || locked();
                    paint(canvas, canvas.getWidth(), canvas.getHeight(), withCard);
                    if (visible) {
                        if (lastAnimated) {
                            phase += 0.05f;
                            handler.removeCallbacks(redraw);
                            handler.postDelayed(redraw, 50L);
                        } else if (withCard && LockScreen.turnsPages(getSharedPreferences("duo_home", 0))) {
                            // The next page of tools comes in on the beat, only while the lock screen is in view.
                            long wait = LockScreen.PAGE_MS - System.currentTimeMillis() % LockScreen.PAGE_MS + 40L;
                            handler.removeCallbacks(redraw);
                            handler.postDelayed(redraw, wait);
                        }
                    }
                }
            } catch (Exception ignored) {
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas);
                    } catch (Exception ignored) {
                    }
                }
            }
        }

        private boolean locked() {
            KeyguardManager keyguard = getSystemService(KeyguardManager.class);
            return keyguard != null && keyguard.isKeyguardLocked();
        }

        void paint(Canvas canvas, int width, int height, boolean withCard) {
            lastAnimated = SaraWallpaper.paint(SaraWallpaper.this, canvas, width, height, withCard, batteryLevel, charging, phase, offsetX * 28f);
        }
    }

    /** Draws the wallpaper, and the card when asked; shared with the screenshot tests and the lock screen editor. */
    static void paint(Context context, Canvas canvas, int width, int height, boolean withCard, int batteryLevel, boolean charging) {
        paint(context, canvas, width, height, withCard, batteryLevel, charging, 0f, 0f);
    }

    static boolean paint(Context context, Canvas canvas, int width, int height, boolean withCard, int batteryLevel, boolean charging, float phase, float tiltX) {
        SharedPreferences prefs = context.getSharedPreferences("duo_home", 0);
        boolean animated = false;
        String id;
        if (withCard) {
            id = LockScreen.wallpaper(prefs); // the lock screen's own wallpaper, or Home's
        } else {
            id = prefs.getString("wallpaper_style", Wallpapers.DEFAULT);
            if (Wallpapers.DEVICE.equals(id) || !Wallpapers.isKnown(id)) {
                id = Wallpapers.DEFAULT; // this is the phone's wallpaper now, so it can't show the phone's wallpaper
            }
        }
        Drawable art = Wallpapers.create(context, id);
        art.setBounds(0, 0, width, height);
        art.draw(canvas);
        if (!Wallpapers.PHOTO.equals(id)) {
            // The hour's light, dust or rain, and the national days; drops on the glass only on the lock screen.
            Ambience.State state = Ambience.now(context, prefs, System.currentTimeMillis(), !Wallpapers.isDark(context, id));
            animated = state.animated();
            Ambience.draw(canvas, width, height, state, withCard, phase, tiltX, 0f);
        }
        if (withCard) {
            LockScreen.dim(canvas, width, height, prefs);
            boolean dark = LockScreen.darkUnder(context, prefs, id);
            RectF card = LockScreen.cardRect(context, prefs, width, height);
            int style = AdaptiveClock.style(prefs);
            if (style != AdaptiveClock.OFF) {
                drawClock(context, prefs, canvas, id, width, height, style, card);
            } else {
                lastClock = null;
            }
            if (card != null) {
                LockScreen.drawCard(context, prefs, canvas, card, dark, batteryLevel, charging);
            }
            lastCard = card;
            LockScreen.drawMessage(context, prefs, canvas, width, height, dark);
        }
        return animated;
    }

    /** Where the info card sits, so the clock can keep out of its way (null when the card is off). */
    static RectF cardRect(Context context, SharedPreferences prefs, int width, int height) {
        return LockScreen.cardRect(context, prefs, width, height);
    }

    /** The last card, for the editor (a tap on it opens its options). */
    static volatile RectF lastCard;

    /** The last placement, for the screenshot tests and the settings summary. */
    static volatile AdaptiveClock.Placement lastClock;

    private static void drawClock(Context context, SharedPreferences prefs, Canvas canvas, String id, int width, int height,
                                  int style, RectF card) {
        try {
            float density = context.getResources().getDisplayMetrics().density;
            RectF avoid = null;
            if (card != null) {
                avoid = new RectF(card);
                avoid.inset(-6 * density, -18 * density);
            }
            boolean compact = prefs.getBoolean(AdaptiveClock.COMPACT_PREF, true) && AdaptiveClock.waitingNotifications() > 0;
            String[] time = AdaptiveClock.timeParts(context, System.currentTimeMillis());
            AdaptiveClock.Placement place = AdaptiveClock.place(context, id, width, height, style, time[0], time[1], avoid, compact,
                    LockScreen.clockSize(prefs), LockScreen.clockSide(prefs));
            AdaptiveClock.draw(canvas, place, style, time[0], time[1], Wallpapers.accentFor(context, id),
                    LockScreen.clockColors(context, prefs, id));
            lastClock = place;
        } catch (Exception ignored) {
            // the clock is a nicety; the wallpaper and the card still draw
        }
    }
}
