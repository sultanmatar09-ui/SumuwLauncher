package com.sumuw.launcher;

import android.Manifest;
import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

/** Today's and tomorrow's events from the phone's calendars, for the Today page. Read only. */
final class Agenda {
    static final class Event {
        final long id;
        final String title;
        final long begin;
        final long end;
        final boolean allDay;
        final int color;

        Event(long id, String title, long begin, long end, boolean allDay, int color) {
            this.id = id;
            this.title = title;
            this.begin = begin;
            this.end = end;
            this.allDay = allDay;
            this.color = color;
        }
    }

    private Agenda() {
    }

    static boolean permitted(Context context) {
        return context.checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED;
    }

    /** Events that haven't ended yet, from now to the end of tomorrow, soonest first. */
    static List<Event> upcoming(Context context, long now, int limit) {
        ArrayList<Event> events = new ArrayList<>();
        if (!permitted(context)) {
            return events;
        }
        Calendar end = Calendar.getInstance();
        end.setTimeInMillis(now);
        end.add(Calendar.DAY_OF_MONTH, 2);
        end.set(Calendar.HOUR_OF_DAY, 0);
        end.set(Calendar.MINUTE, 0);
        end.set(Calendar.SECOND, 0);
        end.set(Calendar.MILLISECOND, 0);
        Uri.Builder range = CalendarContract.Instances.CONTENT_URI.buildUpon();
        ContentUris.appendId(range, now - 86400000L); // all-day events are stored in UTC; look a day back
        ContentUris.appendId(range, end.getTimeInMillis());
        String[] columns = {CalendarContract.Instances.EVENT_ID, CalendarContract.Instances.TITLE,
                CalendarContract.Instances.BEGIN, CalendarContract.Instances.END, CalendarContract.Instances.ALL_DAY,
                CalendarContract.Instances.DISPLAY_COLOR};
        String where = CalendarContract.Instances.VISIBLE + " = 1";
        try (Cursor cursor = context.getContentResolver().query(range.build(), columns, where, null,
                CalendarContract.Instances.BEGIN + " ASC")) {
            if (cursor == null) {
                return events;
            }
            while (cursor.moveToNext() && events.size() < limit) {
                boolean allDay = cursor.getInt(4) == 1;
                long begin = cursor.getLong(2);
                long finish = cursor.getLong(3);
                if (allDay) {
                    // All-day dates are midnight UTC; move them to local midnight of the same date.
                    begin = localMidnight(begin);
                    finish = localMidnight(finish);
                }
                if (finish <= now || begin >= end.getTimeInMillis()) {
                    continue;
                }
                String title = cursor.getString(1);
                events.add(new Event(cursor.getLong(0), title == null || title.trim().isEmpty() ? "—" : title.trim(),
                        begin, finish, allDay, cursor.getInt(5)));
            }
        } catch (Exception ignored) {
        }
        return events;
    }

    // ---------------------------------------------------------------- read off the main thread

    private static final java.util.concurrent.ExecutorService READER = java.util.concurrent.Executors.newSingleThreadExecutor(work -> {
        Thread thread = new Thread(work, "sara-agenda");
        thread.setDaemon(true);
        return thread;
    });
    private static final android.os.Handler MAIN = new android.os.Handler(android.os.Looper.getMainLooper());
    private static List<Event> cache = new ArrayList<>();
    private static long cachedAt;
    private static boolean reading;
    private static boolean cachedPermitted;

    /**
     * The calendar is another app's database: reading it is a call across processes that can take a while,
     * so the cards and the lock screen never read it on the main thread. They take what was read last
     * (at most a minute old) and, when that's stale, a read starts in the background; when it ends,
     * {@code changed} runs on the main thread so the caller can draw again.
     */
    static List<Event> recent(Context context, long now, int limit, Runnable changed) {
        ArrayList<Event> out = new ArrayList<>();
        boolean allowed = permitted(context);
        synchronized (Agenda.class) {
            if (!allowed) {
                cache = new ArrayList<>();
                cachedPermitted = false;
                return out;
            }
            boolean stale = !cachedPermitted || now - cachedAt > 60000L || now < cachedAt;
            if (stale && !reading) {
                reading = true;
                final Context app = context.getApplicationContext();
                READER.execute(() -> {
                    List<Event> fresh = upcoming(app, System.currentTimeMillis(), 8);
                    synchronized (Agenda.class) {
                        cache = fresh;
                        cachedAt = System.currentTimeMillis();
                        cachedPermitted = true;
                        reading = false;
                    }
                    if (changed != null) {
                        MAIN.post(changed);
                    }
                });
            }
            for (Event event : cache) {
                if (event.end > now && out.size() < limit) {
                    out.add(event);
                }
            }
        }
        return out;
    }

    /** Read again on the next look (an event added, the permission just granted). */
    static synchronized void forget() {
        cachedAt = 0L;
        cachedPermitted = false;
    }

    private static long localMidnight(long utcMidnight) {
        Calendar utc = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        utc.setTimeInMillis(utcMidnight);
        Calendar local = Calendar.getInstance();
        local.clear();
        local.set(utc.get(Calendar.YEAR), utc.get(Calendar.MONTH), utc.get(Calendar.DAY_OF_MONTH), 0, 0, 0);
        return local.getTimeInMillis();
    }

    /** 0 for today, 1 for tomorrow. */
    static int dayOffset(long when, long now) {
        Calendar a = Calendar.getInstance();
        a.setTimeInMillis(now);
        Calendar b = Calendar.getInstance();
        b.setTimeInMillis(when);
        int days = (b.get(Calendar.YEAR) - a.get(Calendar.YEAR)) * 366 + b.get(Calendar.DAY_OF_YEAR) - a.get(Calendar.DAY_OF_YEAR);
        return Math.max(0, Math.min(1, days));
    }

    static Uri eventUri(long id) {
        return ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, id);
    }
}
