package com.sumuw.launcher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.Display;
import android.view.HapticFeedbackConstants;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;

/**
 * The Qibla: its direction from where the prayer times are worked out, and a compass that turns with
 * the phone. The arrow points at the Kaaba; when the top of the phone faces it, the arrow takes the
 * accent colour and the phone gives one light tap. The compass listens only while it is on screen.
 */
final class Qibla {
    static final double KAABA_LAT = 21.422487;
    static final double KAABA_LNG = 39.826206;

    private Qibla() {
    }

    /** Degrees from true north, clockwise, along the great circle to the Kaaba. */
    static double bearing(double lat, double lng) {
        if (Math.abs(lat - KAABA_LAT) < 1e-6 && Math.abs(lng - KAABA_LNG) < 1e-6) {
            return 0.0;
        }
        double phi1 = Math.toRadians(lat);
        double phi2 = Math.toRadians(KAABA_LAT);
        double dLng = Math.toRadians(KAABA_LNG - lng);
        double y = Math.sin(dLng) * Math.cos(phi2);
        double x = Math.cos(lat1Or(phi1)) * Math.sin(phi2) - Math.sin(phi1) * Math.cos(phi2) * Math.cos(dLng);
        return (Math.toDegrees(Math.atan2(y, x)) + 360.0) % 360.0;
    }

    private static double lat1Or(double phi1) {
        return phi1;
    }

    /** Kilometres to the Kaaba. */
    static double distanceKm(double lat, double lng) {
        double phi1 = Math.toRadians(lat);
        double phi2 = Math.toRadians(KAABA_LAT);
        double dPhi = phi2 - phi1;
        double dLng = Math.toRadians(KAABA_LNG - lng);
        double a = Math.sin(dPhi / 2) * Math.sin(dPhi / 2) + Math.cos(phi1) * Math.cos(phi2) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
        return 6371.0 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    interface Listener {
        void onHeading(float heading, boolean facing);
    }

    /** A dial with north marked and an arrow to the Qibla, turned by the phone's heading. */
    static final class Compass extends View implements SensorEventListener {
        private final float qibla;
        private final int ink;
        private final int soft;
        private final int accent;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path arrow = new Path();
        private final float[] rotation = new float[9];
        private final float[] remapped = new float[9];
        private final float[] orientation = new float[3];
        private final float[] accel = new float[3];
        private final float[] magnet = new float[3];
        private boolean hasAccel;
        private boolean hasMagnet;
        private final SensorManager sensors;
        private boolean listening;
        private float heading = Float.NaN;
        private float declination;
        private boolean facing;
        private Listener listener;

        Compass(Context context, float qibla, int ink, int soft, int accent) {
            super(context);
            this.qibla = qibla;
            this.ink = ink;
            this.soft = soft;
            this.accent = accent;
            sensors = context.getSystemService(SensorManager.class);
            setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        }

        void setLocation(double lat, double lng) {
            GeomagneticField field = new GeomagneticField((float) lat, (float) lng, 0f, System.currentTimeMillis());
            declination = field.getDeclination();
        }

        void setListener(Listener value) {
            listener = value;
        }

        boolean hasSensor() {
            if (sensors == null) {
                return false;
            }
            return sensors.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) != null
                    || sensors.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR) != null
                    || (sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null
                    && sensors.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD) != null);
        }

        @Override
        public void onVisibilityAggregated(boolean visible) {
            super.onVisibilityAggregated(visible);
            listen(visible);
        }

        @Override
        protected void onDetachedFromWindow() {
            listen(false);
            super.onDetachedFromWindow();
        }

        private void listen(boolean on) {
            if (sensors == null || on == listening) {
                return;
            }
            if (on) {
                Sensor sensor = sensors.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
                if (sensor == null) {
                    sensor = sensors.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR);
                }
                if (sensor != null) {
                    listening = sensors.registerListener(this, sensor, SensorManager.SENSOR_DELAY_UI);
                } else {
                    Sensor accelSensor = sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
                    Sensor magnetSensor = sensors.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
                    if (accelSensor != null && magnetSensor != null) {
                        boolean aOk = sensors.registerListener(this, accelSensor, SensorManager.SENSOR_DELAY_UI);
                        boolean mOk = sensors.registerListener(this, magnetSensor, SensorManager.SENSOR_DELAY_UI);
                        listening = aOk && mOk;
                        if (!listening) {
                            sensors.unregisterListener(this);
                        }
                    }
                }
            } else {
                sensors.unregisterListener(this);
                listening = false;
            }
        }

        @Override
        public void onSensorChanged(SensorEvent event) {
            int type = event.sensor.getType();
            if (type == Sensor.TYPE_ROTATION_VECTOR || type == Sensor.TYPE_GAME_ROTATION_VECTOR) {
                SensorManager.getRotationMatrixFromVector(rotation, event.values);
            } else if (type == Sensor.TYPE_ACCELEROMETER) {
                System.arraycopy(event.values, 0, accel, 0, Math.min(3, event.values.length));
                hasAccel = true;
                if (!hasMagnet || !SensorManager.getRotationMatrix(rotation, null, accel, magnet)) {
                    return;
                }
            } else if (type == Sensor.TYPE_MAGNETIC_FIELD) {
                System.arraycopy(event.values, 0, magnet, 0, Math.min(3, event.values.length));
                hasMagnet = true;
                if (!hasAccel || !SensorManager.getRotationMatrix(rotation, null, accel, magnet)) {
                    return;
                }
            } else {
                return;
            }

            float[] matrix = rotation;
            WindowManager wm = getContext().getSystemService(WindowManager.class);
            Display display = wm != null ? wm.getDefaultDisplay() : null;
            int rot = display != null ? display.getRotation() : Surface.ROTATION_0;
            if (rot == Surface.ROTATION_90) {
                SensorManager.remapCoordinateSystem(rotation, SensorManager.AXIS_Y, SensorManager.AXIS_MINUS_X, remapped);
                matrix = remapped;
            } else if (rot == Surface.ROTATION_180) {
                SensorManager.remapCoordinateSystem(rotation, SensorManager.AXIS_MINUS_X, SensorManager.AXIS_MINUS_Y, remapped);
                matrix = remapped;
            } else if (rot == Surface.ROTATION_270) {
                SensorManager.remapCoordinateSystem(rotation, SensorManager.AXIS_MINUS_Y, SensorManager.AXIS_X, remapped);
                matrix = remapped;
            }

            SensorManager.getOrientation(matrix, orientation);
            float azimuth = (float) ((Math.toDegrees(orientation[0]) + declination + 360.0) % 360.0);
            // Smooth a little, minding the wrap at north.
            if (Float.isNaN(heading)) {
                heading = azimuth;
            } else {
                float delta = ((azimuth - heading + 540f) % 360f) - 180f;
                heading = (heading + delta * 0.25f + 360f) % 360f;
            }
            setHeading(heading);
        }

        /** For tests and for the first frame: the phone's heading in degrees. */
        void setHeading(float value) {
            heading = value;
            float off = Math.abs(((qibla - heading + 540f) % 360f) - 180f);
            boolean now = off <= 5f;
            if (now && !facing) {
                performHapticFeedback(HapticFeedbackConstants.CONFIRM);
            }
            facing = now;
            if (listener != null) {
                listener.onHeading(heading, facing);
            }
            invalidate();
        }

        boolean facing() {
            return facing;
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            float r = Math.min(cx, cy) * 0.86f;
            float turn = Float.isNaN(heading) ? 0f : -heading;
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(2f, r * 0.03f));
            paint.setColor(soft);
            canvas.drawCircle(cx, cy, r, paint);
            canvas.save();
            canvas.rotate(turn, cx, cy);
            for (int i = 0; i < 72; i++) {
                float len = i % 18 == 0 ? r * 0.14f : i % 2 == 0 ? r * 0.07f : r * 0.04f;
                double a = Math.toRadians(i * 5);
                float sx = (float) Math.sin(a);
                float sy = (float) -Math.cos(a);
                canvas.drawLine(cx + sx * (r - len), cy + sy * (r - len), cx + sx * r, cy + sy * r, paint);
            }
            paint.setStyle(Paint.Style.FILL);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(r * 0.16f);
            paint.setColor(ink);
            canvas.drawText("N", cx, cy - r * 0.68f, paint);
            // The arrow to the Qibla, fixed on the dial, turning with it.
            canvas.rotate(qibla, cx, cy);
            int color = facing ? accent : ink;
            paint.setColor(color);
            arrow.reset();
            arrow.moveTo(cx, cy - r * 0.86f);
            arrow.lineTo(cx + r * 0.13f, cy - r * 0.58f);
            arrow.lineTo(cx + r * 0.045f, cy - r * 0.58f);
            arrow.lineTo(cx + r * 0.045f, cy + r * 0.12f);
            arrow.lineTo(cx - r * 0.045f, cy + r * 0.12f);
            arrow.lineTo(cx - r * 0.045f, cy - r * 0.58f);
            arrow.lineTo(cx - r * 0.13f, cy - r * 0.58f);
            arrow.close();
            canvas.drawPath(arrow, paint);
            // A small cube for the Kaaba at the arrow's tip.
            float k = r * 0.09f;
            canvas.drawRect(cx - k, cy - r * 0.98f - k, cx + k, cy - r * 0.98f + k, paint);
            canvas.restore();
            // The phone's own direction: a fixed mark at the top.
            paint.setColor(facing ? accent : soft);
            canvas.drawCircle(cx, cy - r - 2f, Math.max(3f, r * 0.04f), paint);
            canvas.drawCircle(cx, cy, Math.max(3f, r * 0.05f), paint);
        }
    }
}
