package com.sumuw.launcher;

import android.app.NotificationManager;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.RippleDrawable;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.AlarmClock;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowInsets;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

/**
 * Control centre in the manner of iOS 7: a frosted sheet pulled up from the bottom edge, following the
 * finger. Top to bottom: airplane mode, Wi-Fi, Bluetooth, do not disturb and rotation lock; brightness;
 * what is playing with its controls and the volume; then torch, timer, calculator and camera. A swipe
 * down on the sheet, a tap above it or Back puts it away.
 */
final class ControlCenter {
    private final HomeActivity home;
    final FrameLayout view;
    private final View scrim;
    private final Sheet sheet;
    private final LinearLayout content;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final int overhang;
    private int bottomInset;
    private boolean open;
    private boolean askedForSettings;
    private CameraManager camera;
    private String torchId;
    private boolean torchOn;
    private final CameraManager.TorchCallback torchCallback = new CameraManager.TorchCallback() {
        @Override
        public void onTorchModeChanged(String cameraId, boolean enabled) {
            if (cameraId.equals(torchId) && enabled != torchOn) {
                torchOn = enabled;
                if (open) {
                    fill();
                }
            }
        }
    };
    /** If an animation is cut short, this still takes the sheet off the screen so it can't block taps. */
    private final Runnable hideIfClosed = new Runnable() {
        @Override
        public void run() {
            if (!open) {
                view.setVisibility(View.GONE);
            }
        }
    };

    ControlCenter(HomeActivity home) {
        this.home = home;
        overhang = home.dp(32.0f);
        view = new FrameLayout(home);
        view.setVisibility(View.GONE);
        view.setLayoutDirection(View.LAYOUT_DIRECTION_LOCALE);
        scrim = new View(home);
        scrim.setBackgroundColor(0x73000000);
        scrim.setAlpha(0f);
        scrim.setContentDescription(home.getString(R.string.close));
        scrim.setOnClickListener(v -> close());
        view.addView(scrim, new FrameLayout.LayoutParams(-1, -1));
        sheet = new Sheet(home);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setClickable(true); // taps on the sheet itself don't fall through to the scrim
        home.glassify(sheet, 30, true);
        // The bottom corners hang below the screen, so only the top is rounded, as on iOS.
        // Phones: the whole width; tablets and open foldables: a sheet of a phone's width in the middle.
        FrameLayout.LayoutParams sheetParams = new FrameLayout.LayoutParams(sheetWidth(), -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        sheetParams.bottomMargin = -overhang;
        view.addView(sheet, sheetParams);
        content = new LinearLayout(home);
        content.setOrientation(LinearLayout.VERTICAL);
        sheet.addView(content, new LinearLayout.LayoutParams(-1, -2));
        view.setOnApplyWindowInsetsListener((v, insets) -> {
            bottomInset = Build.VERSION.SDK_INT >= 30
                    ? insets.getInsets(WindowInsets.Type.systemBars()).bottom : insets.getSystemWindowInsetBottom();
            pad();
            return insets;
        });
        pad();
    }

    /** The sheet's width: the screen's, up to 560dp. */
    private int sheetWidth() {
        int screen = home.getResources().getDisplayMetrics().widthPixels;
        return screen > home.dp(600.0f) ? home.dp(560.0f) : -1;
    }

    /** The side of a round toggle or a shortcut square: a fifth of the row, at most {@code most}. */
    private int slotSide(float most) {
        int screen = home.getResources().getDisplayMetrics().widthPixels;
        int width = Math.min(screen, home.dp(560.0f)) - home.dp(40.0f);
        return Math.max(home.dp(36.0f), Math.min(home.dp(most), width / ROW - home.dp(8.0f)));
    }

    private void pad() {
        content.setPadding(home.dp(20.0f), home.dp(8.0f), home.dp(20.0f), home.dp(18.0f) + bottomInset + overhang);
    }

    boolean isOpen() {
        return open;
    }

    boolean isShowing() {
        return view.getVisibility() == View.VISIBLE;
    }

    // ---------------------------------------------------------------- moving

    /** How much of the sheet shows when it is fully up (the rest hangs below the screen). */
    private float full() {
        return Math.max(home.dp(200.0f), sheet.getMeasuredHeight() - overhang);
    }

    /** The finger started at the bottom edge and moves up: show the sheet under it. */
    void beginDrag() {
        handler.removeCallbacks(hideIfClosed);
        if (!isShowing()) {
            open = true;
            watchTorch(true);
            fill();
            view.setVisibility(View.VISIBLE);
            int width = home.frame.getWidth() > 0 ? home.frame.getWidth() : home.getResources().getDisplayMetrics().widthPixels;
            int sheetWide = sheetWidth();
            if (sheetWide > 0) {
                width = Math.min(width, sheetWide); // the tablet's middle sheet
            }
            sheet.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
            sheet.setTranslationY(full());
            scrim.setAlpha(0f);
        }
        open = true;
        sheet.animate().cancel();
        scrim.animate().cancel();
    }

    /** {@code up}: how far the finger has come up from where it started. */
    void dragTo(float up) {
        float full = full();
        float shown = Math.max(0f, Math.min(full, up));
        sheet.setTranslationY(full - shown);
        scrim.setAlpha(shown / full);
    }

    /** The finger let go; {@code velocity} in pixels a second, negative upwards. */
    void endDrag(float velocity) {
        float full = full();
        float shown = full - sheet.getTranslationY();
        // Opens with a quarter of the way, or a light flick up.
        float fast = home.dp(350.0f);
        if (velocity < -fast || (velocity < fast && shown > full * 0.25f)) {
            settleOpen();
        } else {
            close();
        }
    }

    /** Opens without a drag (accessibility, tests). */
    void open() {
        beginDrag();
        settleOpen();
    }

    private void settleOpen() {
        open = true;
        sheet.animate().translationY(0f).setDuration(260L).setInterpolator(new DecelerateInterpolator(1.6f)).start();
        scrim.animate().alpha(1f).setDuration(260L).start();
        view.announceForAccessibility(home.getString(R.string.control_center));
    }

    void close() {
        if (!isShowing()) {
            open = false;
            return;
        }
        open = false;
        watchTorch(false);
        sheet.animate().translationY(full()).setDuration(220L).setInterpolator(new DecelerateInterpolator()).start();
        scrim.animate().alpha(0f).setDuration(220L).start();
        handler.removeCallbacks(hideIfClosed);
        handler.postDelayed(hideIfClosed, 240L);
    }

    /** Leaving Home: gone at once, no animation. */
    void closeNow() {
        open = false;
        watchTorch(false);
        sheet.animate().cancel();
        scrim.animate().cancel();
        handler.removeCallbacks(hideIfClosed);
        view.setVisibility(View.GONE);
    }

    /** The sheet itself: a downward drag anywhere on it (not on a slider) pushes it back down. */
    private final class Sheet extends LinearLayout {
        private final int slop;
        private float downX;
        private float downY;
        private boolean dragging;
        private android.view.VelocityTracker tracker;

        Sheet(Context context) {
            super(context);
            slop = ViewConfiguration.get(context).getScaledTouchSlop();
        }

        @Override
        public boolean onInterceptTouchEvent(MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = event.getRawX();
                    downY = event.getRawY();
                    dragging = false;
                    return false;
                case MotionEvent.ACTION_MOVE: {
                    float dy = event.getRawY() - downY;
                    float dx = event.getRawX() - downX;
                    if (dy > slop && dy > Math.abs(dx) * 1.4f) {
                        dragging = true;
                        return true;
                    }
                    return false;
                }
                default:
                    return false;
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if (tracker == null) {
                tracker = android.view.VelocityTracker.obtain();
            }
            MotionEvent copy = MotionEvent.obtain(event);
            copy.setLocation(event.getRawX(), event.getRawY());
            tracker.addMovement(copy);
            copy.recycle();
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = event.getRawX();
                    downY = event.getRawY();
                    dragging = false;
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float dy = event.getRawY() - downY;
                    if (!dragging && dy > slop) {
                        dragging = true;
                    }
                    if (dragging) {
                        setTranslationY(Math.max(0f, dy));
                        scrim.setAlpha(Math.max(0f, 1f - getTranslationY() / full()));
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL: {
                    tracker.computeCurrentVelocity(1000);
                    float velocity = tracker.getYVelocity();
                    tracker.recycle();
                    tracker = null;
                    if (dragging) {
                        dragging = false;
                        if (velocity > home.dp(500.0f) || getTranslationY() > full() * 0.3f) {
                            close();
                        } else {
                            settleOpen();
                        }
                    }
                    return true;
                }
                default:
                    return true;
            }
        }
    }

    // ---------------------------------------------------------------- building

    void fill() {
        content.removeAllViews();
        View grabber = new View(home);
        grabber.setBackground(home.pill(HomeActivity.withAlpha(home.textPrimary, 0.45f), 3));
        grabber.setContentDescription(home.getString(R.string.close));
        grabber.setOnClickListener(v -> close());
        LinearLayout.LayoutParams grabberParams = new LinearLayout.LayoutParams(home.dp(38.0f), home.dp(5.0f));
        grabberParams.gravity = Gravity.CENTER_HORIZONTAL;
        grabberParams.bottomMargin = home.dp(16.0f);
        content.addView(grabber, grabberParams);
        content.setContentDescription(home.getString(R.string.control_center));

        android.content.SharedPreferences prefs = home.getSharedPreferences("duo_home", 0);
        LinearLayout toggles = null;
        int inRow = 0;
        for (String key : chosen(prefs, PREF_TOGGLES, DEFAULT_TOGGLES, TOGGLES)) {
            if (toggles == null || inRow == ROW) {
                toggles = new LinearLayout(home);
                toggles.setGravity(Gravity.CENTER);
                LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1, -2);
                if (inRow == ROW) {
                    rowParams.topMargin = home.dp(12.0f);
                }
                content.addView(toggles, rowParams);
                inRow = 0;
            }
            addToggle(toggles, key);
            inRow++;
        }
        while (toggles != null && inRow > 0 && inRow < ROW && chosen(prefs, PREF_TOGGLES, DEFAULT_TOGGLES, TOGGLES).size() > ROW) {
            toggles.addView(new View(home), new LinearLayout.LayoutParams(0, 1, 1f));
            inRow++;
        }

        divider();
        addBrightness();
        divider();
        addMedia();

        List<String> picked = chosen(prefs, PREF_SHORTCUTS, DEFAULT_SHORTCUTS, SHORTCUTS);
        if (!picked.isEmpty()) {
            divider();
        }
        LinearLayout shortcuts = null;
        inRow = 0;
        for (String key : picked) {
            if (shortcuts == null || inRow == ROW) {
                shortcuts = new LinearLayout(home);
                shortcuts.setGravity(Gravity.CENTER);
                LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1, -2);
                if (inRow == ROW) {
                    rowParams.topMargin = home.dp(14.0f);
                }
                content.addView(shortcuts, rowParams);
                inRow = 0;
            }
            addShortcut(shortcuts, key);
            inRow++;
        }
        // A short last row keeps the columns of the row above.
        while (shortcuts != null && inRow > 0 && inRow < ROW && picked.size() > ROW) {
            shortcuts.addView(new View(home), new LinearLayout.LayoutParams(0, 1, 1f));
            inRow++;
        }
        if (torchOn && torchLevels() > 1) {
            addTorchStrength();
        }

        TextView customise = home.label(home.getString(R.string.cc_edit), 13, home.textSecondary, 500);
        customise.setGravity(Gravity.CENTER);
        customise.setPadding(home.dp(16.0f), home.dp(10.0f), home.dp(16.0f), home.dp(4.0f));
        customise.setOnClickListener(v -> edit());
        LinearLayout.LayoutParams customiseParams = new LinearLayout.LayoutParams(-2, -2);
        customiseParams.gravity = Gravity.CENTER_HORIZONTAL;
        customiseParams.topMargin = home.dp(8.0f);
        content.addView(customise, customiseParams);
        grabber.setOnLongClickListener(v -> {
            edit();
            return true;
        });
    }

    // ---------------------------------------------------------------- what it holds

    static final String PREF_TOGGLES = "cc_toggles";
    static final String PREF_SHORTCUTS = "cc_shortcuts";
    static final String[] TOGGLES = {"airplane", "wifi", "bt", "dnd", "rotation", "location", "vibrate", "data", "hotspot", "nfc", "saver", "privacy"};
    static final String DEFAULT_TOGGLES = "airplane,wifi,bt,dnd,rotation";
    static final String[] SHORTCUTS = {"tasbeeh", "torch", "timer", "calculator", "camera", "alarm", "recorder", "notes", "settings"};
    static final String DEFAULT_SHORTCUTS = "tasbeeh,torch,timer,calculator,camera";
    /** Shortcuts in one row. */
    static final int ROW = 5;
    static final int MOST_TOGGLES = 10;
    static final int MOST_SHORTCUTS = 10;

    /** The keys saved under {@code key} that Sara Home knows, in the saved order. */
    static List<String> chosen(android.content.SharedPreferences prefs, String key, String fallback, String[] catalog) {
        List<String> known = java.util.Arrays.asList(catalog);
        ArrayList<String> result = new ArrayList<>();
        for (String part : prefs.getString(key, fallback).split(",")) {
            String name = part.trim();
            if (known.contains(name) && !result.contains(name)) {
                result.add(name);
            }
        }
        return result;
    }

    static void save(android.content.SharedPreferences prefs, String key, List<String> keys) {
        prefs.edit().putString(key, android.text.TextUtils.join(",", keys)).apply();
    }

    static int toggleName(String key) {
        switch (key) {
            case "airplane": return R.string.cc_airplane;
            case "wifi": return R.string.tile_wifi;
            case "bt": return R.string.tile_bluetooth;
            case "dnd": return R.string.tile_dnd;
            case "rotation": return R.string.cc_rotation;
            case "location": return R.string.tile_location;
            case "vibrate": return R.string.tile_vibrate;
            case "data": return R.string.cc_data;
            case "hotspot": return R.string.cc_hotspot;
            case "nfc": return R.string.cc_nfc;
            case "saver": return R.string.cc_saver;
            default: return R.string.privacy_mode;
        }
    }

    static int shortcutName(String key) {
        switch (key) {
            case "tasbeeh": return R.string.cc_tasbeeh;
            case "torch": return R.string.tile_torch;
            case "timer": return R.string.cc_timer;
            case "calculator": return R.string.cc_calculator;
            case "camera": return R.string.cc_camera;
            case "alarm": return R.string.cc_alarm;
            case "recorder": return R.string.cc_recorder;
            case "notes": return R.string.cc_notes;
            default: return R.string.tile_settings;
        }
    }

    private void addToggle(LinearLayout row, String key) {
        switch (key) {
            case "airplane":
                toggle(row, Glyphs.AIRPLANE, R.string.cc_airplane, airplaneOn(), () -> open(new Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)));
                break;
            case "wifi":
                toggle(row, Glyphs.WIFI, R.string.tile_wifi, home.wifiOn,
                        () -> open(Build.VERSION.SDK_INT >= 29 ? new Intent(Settings.Panel.ACTION_WIFI) : new Intent(Settings.ACTION_WIFI_SETTINGS)));
                break;
            case "bt":
                toggle(row, Glyphs.BLUETOOTH, R.string.tile_bluetooth, bluetoothOn(), () -> open(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)));
                break;
            case "dnd":
                toggle(row, Glyphs.MOON, R.string.tile_dnd, dndOn(), this::toggleDnd);
                break;
            case "rotation":
                toggle(row, Glyphs.ROTATE_LOCK, R.string.cc_rotation, rotationLocked(), this::toggleRotation);
                break;
            case "location":
                toggle(row, Glyphs.LOCATION, R.string.tile_location, locationOn(), () -> open(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)));
                break;
            case "vibrate":
                toggle(row, Glyphs.VIBRATE, R.string.tile_vibrate, vibrateOn(), this::toggleVibrate);
                break;
            case "data":
                toggle(row, Glyphs.DATA, R.string.cc_data, null, () -> open(Build.VERSION.SDK_INT >= 29
                        ? new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) : new Intent(Settings.ACTION_DATA_ROAMING_SETTINGS)));
                break;
            case "hotspot":
                toggle(row, Glyphs.HOTSPOT, R.string.cc_hotspot, null, () -> {
                    close();
                    if (!start(new Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings"))) {
                        start(new Intent(Settings.ACTION_WIRELESS_SETTINGS));
                    }
                });
                break;
            case "nfc":
                toggle(row, Glyphs.NFC, R.string.cc_nfc, nfcOn(), () -> open(new Intent(Settings.ACTION_NFC_SETTINGS)));
                break;
            case "saver":
                toggle(row, Glyphs.SAVER, R.string.cc_saver, saverOn(), () -> open(new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)));
                break;
            default:
                toggle(row, Glyphs.EYE_OFF, R.string.privacy_mode, home.isPrivacyMode(), () -> {
                    home.setPrivacyMode(!home.isPrivacyMode());
                    fill();
                });
                break;
        }
    }

    private void addShortcut(LinearLayout row, String key) {
        switch (key) {
            case "tasbeeh":
                shortcut(row, Glyphs.BEADS, R.string.cc_tasbeeh, null, () -> {
                    close();
                    Tasbeeh.show(home);
                });
                break;
            case "torch":
                shortcut(row, Glyphs.FLASH, R.string.tile_torch, torchId == null ? null : torchOn, this::toggleTorch);
                break;
            case "timer":
                shortcut(row, Glyphs.TIMER, R.string.cc_timer, null, () -> {
                    close();
                    if (!start(new Intent(AlarmClock.ACTION_SHOW_TIMERS))) {
                        start(new Intent(AlarmClock.ACTION_SHOW_ALARMS));
                    }
                });
                break;
            case "calculator":
                shortcut(row, Glyphs.CALCULATOR, R.string.cc_calculator, null, () -> {
                    close();
                    if (!start(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR))) {
                        start(launcherOf("com.sec.android.app.popupcalculator"));
                    }
                });
                break;
            case "camera":
                shortcut(row, Glyphs.CAMERA, R.string.cc_camera, null, () -> {
                    close();
                    start(new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA));
                });
                break;
            case "alarm":
                shortcut(row, Glyphs.ALARM, R.string.cc_alarm, null, () -> {
                    close();
                    start(new Intent(AlarmClock.ACTION_SHOW_ALARMS));
                });
                break;
            case "recorder":
                shortcut(row, Glyphs.MIC, R.string.cc_recorder, null, () -> {
                    close();
                    if (!start(new Intent(MediaStore.Audio.Media.RECORD_SOUND_ACTION))
                            && !start(launcherOf("com.sec.android.app.voicenote"))
                            && !start(launcherOf("com.google.android.apps.recorder"))) {
                        Toast.makeText(home, home.getString(R.string.cc_no_app), Toast.LENGTH_SHORT).show();
                    }
                });
                break;
            case "notes":
                shortcut(row, Glyphs.NOTE, R.string.cc_notes, null, () -> {
                    close();
                    if (!start(launcherOf("com.samsung.android.app.notes"))
                            && !start(launcherOf("com.google.android.keep"))
                            && !start(new Intent("android.intent.action.CREATE_NOTE"))) {
                        Toast.makeText(home, home.getString(R.string.cc_no_app), Toast.LENGTH_SHORT).show();
                    }
                });
                break;
            default:
                shortcut(row, Glyphs.SETTINGS, R.string.tile_settings, null, () -> open(new Intent(Settings.ACTION_SETTINGS)));
                break;
        }
    }

    private void open(Intent intent) {
        close();
        home.startSafely(intent);
    }

    private Intent launcherOf(String pkg) {
        Intent intent = home.getPackageManager().getLaunchIntentForPackage(pkg);
        return intent != null ? intent : new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage(pkg);
    }

    private Boolean locationOn() {
        try {
            android.location.LocationManager manager = home.getSystemService(android.location.LocationManager.class);
            return manager == null || Build.VERSION.SDK_INT < 28 ? null : manager.isLocationEnabled();
        } catch (Exception e) {
            return null;
        }
    }

    private Boolean vibrateOn() {
        android.media.AudioManager audio = home.getSystemService(android.media.AudioManager.class);
        return audio == null ? null : audio.getRingerMode() == android.media.AudioManager.RINGER_MODE_VIBRATE;
    }

    private void toggleVibrate() {
        android.media.AudioManager audio = home.getSystemService(android.media.AudioManager.class);
        try {
            boolean on = audio.getRingerMode() == android.media.AudioManager.RINGER_MODE_VIBRATE;
            audio.setRingerMode(on ? android.media.AudioManager.RINGER_MODE_NORMAL : android.media.AudioManager.RINGER_MODE_VIBRATE);
            fill();
        } catch (Exception e) {
            open(new Intent(Settings.ACTION_SOUND_SETTINGS));
        }
    }

    private Boolean nfcOn() {
        try {
            android.nfc.NfcAdapter adapter = android.nfc.NfcAdapter.getDefaultAdapter(home);
            return adapter == null ? null : adapter.isEnabled();
        } catch (Exception e) {
            return null;
        }
    }

    private Boolean saverOn() {
        android.os.PowerManager power = home.getSystemService(android.os.PowerManager.class);
        return power == null ? null : power.isPowerSaveMode();
    }

    // ---------------------------------------------------------------- the editor

    /** Long press on the handle, "تخصيص" under the sheet, or the row in settings: pick what the sheet holds. */
    void edit() {
        edit(home, this::fill);
    }

    static void edit(final HomeActivity home, final Runnable after) {
        final android.content.SharedPreferences prefs = home.getSharedPreferences("duo_home", 0);
        final ArrayList<String> toggles = new ArrayList<>(chosen(prefs, PREF_TOGGLES, DEFAULT_TOGGLES, TOGGLES));
        final ArrayList<String> shortcuts = new ArrayList<>(chosen(prefs, PREF_SHORTCUTS, DEFAULT_SHORTCUTS, SHORTCUTS));
        android.widget.ScrollView scroll = new android.widget.ScrollView(home);
        LinearLayout list = new LinearLayout(home);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(home.dp(22.0f), home.dp(6.0f), home.dp(22.0f), home.dp(6.0f));
        scroll.addView(list);
        section(home, list, R.string.cc_edit_toggles, TOGGLES, toggles, MOST_TOGGLES, true);
        section(home, list, R.string.cc_edit_shortcuts, SHORTCUTS, shortcuts, MOST_SHORTCUTS, false);
        new android.app.AlertDialog.Builder(home)
                .setTitle(home.getString(R.string.cc_edit_title))
                .setView(scroll)
                .setPositiveButton(home.getString(R.string.done), (dialog, which) -> {
                    if (toggles.isEmpty()) {
                        toggles.addAll(java.util.Arrays.asList(DEFAULT_TOGGLES.split(",")));
                    }
                    save(prefs, PREF_TOGGLES, toggles);
                    save(prefs, PREF_SHORTCUTS, shortcuts);
                    if (after != null) {
                        after.run();
                    }
                })
                .setNeutralButton(home.getString(R.string.cc_edit_reset), (dialog, which) -> {
                    prefs.edit().remove(PREF_TOGGLES).remove(PREF_SHORTCUTS).apply();
                    if (after != null) {
                        after.run();
                    }
                })
                .setNegativeButton(home.getString(R.string.cancel), null)
                .show();
    }

    /** A heading and a tick for each item; ticking adds it at the end, so the order is the order of ticking. */
    private static void section(final HomeActivity home, LinearLayout list, int title, String[] catalog, final ArrayList<String> picked,
                                final int most, final boolean toggle) {
        // The dialog is light whatever the wallpaper, so not the wallpaper's text colours here.
        TextView heading = home.label(home.getString(title), 14, 0xFF5F5F6B, 600);
        heading.setPadding(0, home.dp(14.0f), 0, home.dp(4.0f));
        list.addView(heading);
        for (final String key : catalog) {
            final android.widget.CheckBox box = new android.widget.CheckBox(home);
            box.setText(home.getString(toggle ? toggleName(key) : shortcutName(key)));
            box.setTextSize(16);
            box.setChecked(picked.contains(key));
            box.setMinHeight(home.dp(44.0f));
            box.setTextDirection(View.TEXT_DIRECTION_LOCALE); // "NFC" lines up with the Arabic names
            box.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_START);
            box.setOnCheckedChangeListener((button, on) -> {
                if (on && !picked.contains(key)) {
                    if (picked.size() >= most) {
                        button.setChecked(false);
                        Toast.makeText(home, home.getString(R.string.cc_edit_full, most), Toast.LENGTH_SHORT).show();
                        return;
                    }
                    picked.add(key);
                } else if (!on) {
                    picked.remove(key);
                }
            });
            list.addView(box, new LinearLayout.LayoutParams(-1, -2));
        }
    }

    private boolean start(Intent intent) {
        try {
            home.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void divider() {
        View line = new View(home);
        line.setBackgroundColor(HomeActivity.withAlpha(home.textPrimary, 0.16f));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, Math.max(1, home.dp(0.7f)));
        params.topMargin = home.dp(14.0f);
        params.bottomMargin = home.dp(14.0f);
        content.addView(line, params);
    }

    private interface Action {
        void run();
    }

    /** On: a filled circle with the glyph cut out of it, as iOS 7 drew them. Off: a faint circle. */
    private void toggle(LinearLayout row, int glyph, int name, Boolean on, Action action) {
        boolean active = on != null && on;
        int fill = home.darkWallpaper ? Color.WHITE : 0xFF1C1C22;
        int cut = home.darkWallpaper ? 0xFF1C1C22 : Color.WHITE;
        FrameLayout circle = new FrameLayout(home);
        circle.setBackground(new RippleDrawable(ColorStateList.valueOf(HomeActivity.withAlpha(home.textPrimary, 0.25f)),
                home.pill(active ? fill : HomeActivity.withAlpha(home.textPrimary, 0.14f), 27), null));
        ImageView icon = new ImageView(home);
        icon.setImageDrawable(new Glyphs(glyph, active ? cut : home.textPrimary, home.dp(24.0f)));
        circle.addView(icon, new FrameLayout.LayoutParams(home.dp(24.0f), home.dp(24.0f), Gravity.CENTER));
        String state = on == null ? "" : home.getString(R.string.list_separator) + home.getString(active ? R.string.state_on : R.string.state_off);
        circle.setContentDescription(home.getString(name) + state);
        circle.setOnClickListener(v -> action.run());
        // Five to a row on every screen: each takes a fifth of the row, the circle up to 54dp in its middle.
        int side = slotSide(54.0f);
        circle.setBackground(new RippleDrawable(ColorStateList.valueOf(HomeActivity.withAlpha(home.textPrimary, 0.25f)),
                home.pill(active ? fill : HomeActivity.withAlpha(home.textPrimary, 0.14f), Math.round(side / home.getResources().getDisplayMetrics().density / 2f)), null));
        FrameLayout slot = new FrameLayout(home);
        slot.addView(circle, new FrameLayout.LayoutParams(side, side, Gravity.CENTER));
        row.addView(slot, new LinearLayout.LayoutParams(0, side, 1f));
    }

    /** The bottom row: rounded squares that open a tool (the torch is switched right here). */
    private void shortcut(LinearLayout row, int glyph, int name, Boolean on, Action action) {
        boolean active = on != null && on;
        int fill = home.darkWallpaper ? Color.WHITE : 0xFF1C1C22;
        int cut = home.darkWallpaper ? 0xFF1C1C22 : Color.WHITE;
        FrameLayout square = new FrameLayout(home);
        square.setBackground(new RippleDrawable(ColorStateList.valueOf(HomeActivity.withAlpha(home.textPrimary, 0.25f)),
                home.pill(active ? fill : HomeActivity.withAlpha(home.textPrimary, 0.14f), 16), null));
        ImageView icon = new ImageView(home);
        icon.setImageDrawable(new Glyphs(glyph, active ? cut : home.textPrimary, home.dp(26.0f)));
        square.addView(icon, new FrameLayout.LayoutParams(home.dp(26.0f), home.dp(26.0f), Gravity.CENTER));
        String state = on == null ? "" : home.getString(R.string.list_separator) + home.getString(active ? R.string.state_on : R.string.state_off);
        square.setContentDescription(home.getString(name) + state);
        square.setOnClickListener(v -> action.run());
        // Five to a row: each takes a fifth of the row, the square up to 60dp in the middle of it.
        FrameLayout slot = new FrameLayout(home);
        int side = slotSide(60.0f);
        slot.addView(square, new FrameLayout.LayoutParams(side, side, Gravity.CENTER));
        row.addView(slot, new LinearLayout.LayoutParams(0, side, 1f));
    }

    /** A slider between a small and a big glyph, as iOS 7 drew brightness and volume. */
    private SeekBar slider(int smallGlyph, int bigGlyph, int max, int value, int description) {
        LinearLayout row = new LinearLayout(home);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR); // low on the left, high on the right, like the slider
        ImageView low = new ImageView(home);
        low.setImageDrawable(new Glyphs(smallGlyph, home.textSecondary, home.dp(16.0f)));
        low.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        row.addView(low, new LinearLayout.LayoutParams(home.dp(18.0f), home.dp(18.0f)));
        SeekBar bar = new SeekBar(home);
        bar.setMax(max);
        bar.setProgress(value);
        bar.setProgressTintList(ColorStateList.valueOf(home.textPrimary));
        bar.setThumbTintList(ColorStateList.valueOf(home.textPrimary));
        bar.setProgressBackgroundTintList(ColorStateList.valueOf(HomeActivity.withAlpha(home.textPrimary, 0.45f)));
        bar.setContentDescription(home.getString(description));
        row.addView(bar, new LinearLayout.LayoutParams(0, home.dp(40.0f), 1f));
        ImageView high = new ImageView(home);
        high.setImageDrawable(new Glyphs(bigGlyph, home.textSecondary, home.dp(24.0f)));
        high.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        row.addView(high, new LinearLayout.LayoutParams(home.dp(24.0f), home.dp(24.0f)));
        content.addView(row, new LinearLayout.LayoutParams(-1, -2));
        return bar;
    }

    private void addBrightness() {
        int value = Settings.System.getInt(home.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 128);
        SeekBar bar = slider(Glyphs.SUN, Glyphs.SUN, 255, value, R.string.tile_brightness);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) {
                    return;
                }
                android.view.WindowManager.LayoutParams attributes = home.getWindow().getAttributes();
                attributes.screenBrightness = Math.max(0.02f, progress / 255f);
                home.getWindow().setAttributes(attributes);
                if (Settings.System.canWrite(home)) {
                    try {
                        Settings.System.putInt(home.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE,
                                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                        Settings.System.putInt(home.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, progress);
                    } catch (Exception ignored) {
                    }
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                android.view.WindowManager.LayoutParams attributes = home.getWindow().getAttributes();
                if (Settings.System.canWrite(home)) {
                    attributes.screenBrightness = android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;
                    home.getWindow().setAttributes(attributes);
                } else {
                    askForSettings(R.string.brightness_permission);
                }
            }
        });
    }

    private void askForSettings(int message) {
        if (askedForSettings) {
            return;
        }
        askedForSettings = true;
        Toast.makeText(home, home.getString(message), Toast.LENGTH_LONG).show();
        home.startSafely(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + home.getPackageName())));
    }

    // ---------------------------------------------------------------- music

    /** The app playing now (or paused last), through the notification access Sara Home already uses. */
    private MediaController player() {
        try {
            MediaSessionManager sessions = home.getSystemService(MediaSessionManager.class);
            if (sessions == null) {
                return null;
            }
            List<MediaController> list = sessions.getActiveSessions(new ComponentName(home, DotsService.class));
            MediaController paused = null;
            for (MediaController controller : list) {
                PlaybackState state = controller.getPlaybackState();
                if (state == null) {
                    continue;
                }
                if (state.getState() == PlaybackState.STATE_PLAYING) {
                    return controller;
                }
                if (paused == null && state.getState() == PlaybackState.STATE_PAUSED) {
                    paused = controller;
                }
            }
            return paused;
        } catch (Exception e) {
            return null;
        }
    }

    private void addMedia() {
        final MediaController controller = player();
        MediaMetadata meta = controller == null ? null : controller.getMetadata();
        CharSequence title = meta == null ? null : meta.getText(MediaMetadata.METADATA_KEY_TITLE);
        CharSequence artist = meta == null ? null : meta.getText(MediaMetadata.METADATA_KEY_ARTIST);
        String line = TextUtils.isEmpty(title) ? home.getString(R.string.cc_nothing_playing)
                : TextUtils.isEmpty(artist) ? title.toString() : title + " — " + artist;
        TextView now = home.label(line, 14, TextUtils.isEmpty(title) ? home.textSecondary : home.textPrimary, 600);
        now.setGravity(Gravity.CENTER);
        now.setSingleLine(true);
        now.setEllipsize(TextUtils.TruncateAt.END);
        content.addView(now, new LinearLayout.LayoutParams(-1, -2));
        if (controller != null) {
            now.setOnClickListener(v -> {
                if (controller.getSessionActivity() != null) {
                    try {
                        close();
                        controller.getSessionActivity().send();
                    } catch (Exception ignored) {
                    }
                }
            });
        }
        PlaybackState state = controller == null ? null : controller.getPlaybackState();
        final boolean playing = state != null && state.getState() == PlaybackState.STATE_PLAYING;
        LinearLayout buttons = new LinearLayout(home);
        buttons.setGravity(Gravity.CENTER);
        buttons.setLayoutDirection(View.LAYOUT_DIRECTION_LTR); // previous on the left, next on the right, as on every player
        buttons.setPadding(0, home.dp(6.0f), 0, home.dp(4.0f));
        buttons.addView(mediaButton(Glyphs.PREV, R.string.media_previous, controller, () -> controller.getTransportControls().skipToPrevious()));
        buttons.addView(mediaButton(playing ? Glyphs.PAUSE : Glyphs.PLAY, playing ? R.string.media_pause : R.string.media_play, controller, () -> {
            if (playing) {
                controller.getTransportControls().pause();
            } else {
                controller.getTransportControls().play();
            }
        }));
        buttons.addView(mediaButton(Glyphs.NEXT, R.string.media_next, controller, () -> controller.getTransportControls().skipToNext()));
        content.addView(buttons, new LinearLayout.LayoutParams(-1, -2));

        final AudioManager audio = home.getSystemService(AudioManager.class);
        if (audio != null) {
            SeekBar volume = slider(Glyphs.SPEAKER, Glyphs.SPEAKER_LOUD, audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
                    audio.getStreamVolume(AudioManager.STREAM_MUSIC), R.string.cc_volume);
            volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    if (fromUser) {
                        try {
                            audio.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0);
                        } catch (Exception ignored) {
                            // do not disturb can refuse it
                        }
                    }
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {
                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {
                }
            });
        }
    }

    private View mediaButton(int glyph, int description, MediaController controller, Action action) {
        FrameLayout button = new FrameLayout(home);
        boolean enabled = controller != null;
        button.setBackground(new RippleDrawable(ColorStateList.valueOf(HomeActivity.withAlpha(home.textPrimary, 0.25f)), null,
                home.pill(Color.WHITE, 24)));
        ImageView icon = new ImageView(home);
        icon.setImageDrawable(new Glyphs(glyph, enabled ? home.textPrimary : HomeActivity.withAlpha(home.textPrimary, 0.35f), home.dp(26.0f)));
        button.addView(icon, new FrameLayout.LayoutParams(home.dp(26.0f), home.dp(26.0f), Gravity.CENTER));
        button.setContentDescription(home.getString(description));
        button.setEnabled(enabled);
        button.setOnClickListener(v -> {
            action.run();
            handler.postDelayed(() -> {
                if (open) {
                    fill();
                }
            }, 350L);
        });
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(home.dp(48.0f), home.dp(48.0f));
        params.setMargins(home.dp(18.0f), 0, home.dp(18.0f), 0);
        button.setLayoutParams(params);
        return button;
    }

    // ---------------------------------------------------------------- states

    private Boolean airplaneOn() {
        try {
            return Settings.Global.getInt(home.getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, 0) == 1;
        } catch (Exception e) {
            return null;
        }
    }

    private Boolean bluetoothOn() {
        try {
            BluetoothManager manager = home.getSystemService(BluetoothManager.class);
            BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
            return adapter == null ? null : adapter.isEnabled();
        } catch (Exception e) {
            return null;
        }
    }

    private Boolean dndOn() {
        NotificationManager manager = home.getSystemService(NotificationManager.class);
        if (manager == null) {
            return null;
        }
        int filter = manager.getCurrentInterruptionFilter();
        return filter != NotificationManager.INTERRUPTION_FILTER_ALL && filter != NotificationManager.INTERRUPTION_FILTER_UNKNOWN;
    }

    private void toggleDnd() {
        NotificationManager manager = home.getSystemService(NotificationManager.class);
        if (manager == null) {
            return;
        }
        if (!manager.isNotificationPolicyAccessGranted()) {
            close();
            home.startSafely(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
            return;
        }
        Boolean on = dndOn();
        manager.setInterruptionFilter(on != null && on ? NotificationManager.INTERRUPTION_FILTER_ALL : NotificationManager.INTERRUPTION_FILTER_PRIORITY);
        handler.postDelayed(() -> {
            if (open) {
                fill();
            }
        }, 300L);
    }

    /** Rotation lock is on when the screen doesn't turn with the phone. */
    private Boolean rotationLocked() {
        try {
            return Settings.System.getInt(home.getContentResolver(), Settings.System.ACCELEROMETER_ROTATION, 1) == 0;
        } catch (Exception e) {
            return null;
        }
    }

    private void toggleRotation() {
        if (!Settings.System.canWrite(home)) {
            askedForSettings = false;
            askForSettings(R.string.cc_rotation_permission);
            return;
        }
        try {
            Boolean locked = rotationLocked();
            Settings.System.putInt(home.getContentResolver(), Settings.System.ACCELEROMETER_ROTATION, locked != null && locked ? 1 : 0);
        } catch (Exception ignored) {
        }
        fill();
    }

    private void watchTorch(boolean watch) {
        try {
            if (camera == null) {
                camera = home.getSystemService(CameraManager.class);
                if (camera != null) {
                    for (String id : camera.getCameraIdList()) {
                        CameraCharacteristics features = camera.getCameraCharacteristics(id);
                        Boolean flash = features.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                        Integer facing = features.get(CameraCharacteristics.LENS_FACING);
                        if (flash != null && flash && facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                            torchId = id;
                            break;
                        }
                    }
                }
            }
            if (camera != null && torchId != null) {
                if (watch) {
                    camera.registerTorchCallback(torchCallback, handler);
                } else {
                    camera.unregisterTorchCallback(torchCallback);
                }
            }
        } catch (Exception ignored) {
        }
    }

    /** How many brightness steps the torch has (Android 13+ on phones that offer it; 1 means on or off only). */
    int torchLevels() {
        if (Build.VERSION.SDK_INT < 33 || camera == null || torchId == null) {
            return 1;
        }
        try {
            Integer max = camera.getCameraCharacteristics(torchId).get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL);
            return max == null ? 1 : max;
        } catch (Exception e) {
            return 1;
        }
    }

    /** While the torch is on: a slider for how bright it is, as Android 16 added to its torch tile. */
    private void addTorchStrength() {
        int levels = torchLevels();
        int now = levels;
        try {
            now = camera.getTorchStrengthLevel(torchId);
        } catch (Exception ignored) {
        }
        SeekBar bar = slider(Glyphs.FLASH, Glyphs.FLASH, levels - 1, Math.max(0, now - 1), R.string.torch_strength);
        bar.setTag("torch_strength");
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && Build.VERSION.SDK_INT >= 33) {
                    try {
                        camera.turnOnTorchWithStrengthLevel(torchId, progress + 1);
                    } catch (Exception ignored) {
                    }
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
    }

    private void toggleTorch() {
        if (camera == null || torchId == null) {
            return;
        }
        try {
            camera.setTorchMode(torchId, !torchOn);
            torchOn = !torchOn;
            fill();
        } catch (Exception e) {
            Toast.makeText(home, home.getString(R.string.torch_busy), Toast.LENGTH_SHORT).show();
        }
    }
}
