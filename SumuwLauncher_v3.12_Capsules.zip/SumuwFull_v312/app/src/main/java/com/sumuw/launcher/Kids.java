package com.sumuw.launcher;

import android.content.SharedPreferences;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Children's mode: Home shows only the apps the parent chose, big, and nothing else (no search, no
 * settings, no notifications, no control centre). Leaving it takes the phone's fingerprint, face or
 * PIN. Android still lets anyone switch apps from the recent apps screen; for a full lock, the phone's
 * own "pin app" (screen pinning) is the tool.
 */
final class Kids {
    static final String PREF_ON = "kids_on";
    static final String PREF_APPS = "kids_apps";

    private Kids() {
    }

    static boolean on(SharedPreferences prefs) {
        return prefs.getBoolean(PREF_ON, false);
    }

    static Set<String> apps(SharedPreferences prefs) {
        LinkedHashSet<String> keys = new LinkedHashSet<>();
        for (String key : prefs.getString(PREF_APPS, "").split("\\|")) {
            if (!key.isEmpty()) {
                keys.add(key);
            }
        }
        return keys;
    }

    static void saveApps(SharedPreferences prefs, Set<String> keys) {
        prefs.edit().putString(PREF_APPS, android.text.TextUtils.join("|", keys)).apply();
    }
}
