package com.sumuw.launcher;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.graphics.Insets;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowInsets;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

/**
 * The app drawer: a glass sheet that comes up over the home screen with every app, the search and the
 * categories. The home screen keeps the cards and the dock, so it has room to breathe.
 *
 * It follows the finger both ways: up from the home screen to open it, down from the top of the list (or
 * its handle) to close it. While closed it stays laid out but invisible, so it opens without a stutter.
 */
final class AppDrawer {
    final FrameLayout view;
    final LinearLayout sheet;
    /** Where the search, the categories and the grid go. */
    final LinearLayout column;
    final FrameLayout handle;

    private final HomeActivity home;
    private float shown;
    private boolean open;
    private ValueAnimator animator;
    private final float flingVelocity;

    AppDrawer(final HomeActivity home, int tint) {
        this.home = home;
        flingVelocity = 350f * home.getResources().getDisplayMetrics().density;
        view = new FrameLayout(home);
        view.setVisibility(View.INVISIBLE);
        view.setClickable(true); // touches on the open sheet never reach the home screen under it
        sheet = new LinearLayout(home);
        sheet.setOrientation(LinearLayout.VERTICAL);
        home.glassify(sheet, 30, false);
        Drawable glassLayer = sheet.getBackground();
        GradientDrawable veil = new GradientDrawable();
        veil.setColor(tint);
        float r = home.dp(30.0f);
        veil.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        sheet.setBackground(new LayerDrawable(new Drawable[]{glassLayer, veil}));
        sheet.setClipToOutline(true);

        handle = new FrameLayout(home);
        View bar = new View(home);
        bar.setBackground(home.pill(HomeActivity.withAlpha(home.textPrimary, 0.38f), 3));
        handle.addView(bar, new FrameLayout.LayoutParams(home.dp(40.0f), home.dp(5.0f), Gravity.CENTER));
        handle.setContentDescription(home.getString(R.string.drawer_close));
        handle.setOnClickListener(v -> close(true));
        handle.setOnTouchListener(new View.OnTouchListener() {
            private float downY;
            private boolean dragging;
            private VelocityTracker velocity;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int slop = ViewConfiguration.get(home).getScaledTouchSlop();
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downY = event.getRawY();
                        dragging = false;
                        if (velocity != null) {
                            velocity.recycle();
                        }
                        velocity = VelocityTracker.obtain();
                        velocity.addMovement(event);
                        return false;
                    case MotionEvent.ACTION_MOVE:
                        if (velocity != null) {
                            velocity.addMovement(event);
                        }
                        float down = event.getRawY() - downY;
                        if (!dragging && down > slop) {
                            dragging = true;
                            v.cancelLongPress();
                            v.setPressed(false);
                        }
                        if (dragging) {
                            pullTo(down - slop);
                            return true;
                        }
                        return false;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        float vy = 0f;
                        if (velocity != null) {
                            velocity.addMovement(event);
                            velocity.computeCurrentVelocity(1000);
                            vy = velocity.getYVelocity();
                            velocity.recycle();
                            velocity = null;
                        }
                        if (dragging) {
                            dragging = false;
                            endPull(event.getRawY() - downY, event.getActionMasked() == MotionEvent.ACTION_UP ? vy : 0f);
                            return true;
                        }
                        return false;
                    default:
                        return false;
                }
            }
        });
        sheet.addView(handle, new LinearLayout.LayoutParams(-1, home.dp(26.0f)));
        column = new LinearLayout(home);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setLayoutDirection(View.LAYOUT_DIRECTION_LOCALE);
        column.setPadding(home.dp(14.0f), 0, home.dp(14.0f), home.dp(4.0f));
        sheet.addView(column, new LinearLayout.LayoutParams(-1, 0, 1f));
        view.addView(sheet, new FrameLayout.LayoutParams(-1, -1));
        view.setOnApplyWindowInsetsListener((v, insets) -> {
            int left;
            int top;
            int right;
            int bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
                left = bars.left;
                top = bars.top;
                right = bars.right;
                bottom = bars.bottom;
            } else {
                left = insets.getSystemWindowInsetLeft();
                top = insets.getSystemWindowInsetTop();
                right = insets.getSystemWindowInsetRight();
                bottom = insets.getSystemWindowInsetBottom();
            }
            sheet.setPadding(left, top + home.dp(4.0f), right, bottom);
            return insets;
        });
        view.addOnLayoutChangeListener((v, l, t, rt, b, ol, ot, orr, ob) -> {
            if (b - t != ob - ot) {
                apply(shown); // keep a closed sheet below the screen after a rotation or a fold
            }
        });
    }

    boolean isOpen() {
        return open || shown > 0f;
    }

    /** How far up it is, 0 closed to 1 open. */
    float shown() {
        return shown;
    }

    void open(boolean animate) {
        open = true;
        settle(1f, animate);
        home.onDrawerOpened();
    }

    void close(boolean animate) {
        if (!open && shown == 0f) {
            return;
        }
        open = false;
        settle(0f, animate);
        home.onDrawerClosed();
    }

    /** A swipe up from the home screen has started. */
    void beginDrag() {
        cancel();
        view.setVisibility(View.VISIBLE);
    }

    void dragTo(float up) {
        apply(clamp(up / Math.max(1f, height())));
    }

    void endDrag(float velocityY) {
        if (velocityY < -flingVelocity || (velocityY < flingVelocity && shown > 0.25f)) {
            open(true);
        } else {
            open = true; // so close() runs its clean-up
            close(true);
        }
    }

    /** A pull down from the top of the open list. */
    void pullTo(float down) {
        cancel();
        apply(clamp(1f - Math.max(0f, down) / Math.max(1f, height())));
    }

    void endPull(float down, float velocityY) {
        if (velocityY > flingVelocity || (velocityY > -flingVelocity && down > height() * 0.2f)) {
            close(true);
        } else {
            open(true);
        }
    }

    private float height() {
        return view.getHeight() > 0 ? view.getHeight() : home.getResources().getDisplayMetrics().heightPixels;
    }

    private static float clamp(float value) {
        return Math.max(0f, Math.min(1f, value));
    }

    private void cancel() {
        if (animator != null) {
            animator.cancel();
            animator = null;
        }
    }

    private void settle(final float target, boolean animate) {
        cancel();
        if (!animate || !view.isAttachedToWindow() || !home.animationsOn()) {
            apply(target);
            return;
        }
        view.setVisibility(View.VISIBLE);
        float distance = Math.abs(target - shown);
        animator = ValueAnimator.ofFloat(shown, target);
        animator.setDuration((long) (150 + 230 * distance));
        animator.setInterpolator(new DecelerateInterpolator(1.6f));
        animator.addUpdateListener(a -> apply((Float) a.getAnimatedValue()));
        animator.addListener(new AnimatorListenerAdapter() {
            private boolean cancelled;

            @Override
            public void onAnimationCancel(Animator animation) {
                cancelled = true;
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                if (!cancelled) {
                    apply(target);
                }
            }
        });
        animator.start();
    }

    private void apply(float value) {
        shown = value;
        sheet.setTranslationY((1f - value) * height());
        view.setVisibility(value > 0f ? View.VISIBLE : View.INVISIBLE);
        home.drawerProgress(value);
    }

    /** For a screen without the glass (the phone's own wallpaper): a denser veil keeps the icons readable. */
    static int veilFor(boolean dark, boolean glassAvailable) {
        if (dark) {
            return glassAvailable ? 0x8C0E1118 : 0xE6101318;
        }
        return glassAvailable ? 0x99F3F5F9 : 0xEEF3F5F9;
    }
}
