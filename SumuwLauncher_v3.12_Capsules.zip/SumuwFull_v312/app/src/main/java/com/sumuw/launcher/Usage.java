package com.sumuw.launcher;

import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Remembers when each app is opened, by hour of day, for the "most used" order and the dock's
 * suggestions. It stays in the launcher's own settings on the phone and is never sent anywhere.
 */
final class Usage {
    static final String KEY = "usage";
    private static final int MAX_APPS = 400;
    /** Past this many launches an app's counts are halved, so new habits can overtake old ones. */
    private static final int CAP = 600;
    /** The least evidence for a suggestion: one launch at this hour plus one close to it. */
    private static final double MIN_SCORE = 4.0;

    private final SharedPreferences prefs;
    private final HashMap<String, int[]> hours = new HashMap<>();
    private final HashMap<String, Long> last = new HashMap<>();
    /** Launches by place: a cell of about a kilometre (two decimals of a degree) to app to count. */
    private final HashMap<String, HashMap<String, Integer>> places = new HashMap<>();
    static final String PLACES_KEY = "usage_places";
    /** The current place's cell, set from the last fresh location; null when unknown. */
    String here;
    /** Apps that fit the moment (music with headphones on, maps in the car): a strong nudge up. */
    java.util.Set<String> boosted = new java.util.HashSet<>();

    Usage(SharedPreferences prefs) {
        this.prefs = prefs;
        load();
    }

    private void load() {
        try {
            JSONObject all = new JSONObject(prefs.getString(KEY, "{}"));
            Iterator<String> keys = all.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                JSONObject item = all.getJSONObject(key);
                JSONArray counts = item.getJSONArray("h");
                int[] slots = new int[24];
                for (int i = 0; i < 24 && i < counts.length(); i++) {
                    slots[i] = Math.max(0, counts.optInt(i));
                }
                hours.put(key, slots);
                last.put(key, item.optLong("l", 0L));
            }
        } catch (Exception ignored) {
            // damaged data just starts the counts again
        }
        try {
            JSONObject cells = new JSONObject(prefs.getString(PLACES_KEY, "{}"));
            Iterator<String> keys = cells.keys();
            while (keys.hasNext()) {
                String cell = keys.next();
                JSONObject counts = cells.getJSONObject(cell);
                HashMap<String, Integer> map = new HashMap<>();
                Iterator<String> apps = counts.keys();
                while (apps.hasNext()) {
                    String app = apps.next();
                    map.put(app, counts.optInt(app));
                }
                places.put(cell, map);
            }
        } catch (Exception ignored) {
        }
    }

    /** "24.71,46.67": about a kilometre square. */
    static String cell(double lat, double lng) {
        return String.format(java.util.Locale.US, "%.2f,%.2f", lat, lng);
    }

    int placeCount(String cell, String key) {
        HashMap<String, Integer> map = cell == null ? null : places.get(cell);
        Integer count = map == null ? null : map.get(key);
        return count == null ? 0 : count;
    }

    private void recordPlace(String key) {
        if (here == null) {
            return;
        }
        HashMap<String, Integer> map = places.get(here);
        if (map == null) {
            if (places.size() >= 40) {
                places.remove(places.keySet().iterator().next()); // forget an old place
            }
            map = new HashMap<>();
            places.put(here, map);
        }
        map.put(key, placeCount(here, key) + 1);
        if (map.size() > 60) {
            String least = null;
            for (Map.Entry<String, Integer> entry : map.entrySet()) {
                if (least == null || entry.getValue() < map.get(least)) {
                    least = entry.getKey();
                }
            }
            map.remove(least);
        }
        try {
            JSONObject cells = new JSONObject();
            for (Map.Entry<String, HashMap<String, Integer>> entry : places.entrySet()) {
                JSONObject counts = new JSONObject();
                for (Map.Entry<String, Integer> app : entry.getValue().entrySet()) {
                    counts.put(app.getKey(), app.getValue());
                }
                cells.put(entry.getKey(), counts);
            }
            prefs.edit().putString(PLACES_KEY, cells.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    void record(String key, long now) {
        int[] slots = hours.get(key);
        if (slots == null) {
            slots = new int[24];
            hours.put(key, slots);
        }
        slots[hourOf(now)]++;
        if (sum(slots) > CAP) {
            for (int i = 0; i < 24; i++) {
                slots[i] /= 2;
            }
        }
        last.put(key, now);
        recordPlace(key);
        trim();
        save();
    }

    void forget(String key) {
        if (hours.remove(key) != null) {
            last.remove(key);
            save();
        }
    }

    int total(String key) {
        int[] slots = hours.get(key);
        return slots == null ? 0 : sum(slots);
    }

    long lastUsed(String key) {
        Long time = last.get(key);
        return time == null ? 0L : time;
    }

    /** How likely the app is to be opened at this hour: its own hour counts most, neighbours less. */
    double score(String key, long now) {
        int[] slots = hours.get(key);
        if (slots == null) {
            return 0;
        }
        int h = hourOf(now);
        double score = 3.0 * slots[h]
                + 1.5 * (slots[(h + 23) % 24] + slots[(h + 1) % 24])
                + 0.5 * (slots[(h + 22) % 24] + slots[(h + 2) % 24])
                + 0.1 * sum(slots);
        long since = now - lastUsed(key);
        if (since >= 0 && since < 2 * 60 * 60 * 1000L) {
            score += 1.0; // just used: likely to come back to it
        }
        // Where you are: what you open here (at home, at work) counts as much as the hour.
        score += 2.5 * Math.min(8, placeCount(here, key));
        if (boosted.contains(key)) {
            score += 12.0;
        }
        return score;
    }

    /** Up to {@code count} of the candidates that are usually opened around this time, best first. */
    List<String> suggestions(Collection<String> candidates, long now, int count) {
        final HashMap<String, Double> scores = new HashMap<>();
        ArrayList<String> picks = new ArrayList<>();
        for (String key : candidates) {
            double score = score(key, now);
            if (score >= MIN_SCORE || boosted.contains(key)) {
                scores.put(key, score);
                picks.add(key);
            }
        }
        Collections.sort(picks, new Comparator<String>() {
            @Override
            public int compare(String a, String b) {
                return Double.compare(scores.get(b), scores.get(a));
            }
        });
        return picks.size() > count ? new ArrayList<>(picks.subList(0, count)) : picks;
    }

    static int hourOf(long time) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(time);
        return calendar.get(Calendar.HOUR_OF_DAY);
    }

    private static int sum(int[] slots) {
        int total = 0;
        for (int value : slots) {
            total += value;
        }
        return total;
    }

    private void trim() {
        while (hours.size() > MAX_APPS) {
            String oldest = null;
            long oldestTime = Long.MAX_VALUE;
            for (Map.Entry<String, Long> entry : last.entrySet()) {
                if (entry.getValue() < oldestTime) {
                    oldestTime = entry.getValue();
                    oldest = entry.getKey();
                }
            }
            if (oldest == null) {
                return;
            }
            hours.remove(oldest);
            last.remove(oldest);
        }
    }

    private void save() {
        try {
            JSONObject all = new JSONObject();
            for (Map.Entry<String, int[]> entry : hours.entrySet()) {
                JSONArray counts = new JSONArray();
                for (int value : entry.getValue()) {
                    counts.put(value);
                }
                all.put(entry.getKey(), new JSONObject().put("h", counts).put("l", lastUsed(entry.getKey())));
            }
            prefs.edit().putString(KEY, all.toString()).apply();
        } catch (Exception ignored) {
        }
    }
}
