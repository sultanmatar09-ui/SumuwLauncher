package com.sumuw.launcher;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

/**
 * A line of a card that changes by itself like a news ticker: one item at a time, the next one sliding
 * in from the right while the current one leaves to the left. Every ticker on the screen moves on the
 * same beat, so the cards change together, at the same pace.
 *
 * Which item shows follows the clock (the beat number), not a counter, so a card that is built again
 * every minute comes back on the item it was showing, and two cards always turn at the same moment.
 */
final class Ticker extends FrameLayout {
    /** How long each item stays. */
    static final long BEAT_MS = 4000L;
    /** How long the slide takes. */
    static final long SLIDE_MS = 420L;

    private final int perPage;
    private LinearLayout filling;
    private int index;
    private int offset;
    private boolean touching;

    /** One item per page, or several stacked (two rows of a table). */
    Ticker(Context context, int perPage) {
        super(context);
        this.perPage = Math.max(1, perPage);
        setClipChildren(true);
        setClipToPadding(true);
    }

    Ticker(Context context) {
        this(context, 1);
    }

    /** Adds an item at the end; the first page shows at once. */
    void addItem(View item) {
        if (perPage == 1) {
            addPage(item);
            return;
        }
        if (filling == null || filling.getChildCount() >= perPage) {
            filling = new LinearLayout(getContext());
            filling.setOrientation(LinearLayout.VERTICAL);
            addPage(filling);
        }
        filling.addView(item, new LinearLayout.LayoutParams(-1, -2));
    }

    private void addPage(View page) {
        addView(page, new LayoutParams(-1, -2));
        jumpTo(pageAt(System.currentTimeMillis()));
    }

    void clear() {
        removeAllViews();
        filling = null;
        index = 0;
        offset = 0;
    }

    int pageCount() {
        return getChildCount();
    }

    int index() {
        return index;
    }

    View current() {
        return index < getChildCount() ? getChildAt(index) : null;
    }

    static long beatOf(long now) {
        return now / BEAT_MS;
    }

    /** The page the clock asks for now. */
    int pageAt(long now) {
        int count = getChildCount();
        if (count == 0) {
            return 0;
        }
        return (int) Math.floorMod(beatOf(now) + offset, (long) count);
    }

    /** Shows this page now (a new headline), and keeps the beat from here on. */
    void showNow(int page) {
        int count = getChildCount();
        if (count == 0) {
            return;
        }
        offset = (int) Math.floorMod(page - beatOf(System.currentTimeMillis()), (long) count);
        jumpTo(page);
    }

    boolean touching() {
        return touching;
    }

    /** On each beat: slide to the page the clock asks for; without motion (animations off), just change. */
    boolean sync(long now, boolean animate) {
        int target = pageAt(now);
        if (target == index || getChildCount() < 2) {
            return false;
        }
        if (!animate || getWidth() == 0) {
            jumpTo(target);
            return true;
        }
        final View out = getChildAt(index);
        final View in = getChildAt(target);
        index = target;
        float width = getWidth();
        // Right to left on the screen, whatever the language: in from the right edge, out by the left.
        in.animate().cancel();
        out.animate().cancel();
        in.setTranslationX(width);
        in.setAlpha(1f);
        in.setVisibility(VISIBLE);
        in.animate().translationX(0f).setDuration(SLIDE_MS).setInterpolator(new DecelerateInterpolator(1.6f)).start();
        out.animate().translationX(-width).alpha(0.2f).setDuration(SLIDE_MS).setInterpolator(new DecelerateInterpolator(1.2f))
                .withEndAction(() -> {
                    if (indexOfChild(out) != index) {
                        out.setVisibility(INVISIBLE);
                    }
                    out.setTranslationX(0f);
                    out.setAlpha(1f);
                }).start();
        return true;
    }

    private void jumpTo(int page) {
        index = Math.max(0, Math.min(page, getChildCount() - 1));
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            child.animate().cancel();
            child.setTranslationX(0f);
            child.setAlpha(1f);
            child.setVisibility(i == index ? VISIBLE : INVISIBLE);
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        jumpTo(pageAt(System.currentTimeMillis()));
    }

    @Override
    public void onVisibilityAggregated(boolean visible) {
        super.onVisibilityAggregated(visible);
        if (visible && getChildCount() > 1) {
            jumpTo(pageAt(System.currentTimeMillis())); // a card swiped into view starts on the beat's item
        }
    }

    /** A finger on the ticker holds it still. */
    @Override
    public boolean onInterceptTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            touching = true;
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            touching = false;
        }
        return super.onInterceptTouchEvent(event);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            touching = false;
        }
        return super.onTouchEvent(event);
    }
}
