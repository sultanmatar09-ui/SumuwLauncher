package com.sumuw.launcher;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * The usage breaker: for the apps the user picks, a short pause before they open (with how many times
 * they were opened today), and a gentle reminder once the chosen minutes have gone by in them. Coming
 * back to the home screen calls the reminder off, so it only comes while still in the app.
 *
 * It counts only what the launcher itself sees (openings from Sara), keeps it on the phone, and needs no
 * special access.
 */
final class Breaker {
    static final String APPS = "breaker_apps";
    static final String MINUTES = "breaker_minutes";
    static final int[] MINUTE_CHOICES = {5, 10, 15, 30, 45};
    static final int PAUSE_SECONDS = 4;
    static final String ACTION = "com.sumuw.launcher.BREAKER";
    private static final int REQUEST = 41;
    private static final String CHANNEL = "breaker";

    private Breaker() {
    }

    static Set<String> apps(SharedPreferences prefs) {
        LinkedHashSet<String> set = new LinkedHashSet<>();
        for (String pkg : prefs.getString(APPS, "").split(",")) {
            if (!pkg.trim().isEmpty()) {
                set.add(pkg.trim());
            }
        }
        return set;
    }

    static boolean watched(SharedPreferences prefs, String pkg) {
        return apps(prefs).contains(pkg);
    }

    /** Starts or stops watching an app; true when it is watched now. */
    static boolean toggle(SharedPreferences prefs, String pkg) {
        Set<String> set = apps(prefs);
        boolean on = !set.remove(pkg);
        if (on) {
            set.add(pkg);
        }
        prefs.edit().putString(APPS, android.text.TextUtils.join(",", set)).apply();
        return on;
    }

    static int minutes(SharedPreferences prefs) {
        return prefs.getInt(MINUTES, 15);
    }

    private static String today(long now) {
        Calendar day = Calendar.getInstance();
        day.setTimeInMillis(now);
        return day.get(Calendar.YEAR) + "-" + day.get(Calendar.DAY_OF_YEAR);
    }

    /** Times the app was opened today, before this one. */
    static int openedToday(SharedPreferences prefs, String pkg, long now) {
        if (!today(now).equals(prefs.getString("breaker_day", ""))) {
            return 0;
        }
        return prefs.getInt("breaker_n_" + pkg, 0);
    }

    static void countOpening(SharedPreferences prefs, String pkg, long now) {
        SharedPreferences.Editor edit = prefs.edit();
        String day = today(now);
        if (!day.equals(prefs.getString("breaker_day", ""))) {
            // A new day: yesterday's counts go.
            for (String key : prefs.getAll().keySet()) {
                if (key.startsWith("breaker_n_")) {
                    edit.remove(key);
                }
            }
            edit.putString("breaker_day", day);
            edit.putInt("breaker_n_" + pkg, 1);
        } else {
            edit.putInt("breaker_n_" + pkg, prefs.getInt("breaker_n_" + pkg, 0) + 1);
        }
        edit.apply();
    }

    private static PendingIntent reminder(Context context, String label, int flags) {
        Intent intent = new Intent(context, ReminderReceiver.class).setAction(ACTION).putExtra("label", label);
        return PendingIntent.getBroadcast(context, REQUEST, intent, PendingIntent.FLAG_IMMUTABLE | flags);
    }

    /** The app opened: remind in the chosen minutes, unless the home screen comes back first. */
    static void started(Context context, String label) {
        SharedPreferences prefs = context.getSharedPreferences("duo_home", 0);
        AlarmManager alarms = context.getSystemService(AlarmManager.class);
        if (alarms == null) {
            return;
        }
        long at = System.currentTimeMillis() + minutes(prefs) * 60000L;
        alarms.set(AlarmManager.RTC, at, reminder(context, label, PendingIntent.FLAG_UPDATE_CURRENT));
        prefs.edit().putLong("breaker_due", at).putString("breaker_label", label).apply();
    }

    /** Back on the home screen: no reminder needed. */
    static void stop(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("duo_home", 0);
        if (!prefs.contains("breaker_due")) {
            return;
        }
        AlarmManager alarms = context.getSystemService(AlarmManager.class);
        PendingIntent pending = reminder(context, "", PendingIntent.FLAG_NO_CREATE);
        if (alarms != null && pending != null) {
            alarms.cancel(pending);
            pending.cancel();
        }
        prefs.edit().remove("breaker_due").remove("breaker_label").apply();
    }

    static void remind(Context context, String label) {
        SharedPreferences prefs = context.getSharedPreferences("duo_home", 0);
        prefs.edit().remove("breaker_due").apply();
        if (!ReminderReceiver.canNotify(context)) {
            return;
        }
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (manager == null) {
            return;
        }
        manager.createNotificationChannel(new NotificationChannel(CHANNEL, context.getString(R.string.breaker_title), NotificationManager.IMPORTANCE_DEFAULT));
        Intent home = new Intent(context, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent open = PendingIntent.getActivity(context, 42, home, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String text = context.getString(R.string.breaker_reminder, label == null ? "" : label, NowBar.number(context, minutes(prefs)));
        Notification notification = new Notification.Builder(context, CHANNEL)
                .setSmallIcon(R.drawable.ic_notify)
                .setContentTitle(context.getString(R.string.breaker_title))
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(open)
                .setAutoCancel(true)
                .build();
        manager.notify(960, notification);
    }
}
