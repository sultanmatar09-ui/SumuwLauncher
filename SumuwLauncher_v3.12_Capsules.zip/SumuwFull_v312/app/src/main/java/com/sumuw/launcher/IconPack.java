package com.sumuw.launcher;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

/**
 * Icon packs from the Play Store, in the common format Nova, ADW, Apex and GO launchers read: the pack
 * lists each app's component with the drawable that replaces its icon (appfilter.xml). Apps the pack
 * doesn't cover keep their own icon.
 */
final class IconPack {
    private static final String[] ACTIONS = {"com.novalauncher.THEME", "org.adw.launcher.THEMES",
            "com.anddoes.launcher.THEME", "com.gau.go.launcherex.theme"};

    final String packageName;
    private final Resources resources;
    private final HashMap<String, String> drawables = new HashMap<>();

    private IconPack(String packageName, Resources resources) {
        this.packageName = packageName;
        this.resources = resources;
    }

    /** Installed packs as package name to label, sorted by label. */
    static Map<String, String> installed(Context context) {
        PackageManager pm = context.getPackageManager();
        ArrayList<String[]> found = new ArrayList<>();
        java.util.HashSet<String> seen = new java.util.HashSet<>();
        for (String action : ACTIONS) {
            try {
                for (ResolveInfo info : pm.queryIntentActivities(new Intent(action), PackageManager.GET_META_DATA)) {
                    String pkg = info.activityInfo.packageName;
                    if (seen.add(pkg)) {
                        found.add(new String[]{pkg, String.valueOf(info.loadLabel(pm))});
                    }
                }
            } catch (Exception ignored) {
            }
        }
        final java.text.Collator collator = java.text.Collator.getInstance();
        java.util.Collections.sort(found, (a, b) -> collator.compare(a[1], b[1]));
        LinkedHashMap<String, String> result = new LinkedHashMap<>();
        for (String[] pack : found) {
            result.put(pack[0], pack[1]);
        }
        return result;
    }

    /** Reads a pack's list; null if it isn't installed or can't be read. */
    static IconPack load(Context context, String packageName) {
        if (packageName == null || packageName.length() == 0) {
            return null;
        }
        try {
            Resources resources = context.getPackageManager().getResourcesForApplication(packageName);
            IconPack pack = new IconPack(packageName, resources);
            XmlPullParser parser = null;
            int id = resources.getIdentifier("appfilter", "xml", packageName);
            if (id != 0) {
                parser = resources.getXml(id);
                pack.read(parser);
            } else {
                try (InputStream in = resources.getAssets().open("appfilter.xml")) {
                    parser = XmlPullParserFactory.newInstance().newPullParser();
                    parser.setInput(in, "UTF-8");
                    pack.read(parser);
                }
            }
            return pack.drawables.isEmpty() ? null : pack;
        } catch (Exception e) {
            return null;
        }
    }

    private void read(XmlPullParser parser) throws Exception {
        for (int event = parser.getEventType(); event != XmlPullParser.END_DOCUMENT; event = parser.next()) {
            if (event != XmlPullParser.START_TAG || !"item".equals(parser.getName())) {
                continue;
            }
            String component = parser.getAttributeValue(null, "component");
            String drawable = parser.getAttributeValue(null, "drawable");
            if (component == null || drawable == null) {
                continue;
            }
            // "ComponentInfo{com.whatsapp/com.whatsapp.Main}"
            int open = component.indexOf('{');
            int close = component.indexOf('}');
            if (open >= 0 && close > open) {
                ComponentName name = ComponentName.unflattenFromString(component.substring(open + 1, close));
                if (name != null) {
                    drawables.put(name.flattenToString(), drawable);
                }
            }
        }
    }

    int size() {
        return drawables.size();
    }

    /** The pack's icon for an app, or null when the pack doesn't have one. */
    Drawable iconFor(ComponentName component) {
        String name = drawables.get(component.flattenToString());
        if (name == null) {
            return null;
        }
        try {
            int id = resources.getIdentifier(name, "drawable", packageName);
            if (id == 0) {
                id = resources.getIdentifier(name, "mipmap", packageName);
            }
            return id == 0 ? null : resources.getDrawable(id, null);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Every icon the pack has, not just the ones tied to an app: packs list them in drawable.xml (the
     * same list their own icon picker shows). Without that list, the icons named in appfilter.xml.
     */
    List<String> allDrawables() {
        java.util.LinkedHashSet<String> names = new java.util.LinkedHashSet<>();
        try {
            XmlPullParser parser = null;
            int id = resources.getIdentifier("drawable", "xml", packageName);
            InputStream in = null;
            if (id != 0) {
                parser = resources.getXml(id);
            } else {
                try {
                    in = resources.getAssets().open("drawable.xml");
                    parser = XmlPullParserFactory.newInstance().newPullParser();
                    parser.setInput(in, "UTF-8");
                } catch (Exception ignored) {
                    parser = null;
                }
            }
            if (parser != null) {
                for (int event = parser.getEventType(); event != XmlPullParser.END_DOCUMENT; event = parser.next()) {
                    if (event == XmlPullParser.START_TAG && "item".equals(parser.getName())) {
                        String name = parser.getAttributeValue(null, "drawable");
                        if (name != null && name.length() > 0) {
                            names.add(name);
                        }
                    }
                }
            }
            if (in != null) {
                in.close();
            }
        } catch (Exception ignored) {
        }
        if (names.isEmpty()) {
            ArrayList<String> mapped = new ArrayList<>(new java.util.TreeSet<>(drawables.values()));
            names.addAll(mapped);
        }
        return new ArrayList<>(names);
    }

    /** The pack's icon for this app's component name, as the pack calls it, or null. */
    String nameFor(ComponentName component) {
        return drawables.get(component.flattenToString());
    }

    /** One of the pack's icons by its name, or null. */
    Drawable drawableNamed(String name) {
        try {
            int id = resources.getIdentifier(name, "drawable", packageName);
            if (id == 0) {
                id = resources.getIdentifier(name, "mipmap", packageName);
            }
            return id == 0 ? null : resources.getDrawable(id, null);
        } catch (Exception e) {
            return null;
        }
    }

    static List<String> actions() {
        ArrayList<String> list = new ArrayList<>();
        java.util.Collections.addAll(list, ACTIONS);
        return list;
    }
}
