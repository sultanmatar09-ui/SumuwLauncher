package com.sumuw.launcher;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Where things are worked out for.
 * <ul>
 * <li>Prayer times: where the phone is (GPS, the default since 3.5.6), with a chosen Saudi city (Riyadh by
 * default) for when there is no fix or the user turns that off.</li>
 * <li>Weather, rain and dust alerts, and the Qibla: where the phone is now (GPS), unless the user turns
 * that off; then the prayer times' place.</li>
 * </ul>
 * The fix is taken while Home is on the screen (no background location), at most every fifteen minutes.
 */
final class Places {
    static final String GPS = "gps";
    /** Prayer times on "my location": a fix this old is fine. */
    static final long REFRESH_MS = 3L * 3600000L;
    /** Weather on GPS: a new fix when Home comes back after this long. */
    static final long FRESH_MS = 15L * 60000L;
    static final String PREF_WEATHER_GPS = "weather_gps";
    static final String PREF_PRAYER_GPS = "prayer_gps";
    /** Moved this far (km) since the weather was fetched: fetch it again for the new place. */
    static final double MOVED_KM = 2.0;

    private Places() {
    }

    static boolean usesGps(SharedPreferences prefs) {
        return GPS.equals(prefs.getString("prayer_city", "riyadh"));
    }

    /** Weather, alerts and the Qibla follow the phone (the default since 3.5.4). */
    static boolean weatherGps(SharedPreferences prefs) {
        return prefs.getBoolean(PREF_WEATHER_GPS, true);
    }

    /** Prayer times follow the phone: the older "use my location" choice, or the GPS switch (on by default). */
    static boolean prayerGps(SharedPreferences prefs) {
        return usesGps(prefs) || prefs.getBoolean(PREF_PRAYER_GPS, true);
    }

    static boolean wantsLocation(SharedPreferences prefs) {
        return prayerGps(prefs) || weatherGps(prefs);
    }

    /** The chosen city, used when the prayer times don't follow the phone or there is no fix yet. */
    static PrayerTimes.City city(SharedPreferences prefs) {
        String id = prefs.getString("prayer_city", "riyadh");
        return PrayerTimes.city(GPS.equals(id) ? "riyadh" : id);
    }

    static boolean hasFix(SharedPreferences prefs) {
        return prefs.contains("loc_lat");
    }

    /** The prayer times' place. */
    static double[] latLng(SharedPreferences prefs) {
        if (prayerGps(prefs) && hasFix(prefs)) {
            return new double[]{prefs.getFloat("loc_lat", 0f), prefs.getFloat("loc_lng", 0f)};
        }
        PrayerTimes.City city = city(prefs);
        return new double[]{city.lat, city.lng};
    }

    /** Where the phone is now, for the weather, the alerts and the Qibla; the prayer place without a fix. */
    static double[] here(SharedPreferences prefs) {
        if (weatherGps(prefs) && hasFix(prefs)) {
            return new double[]{prefs.getFloat("loc_lat", 0f), prefs.getFloat("loc_lng", 0f)};
        }
        return latLng(prefs);
    }

    /** Prayer times by GPS are in the phone's own time zone (right when travelling); a Saudi city in Riyadh's. */
    static TimeZone zone(SharedPreferences prefs) {
        return prayerGps(prefs) && hasFix(prefs) ? TimeZone.getDefault() : TimeZone.getTimeZone("Asia/Riyadh");
    }

    /** The prayer times' place, by name. */
    static String name(Context context, SharedPreferences prefs) {
        if (prayerGps(prefs) && hasFix(prefs)) {
            return fixName(context, prefs);
        }
        if (usesGps(prefs)) {
            return context.getString(R.string.locating);
        }
        return city(prefs).name;
    }

    /** The name of the place the weather is for: "الرياض" from the fix, or the prayer city. */
    static String hereName(Context context, SharedPreferences prefs) {
        if (weatherGps(prefs) && hasFix(prefs)) {
            return fixName(context, prefs);
        }
        return name(context, prefs);
    }

    /** The fix's town from the phone's geocoder, else the nearest listed city within 30 km, else "موقعي الحالي". */
    static String fixName(Context context, SharedPreferences prefs) {
        String named = prefs.getString("loc_name", "");
        if (named.length() > 0) {
            return named;
        }
        PrayerTimes.City near = nearestCity(prefs.getFloat("loc_lat", 0f), prefs.getFloat("loc_lng", 0f), 30.0);
        return near != null ? near.name : context.getString(R.string.my_location);
    }

    static PrayerTimes.City nearestCity(double lat, double lng, double withinKm) {
        PrayerTimes.City best = null;
        double bestKm = withinKm;
        for (PrayerTimes.City city : PrayerTimes.CITIES) {
            double km = distanceKm(lat, lng, city.lat, city.lng);
            if (km <= bestKm) {
                best = city;
                bestKm = km;
            }
        }
        return best;
    }

    static double distanceKm(double lat1, double lng1, double lat2, double lng2) {
        double p1 = Math.toRadians(lat1);
        double p2 = Math.toRadians(lat2);
        double dp = p2 - p1;
        double dl = Math.toRadians(lng2 - lng1);
        double a = Math.sin(dp / 2) * Math.sin(dp / 2) + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2);
        return 6371.0 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    /**
     * The country of the fix, for the prayer method: the geocoder's answer, else "SA" inside Saudi Arabia's
     * rough outline, else "" (unknown). Without a fix, the chosen Saudi city.
     */
    static String country(SharedPreferences prefs) {
        if (!(prayerGps(prefs) && hasFix(prefs))) {
            return "SA";
        }
        String known = prefs.getString("loc_country", "");
        if (known.length() > 0) {
            return known.toUpperCase(Locale.ROOT);
        }
        float lat = prefs.getFloat("loc_lat", 0f);
        float lng = prefs.getFloat("loc_lng", 0f);
        boolean saudi = lat > 16.3f && lat < 32.2f && lng > 34.5f && lng < 55.7f
                && !(lat > 22.6f && lng > 51.6f) // the Emirates and Qatar
                && !(lat < 17.4f && lng > 43.5f); // Yemen
        return saudi || nearestCity(lat, lng, 30.0) != null ? "SA" : "";
    }

    static boolean permitted(Context context) {
        return context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || precise(context);
    }

    /** The phone's location switch (in its quick settings) is on. */
    static boolean servicesOn(Context context) {
        try {
            LocationManager manager = context.getSystemService(LocationManager.class);
            return manager == null || Build.VERSION.SDK_INT < 28 || manager.isLocationEnabled();
        } catch (Exception e) {
            return true;
        }
    }

    /** "Precise" in Android's location question: the GPS itself. */
    static boolean precise(Context context) {
        return context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    static boolean stale(SharedPreferences prefs) {
        long age = System.currentTimeMillis() - prefs.getLong("loc_time", 0L);
        return age < 0 || age > FRESH_MS;
    }

    /** Updates the stored location from the phone, then calls {@code done} on the main thread. */
    static void refresh(final Context context, final SharedPreferences prefs, final Runnable done) {
        if (!wantsLocation(prefs) || !permitted(context)) {
            return;
        }
        LocationManager manager = context.getSystemService(LocationManager.class);
        if (manager == null) {
            return;
        }
        long freshness = FRESH_MS;
        Location best = null;
        try {
            for (String provider : manager.getProviders(true)) {
                Location location = manager.getLastKnownLocation(provider);
                if (location != null && (best == null || location.getTime() > best.getTime())) {
                    best = location;
                }
            }
        } catch (SecurityException ignored) {
            return;
        }
        if (best != null && System.currentTimeMillis() - best.getTime() < Math.min(freshness, 5 * 60000L)) {
            store(context, prefs, best);
            done.run();
            return;
        }
        if (Build.VERSION.SDK_INT >= 30) {
            final Location fallback = best;
            try {
                manager.getCurrentLocation(provider(context, manager), null, context.getMainExecutor(), location -> {
                    Location result = location != null ? location : fallback;
                    if (result != null) {
                        store(context, prefs, result);
                        done.run();
                    }
                });
            } catch (Exception ignored) {
                if (fallback != null) {
                    store(context, prefs, fallback);
                    done.run();
                }
            }
        } else if (best != null) {
            store(context, prefs, best);
            done.run();
        }
    }

    /** Google's fused location where there is one, the GPS when precise location is allowed, else the network. */
    private static String provider(Context context, LocationManager manager) {
        if (Build.VERSION.SDK_INT >= 31 && manager.isProviderEnabled(LocationManager.FUSED_PROVIDER)) {
            return LocationManager.FUSED_PROVIDER;
        }
        if (precise(context) && manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            return LocationManager.GPS_PROVIDER;
        }
        return manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) ? LocationManager.NETWORK_PROVIDER : LocationManager.GPS_PROVIDER;
    }

    static void store(Context context, SharedPreferences prefs, Location location) {
        store(context, prefs, location.getLatitude(), location.getLongitude());
    }

    static void store(Context context, SharedPreferences prefs, double lat, double lng) {
        SharedPreferences.Editor edit = prefs.edit().putFloat("loc_lat", (float) lat).putFloat("loc_lng", (float) lng)
                .putLong("loc_time", System.currentTimeMillis());
        boolean named = prefs.contains("loc_name_lat")
                && distanceKm(lat, lng, prefs.getFloat("loc_name_lat", 0f), prefs.getFloat("loc_name_lng", 0f)) < MOVED_KM;
        if (!named) {
            edit.remove("loc_name");
        }
        edit.apply();
        if (!named) {
            nameInBackground(context, prefs, lat, lng);
        }
    }

    /** Asks the phone's geocoder for the town's name, in the phone's language. Needs the internet. */
    private static void nameInBackground(final Context context, final SharedPreferences prefs, final double lat, final double lng) {
        if (context == null || !android.location.Geocoder.isPresent()) {
            return;
        }
        final Handler main = new Handler(Looper.getMainLooper());
        new Thread(() -> {
            try {
                android.location.Geocoder geocoder = new android.location.Geocoder(context, Locale.getDefault());
                @SuppressWarnings("deprecation")
                List<android.location.Address> found = geocoder.getFromLocation(lat, lng, 1);
                if (found == null || found.isEmpty()) {
                    return;
                }
                android.location.Address address = found.get(0);
                String town = address.getLocality();
                if (town == null || town.isEmpty()) {
                    town = address.getSubAdminArea();
                }
                if (town == null || town.isEmpty()) {
                    town = address.getAdminArea();
                }
                final String country = address.getCountryCode() == null ? "" : address.getCountryCode();
                if (town != null && !town.isEmpty()) {
                    final String name = town;
                    main.post(() -> prefs.edit().putString("loc_name", name).putString("loc_country", country)
                            .putFloat("loc_name_lat", (float) lat).putFloat("loc_name_lng", (float) lng).apply());
                }
            } catch (Exception ignored) {
                // offline or no geocoder: the nearest listed city stands in
            }
        }).start();
    }
}
