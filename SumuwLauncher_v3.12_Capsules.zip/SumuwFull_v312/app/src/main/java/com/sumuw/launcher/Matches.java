package com.sumuw.launcher;

import android.content.SharedPreferences;
import android.text.TextUtils;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Upcoming football matches for the home card. Kick-off times come from ESPN's public scores service
 * (the same data its apps use), in UTC, and are shown in the phone's time. ESPN's TV listings are for the
 * US, so the channel comes from who holds the rights in Saudi Arabia this season, as the broadcasters and
 * leagues announced them (see {@link #CHANNELS}).
 */
final class Matches {
    static final long REFRESH_MS = 30L * 60000L;
    static final String PREF_LEAGUES = "match_leagues";
    static final String PREF_TEAMS = "match_teams";
    static final String DEFAULT_LEAGUES = "ksa.1,uefa.champions,eng.1,esp.1";
    static final String PREF_ALERT = "match_alert_min";
    /** Minutes before a favourite club's match for the alert; 0 is off. */
    static final int[] ALERT_CHOICES = {0, 10, 15, 30, 60};

    static int alertMinutes(SharedPreferences prefs) {
        return prefs.getInt(PREF_ALERT, 15);
    }
    private static final String BASE = "https://site.api.espn.com/apis/site/v2/sports/soccer/";

    /** ESPN's id of each competition, its Arabic name, and its rights holder in Saudi Arabia for 2026-27. */
    static final String[][] LEAGUES = {
            {"ksa.1", "دوري روشن السعودي", "ثمانية", "روشن"},
            {"ksa.kings.cup", "كأس خادم الحرمين الشريفين", "ثمانية", "كأس الملك"},
            {"afc.champions", "دوري أبطال آسيا للنخبة", "beIN SPORTS", "أبطال آسيا"},
            {"uefa.champions", "دوري أبطال أوروبا", "beIN SPORTS", "أبطال أوروبا"},
            {"uefa.europa", "الدوري الأوروبي", "beIN SPORTS", "الأوروبي"},
            {"eng.1", "الدوري الإنجليزي", "beIN SPORTS", "الإنجليزي"},
            {"esp.1", "الدوري الإسباني", "beIN SPORTS", "الإسباني"},
            {"ita.1", "الدوري الإيطالي", "STARZPLAY", "الإيطالي"},
            {"ger.1", "الدوري الألماني", "شاهد", "الألماني"},
            {"fra.1", "الدوري الفرنسي", "beIN SPORTS", "الفرنسي"},
            // More leagues to pick clubs from. A channel is named only where its Saudi rights holder is
            // known for sure; the rest show none rather than a guess.
            {"ned.1", "الدوري الهولندي", "", "الهولندي"},
            {"por.1", "الدوري البرتغالي", "", "البرتغالي"},
            {"tur.1", "الدوري التركي", "", "التركي"},
            {"usa.1", "الدوري الأمريكي", "Apple TV", "الأمريكي"},
            {"afc.asian.cup", "كأس آسيا", "", "كأس آسيا"},
            {"fifa.friendly", "مباريات دولية ودية", "", "ودية"},
    };

    /** Where favourite clubs (and national teams) are picked from: ESPN's club list of each. */
    static final String[] TEAM_SOURCES = {"ksa.1", "eng.1", "esp.1", "ita.1", "ger.1", "fra.1", "ned.1", "por.1", "tur.1", "usa.1",
            "uefa.champions", "afc.champions", "afc.asian.cup"};

    /** Europe's leagues and cups: their clubs also play in the UEFA competitions. */
    static boolean european(String slug) {
        return slug.startsWith("uefa.") || slug.equals("eng.1") || slug.equals("esp.1") || slug.equals("ita.1") || slug.equals("ger.1")
                || slug.equals("fra.1") || slug.equals("ned.1") || slug.equals("por.1") || slug.equals("tur.1");
    }

    /** A national team, picked from the Asian Cup's list. */
    static boolean national(String slug) {
        return slug.equals("afc.asian.cup") || slug.startsWith("fifa.");
    }


    static final class Match {
        final String id;
        final String league;
        final long time;
        final String home;
        final String homeId;
        final String away;
        final String awayId;
        final boolean live;
        /** The minute while it is played ("67'"), "HT" at half time, "FT" at the end. */
        final String clock;
        /** "pre" not started, "in" being played, "post" finished. */
        final String state;
        final String homeScore;
        final String awayScore;
        final String homeLogo;
        final String awayLogo;

        Match(String id, String league, long time, String home, String homeId, String away, String awayId, boolean live, String clock) {
            this(id, league, time, home, homeId, away, awayId, live ? "in" : "pre", clock, "", "", "", "");
        }

        Match(String id, String league, long time, String home, String homeId, String away, String awayId, String state, String clock,
              String homeScore, String awayScore, String homeLogo, String awayLogo) {
            this.id = id;
            this.league = league;
            this.time = time;
            this.home = home;
            this.homeId = homeId;
            this.away = away;
            this.awayId = awayId;
            this.state = state;
            this.live = "in".equals(state);
            this.clock = clock;
            this.homeScore = homeScore;
            this.awayScore = awayScore;
            this.homeLogo = homeLogo;
            this.awayLogo = awayLogo;
        }

        boolean finished() {
            return "post".equals(state);
        }

        boolean hasScore() {
            return (live || finished()) && homeScore.length() > 0 && awayScore.length() > 0;
        }

        boolean involves(Set<String> teams) {
            return teams.contains(homeId) || teams.contains(awayId);
        }
    }

    /** A club the user follows: ESPN's id, its name, and the league it was picked from. */
    static final class Team {
        final String id;
        final String name;
        final String league;

        Team(String id, String name, String league) {
            this.id = id;
            this.name = name;
            this.league = league;
        }
    }

    private Matches() {
    }

    static String leagueName(String slug) {
        for (String[] league : LEAGUES) {
            if (league[0].equals(slug)) {
                return league[1];
            }
        }
        return slug;
    }

    /** "روشن", "الإنجليزي": for the narrow card. */
    static String leagueShort(String slug) {
        for (String[] league : LEAGUES) {
            if (league[0].equals(slug)) {
                return league[3];
            }
        }
        return slug;
    }

    static String channel(String slug) {
        for (String[] league : LEAGUES) {
            if (league[0].equals(slug)) {
                return league[2];
            }
        }
        return "";
    }

    static boolean saudi(String slug) {
        return slug.startsWith("ksa.");
    }

    // ---------------------------------------------------------------- choices

    static Set<String> leagues(SharedPreferences prefs) {
        LinkedHashSet<String> set = new LinkedHashSet<>();
        for (String part : prefs.getString(PREF_LEAGUES, DEFAULT_LEAGUES).split(",")) {
            if (part.length() > 0) {
                set.add(part);
            }
        }
        return set;
    }

    static void saveLeagues(SharedPreferences prefs, Set<String> leagues) {
        prefs.edit().putString(PREF_LEAGUES, TextUtils.join(",", leagues)).putLong("matches_time", 0L).apply();
    }

    static List<Team> teams(SharedPreferences prefs) {
        ArrayList<Team> list = new ArrayList<>();
        for (String part : prefs.getString(PREF_TEAMS, "").split(";")) {
            String[] f = part.split("\\|", -1);
            if (f.length == 3 && f[0].length() > 0) {
                list.add(new Team(f[0], f[1], f[2]));
            }
        }
        return list;
    }

    static void saveTeams(SharedPreferences prefs, List<Team> teams) {
        StringBuilder text = new StringBuilder();
        for (Team team : teams) {
            if (text.length() > 0) {
                text.append(';');
            }
            text.append(team.id).append('|').append(team.name.replace('|', ' ').replace(';', ' ')).append('|').append(team.league);
        }
        prefs.edit().putString(PREF_TEAMS, text.toString()).putLong("matches_time", 0L).apply();
    }

    static Set<String> teamIds(SharedPreferences prefs) {
        LinkedHashSet<String> ids = new LinkedHashSet<>();
        for (Team team : teams(prefs)) {
            ids.add(team.id);
        }
        return ids;
    }

    /**
     * What to ask ESPN for: the chosen leagues, plus the competitions where the favourite clubs also play
     * (a Saudi club in the King's Cup and Asia, a European one in the UEFA competitions).
     */
    static Set<String> toFetch(SharedPreferences prefs) {
        LinkedHashSet<String> fetch = new LinkedHashSet<>(leagues(prefs));
        for (Team team : teams(prefs)) {
            fetch.add(team.league);
            if (saudi(team.league)) {
                fetch.add("ksa.kings.cup");
                fetch.add("afc.champions");
            } else if (national(team.league)) {
                fetch.add("fifa.friendly"); // national teams: the Asian Cup and friendlies
            } else if (european(team.league)) {
                fetch.add("uefa.champions");
                fetch.add("uefa.europa");
            }
        }
        return fetch;
    }

    // ---------------------------------------------------------------- network

    static String get(String address) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
        try {
            connection.setConnectTimeout(9000);
            connection.setReadTimeout(12000);
            connection.setRequestProperty("User-Agent", "SaraHome/" + HomeActivity.VERSION_NAME);
            if (connection.getResponseCode() != 200) {
                throw new java.io.IOException("HTTP " + connection.getResponseCode());
            }
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            try (InputStream in = connection.getInputStream()) {
                byte[] chunk = new byte[8192];
                int read;
                while ((read = in.read(chunk)) > 0 && buffer.size() < 3_000_000) {
                    buffer.write(chunk, 0, read);
                }
            }
            return new String(buffer.toByteArray(), StandardCharsets.UTF_8);
        } finally {
            connection.disconnect();
        }
    }

    /** The coming ten days of every competition asked for. Off the main thread. */
    static List<Match> fetch(Set<String> leagues, long now) throws Exception {
        SimpleDateFormat day = new SimpleDateFormat("yyyyMMdd", Locale.US);
        day.setTimeZone(TimeZone.getTimeZone("UTC"));
        String range = day.format(new java.util.Date(now - 3 * 3600000L)) + "-" + day.format(new java.util.Date(now + 10 * 86400000L));
        ArrayList<Match> all = new ArrayList<>();
        int worked = 0;
        Exception last = null;
        for (String league : leagues) {
            try {
                all.addAll(parse(get(BASE + league + "/scoreboard?dates=" + range + "&limit=300"), league, now));
                worked++;
            } catch (Exception error) {
                try {
                    // Without the date range the service answers with the current round, which still helps.
                    all.addAll(parse(get(BASE + league + "/scoreboard"), league, now));
                    worked++;
                } catch (Exception again) {
                    last = again;
                }
            }
        }
        if (worked == 0 && last != null) {
            throw last;
        }
        sort(all);
        return all;
    }

    static void sort(List<Match> matches) {
        Collections.sort(matches, (a, b) -> Long.compare(a.time, b.time));
    }

    private static long parseTime(String text) {
        String[] patterns = {"yyyy-MM-dd'T'HH:mm'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mmXXX"};
        for (String pattern : patterns) {
            try {
                SimpleDateFormat format = new SimpleDateFormat(pattern, Locale.US);
                format.setTimeZone(TimeZone.getTimeZone("UTC"));
                return format.parse(text).getTime();
            } catch (Exception ignored) {
            }
        }
        return 0L;
    }

    /**
     * Matches not yet started, being played, or finished in the last twelve hours (for the result).
     * Postponed and cancelled ones are left out, and so is a "scheduled" match from days ago (stale data).
     */
    static List<Match> parse(String json, String league, long now) throws Exception {
        ArrayList<Match> list = new ArrayList<>();
        JSONArray events = new JSONObject(json).optJSONArray("events");
        for (int i = 0; events != null && i < events.length(); i++) {
            JSONObject event = events.getJSONObject(i);
            JSONObject type = event.optJSONObject("status") != null ? event.getJSONObject("status").optJSONObject("type") : null;
            String state = type == null ? "pre" : type.optString("state", "pre");
            String name = type == null ? "" : type.optString("name", "");
            if (name.contains("POSTPONED") || name.contains("CANCELED") || name.contains("ABANDONED") || name.contains("DELAYED")) {
                continue;
            }
            long time = parseTime(event.optString("date", ""));
            boolean live = "in".equals(state);
            boolean over = "post".equals(state);
            if (time == 0L || (over && time < now - 12 * 3600000L) || (!over && !live && time < now - 15 * 60000L)
                    || (live && time < now - 4 * 3600000L)) {
                continue;
            }
            JSONArray competitions = event.optJSONArray("competitions");
            JSONArray teams = competitions == null || competitions.length() == 0 ? null
                    : competitions.getJSONObject(0).optJSONArray("competitors");
            if (teams == null || teams.length() < 2) {
                continue;
            }
            String home = null;
            String homeId = "";
            String away = null;
            String awayId = "";
            String homeScore = "";
            String awayScore = "";
            String homeLogo = "";
            String awayLogo = "";
            for (int t = 0; t < teams.length(); t++) {
                JSONObject side = teams.getJSONObject(t);
                JSONObject team = side.optJSONObject("team");
                if (team == null) {
                    continue;
                }
                String teamName = team.optString("displayName", team.optString("name", ""));
                String score = side.optString("score", "");
                String logo = team.optString("logo", "");
                if ("home".equals(side.optString("homeAway"))) {
                    home = teamName;
                    homeId = team.optString("id", "");
                    homeScore = score;
                    homeLogo = logo;
                } else {
                    away = teamName;
                    awayId = team.optString("id", "");
                    awayScore = score;
                    awayLogo = logo;
                }
            }
            if (home == null || away == null) {
                continue;
            }
            String clock = "";
            if (event.optJSONObject("status") != null) {
                clock = event.getJSONObject("status").optString("displayClock", "");
                String detail = type == null ? "" : type.optString("shortDetail", "");
                if (detail.equals("HT") || detail.equals("FT") || detail.startsWith("AET") || detail.startsWith("FT-Pens") || clock.length() == 0) {
                    clock = detail;
                }
            }
            list.add(new Match(event.optString("id", ""), league, time, home, homeId, away, awayId, live ? "in" : over ? "post" : "pre",
                    clock, homeScore, awayScore, homeLogo, awayLogo));
        }
        return list;
    }

    /** The clubs of a league, as {id, name} sorted by their Arabic name. Off the main thread. */
    static List<String[]> fetchTeams(String league) throws Exception {
        JSONObject root = new JSONObject(get(BASE + league + "/teams?limit=200"));
        ArrayList<String[]> list = new ArrayList<>();
        JSONArray sports = root.optJSONArray("sports");
        JSONArray leagues = sports == null || sports.length() == 0 ? null : sports.getJSONObject(0).optJSONArray("leagues");
        JSONArray teams = leagues == null || leagues.length() == 0 ? null : leagues.getJSONObject(0).optJSONArray("teams");
        for (int i = 0; teams != null && i < teams.length(); i++) {
            JSONObject team = teams.getJSONObject(i).optJSONObject("team");
            if (team != null && team.optString("id").length() > 0) {
                list.add(new String[]{team.optString("id"), team.optString("displayName", team.optString("name", ""))});
            }
        }
        final java.text.Collator collator = java.text.Collator.getInstance(new Locale("ar"));
        Collections.sort(list, (a, b) -> collator.compare(arabic(a[1]), arabic(b[1])));
        return list;
    }

    // ---------------------------------------------------------------- cache

    static void store(SharedPreferences prefs, List<Match> matches, long when) {
        JSONArray array = new JSONArray();
        try {
            for (Match match : matches) {
                if (array.length() >= 120) {
                    break;
                }
                array.put(new JSONObject().put("id", match.id).put("l", match.league).put("t", match.time)
                        .put("h", match.home).put("hi", match.homeId).put("a", match.away).put("ai", match.awayId)
                        .put("s", match.state).put("c", match.clock).put("hs", match.homeScore).put("as", match.awayScore)
                        .put("hl", match.homeLogo).put("al", match.awayLogo));
            }
        } catch (Exception ignored) {
        }
        prefs.edit().putString("matches_json", array.toString()).putLong("matches_time", when).apply();
    }

    static List<Match> cached(SharedPreferences prefs) {
        ArrayList<Match> list = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(prefs.getString("matches_json", "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject o = array.getJSONObject(i);
                String state = o.has("s") ? o.optString("s") : o.optBoolean("live") ? "in" : "pre";
                list.add(new Match(o.optString("id"), o.optString("l"), o.optLong("t"), o.optString("h"), o.optString("hi"),
                        o.optString("a"), o.optString("ai"), state, o.optString("c"), o.optString("hs"), o.optString("as"),
                        o.optString("hl"), o.optString("al")));
            }
        } catch (Exception ignored) {
        }
        return list;
    }

    /**
     * What the card shows, most relevant first: a favourite club playing now, its result if the match
     * ended in the last three hours, its next match within two days, then other matches being played in
     * the chosen leagues, then everything else to come, soonest first. Other finished matches drop out.
     */
    static List<Match> upcoming(SharedPreferences prefs, List<Match> all, long now, int limit) {
        Set<String> leagues = leagues(prefs);
        Set<String> favourites = teamIds(prefs);
        ArrayList<Match> favLive = new ArrayList<>();
        ArrayList<Match> favResults = new ArrayList<>();
        ArrayList<Match> favSoon = new ArrayList<>();
        ArrayList<Match> otherLive = new ArrayList<>();
        ArrayList<Match> later = new ArrayList<>();
        for (Match match : all) {
            boolean mine = match.involves(favourites);
            if (!mine && !leagues.contains(match.league)) {
                continue;
            }
            if (match.finished()) {
                if (mine && match.time > now - 5 * 3600000L) {
                    favResults.add(match); // kicked off within five hours: ended within about three
                }
            } else if (match.live) {
                (mine ? favLive : otherLive).add(match);
            } else if (match.time >= now - 150 * 60000L) {
                (mine && match.time < now + 48 * 3600000L ? favSoon : later).add(match);
            }
        }
        sort(favLive);
        sort(favSoon);
        sort(otherLive);
        sort(later);
        Collections.sort(favResults, (a, b) -> Long.compare(b.time, a.time));
        ArrayList<Match> result = new ArrayList<>(favLive);
        result.addAll(favResults);
        result.addAll(favSoon);
        result.addAll(otherLive);
        result.addAll(later);
        return result.size() > limit ? new ArrayList<>(result.subList(0, limit)) : result;
    }

    /** The next match of a favourite club that hasn't started, or null. */
    static Match nextFavourite(SharedPreferences prefs, long after) {
        Set<String> favourites = teamIds(prefs);
        Match best = null;
        for (Match match : cached(prefs)) {
            if ("pre".equals(match.state) && match.time > after && match.involves(favourites)
                    && (best == null || match.time < best.time)) {
                best = match;
            }
        }
        return best;
    }

    // ---------------------------------------------------------------- club crests

    static java.io.File crestFile(android.content.Context context, String teamId) {
        return new java.io.File(new java.io.File(context.getFilesDir(), "crests"), teamId.replaceAll("[^0-9A-Za-z]", "_") + ".png");
    }

    /** A crest is kept for a month. */
    static boolean hasFreshCrest(android.content.Context context, String teamId) {
        java.io.File file = crestFile(context, teamId);
        return file.exists() && System.currentTimeMillis() - file.lastModified() < 30L * 86400000L;
    }

    /** ESPN's crests are 500 pixels; its image service gives them at icon size. */
    static String smallLogo(String url) {
        String host = "https://a.espncdn.com";
        if (url.startsWith(host + "/i/teamlogos/")) {
            return host + "/combiner/i?img=" + url.substring(host.length()) + "&w=96&h=96";
        }
        return url;
    }

    /** Downloads the crests of these matches' clubs that aren't kept yet. Off the main thread. */
    static int fetchCrests(android.content.Context context, List<Match> matches, int most) {
        int saved = 0;
        java.util.LinkedHashMap<String, String> wanted = new java.util.LinkedHashMap<>();
        for (Match match : matches) {
            if (wanted.size() >= most) {
                break;
            }
            if (match.homeLogo.length() > 0 && !hasFreshCrest(context, match.homeId)) {
                wanted.put(match.homeId, match.homeLogo);
            }
            if (match.awayLogo.length() > 0 && !hasFreshCrest(context, match.awayId)) {
                wanted.put(match.awayId, match.awayLogo);
            }
        }
        for (java.util.Map.Entry<String, String> entry : wanted.entrySet()) {
            byte[] data = download(smallLogo(entry.getValue()));
            if (data == null) {
                data = download(entry.getValue());
            }
            if (data != null && saveCrest(context, entry.getKey(), data)) {
                saved++;
            }
        }
        return saved;
    }

    /** Crests for clubs given as {id, logo address}, those not saved lately; at most {@code most}. */
    static int fetchCrests(android.content.Context context, java.util.Map<String, String> clubs, int most) {
        int saved = 0;
        int tried = 0;
        for (java.util.Map.Entry<String, String> entry : clubs.entrySet()) {
            if (tried >= most) {
                break;
            }
            if (entry.getValue() == null || entry.getValue().isEmpty() || hasFreshCrest(context, entry.getKey())) {
                continue;
            }
            tried++;
            byte[] data = download(smallLogo(entry.getValue()));
            if (data == null) {
                data = download(entry.getValue());
            }
            if (data != null && saveCrest(context, entry.getKey(), data)) {
                saved++;
            }
        }
        return saved;
    }

    private static byte[] download(String address) {
        try {
            HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
            try {
                connection.setConnectTimeout(8000);
                connection.setReadTimeout(10000);
                if (connection.getResponseCode() != 200) {
                    return null;
                }
                ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                try (InputStream in = connection.getInputStream()) {
                    byte[] chunk = new byte[8192];
                    int read;
                    while ((read = in.read(chunk)) > 0 && buffer.size() < 1_500_000) {
                        buffer.write(chunk, 0, read);
                    }
                }
                return buffer.toByteArray();
            } finally {
                connection.disconnect();
            }
        } catch (Exception e) {
            return null;
        }
    }

    /** Scales the crest to 96 pixels and keeps it as a PNG. */
    static boolean saveCrest(android.content.Context context, String teamId, byte[] data) {
        try {
            android.graphics.Bitmap image = android.graphics.BitmapFactory.decodeByteArray(data, 0, data.length);
            if (image == null) {
                return false;
            }
            int side = Math.max(image.getWidth(), image.getHeight());
            if (side > 96) {
                float scale = 96f / side;
                image = android.graphics.Bitmap.createScaledBitmap(image, Math.max(1, Math.round(image.getWidth() * scale)),
                        Math.max(1, Math.round(image.getHeight() * scale)), true);
            }
            java.io.File file = crestFile(context, teamId);
            java.io.File folder = file.getParentFile();
            if (folder != null && !folder.exists() && !folder.mkdirs()) {
                return false;
            }
            java.io.File temp = new java.io.File(file.getPath() + ".tmp");
            try (java.io.FileOutputStream out = new java.io.FileOutputStream(temp)) {
                image.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out);
            }
            return temp.renameTo(file);
        } catch (Exception | OutOfMemoryError e) {
            return false;
        }
    }



    // ---------------------------------------------------------------- Arabic club names

    private static final HashMap<String, String> NAMES = new HashMap<>();

    private static void name(String english, String arabic) {
        NAMES.put(key(english), arabic);
    }

    static {
        // Saudi clubs
        name("Al Hilal", "الهلال");
        name("Al Nassr", "النصر");
        name("Al Ittihad", "الاتحاد");
        name("Al Ahli", "الأهلي");
        name("Al Shabab", "الشباب");
        name("Al Ettifaq", "الاتفاق");
        name("Al Taawoun", "التعاون");
        name("Al Fateh", "الفتح");
        name("Al Fayha", "الفيحاء");
        name("Al Feiha", "الفيحاء");
        name("Al Khaleej", "الخليج");
        name("Al Qadsiah", "القادسية");
        name("Al Qadisiyah", "القادسية");
        name("Al Riyadh", "الرياض");
        name("Al Kholood", "الخلود");
        name("Al Khulood", "الخلود");
        name("Al Okhdood", "الأخدود");
        name("Al Akhdoud", "الأخدود");
        name("Al Hazem", "الحزم");
        name("Al Najma", "النجمة");
        name("NEOM", "نيوم");
        name("Neom SC", "نيوم");
        name("Damac", "ضمك");
        name("Al Wehda", "الوحدة");
        name("Al Raed", "الرائد");
        name("Al Orobah", "العروبة");
        name("Abha", "أبها");
        name("Al Tai", "الطائي");
        name("Al Ula", "العلا");
        name("Jeddah", "جدة");
        name("Al Jabalain", "الجبلين");
        name("Al Batin", "الباطن");
        name("Al Adalah", "العدالة");
        name("Al Jandal", "الجندل");
        name("Al Arabi", "العربي");
        name("Ohod", "أحد");
        name("Al Faisaly", "الفيصلي");
        name("Al Zulfi", "الزلفي");
        name("Al Diriyah", "الدرعية");
        name("Al Bukiryah", "البكيرية");
        name("Al Safa", "الصفا");
        name("Al Ansar", "الأنصار");
        // Asia
        name("Al Sadd", "السد");
        name("Al Duhail", "الدحيل");
        name("Al Gharafa", "الغرافة");
        name("Al Rayyan", "الريان");
        name("Al Wakrah", "الوكرة");
        name("Al Shamal", "الشمال");
        name("Al Ain", "العين");
        name("Shabab Al-Ahli", "شباب الأهلي");
        name("Shabab Al Ahli", "شباب الأهلي");
        name("Al Wasl", "الوصل");
        name("Sharjah", "الشارقة");
        name("Al Wahda", "الوحدة");
        name("Al Shorta", "الشرطة");
        name("Al Zawraa", "الزوراء");
        name("Persepolis", "برسبوليس");
        name("Esteghlal", "استقلال طهران");
        name("Traktor Sazi FC", "تراكتور");
        name("Tractor", "تراكتور");
        name("Nasaf", "ناساف");
        name("Nasaf Qarshi", "ناساف");
        // Europe
        name("Real Madrid", "ريال مدريد");
        name("Barcelona", "برشلونة");
        name("Atlético Madrid", "أتلتيكو مدريد");
        name("Atletico Madrid", "أتلتيكو مدريد");
        name("Athletic Club", "أتلتيك بيلباو");
        name("Real Sociedad", "ريال سوسيداد");
        name("Sevilla", "إشبيلية");
        name("Villarreal", "فياريال");
        name("Real Betis", "ريال بيتيس");
        name("Valencia", "فالنسيا");
        name("Girona", "جيرونا");
        name("Manchester City", "مانشستر سيتي");
        name("Manchester United", "مانشستر يونايتد");
        name("Liverpool", "ليفربول");
        name("Arsenal", "آرسنال");
        name("Chelsea", "تشيلسي");
        name("Tottenham Hotspur", "توتنهام");
        name("Newcastle United", "نيوكاسل");
        name("Aston Villa", "أستون فيلا");
        name("West Ham United", "وست هام");
        name("Brighton & Hove Albion", "برايتون");
        name("Everton", "إيفرتون");
        name("Crystal Palace", "كريستال بالاس");
        name("Nottingham Forest", "نوتنغهام فورست");
        name("Fulham", "فولهام");
        name("Brentford", "برينتفورد");
        name("AFC Bournemouth", "بورنموث");
        name("Wolverhampton Wanderers", "وولفرهامبتون");
        name("Leeds United", "ليدز يونايتد");
        name("Sunderland", "سندرلاند");
        name("Bayern Munich", "بايرن ميونخ");
        name("Borussia Dortmund", "بوروسيا دورتموند");
        name("Bayer Leverkusen", "باير ليفركوزن");
        name("RB Leipzig", "لايبزيغ");
        name("Eintracht Frankfurt", "آينتراخت فرانكفورت");
        name("VfB Stuttgart", "شتوتغارت");
        name("Juventus", "يوفنتوس");
        name("Internazionale", "إنتر");
        name("Inter Milan", "إنتر");
        name("AC Milan", "ميلان");
        name("Napoli", "نابولي");
        name("AS Roma", "روما");
        name("Lazio", "لاتسيو");
        name("Atalanta", "أتالانتا");
        name("Fiorentina", "فيورنتينا");
        name("Paris Saint-Germain", "باريس سان جيرمان");
        name("Marseille", "مرسيليا");
        name("AS Monaco", "موناكو");
        name("Monaco", "موناكو");
        name("Lyon", "ليون");
        name("Lille", "ليل");
        name("Benfica", "بنفيكا");
        name("FC Porto", "بورتو");
        name("Sporting CP", "سبورتنغ لشبونة");
        name("Galatasaray", "غلطة سراي");
        name("Fenerbahce", "فنربخشة");
        name("Ajax Amsterdam", "أياكس");
        name("PSV Eindhoven", "آيندهوفن");
        name("Celtic", "سيلتك");
        name("Club Brugge", "كلوب بروج");
        name("Feyenoord Rotterdam", "فينورد");
        name("Feyenoord", "فينورد");
        name("AZ Alkmaar", "ألكمار");
        name("FC Twente", "تفينتي");
        name("SC Braga", "براغا");
        name("Besiktas", "بشكتاش");
        name("Trabzonspor", "طرابزون سبور");
        name("Inter Miami CF", "إنتر ميامي");
        name("LA Galaxy", "لوس أنجلوس غالاكسي");
        name("LAFC", "لوس أنجلوس إف سي");
        // National teams (the Asian Cup's list).
        name("Saudi Arabia", "المنتخب السعودي");
        name("Japan", "اليابان");
        name("South Korea", "كوريا الجنوبية");
        name("North Korea", "كوريا الشمالية");
        name("Iran", "إيران");
        name("Australia", "أستراليا");
        name("Qatar", "قطر");
        name("United Arab Emirates", "الإمارات");
        name("Iraq", "العراق");
        name("Jordan", "الأردن");
        name("Oman", "عُمان");
        name("Kuwait", "الكويت");
        name("Bahrain", "البحرين");
        name("Syria", "سوريا");
        name("Palestine", "فلسطين");
        name("Lebanon", "لبنان");
        name("Yemen", "اليمن");
        name("Uzbekistan", "أوزبكستان");
        name("China PR", "الصين");
        name("China", "الصين");
        name("Vietnam", "فيتنام");
        name("Thailand", "تايلاند");
        name("Indonesia", "إندونيسيا");
        name("Tajikistan", "طاجيكستان");
        name("Kyrgyzstan", "قيرغيزستان");
        name("Kyrgyz Republic", "قيرغيزستان");
        name("Singapore", "سنغافورة");
        name("India", "الهند");
    }

    private static String key(String english) {
        String lower = english.toLowerCase(Locale.ROOT).replace("é", "e").replace("ü", "u").replace("ç", "c");
        return lower.replaceAll("[^a-z0-9&]", "").replaceFirst("^(fc|sc)", "").replaceFirst("(fc|sc|club)$", "");
    }

    /** The club's Arabic name when known, otherwise ESPN's name as it is. */
    static String arabic(String english) {
        String found = NAMES.get(key(english));
        return found != null ? found : english;
    }
}
