package com.sumuw.launcher;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.ActivityOptions;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.app.WallpaperColors;
import android.app.WallpaperManager;
import android.appwidget.AppWidgetHost;
import android.appwidget.AppWidgetHostView;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.Context;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.app.SearchManager;
import android.app.KeyguardManager;
import android.hardware.biometrics.BiometricPrompt;
import android.os.CancellationSignal;
import android.view.ViewConfiguration;
import android.widget.AbsListView;
import android.speech.RecognizerIntent;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiManager;
import android.telephony.PhoneStateListener;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import android.os.PowerManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.LauncherActivityInfo;
import android.content.pm.LauncherApps;
import android.content.pm.ShortcutInfo;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Insets;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.app.Notification;
import android.service.notification.StatusBarNotification;
import android.os.Handler;
import android.os.Looper;
import android.os.UserHandle;
import android.os.UserManager;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Xml;
import android.view.DragEvent;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.Collator;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.xmlpull.v1.XmlPullParser;

public class HomeActivity extends Activity {
    static final String VERSION_NAME = "3.9";
    private static final int[] PRAYER_NAMES = {R.string.prayer_fajr, R.string.prayer_sunrise, R.string.prayer_dhuhr,
            R.string.prayer_asr, R.string.prayer_maghrib, R.string.prayer_isha};
    private static final long NEWS_INTERVAL_MS = 60000L;
    private static final int NEWS_PER_SOURCE = 5;
    /** The live list glides to the next headline this often, and waits a little longer after a touch. */
    private static final long NEWS_STEP_MS = 4500L;
    private static final long NEWS_RESUME_MS = 5000L;
    /** Survives recreate() (wallpaper/accent changes) so those don't trigger a refetch. */
    private static volatile long lastNewsAttempt = 0L;

    private static final int ACTION_FAVORITE = 0;
    private static final int ACTION_EARLIER = 1;
    private static final int ACTION_LATER = 2;
    private static final int ACTION_HIDE = 3;
    private static final int ACTION_INFO = 4;
    private static final int ACTION_UNINSTALL = 5;
    private static final int ACTION_UNDOCK = 6;
    private static final int ACTION_ARRANGE = 7;
    private static final int ACTION_FOLDER = 8;
    private static final int ACTION_UNFOLDER = 9;
    private static final int ACTION_NO_SUGGEST = 10;
    private static final int ACTION_ICON = 11;
    private static final int ACTION_SWIPE = 12;
    private static final int ACTION_BREAKER = 13;
    private static final int REQUEST_ICON_PICTURE = 7304;
    /** The kinds of home cards, in the order the editor lists them. */
    static final String[] CARD_TYPES = {"morning", "matches", "clock", "news", "weather", "prayers", "agenda", "battery", "table",
            "countdown", "khatma", "music", "messages"};
    /** The clock sits in the title row now, so the narrow card leads with the coming matches. */
    private static final String[] CARD_DEFAULTS = {"matches,prayers,clock,music", "news,weather,morning,messages"};
    private static final int PLACE_GRID = 0;
    private static final int PLACE_DOCK = 1;
    private static final int PLACE_SUGGESTED = 2;
    static final String SORT_MANUAL = "manual";
    static final String SORT_ALPHA = "alpha";
    static final String SORT_USAGE = "usage";
    static final String SORT_NEWEST = "newest";
    static final String[] SORT_MODES = {SORT_MANUAL, SORT_ALPHA, SORT_USAGE, SORT_NEWEST};
    private static final int REQUEST_BIND_WIDGET = 61;
    private static final int REQUEST_CONFIGURE_WIDGET = 62;
    private static final int WIDGET_HOST_ID = 1024;

    private AppAdapter adapter;
    private LinearLayout arrangeBar;
    private TextView clock;
    private LinearLayout dateCard;
    private LinearLayout cardsRow;
    private LinearLayout clockChip;
    private TextView titleClock;
    private TextView titleDay;
    private boolean matchesLoading;
    final ArrayList<CardStack> cardStacks = new ArrayList<>();
    private final ArrayList<View> cardGlass = new ArrayList<>();
    private final HashMap<String, Runnable> cardUpdaters = new HashMap<>();
    private int pendingStackSlot = -1;
    private String pendingIconKey;
    private StatusRing cardRing;
    private int batteryLevelNow = -1;
    private boolean batteryCharging;
    private boolean batterySaver;
    private TextView dateLine;
    private TextView hijriDate;
    private LinearLayout dock;
    private float downX;
    private float downY;
    private GridView grid;
    private LinearLayout newsCard;
    private Ticker newsList;
    private View newsLiveDot;
    private TextView newsUpdated;
    private LinearLayout pageDots;
    SharedPreferences prefs;
    private EditText search;
    static final String GOOGLE_PKG = "com.google.android.googlequicksearchbox";
    private LinearLayout searchBar;
    private ImageView searchBrand;
    private ImageView micButton;
    private LinearLayout webRow;
    /** Calculator, settings pages and contacts for what is typed, above the Google row. */
    LinearLayout smartBox;
    private String smartQuery = "";
    static final int REQUEST_CONTACTS = 7741;
    private ImageView webIcon;
    private TextView webText;
    LinearLayout root;
    private LauncherApps launcherApps;
    private UserManager userManager;

    int accent = Color.rgb(101, 103, 191);
    private String wallpaperId = Wallpapers.DEFAULT;
    boolean darkWallpaper = true;
    int textPrimary = Color.WHITE;
    int textSecondary = 0xB8FFFFFF;
    private final GlassDrawable.Source glass = new GlassDrawable.Source();
    private int configStamp;
    private boolean themedIcons;
    private boolean dotsEnabled;
    private PopupWindow appPopup;
    private StatusRing statusRing;
    private View batteryView;
    private boolean batteryRegistered;
    private String batteryText = "";
    boolean wifiOn;
    private int wifiBars;
    private int signalBars = -1;
    private TelephonyManager telephony;
    private PhoneStateListener signalListener;
    private SignalStrength lastSignal;
    private final BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent == null ? null : intent.getAction();
            if (Intent.ACTION_BATTERY_CHANGED.equals(action) || PowerManager.ACTION_POWER_SAVE_MODE_CHANGED.equals(action)) {
                updateBattery(intent);
            } else if (Intent.ACTION_AIRPLANE_MODE_CHANGED.equals(action)) {
                updateSignal(lastSignal);
                updateNetwork();
            } else {
                updateNetwork();
            }
            runCardUpdater("battery");
        }
    };
    FrameLayout frame;
    private ScrollView todayPanel;
    private LinearLayout todayContent;
    private boolean todayOpen;
    private final List<View> todayGlass = new ArrayList<>();
    private TextView prayerLine;
    private LinearLayout weatherChip;
    private ImageView weatherIcon;
    private TextView weatherTemp;
    private List<NewsSources.Source> sources = new ArrayList<>();
    private boolean prayerOn;
    private boolean weatherOn;
    private final List<View> glassViews = new ArrayList<>();

    /** Every launchable activity, including hidden ones. Only touched on the main thread. */
    final List<AppEntry> apps = new ArrayList<>();
    private final List<AppEntry> filteredApps = new ArrayList<>();
    private final List<Tile> tiles = new ArrayList<>();
    private final List<Tile> pageTiles = new ArrayList<>();
    private List<Folders.Folder> folders = new ArrayList<>();
    private PopupWindow folderPopup;
    private boolean twoPane;
    private AppWidgetManager widgetManager;
    private AppWidgetHost widgetHost;
    private final HashMap<Integer, AppWidgetHostView> widgetViews = new HashMap<>();
    private int pendingWidgetId = -1;
    private boolean appsLoaded = false;
    private int appLoadGeneration = 0;

    private String newsSignature = "";
    private final Set<String> seenNewsLinks = new HashSet<>();
    private final List<TextView> newsTimeViews = new ArrayList<>();
    private final List<NewsItem> newsTimeItems = new ArrayList<>();
    private boolean newsLooping = false;
    private boolean newsFailed = false;
    private final List<NewsItem> newsItems = Collections.synchronizedList(new ArrayList<NewsItem>());
    private int currentPage = 0;
    private int columns = 4;
    private int rows = 5;
    private int pageCapacity = 20;
    private int cellHeight = 0;
    private boolean reorderMode = false;
    /** Hides news, notification dots and suggestions, for when others can see the screen. */
    boolean privacyMode;
    /** Private folders and hidden apps stay open until the home screen is left. */
    boolean privateUnlocked;
    private boolean authInProgress;
    private Runnable pendingAuth;
    private static final int REQUEST_CONFIRM = 7301;
    private static final int REQUEST_CALENDAR = 7302;
    private ImageView eyeButton;
    /** Sara's own notification panel (pull down on the apps). */
    NotificationPanel notifications;
    /** Shown while Sara Home isn't the phone's Home app (the cause of the phone's launcher coming back). */
    private LinearLayout defaultBanner;
    private boolean defaultBannerDismissed;
    private boolean hideLabels;
    private IconPack iconPack;
    private String iconPackName;
    private int stackIndex;
    // double tap on an empty spot
    private float tapX;
    private float tapY;
    private long tapDownTime;
    private boolean tapMoved;
    private long lastTapUp;
    private float lastTapX;
    private float lastTapY;
    private Usage usage;
    private LinearLayout suggestBox;
    private int suggestHour = -1;
    private GestureFrame gridFrame;
    private boolean gridDense;
    private boolean scrollLayout;
    private AppEntry dockHeld;
    private float dockTouchY;
    /** An app held in the grid: sliding the finger then drags it, so it can be dropped on the dock. */
    private AppEntry gridHeld;
    private float gridTouchX;
    private float gridTouchY;

    /** What a drag from the grid to the dock carries. */
    static final class GridDrag {
        final AppEntry entry;

        GridDrag(AppEntry entry) {
            this.entry = entry;
        }
    }
    private final Handler clockHandler = new Handler(Looper.getMainLooper());
    private final Handler newsHandler = new Handler(Looper.getMainLooper());
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService newsExecutor = Executors.newFixedThreadPool(3);
    private final ExecutorService appExecutor = Executors.newSingleThreadExecutor();

    private final Runnable newsUpdater = new Runnable() {
        @Override
        public void run() {
            lastNewsAttempt = System.currentTimeMillis();
            refreshAllNews();
            newsHandler.postDelayed(this, NEWS_INTERVAL_MS);
        }
    };

    private final Runnable clockUpdater = new Runnable() {
        @Override
        public void run() {
            updateWidgets();
            renderNews();
            updateNetwork();
            refreshNow();
            if (Usage.hourOf(System.currentTimeMillis()) != suggestHour) {
                refreshSuggestions();
            }
            if (todayOpen || twoPane) {
                fillToday();
            }
            scheduleClockTick();
        }
    };

    private final Runnable appReloader = new Runnable() {
        @Override
        public void run() {
            loadAppsAsync();
        }
    };

    /** Same approach as AOSP Launcher3: react to installs/removals instead of rescanning on every resume. */
    private final LauncherApps.Callback packageCallback = new LauncherApps.Callback() {
        @Override
        public void onPackageRemoved(String packageName, UserHandle user) {
            scheduleAppReload();
        }

        @Override
        public void onPackageAdded(String packageName, UserHandle user) {
            scheduleAppReload();
        }

        @Override
        public void onPackageChanged(String packageName, UserHandle user) {
            scheduleAppReload();
        }

        @Override
        public void onPackagesAvailable(String[] packageNames, UserHandle user, boolean replacing) {
            scheduleAppReload();
        }

        @Override
        public void onPackagesUnavailable(String[] packageNames, UserHandle user, boolean replacing) {
            scheduleAppReload();
        }

        /** Paused by Digital Wellbeing, a focus mode or a "freezer" app: the icon greys at once. */
        @Override
        public void onPackagesSuspended(String[] packageNames, UserHandle user) {
            scheduleAppReload();
        }

        /** Unpaused: the icon comes back to life at once, not on the next restart. */
        @Override
        public void onPackagesUnsuspended(String[] packageNames, UserHandle user) {
            scheduleAppReload();
        }
    };

    /** The work profile turned on or off: its apps grey or come back. */
    private final BroadcastReceiver profileReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            scheduleAppReload();
        }
    };

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void onCreate(Bundle bundle) {
        Fonts.init(this);
        setTheme(Fonts.theme(false)); // Naskh for dialogs and the search field too
        super.onCreate(bundle);
        prefs = getSharedPreferences("duo_home", 0);
        accent = prefs.getInt("accent", accent);
        configStamp = prefs.getInt("config_stamp", 0);
        iconStyle = IconTint.style(prefs);
        themedIcons = !IconTint.NORMAL.equals(iconStyle);
        iconShape = prefs.getString(IconShapes.PREF, IconShapes.SYSTEM);
        // 3.7: music joins the first stack and good morning the second, once, for stacks set up before
        // (at the end, so the card each stack was left on stays where it was).
        if (!prefs.getBoolean("cards_37_added", false)) {
            SharedPreferences.Editor edit = prefs.edit().putBoolean("cards_37_added", true);
            String first = prefs.getString("cards_0", null);
            if (first != null && !first.contains("music")) {
                edit.putString("cards_0", first.isEmpty() ? "music" : first + ",music");
            }
            String second = prefs.getString("cards_1", null);
            if (second != null && !second.contains("morning")) {
                edit.putString("cards_1", second.isEmpty() ? "morning" : second + ",morning");
            }
            edit.apply();
        }
        // 3.9: the messages card (reply from the home screen) joins the second stack, once.
        if (!prefs.getBoolean("cards_39_added", false)) {
            SharedPreferences.Editor edit = prefs.edit().putBoolean("cards_39_added", true);
            String second = prefs.getString("cards_1", null);
            if (second != null && !second.contains("messages")) {
                edit.putString("cards_1", second.isEmpty() ? "messages" : second + ",messages");
            }
            edit.apply();
        }
        dotsEnabled = prefs.getBoolean("notification_dots", true);
        prayerOn = prefs.getBoolean("prayer_on", true);
        // Unfolded foldables and tablets get Today as a permanent side pane.
        twoPane = getResources().getConfiguration().screenWidthDp >= 600;
        drawerMode = prefs.getBoolean("app_drawer", true);
        folders = Folders.load(prefs);
        usage = new Usage(prefs);
        privacyMode = prefs.getBoolean("privacy_mode", false);
        hideLabels = prefs.getBoolean("hide_labels", false);
        gridDense = prefs.getBoolean("grid_dense", false);
        scrollLayout = "scroll".equals(prefs.getString("app_layout", "pages"));
        widgetManager = AppWidgetManager.getInstance(this);
        widgetHost = new AppWidgetHost(getApplicationContext(), WIDGET_HOST_ID);
        weatherOn = prefs.getBoolean("weather_on", true);
        sources = NewsSources.enabled(prefs);
        dropLegacyNewsCache();
        String saved = prefs.getString("wallpaper_style", Wallpapers.DEFAULT);
        wallpaperId = Wallpapers.isKnown(saved) ? saved : Wallpapers.DEFAULT;
        if (prefs.getBoolean("accent_auto", false)) {
            accent = Wallpapers.accentFor(this, wallpaperId);
        }
        launcherApps = getSystemService(LauncherApps.class);
        userManager = getSystemService(UserManager.class);
        if (TvHome.wanted(this, prefs)) {
            // A television: its own screen, made for the remote.
            tv = new TvHome(this);
            setContentView(tv.view);
            loadAppsAsync();
            try {
                launcherApps.registerCallback(packageCallback, uiHandler);
            } catch (Exception ignored) {
            }
            return;
        }
        buildUI();
        loadAppsAsync();
        try {
            ReminderReceiver.schedule(this);
        } catch (Exception ignored) {
        }
        try {
            launcherApps.registerCallback(packageCallback, uiHandler);
        } catch (Exception ignored) {
        }
        watchAudioRoutes();
        IntentFilter profiles = new IntentFilter();
        profiles.addAction(Intent.ACTION_MANAGED_PROFILE_AVAILABLE);
        profiles.addAction(Intent.ACTION_MANAGED_PROFILE_UNAVAILABLE);
        profiles.addAction(Intent.ACTION_MANAGED_PROFILE_UNLOCKED);
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(profileReceiver, profiles, Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(profileReceiver, profiles);
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if ((tv != null || grid != null) && prefs.getInt("config_stamp", 0) != configStamp) {
            recreate(); // settings changed the look (or turned the TV layout on or off); rebuild with the new choices
            return;
        }
        if (tv != null) {
            tv.resume();
            return;
        }
        if (grid == null) {
            return;
        }
        placeControlCenterHandle();
        DotsService.listener = new DotsService.Listener() {
            @Override
            public void onDotsChanged() {
                if (dotsEnabled && DotsService.version() != dotsVersionShown) {
                    scheduleDotsRefresh();
                }
                if (notifications != null) {
                    uiHandler.removeCallbacks(panelRefresher);
                    uiHandler.postDelayed(panelRefresher, 250L);
                }
                uiHandler.removeCallbacks(nowRefresher);
                uiHandler.postDelayed(nowRefresher, 300L);
            }
        };
        watchTorch(true);
        refreshNow();
        Breaker.stop(this); // back home: the usage reminder isn't needed
        if (dotsEnabled) {
            dotsVersionShown = DotsService.version();
            adapter.notifyDataSetChanged();
        }
        handlePendingAction();
        watchBattery();
        refreshSuggestions();
        updateDefaultBanner();
        // The picture chosen here becomes the phone's wallpaper too (lock screen, recent apps).
        SystemWallpaper.syncIfNeeded(this, ok -> {
            if (ok && !isFinishing()) {
                Toast.makeText(this, getString(R.string.system_wallpaper_done), Toast.LENGTH_SHORT).show();
            }
        });
        if (appsLoaded && SORT_USAGE.equals(sortMode()) && !isSearchOpen()) {
            applyFilter(currentQuery());
        }
        Agenda.forget(); // back from the calendar app, perhaps with a new event
        refreshWeather(false);
        followLocation(false);
        updateUsagePlace();
        Haram.check(this, prefs);
        if (Kids.on(prefs) && !kidsShowing() && appsLoaded) {
            showKids();
        }
        // The car was left while Home was in the background: take the place now, if it is still close in time.
        long pending = prefs.getLong("parking_pending", 0L);
        if (pending > 0 && System.currentTimeMillis() - pending < 15 * 60000L && !AudioRoutes.hasParking(prefs)) {
            rememberParking();
        }
        updateWidgets();
        renderNews();
        scheduleClockTick();
        scheduleTickerBeat();
        newsHandler.removeCallbacks(newsUpdater);
        long since = System.currentTimeMillis() - lastNewsAttempt;
        if (since < 0 || since >= NEWS_INTERVAL_MS) {
            newsUpdater.run();
        } else {
            newsHandler.postDelayed(newsUpdater, NEWS_INTERVAL_MS - since);
        }
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        applySystemBars();
    }

    @Override
    protected void onPause() {
        if (tv != null) {
            tv.pause();
            if (tvDialog != null) {
                tvDialog.dismiss();
            }
            super.onPause();
            return;
        }
        clockHandler.removeCallbacks(clockUpdater);
        newsHandler.removeCallbacks(newsUpdater);
        stopTickerBeat();
        if (batteryRegistered) {
            try {
                unregisterReceiver(batteryReceiver);
            } catch (Exception ignored) {
            }
            batteryRegistered = false;
        }
        stopSignal();
        watchTorch(false);
        if (notifications != null && notifications.isOpen()) {
            notifications.close(); // coming back to Home shows Home, not an old panel
        }
        if (controlCenter != null) {
            controlCenter.closeNow();
        }
        if (!authInProgress) {
            privateUnlocked = false; // private folders lock again once the home screen is left
        }
        DotsService.listener = null;
        dismissAppPopup();
        dismissFolderPopup();
        super.onPause();
    }

    @Override
    protected void onStart() {
        super.onStart();
        try {
            widgetHost.startListening();
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        try {
            widgetHost.stopListening();
        } catch (Exception ignored) {
        }
        // Coming back from an app should show the normal grid, not stale search results.
        if (isSearchOpen()) {
            closeSearch();
        }
        if (drawer != null && drawer.isOpen()) {
            closeDrawer(false); // coming back shows the home screen, as the phone's own launcher does
        }
    }

    @Override
    protected void onDestroy() {
        clockHandler.removeCallbacksAndMessages(null);
        newsHandler.removeCallbacksAndMessages(null);
        uiHandler.removeCallbacksAndMessages(null);
        try {
            launcherApps.unregisterCallback(packageCallback);
        } catch (Exception ignored) {
        }
        try {
            unregisterReceiver(profileReceiver);
        } catch (Exception ignored) {
        }
        newsExecutor.shutdownNow();
        appExecutor.shutdownNow();
        if (audioCallback != null) {
            try {
                getSystemService(android.media.AudioManager.class).unregisterAudioDeviceCallback(audioCallback);
            } catch (Exception ignored) {
            }
        }
        super.onDestroy();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (tv != null) {
            tv.home();
            return;
        }
        if (movingCards) {
            stopMovingCards();
        }
        // Home pressed while already on the home screen (Launcher3's check): go back to the first page.
        boolean alreadyOnHome = hasWindowFocus()
                && (intent.getFlags() & Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT) != Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT;
        if (isSearchOpen()) {
            closeSearch();
        }
        if (reorderMode) {
            setReorderMode(false);
        }
        if (todayOpen) {
            closeToday();
            return;
        }
        if (drawer != null && drawer.isOpen()) {
            closeDrawer(alreadyOnHome);
            return;
        }
        if (alreadyOnHome && currentPage != 0) {
            currentPage = 0;
            prefs.edit().putInt("page", 0).apply();
            showPage();
        }
    }

    @Override
    public void onBackPressed() {
        if (tv != null) {
            tv.back();
            return;
        }
        if (movingCards) {
            stopMovingCards();
            return;
        }
        if (kidsShowing()) {
            return; // children's mode is left with the lock only
        }
        if (driveShowing()) {
            hideDrivePanel();
            return;
        }
        if (controlCenter != null && controlCenter.isShowing()) {
            controlCenter.close();
            return;
        }
        if (notifications != null && notifications.isOpen()) {
            notifications.close();
            return;
        }
        if (todayOpen) {
            closeToday();
            return;
        }
        if (isSearchOpen()) {
            closeSearch();
            return;
        }
        if (reorderMode) {
            setReorderMode(false);
            return;
        }
        if (drawer != null && drawer.isOpen()) {
            closeDrawer(true);
            return;
        }
        // A home screen has nothing behind it, so Back is ignored here (as in Launcher3).
    }

    // ---------------------------------------------------------------- apps

    private void scheduleAppReload() {
        uiHandler.removeCallbacks(appReloader);
        uiHandler.postDelayed(appReloader, 250L);
    }

    /** Loads labels and icons off the main thread so returning to Home never stutters. */
    private void loadAppsAsync() {
        if (appExecutor.isShutdown()) {
            return;
        }
        final int generation = ++appLoadGeneration;
        appExecutor.execute(new Runnable() {
            @Override
            public void run() {
                final List<AppEntry> loaded = queryApps();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isDestroyed() || generation != appLoadGeneration) {
                            return;
                        }
                        apps.clear();
                        apps.addAll(loaded);
                        appsLoaded = true;
                        if (tv != null) {
                            applySavedOrder();
                            tv.appsChanged();
                            return;
                        }
                        audioRoutesChanged();
                        boostForContext();
                        applySavedOrder();
                        currentPage = prefs.getInt("page", 0);
                        applyFilter(currentQuery());
                        refreshDock();
                        updateSearchBrand();
                        handlePendingAction();
                    }
                });
            }
        });
    }

    private List<AppEntry> queryApps() {
        ArrayList<AppEntry> result = new ArrayList<>();
        UserHandle me = android.os.Process.myUserHandle();
        List<UserHandle> profiles;
        try {
            profiles = launcherApps.getProfiles();
        } catch (Exception e) {
            profiles = Collections.singletonList(me);
        }
        String ownPackage = getPackageName();
        String packName = prefs.getString("icon_pack", "");
        if (!packName.equals(iconPackName)) {
            iconPack = IconPack.load(this, packName);
            iconPackName = packName;
        }
        IconPack pack = iconPack;
        Set<String> custom = CustomIcons.keys(prefs);
        for (UserHandle user : profiles) {
            List<LauncherActivityInfo> infos;
            try {
                infos = launcherApps.getActivityList(null, user);
            } catch (Exception e) {
                continue;
            }
            boolean profileOff = false;
            try {
                profileOff = !user.equals(me) && userManager.isQuietModeEnabled(user); // work apps paused
            } catch (Exception ignored) {
            }
            // Work-profile apps get their own key so they don't collide with the personal copy.
            String suffix = user.equals(me) ? "" : "@" + userManager.getSerialNumberForUser(user);
            for (LauncherActivityInfo info : infos) {
                ComponentName component = info.getComponentName();
                if (component.getPackageName().equals(ownPackage)) {
                    continue;
                }
                CharSequence label = info.getLabel();
                Drawable icon;
                try {
                    icon = info.getBadgedIcon(0);
                } catch (Exception e) {
                    icon = getPackageManager().getDefaultActivityIcon();
                }
                ApplicationInfo appInfo = info.getApplicationInfo();
                boolean system = appInfo != null && (appInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                String text = TextUtils.isEmpty(label) ? component.getPackageName() : label.toString();
                boolean packed = false;
                if (pack != null) {
                    Drawable fromPack = pack.iconFor(component);
                    if (fromPack != null) {
                        icon = fromPack;
                        packed = true;
                    }
                }
                String key = component.flattenToShortString() + suffix;
                if (custom.contains(key)) {
                    Drawable mine = CustomIcons.load(this, key);
                    if (mine != null) {
                        icon = mine;
                        packed = true; // the user's own choice: themed icons leave it alone too
                    }
                }
                AppEntry entry = new AppEntry(text, component, user, key, icon, system);
                entry.packed = packed;
                entry.category = appInfo != null ? appInfo.category : -1;
                if (profileOff) {
                    entry.state = STATE_PROFILE_OFF;
                } else if (archived(appInfo)) {
                    entry.state = STATE_ARCHIVED;
                } else if (appInfo != null && (appInfo.flags & ApplicationInfo.FLAG_SUSPENDED) != 0) {
                    entry.state = STATE_PAUSED;
                }
                try {
                    entry.installed = info.getFirstInstallTime();
                } catch (Exception ignored) {
                }
                result.add(entry);
            }
        }
        if (tv != null) {
            addTvApps(result, me, ownPackage);
        }
        final Collator collator = labelCollator();
        Collections.sort(result, new Comparator<AppEntry>() {
            @Override
            public int compare(AppEntry a, AppEntry b) {
                return collator.compare(a.label, b.label);
            }
        });
        return result;
    }

    /**
     * On a TV: the apps made for TV (listed with the TV category, often without the phone one), each with its
     * banner. An app that has both opens its TV screen.
     */
    private void addTvApps(List<AppEntry> result, UserHandle me, String ownPackage) {
        android.content.pm.PackageManager pm = getPackageManager();
        List<android.content.pm.ResolveInfo> found;
        try {
            found = pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0);
        } catch (Exception e) {
            found = Collections.emptyList();
        }
        for (android.content.pm.ResolveInfo info : found) {
            android.content.pm.ActivityInfo activity = info.activityInfo;
            if (activity == null || ownPackage.equals(activity.packageName)) {
                continue;
            }
            ComponentName component = new ComponentName(activity.packageName, activity.name);
            for (int i = result.size() - 1; i >= 0; i--) {
                AppEntry phone = result.get(i);
                if (phone.pkg.equals(activity.packageName) && me.equals(phone.user)) {
                    result.remove(i);
                }
            }
            CharSequence label = null;
            Drawable icon = null;
            try {
                label = info.loadLabel(pm);
                icon = info.loadIcon(pm);
            } catch (Exception ignored) {
            }
            if (icon == null) {
                icon = pm.getDefaultActivityIcon();
            }
            ApplicationInfo appInfo = activity.applicationInfo;
            boolean system = appInfo != null && (appInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
            AppEntry entry = new AppEntry(TextUtils.isEmpty(label) ? activity.packageName : label.toString(), component, me,
                    component.flattenToShortString(), icon, system);
            entry.leanback = true;
            entry.category = appInfo != null ? appInfo.category : -1;
            try {
                entry.banner = activity.loadBanner(pm);
            } catch (Exception ignored) {
            }
            result.add(entry);
        }
        for (AppEntry entry : result) {
            if (entry.banner == null) {
                try {
                    entry.banner = pm.getActivityBanner(entry.component);
                    if (entry.banner == null) {
                        entry.banner = pm.getApplicationBanner(entry.pkg);
                    }
                } catch (Exception ignored) {
                }
            }
        }
    }

    private static Collator labelCollator() {
        Collator collator = Collator.getInstance();
        collator.setStrength(Collator.SECONDARY);
        return collator;
    }

    private String currentQuery() {
        return search == null ? "" : search.getText().toString();
    }

    private void applyFilter(String query) {
        updateWebRow(query);
        filteredApps.clear();
        String normalized = ArabicText.normalize(query);
        Set<String> hidden = hiddenKeys();
        boolean byCategory = normalized.length() == 0 && drawerCategory != null && drawer != null;
        if (byCategory) {
            filteredApps.addAll(appsInCategory(drawerCategory, hidden));
            currentPage = 0;
        } else if (normalized.length() == 0) {
            filteredApps.addAll(visibleInOrder(hidden));
            int pages = Math.max(1, (filteredApps.size() + pageCapacity - 1) / pageCapacity);
            currentPage = Math.max(0, Math.min(currentPage, pages - 1));
        } else {
            ArrayList<AppEntry> matches = new ArrayList<>();
            final HashMap<AppEntry, Integer> scores = new HashMap<>();
            Set<String> locked = privateUnlocked ? Collections.<String>emptySet() : lockedKeys();
            for (AppEntry entry : apps) {
                if (hidden.contains(entry.key) || locked.contains(entry.key)) {
                    continue; // hidden apps and private folders don't show up in search
                }
                int score = ArabicText.matchScore(entry.searchLabel, entry.pkg, normalized);
                if (score >= 0) {
                    matches.add(entry);
                    scores.put(entry, score);
                }
            }
            // Stable sort: equal scores keep the user's own app order.
            Collections.sort(matches, new Comparator<AppEntry>() {
                @Override
                public int compare(AppEntry a, AppEntry b) {
                    return scores.get(a) - scores.get(b);
                }
            });
            filteredApps.addAll(matches);
            currentPage = 0;
        }
        buildTiles(normalized.length() > 0 || byCategory);
        int tilePages = Math.max(1, (tiles.size() + pageCapacity - 1) / pageCapacity);
        currentPage = Math.max(0, Math.min(currentPage, tilePages - 1));
        showPage();
        if (drawer != null) {
            afterDrawerFilter(normalized);
        }
    }

    /** The apps that aren't hidden, in the order picked: the user's own, A to Z, most used or newest. */
    private List<AppEntry> visibleInOrder(Set<String> hidden) {
        ArrayList<AppEntry> list = new ArrayList<>();
        // Apps in the dock don't repeat in the grid, unless they were put in a folder. Search still finds them.
        Set<String> docked = prefs.getBoolean("hide_dock_apps", true) ? allDocked() : Collections.<String>emptySet();
        for (AppEntry entry : apps) {
            if (hidden.contains(entry.key)) {
                continue;
            }
            if (docked.contains(entry.key) && Folders.folderOf(folders, entry.key) == null) {
                continue;
            }
            list.add(entry);
        }
        String mode = sortMode();
        final Collator collator = labelCollator();
        if (SORT_ALPHA.equals(mode)) {
            Collections.sort(list, (a, b) -> collator.compare(a.label, b.label));
        } else if (SORT_USAGE.equals(mode)) {
            Collections.sort(list, (a, b) -> {
                int byUse = usage.total(b.key) - usage.total(a.key);
                return byUse != 0 ? byUse : collator.compare(a.label, b.label);
            });
        } else if (SORT_NEWEST.equals(mode)) {
            Collections.sort(list, (a, b) -> {
                int byDate = Long.compare(b.installed, a.installed);
                return byDate != 0 ? byDate : collator.compare(a.label, b.label);
            });
        }
        return list;
    }

    String sortMode() {
        return sortModeFrom(prefs);
    }

    /** Until a choice is made, keep what people had: their own order if they ever arranged icons, else A to Z. */
    static String sortModeFrom(SharedPreferences prefs) {
        String mode = prefs.getString("sort_mode", null);
        if (mode == null) {
            return prefs.getString("app_order", "").length() > 0 ? SORT_MANUAL : SORT_ALPHA;
        }
        return mode;
    }

    static int sortLabel(String mode) {
        switch (mode) {
            case SORT_ALPHA:
                return R.string.sort_alpha;
            case SORT_USAGE:
                return R.string.sort_usage;
            case SORT_NEWEST:
                return R.string.sort_newest;
            default:
                return R.string.sort_manual;
        }
    }

    void setSortMode(String mode) {
        prefs.edit().putString("sort_mode", mode).putInt("page", 0).apply();
        currentPage = 0;
        applyFilter(currentQuery());
        if (grid != null) {
            grid.setSelection(0);
        }
    }

    void setScrollLayout(boolean scroll) {
        scrollLayout = scroll;
        prefs.edit().putString("app_layout", scroll ? "scroll" : "pages").putInt("page", 0).apply();
        currentPage = 0;
        applyFilter(currentQuery());
        if (grid != null) {
            grid.setSelection(0);
        }
    }

    void setGridDense(boolean dense, boolean announce) {
        if (dense == gridDense) {
            return;
        }
        gridDense = dense;
        prefs.edit().putBoolean("grid_dense", dense).apply();
        if (grid != null) {
            fitGrid(grid.getWidth() - grid.getPaddingLeft() - grid.getPaddingRight(), grid.getHeight(), true);
        }
        if (announce) {
            Toast.makeText(this, getString(dense ? R.string.density_compact_on : R.string.density_roomy_on), Toast.LENGTH_SHORT).show();
        }
    }

    /** Moving icons needs the user's own order: start it from what is on screen now, so nothing jumps. */
    private void ensureManualOrder() {
        boolean chosen = prefs.contains("sort_mode");
        if (SORT_MANUAL.equals(sortMode())) {
            if (!chosen) {
                prefs.edit().putString("sort_mode", SORT_MANUAL).apply();
            }
            return;
        }
        List<AppEntry> shown = visibleInOrder(hiddenKeys());
        HashSet<AppEntry> placed = new HashSet<>(shown);
        ArrayList<AppEntry> ordered = new ArrayList<>(shown);
        for (AppEntry entry : apps) {
            if (!placed.contains(entry)) {
                ordered.add(entry);
            }
        }
        apps.clear();
        apps.addAll(ordered);
        saveAppOrder();
        prefs.edit().putString("sort_mode", SORT_MANUAL).apply();
        applyFilter(currentQuery());
        if (chosen) {
            Toast.makeText(this, getString(R.string.sort_now_manual), Toast.LENGTH_LONG).show();
        }
    }

    private void showPage() {
        pageTiles.clear();
        if (scrollLayout) {
            pageTiles.addAll(tiles); // one long list that scrolls up and down
        } else {
            int start = currentPage * pageCapacity;
            for (int i = start; i < Math.min(tiles.size(), start + pageCapacity); i++) {
                pageTiles.add(tiles.get(i));
            }
        }
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
        updatePageIndicator();
    }

    private AppEntry findByKey(String token) {
        if (token == null || token.length() == 0) {
            return null;
        }
        // Versions up to 1.5 stored bare package names; match those to the personal-profile app.
        boolean legacy = token.indexOf('/') < 0;
        for (AppEntry entry : apps) {
            if (legacy ? entry.pkg.equals(token) && entry.key.indexOf('@') < 0 : entry.key.equals(token)) {
                return entry;
            }
        }
        return null;
    }

    private AppEntry findPreferred(String pkg, String altPkg, String hint) {
        for (AppEntry entry : apps) {
            if (entry.pkg.equals(pkg) || (altPkg.length() > 0 && entry.pkg.equals(altPkg))) {
                return entry;
            }
        }
        for (AppEntry entry : apps) {
            if (entry.pkg.toLowerCase(Locale.ROOT).contains(hint) || entry.label.toLowerCase(Locale.ROOT).contains(hint)) {
                return entry;
            }
        }
        return null;
    }

    private Rect launchBounds(View source) {
        if (source == null || !source.isAttachedToWindow() || source.getWidth() == 0) {
            return null;
        }
        int[] location = new int[2];
        source.getLocationOnScreen(location);
        return new Rect(location[0], location[1], location[0] + source.getWidth(), location[1] + source.getHeight());
    }

    /** The app window grows out of the tapped icon, like the stock launcher. */
    private Bundle launchOptions(View source) {
        if (source == null || !source.isAttachedToWindow() || source.getWidth() == 0) {
            return null;
        }
        return ActivityOptions.makeClipRevealAnimation(source, 0, 0, source.getWidth(), source.getHeight()).toBundle();
    }

    /**
     * Opens an app the way the phone's own launcher does (AOSP Launcher3, One UI Home): for the phone's
     * own profile an explicit launcher intent through startActivity, and LauncherApps only for work and
     * dual-app profiles. Some apps, Google Drive among them, did nothing when opened only through
     * LauncherApps. If the app changed its launcher entry since the list was read, its current entry is
     * looked up; if nothing works, the reason is shown instead of a silent tap.
     */
    void launch(AppEntry entry, View source) {
        if (entry.state == STATE_READY && Breaker.watched(prefs, entry.pkg)) {
            if (breakerLetThrough != entry) {
                showBreaker(entry, source);
                return;
            }
            breakerLetThrough = null;
            Breaker.countOpening(prefs, entry.pkg, System.currentTimeMillis());
            Breaker.started(this, entry.label);
        }
        Rect bounds = launchBounds(source);
        Bundle options = launchOptions(source);
        boolean mine = android.os.Process.myUserHandle().equals(entry.user);
        Exception failure = null;
        if (entry.state == STATE_PROFILE_OFF && Build.VERSION.SDK_INT >= 28) {
            // Work apps are paused: ask Android to turn them on (it may ask for the work PIN), then open.
            try {
                userManager.requestQuietModeEnabled(false, entry.user);
                Toast.makeText(this, getString(R.string.app_state_profile_waking), Toast.LENGTH_SHORT).show();
                return;
            } catch (Exception error) {
                failure = error;
            }
        }
        if (entry.state == STATE_ARCHIVED) {
            // Archived: LauncherApps asks Android to download it again (the way the phone's launcher does).
            try {
                launcherApps.startMainActivity(entry.component, entry.user, bounds, options);
                Toast.makeText(this, getString(R.string.app_state_restoring, entry.label), Toast.LENGTH_SHORT).show();
                return;
            } catch (Exception error) {
                failure = error;
            }
        }
        if (mine) {
            try {
                Intent intent = new Intent(Intent.ACTION_MAIN)
                        .addCategory(entry.leanback ? Intent.CATEGORY_LEANBACK_LAUNCHER : Intent.CATEGORY_LAUNCHER)
                        .setComponent(entry.component)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                intent.setSourceBounds(bounds);
                startActivity(intent, options);
                recordLaunch(entry);
                return;
            } catch (Exception error) {
                failure = error;
            }
        }
        try {
            launcherApps.startMainActivity(entry.component, entry.user, bounds, options);
            recordLaunch(entry);
            return;
        } catch (Exception error) {
            failure = error;
        }
        try {
            List<LauncherActivityInfo> current = launcherApps.getActivityList(entry.pkg, entry.user);
            if (current != null && !current.isEmpty()) {
                launcherApps.startMainActivity(current.get(0).getComponentName(), entry.user, bounds, null);
                recordLaunch(entry);
                scheduleAppReload(); // the list still had the old entry
                return;
            }
        } catch (Exception error) {
            failure = error;
        }
        if (mine) {
            try {
                Intent fallback = getPackageManager().getLaunchIntentForPackage(entry.pkg);
                if (fallback != null) {
                    fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(fallback);
                    recordLaunch(entry);
                    return;
                }
            } catch (Exception error) {
                failure = error;
            }
        }
        String reason = failure == null ? "" : failure.getClass().getSimpleName();
        Toast.makeText(this, getString(R.string.cannot_open_app, entry.label, reason), Toast.LENGTH_LONG).show();
    }

    String stateName(int state) {
        return getString(state == STATE_PAUSED ? R.string.app_state_paused
                : state == STATE_ARCHIVED ? R.string.app_state_archived : R.string.app_state_profile_off);
    }

    private void recordLaunch(AppEntry entry) {
        if (usage != null) {
            final String key = entry.key;
            final long now = System.currentTimeMillis();
            if (!appExecutor.isShutdown()) {
                appExecutor.execute(() -> {
                    if (usage != null) {
                        synchronized (usage) {
                            usage.record(key, now);
                        }
                    }
                });
            }
        }
    }

    /**
     * Opens the app straight away; the small press bounce is only for the eye. (It used to open the app
     * when the bounce ended, and a bounce cut short by the grid refreshing meant the tap did nothing.)
     */
    private void animateLaunch(final AppEntry entry, final View source) {
        source.animate().cancel();
        source.setScaleX(0.92f);
        source.setScaleY(0.92f);
        source.animate().scaleX(1.0f).scaleY(1.0f).setDuration(220L).setInterpolator(new DecelerateInterpolator()).start();
        launch(entry, source);
    }

    private void openAppInfo(AppEntry entry) {
        try {
            launcherApps.startAppDetailsActivity(entry.component, entry.user, null, null);
        } catch (Exception e) {
            try {
                startActivity(new Intent("android.settings.APPLICATION_DETAILS_SETTINGS", Uri.parse("package:" + entry.pkg)));
            } catch (Exception ignored) {
            }
        }
    }

    private void uninstall(AppEntry entry) {
        try {
            Intent intent = new Intent(Intent.ACTION_DELETE, Uri.fromParts("package", entry.pkg, null));
            intent.putExtra(Intent.EXTRA_USER, entry.user);
            startActivity(intent);
        } catch (Exception e) {
            openAppInfo(entry);
        }
    }

    // ---------------------------------------------------------------- favorites, order, hidden

    /** Where the dock page on show keeps its apps: the first page in "favorites", the others after it. */
    String favoritesKey() {
        return dockPage == 0 ? "favorites" : "favorites_" + dockPage;
    }

    /** The apps on every dock page, so none of them repeats in the grid. */
    private Set<String> allDocked() {
        HashSet<String> all = new HashSet<>(getFavorites());
        int pages = dockPages();
        for (int page = 0; page < pages; page++) {
            if (page == dockPage) {
                continue;
            }
            String saved = prefs.getString(page == 0 ? "favorites" : "favorites_" + page, "");
            for (String token : saved.split("\\|")) {
                AppEntry entry = findByKey(token);
                if (entry != null) {
                    all.add(entry.key);
                }
            }
        }
        return all;
    }

    int dockPages() {
        return Math.max(1, Math.min(3, prefs.getInt("dock_pages", 1)));
    }

    int dockColumns() {
        return prefs.getInt("dock_columns", 1) == 2 ? 2 : 1;
    }

    /** The dock page on show (pages hold different sets of apps, for work and home, say). */
    int dockPage;

    void setDockPage(int page) {
        int next = Math.max(0, Math.min(dockPages() - 1, page));
        if (next == dockPage) {
            return;
        }
        dockPage = next;
        prefs.edit().putInt("dock_page", next).apply();
        refreshDock();
    }

    private List<String> getFavorites() {
        String saved = prefs.getString(favoritesKey(), null);
        if (saved == null && dockPage > 0) {
            saved = ""; // a new page starts empty
        }
        ArrayList<String> list = new ArrayList<>();
        if (saved != null) {
            for (String token : saved.split("\\|")) {
                AppEntry entry = findByKey(token);
                if (entry != null && !list.contains(entry.key)) {
                    list.add(entry.key);
                }
            }
            return list;
        }
        addDefault(list, findPreferred("com.samsung.android.dialer", "com.google.android.dialer", "dialer"));
        addDefault(list, findPreferred("com.samsung.android.messaging", "com.google.android.apps.messaging", "messaging"));
        addDefault(list, findPreferred("com.sec.android.app.camera", "", "camera"));
        addDefault(list, findPreferred("com.sec.android.gallery3d", "com.google.android.apps.photos", "gallery"));
        for (AppEntry entry : apps) {
            if (list.size() >= 4) {
                break;
            }
            addDefault(list, entry);
        }
        return list;
    }

    private void addDefault(List<String> list, AppEntry entry) {
        if (entry == null || list.contains(entry.key) || list.size() >= 4) {
            return;
        }
        list.add(entry.key);
    }

    private void saveFavorites(List<String> keys) {
        if (!appsLoaded) {
            return; // never overwrite saved favorites before the app list exists
        }
        prefs.edit().putString(favoritesKey(), TextUtils.join("|", keys)).apply();
        refreshDock();
        applyFilter(currentQuery()); // an app added to the dock leaves the grid, one taken out comes back
    }

    private void applySavedOrder() {
        String saved = prefs.getString("app_order", null);
        if (saved == null || saved.length() == 0) {
            return;
        }
        final HashMap<String, Integer> rank = new HashMap<>();
        final HashMap<String, Integer> legacyRank = new HashMap<>();
        String[] tokens = saved.split("\\|");
        for (int i = 0; i < tokens.length; i++) {
            String token = tokens[i];
            if (token.length() == 0) {
                continue;
            }
            Map<String, Integer> target = token.indexOf('/') >= 0 ? rank : legacyRank;
            if (!target.containsKey(token)) {
                target.put(token, i);
            }
        }
        final Collator collator = labelCollator();
        Collections.sort(apps, new Comparator<AppEntry>() {
            @Override
            public int compare(AppEntry a, AppEntry b) {
                int ia = orderIndex(a, rank, legacyRank);
                int ib = orderIndex(b, rank, legacyRank);
                if (ia < 0 && ib < 0) {
                    return collator.compare(a.label, b.label);
                }
                if (ia < 0) {
                    return 1;
                }
                if (ib < 0) {
                    return -1;
                }
                return ia != ib ? ia - ib : collator.compare(a.label, b.label);
            }
        });
    }

    private static int orderIndex(AppEntry entry, Map<String, Integer> rank, Map<String, Integer> legacyRank) {
        Integer index = rank.get(entry.key);
        if (index == null && entry.key.indexOf('@') < 0) {
            index = legacyRank.get(entry.pkg);
        }
        return index == null ? -1 : index;
    }

    private void saveAppOrder() {
        ArrayList<String> keys = new ArrayList<>();
        for (AppEntry entry : apps) {
            keys.add(entry.key);
        }
        prefs.edit().putString("app_order", TextUtils.join("|", keys)).apply();
    }

    private void moveApp(AppEntry entry, int direction) {
        ensureManualOrder();
        // Move relative to the visible list so hidden apps don't swallow the move.
        int visibleIndex = filteredApps.indexOf(entry);
        int target = visibleIndex + direction;
        if (visibleIndex < 0 || target < 0 || target >= filteredApps.size()) {
            return;
        }
        AppEntry other = filteredApps.get(target);
        Collections.swap(apps, apps.indexOf(entry), apps.indexOf(other));
        saveAppOrder();
        applyFilter(currentQuery());
        Toast.makeText(this, getString(R.string.app_order_saved), Toast.LENGTH_SHORT).show();
    }

    private void moveAppBefore(AppEntry moving, AppEntry anchor) {
        if (moving == null || anchor == null || moving == anchor) {
            return;
        }
        ensureManualOrder();
        int from = apps.indexOf(moving);
        int to = apps.indexOf(anchor);
        if (from < 0 || to < 0) {
            return;
        }
        apps.remove(from);
        if (from < to) {
            to--;
        }
        apps.add(to, moving);
        saveAppOrder();
        applyFilter(currentQuery());
        Toast.makeText(this, getString(R.string.app_order_saved), Toast.LENGTH_SHORT).show();
    }

    private Set<String> hiddenKeys() {
        HashSet<String> keys = new HashSet<>();
        String saved = prefs.getString("hidden", "");
        for (String token : saved.split("\\|")) {
            if (token.length() > 0) {
                keys.add(token);
            }
        }
        return keys;
    }

    private void saveHidden(Set<String> keys) {
        prefs.edit().putString("hidden", TextUtils.join("|", keys)).apply();
    }

    private void hideApp(AppEntry entry) {
        Set<String> keys = hiddenKeys();
        keys.add(entry.key);
        saveHidden(keys);
        applyFilter(currentQuery());
        Toast.makeText(this, getString(R.string.app_hidden), Toast.LENGTH_LONG).show();
    }

    private void showHiddenApps() {
        Set<String> hidden = hiddenKeys();
        final ArrayList<AppEntry> list = new ArrayList<>();
        for (AppEntry entry : apps) {
            if (hidden.contains(entry.key)) {
                list.add(entry);
            }
        }
        if (list.isEmpty()) {
            Toast.makeText(this, getString(R.string.no_hidden_apps), Toast.LENGTH_SHORT).show();
            return;
        }
        String[] labels = new String[list.size()];
        final boolean[] checked = new boolean[list.size()];
        for (int i = 0; i < list.size(); i++) {
            labels[i] = list.get(i).label;
            checked[i] = true;
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.hidden_apps_title))
                .setMultiChoiceItems(labels, checked, (dialog, which, isChecked) -> checked[which] = isChecked)
                .setPositiveButton(getString(R.string.done), (dialog, which) -> {
                    Set<String> keys = hiddenKeys();
                    for (int i = 0; i < list.size(); i++) {
                        if (!checked[i]) {
                            keys.remove(list.get(i).key);
                        }
                    }
                    saveHidden(keys);
                    applyFilter(currentQuery());
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    // ---------------------------------------------------------------- search

    void updateDefaultBanner() {
        if (defaultBanner == null) {
            return;
        }
        boolean show = !defaultBannerDismissed && !DefaultHome.isDefault(this);
        int visibility = show ? View.VISIBLE : View.GONE;
        if (defaultBanner.getVisibility() != visibility) {
            defaultBanner.setVisibility(visibility);
        }
    }

    // ---------------------------------------------------------------- shared with the notification panel

    boolean isPrivacyMode() {
        return privacyMode;
    }

    boolean isPrivateUnlocked() {
        return privateUnlocked;
    }

    void glassTracked(View view, float radiusDp, boolean strong, List<View> track) {
        glassify(view, radiusDp, strong);
        track.add(view);
    }

    void forgetGlass(List<View> track) {
        glassViews.removeAll(track);
        track.clear();
    }

    /** Fades the home screen out under a full panel (Today, notifications) and back in. */
    void fadeHome(boolean away) {
        for (int i = 0; i < root.getChildCount(); i++) {
            View child = root.getChildAt(i);
            // On a layer the glass and the icons are drawn once, not again for every frame of the fade.
            child.animate().alpha(away ? 0f : 1f).setDuration(away ? 180L : 200L).withLayer().start();
        }
    }

    /** While a panel follows the finger: Home fades with it, each part on its own layer. */
    void homeAlpha(float alpha) {
        for (int i = 0; i < root.getChildCount(); i++) {
            View child = root.getChildAt(i);
            child.animate().cancel();
            child.setAlpha(alpha);
        }
    }

    void homeLayers(boolean on) {
        for (int i = 0; i < root.getChildCount(); i++) {
            View child = root.getChildAt(i);
            if (on) {
                child.setLayerType(View.LAYER_TYPE_HARDWARE, null);
            } else {
                child.setLayerType(View.LAYER_TYPE_NONE, null);
            }
        }
    }

    void startSafely(Intent intent) {
        try {
            startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception ignored) {
        }
    }

    // ---------------------------------------------------------------- privacy and private folders

    private boolean dotsShown() {
        return dotsEnabled && !privacyMode;
    }

    private void updateEyeButton() {
        if (eyeButton == null) {
            return;
        }
        eyeButton.setImageDrawable(new Glyphs(privacyMode ? Glyphs.EYE_OFF : Glyphs.EYE, textPrimary, dp(20.0f)));
        eyeButton.setContentDescription(getString(privacyMode ? R.string.privacy_off : R.string.privacy_on));
    }

    void setPrivacyMode(boolean on) {
        privacyMode = on;
        if (notifications != null) {
            notifications.markStale(); // what the messages say shows or hides: build the panel again
            if (notifications.isOpen()) {
                notifications.refresh();
            }
        }
        prefs.edit().putBoolean("privacy_mode", on).apply();
        updateEyeButton();
        newsSignature = null;
        renderNews();
        refreshDock();
        if (!replying) {
            runCardUpdater("messages"); // the messages card hides (or shows) what they say at once
        }
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
        if (todayOpen) {
            fillToday();
        }
        Toast.makeText(this, getString(on ? R.string.privacy_now_on : R.string.privacy_now_off), Toast.LENGTH_SHORT).show();
    }

    /** Apps inside private folders. */
    Set<String> lockedKeys() {
        HashSet<String> keys = new HashSet<>();
        for (Folders.Folder folder : folders) {
            if (folder.locked) {
                keys.addAll(folder.keys);
            }
        }
        return keys;
    }

    private Drawable lockedFolderIcon() {
        Folders.Icon base = new Folders.Icon(new ArrayList<Drawable>(), darkWallpaper ? 0x47FFFFFF : 0xA6FFFFFF, darkWallpaper ? 0x66FFFFFF : 0xE6FFFFFF);
        Glyphs lock = new Glyphs(Glyphs.LOCK, textPrimary, dp(24.0f));
        android.graphics.drawable.LayerDrawable layers = new android.graphics.drawable.LayerDrawable(new Drawable[]{base, lock});
        int inset = dp(gridDense ? 11.0f : 15.0f);
        layers.setLayerInset(1, inset, inset, inset, inset);
        return layers;
    }

    void setFolderLocked(final Folders.Folder folder, boolean lock) {
        if (lock) {
            KeyguardManager keyguard = getSystemService(KeyguardManager.class);
            if (keyguard == null || !keyguard.isDeviceSecure()) {
                Toast.makeText(this, getString(R.string.auth_no_screen_lock), Toast.LENGTH_LONG).show();
                return;
            }
            folder.locked = true;
            saveFolders();
            Toast.makeText(this, getString(R.string.folder_locked_done, folder.name), Toast.LENGTH_SHORT).show();
        } else {
            authenticate(getString(R.string.auth_folder, folder.name), () -> {
                folder.locked = false;
                saveFolders();
            });
        }
    }

    /**
     * Asks for fingerprint, face or the phone's PIN, then runs the action. It stays open until the home
     * screen is left. Phones with no screen lock have nothing to check against, so the action just runs.
     */
    void authenticate(String title, final Runnable onSuccess) {
        if (privateUnlocked) {
            onSuccess.run();
            return;
        }
        KeyguardManager keyguard = getSystemService(KeyguardManager.class);
        if (keyguard == null || !keyguard.isDeviceSecure()) {
            onSuccess.run();
            return;
        }
        authInProgress = true;
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                BiometricPrompt.Builder builder = new BiometricPrompt.Builder(this).setTitle(title);
                if (Build.VERSION.SDK_INT >= 30) {
                    builder.setAllowedAuthenticators(android.hardware.biometrics.BiometricManager.Authenticators.BIOMETRIC_WEAK
                            | android.hardware.biometrics.BiometricManager.Authenticators.DEVICE_CREDENTIAL);
                } else {
                    builder.setDeviceCredentialAllowed(true);
                }
                builder.build().authenticate(new CancellationSignal(), getMainExecutor(), new BiometricPrompt.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                        authInProgress = false;
                        privateUnlocked = true;
                        onSuccess.run();
                    }

                    @Override
                    public void onAuthenticationError(int code, CharSequence message) {
                        authInProgress = false;
                    }
                });
                return;
            } catch (Exception ignored) {
                // fall back to the PIN screen below
            }
        }
        Intent confirm = keyguard.createConfirmDeviceCredentialIntent(title, null);
        if (confirm == null) {
            authInProgress = false;
            onSuccess.run();
            return;
        }
        pendingAuth = onSuccess;
        startActivityForResult(confirm, REQUEST_CONFIRM);
    }

    // ---------------------------------------------------------------- lock screen helpers

    /** Swipe down: the notification shade, through the accessibility service or the status bar. */
    boolean expandNotifications() {
        if (LockService.showNotifications()) {
            return true;
        }
        try {
            Object statusBar = getSystemService("statusbar");
            Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(statusBar);
            return true;
        } catch (Throwable error) {
            return false;
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        if (tv != null) {
            return super.dispatchTouchEvent(event);
        }
        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            fingerDown = true;
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            fingerDown = false;
            if (dotsPending) {
                dotsPending = false;
                scheduleDotsRefresh();
            }
        }
        if (movingCards && moveCardsGesture(event)) {
            return true;
        }
        if (controlCenterGesture(event)) {
            return true;
        }
        trackDoubleTap(event);
        return super.dispatchTouchEvent(event);
    }

    // ---------------------------------------------------------------- control centre gesture

    ControlCenter controlCenter;
    private boolean ccCandidate;
    private boolean ccDragging;
    private float ccDownX;
    private float ccDownY;
    private android.view.VelocityTracker ccVelocity;

    /** Height of Android's bottom gesture strip (going home); swipes starting in it go to the system. */
    private int gestureBottom;
    private View ccHandle;

    /**
     * Where a swipe has to start to pull the control centre up: the bottom of the home screen, from a
     * little above the search bar down. It used to be a 64dp strip, much of it under Android's own
     * gesture strip (where a swipe goes home instead), so only a swipe started at just the right height
     * opened it. Now the strip starts above the search bar and is never less than 110dp above the system's.
     */
    float controlCenterEdge() {
        int[] at = new int[2];
        frame.getLocationOnScreen(at);
        int screenBottom = at[1] + frame.getHeight();
        int systemTop = screenBottom - Math.max(root == null ? 0 : root.getPaddingBottom(), gestureBottom);
        float edge = systemTop - dp(110.0f);
        if (searchBar != null && searchBar.isShown() && searchBar.getHeight() > 0) {
            int[] bar = new int[2];
            searchBar.getLocationOnScreen(bar);
            if (bar[1] > screenBottom * 0.6f) { // the search bar at the bottom (not moved to the top)
                edge = Math.min(edge, bar[1] - dp(22.0f));
            }
        }
        return edge;
    }

    /**
     * A small bar at the bottom middle, just above Android's own gesture strip: it shows where the control
     * centre comes from, and a tap on it opens it too.
     */
    private void placeControlCenterHandle() {
        if (frame == null || root == null) {
            return;
        }
        boolean wanted = prefs.getBoolean("control_center", true) && prefs.getBoolean("cc_handle", true) && !twoPane;
        if (!wanted) {
            if (ccHandle != null) {
                ccHandle.setVisibility(View.GONE);
            }
            return;
        }
        if (ccHandle == null) {
            FrameLayout target = new FrameLayout(this);
            View bar = new View(this);
            bar.setBackground(pill(withAlpha(textPrimary, 0.40f), 2));
            target.addView(bar, new FrameLayout.LayoutParams(dp(36.0f), dp(4.0f), Gravity.CENTER));
            target.setContentDescription(getString(R.string.control_center));
            target.setOnClickListener(v -> {
                if (controlCenterAllowed()) {
                    controlCenter.open();
                }
            });
            ccHandle = target;
            frame.addView(target, new FrameLayout.LayoutParams(dp(72.0f), dp(16.0f), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL));
        }
        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) ccHandle.getLayoutParams();
        int margin = Math.max(root.getPaddingBottom(), gestureBottom);
        if (params.bottomMargin != margin) {
            params.bottomMargin = margin;
            ccHandle.setLayoutParams(params);
        }
        ccHandle.setVisibility(View.VISIBLE);
    }

    private boolean controlCenterAllowed() {
        return controlCenter != null && prefs.getBoolean("control_center", true) && !controlCenter.isShowing()
                && !(drawer != null && drawer.isOpen())
                && !(notifications != null && notifications.isOpen()) && !todayOpen && !isSearchOpen() && !reorderMode
                && folderPopup == null && appPopup == null && !kidsShowing() && !driveShowing();
    }

    /**
     * Watches for a swipe up that starts at the bottom edge. Until it is clearly one, every touch goes on
     * as usual (taps on the bottom row of icons still work); once it is, the views under the finger get a
     * cancel and the sheet follows the finger.
     */
    private boolean controlCenterGesture(MotionEvent event) {
        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            ccDragging = false;
            ccCandidate = controlCenterAllowed() && event.getRawY() >= controlCenterEdge();
            if (ccVelocity != null) {
                ccVelocity.recycle();
                ccVelocity = null;
            }
            if (ccCandidate) {
                ccDownX = event.getRawX();
                ccDownY = event.getRawY();
                ccVelocity = android.view.VelocityTracker.obtain();
                ccVelocity.addMovement(event);
            }
            return false;
        }
        if (!ccCandidate) {
            return false;
        }
        if (ccVelocity != null) {
            ccVelocity.addMovement(event);
        }
        if (action == MotionEvent.ACTION_MOVE) {
            float up = ccDownY - event.getRawY();
            float side = Math.abs(event.getRawX() - ccDownX);
            int slop = ViewConfiguration.get(this).getScaledTouchSlop();
            if (!ccDragging) {
                // Forgiving: a little upward movement, even a slanted one, starts the pull.
                if (up > slop && up > side * 1.1f) {
                    ccDragging = true;
                    MotionEvent cancel = MotionEvent.obtain(event);
                    cancel.setAction(MotionEvent.ACTION_CANCEL);
                    super.dispatchTouchEvent(cancel);
                    cancel.recycle();
                    controlCenter.beginDrag();
                } else if (side > slop * 3 || up < -slop) {
                    ccCandidate = false; // sideways or down: a page swipe or something else
                    return false;
                } else {
                    return false;
                }
            }
            controlCenter.dragTo(up);
            return true;
        }
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            boolean was = ccDragging;
            ccDragging = false;
            ccCandidate = false;
            if (was) {
                float velocity = 0f;
                if (ccVelocity != null && action == MotionEvent.ACTION_UP) {
                    ccVelocity.computeCurrentVelocity(1000);
                    velocity = ccVelocity.getYVelocity();
                }
                controlCenter.endDrag(velocity);
            }
            if (ccVelocity != null) {
                ccVelocity.recycle();
                ccVelocity = null;
            }
            return was;
        }
        return ccDragging;
    }

    // ---------------------------------------------------------------- notification dots

    private boolean fingerDown;
    private boolean dotsPending;
    private int dotsVersionShown = -1;

    private final Runnable dotsRefresher = new Runnable() {
        @Override
        public void run() {
            if (fingerDown) {
                dotsPending = true; // never swap the icons under a finger: the tap would be lost
                return;
            }
            dotsVersionShown = DotsService.version();
            if (adapter != null) {
                adapter.notifyDataSetChanged();
            }
            refreshDock();
        }
    };

    private final Runnable panelRefresher = new Runnable() {
        @Override
        public void run() {
            if (notifications != null) {
                notifications.refresh();
            }
        }
    };

    /** Dots change in bursts (a chat sends several at once): wait for the burst, and for the finger to lift. */
    private void scheduleDotsRefresh() {
        uiHandler.removeCallbacks(dotsRefresher);
        if (fingerDown) {
            dotsPending = true;
            return;
        }
        uiHandler.postDelayed(dotsRefresher, 300L);
    }

    /** Watches every touch, without taking any, for two quick taps on a spot with nothing to tap. */
    private void trackDoubleTap(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                tapX = event.getRawX();
                tapY = event.getRawY();
                tapDownTime = event.getEventTime();
                tapMoved = false;
                break;
            case MotionEvent.ACTION_MOVE:
                if (Math.hypot(event.getRawX() - tapX, event.getRawY() - tapY) > ViewConfiguration.get(this).getScaledTouchSlop()) {
                    tapMoved = true;
                }
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
            case MotionEvent.ACTION_CANCEL:
                tapMoved = true;
                break;
            case MotionEvent.ACTION_UP: {
                boolean quick = event.getEventTime() - tapDownTime < 300;
                if (tapMoved || !quick || !emptyAt(tapX, tapY)) {
                    lastTapUp = 0;
                    break;
                }
                if (lastTapUp > 0 && event.getEventTime() - lastTapUp < ViewConfiguration.getDoubleTapTimeout()
                        && Math.hypot(tapX - lastTapX, tapY - lastTapY) < dp(56.0f)) {
                    lastTapUp = 0;
                    onDoubleTapEmpty();
                } else {
                    lastTapUp = event.getEventTime();
                    lastTapX = tapX;
                    lastTapY = tapY;
                }
                break;
            }
            default:
                break;
        }
    }

    /** True when nothing tappable is under the point: the wallpaper, an empty cell, the space between cards. */
    boolean emptyAt(float rawX, float rawY) {
        if (todayOpen || isSearchOpen() || reorderMode || (notifications != null && notifications.isOpen())
                || (appPopup != null && appPopup.isShowing()) || (folderPopup != null && folderPopup.isShowing())) {
            return false;
        }
        View decor = getWindow().getDecorView();
        int[] at = new int[2];
        decor.getLocationOnScreen(at);
        return interactiveAt(decor, rawX - at[0] + decor.getLeft(), rawY - at[1] + decor.getTop()) == null;
    }

    /** The topmost tappable view under a point given in the view's parent's coordinates, or null. */
    private View interactiveAt(View view, float x, float y) {
        if (view.getVisibility() != View.VISIBLE) {
            return null;
        }
        float left = view.getLeft() + view.getTranslationX();
        float top = view.getTop() + view.getTranslationY();
        if (x < left || y < top || x >= left + view.getWidth() || y >= top + view.getHeight()) {
            return null;
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            float inX = x - left + view.getScrollX();
            float inY = y - top + view.getScrollY();
            for (int i = group.getChildCount() - 1; i >= 0; i--) {
                View hit = interactiveAt(group.getChildAt(i), inX, inY);
                if (hit != null) {
                    return hit;
                }
            }
        }
        if (view instanceof AbsListView) {
            return null; // the grid itself: only its icons count
        }
        boolean interactive = view.isClickable() || view.isLongClickable() || view instanceof EditText
                || view instanceof android.appwidget.AppWidgetHostView;
        return interactive ? view : null;
    }

    private void onDoubleTapEmpty() {
        if (!prefs.getBoolean("double_tap_lock", true)) {
            return;
        }
        if (LockService.lockScreen()) {
            return;
        }
        if (Build.VERSION.SDK_INT < 28) {
            Toast.makeText(this, getString(R.string.lock_needs_android9), Toast.LENGTH_LONG).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.double_tap_lock))
                .setMessage(getString(R.string.lock_service_explain))
                .setPositiveButton(getString(R.string.open_settings), (dialog, which) -> {
                    try {
                        startActivity(new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS));
                    } catch (Exception ignored) {
                    }
                })
                .setNeutralButton(getString(R.string.turn_off), (dialog, which) ->
                        prefs.edit().putBoolean("double_tap_lock", false).apply())
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    // ---------------------------------------------------------------- Today: calendar and widget stack

    private void addAgendaCard(long now) {
        if (privacyMode || !prefs.getBoolean("calendar_on", true)) {
            return;
        }
        LinearLayout card = todayCard();
        todayCardHeader(card, getString(R.string.agenda_title), null);
        if (!Agenda.permitted(this)) {
            TextView ask = label(getString(R.string.agenda_allow), 14, accentOnWallpaper(), 600);
            ask.setPadding(0, dp(4.0f), 0, dp(4.0f));
            ask.setOnClickListener(view -> Permissions.ask(this, new String[]{android.Manifest.permission.READ_CALENDAR}, REQUEST_CALENDAR, R.string.perm_why_calendar));
            card.addView(ask, new LinearLayout.LayoutParams(-1, -2));
            return;
        }
        List<Agenda.Event> events = Agenda.recent(this, now, 5, this::agendaRead);
        if (events.isEmpty()) {
            card.addView(label(getString(R.string.agenda_empty), 14, textSecondary, 400));
            return;
        }
        for (final Agenda.Event event : events) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(7.0f), 0, dp(7.0f));
            View bar = new View(this);
            bar.setBackground(pill(event.color != 0 ? (event.color | 0xFF000000) : accent, 2));
            row.addView(bar, new LinearLayout.LayoutParams(dp(4.0f), dp(34.0f)));
            LinearLayout texts = new LinearLayout(this);
            texts.setOrientation(LinearLayout.VERTICAL);
            TextView title = label(event.title, 15, textPrimary, 500);
            title.setSingleLine(true);
            title.setEllipsize(TextUtils.TruncateAt.END);
            texts.addView(title);
            String day = getString(Agenda.dayOffset(event.begin, now) == 0 ? R.string.agenda_today : R.string.agenda_tomorrow);
            String when = event.allDay ? getString(R.string.agenda_all_day) : timeText(event.begin);
            texts.addView(label(day + getString(R.string.list_separator) + when, 12, textSecondary, 400));
            LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(0, -2, 1f);
            textParams.setMarginStart(dp(12.0f));
            row.addView(texts, textParams);
            row.setContentDescription(event.title + "، " + day + "، " + when);
            row.setBackground(new RippleDrawable(ColorStateList.valueOf(withAlpha(textPrimary, 0.16f)), null, pill(Color.WHITE, 12)));
            row.setOnClickListener(view -> {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Agenda.eventUri(event.id)));
                } catch (Exception ignored) {
                }
            });
            card.addView(row, new LinearLayout.LayoutParams(-1, -2));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQUEST_CALENDAR) {
            Agenda.forget();
        }
        if (requestCode == REQUEST_CALENDAR && todayOpen) {
            fillToday();
        }
        if (requestCode == REQUEST_CALENDAR) {
            runCardUpdater("agenda");
        }
        if (requestCode == REQUEST_LOCATION_HOME) {
            if (Places.permitted(this)) {
                followLocation(true);
            } else {
                Toast.makeText(this, getString(R.string.weather_gps_denied, Places.name(this, prefs)), Toast.LENGTH_LONG).show();
            }
        }
        if (requestCode == REQUEST_CONTACTS) {
            smartQuery = "";
            updateWebRow(currentQuery());
        }
    }

    /** Several widgets in one place, like One UI's stacks: swipe sideways to go through them. */
    private void addWidgetStack(final LinearLayout card, final List<Integer> ids) {
        stackIndex = Math.max(0, Math.min(stackIndex, ids.size() - 1));
        final int id = ids.get(stackIndex);
        AppWidgetProviderInfo info = widgetManager.getAppWidgetInfo(id);
        AppWidgetHostView view = info == null ? null : widgetViews.get(id);
        if (info != null && view == null) {
            try {
                view = widgetHost.createView(getApplicationContext(), id, info);
                widgetViews.put(id, view);
            } catch (Exception ignored) {
            }
        }
        final String name = info == null ? "" : appName(info.provider.getPackageName());
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(label(name, 12, textSecondary, 500), new LinearLayout.LayoutParams(0, -2, 1f));
        ImageView remove = new ImageView(this);
        remove.setImageDrawable(new Glyphs(Glyphs.CLOSE, textSecondary, dp(14.0f)));
        remove.setScaleType(ImageView.ScaleType.CENTER);
        remove.setContentDescription(getString(R.string.widget_remove) + "، " + name);
        remove.setOnClickListener(v -> removeWidget(id, name));
        header.addView(remove, new LinearLayout.LayoutParams(dp(32.0f), dp(32.0f)));
        card.addView(header, new LinearLayout.LayoutParams(-1, -2));

        GestureFrame stack = new GestureFrame(this);
        stack.setContentDescription(getString(R.string.widget_stack_description, stackIndex + 1, ids.size()));
        stack.setCallback(new GestureFrame.Callback() {
            @Override
            public void onSwipe(float dx) {
                boolean rtl = stack.getLayoutDirection() == View.LAYOUT_DIRECTION_RTL;
                boolean forward = rtl ? dx > 0 : dx < 0;
                stackIndex = (stackIndex + (forward ? 1 : -1) + ids.size()) % ids.size();
                fillToday();
            }

            @Override
            public void onPullDown() {
            }

            @Override
            public boolean canPullDown() {
                return false;
            }

            @Override
            public boolean canPushUp() {
                return false;
            }

            @Override
            public void onPushUp() {
            }

            @Override
            public void onPinch(float scale) {
            }
        });
        int height = dp(150.0f);
        if (view != null && info != null) {
            if (view.getParent() instanceof ViewGroup) {
                ((ViewGroup) view.getParent()).removeView(view);
            }
            height = Math.max(dp(110.0f), Math.min(dp(420.0f), info.minHeight));
            stack.addView(view, new FrameLayout.LayoutParams(-1, -1));
        }
        card.addView(stack, new LinearLayout.LayoutParams(-1, height));
        LinearLayout dots = new LinearLayout(this);
        dots.setGravity(Gravity.CENTER);
        dots.setPadding(0, dp(8.0f), 0, dp(10.0f));
        for (int i = 0; i < ids.size(); i++) {
            View dot = new View(this);
            dot.setBackground(pill(i == stackIndex ? textPrimary : withAlpha(textPrimary, 0.35f), 4));
            LinearLayout.LayoutParams dotParams = new LinearLayout.LayoutParams(dp(i == stackIndex ? 16.0f : 6.0f), dp(6.0f));
            dotParams.setMargins(dp(3.0f), 0, dp(3.0f), 0);
            dots.addView(dot, dotParams);
        }
        dots.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        card.addView(dots, new LinearLayout.LayoutParams(-1, -2));
    }

    // ---------------------------------------------------------------- Google search

    private AppEntry googleEntry() {
        AppEntry other = null;
        UserHandle me = android.os.Process.myUserHandle();
        for (AppEntry entry : apps) {
            if (GOOGLE_PKG.equals(entry.pkg)) {
                if (me.equals(entry.user)) {
                    return entry;
                }
                other = entry;
            }
        }
        return other;
    }

    /**
     * The Google mark comes from the installed Google app's own icon (its foreground layer, so it is the
     * bare "G" like on Pixel phones). Without the Google app the bar shows a plain magnifier.
     */
    private Drawable googleMark() {
        AppEntry google = googleEntry();
        if (google == null || google.icon == null) {
            return null;
        }
        if (google.icon.getConstantState() == null) {
            int size = dp(48.0f);
            Bitmap copy = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            android.graphics.Rect old = google.icon.copyBounds(); // the grid shares this drawable
            google.icon.setBounds(0, 0, size, size);
            google.icon.draw(new Canvas(copy));
            google.icon.setBounds(old);
            return new android.graphics.drawable.BitmapDrawable(getResources(), copy);
        }
        Drawable icon = google.icon.getConstantState().newDrawable(getResources()).mutate();
        return markFrom(icon);
    }

    private Drawable markFrom(Drawable icon) {
        if (icon instanceof AdaptiveIconDrawable && ((AdaptiveIconDrawable) icon).getForeground() != null) {
            return new BleedDrawable(((AdaptiveIconDrawable) icon).getForeground());
        }
        return icon;
    }

    private void updateSearchBrand() {
        if (searchBrand == null) {
            return;
        }
        Drawable mark = googleMark();
        if (drawerMode) {
            searchBrand.setImageDrawable(new Glyphs(Glyphs.SEARCH, textSecondary, dp(22.0f))); // the drawer searches the apps first
        } else {
            searchBrand.setImageDrawable(mark != null ? mark : new SearchIcon(textSecondary, dp(20.0f)));
        }
        if (webIcon != null) {
            Drawable small = googleMark();
            webIcon.setImageDrawable(small != null ? small : new SearchIcon(textSecondary, dp(18.0f)));
        }
    }

    private void updateWebRow(String query) {
        if (webRow == null) {
            return;
        }
        String text = query == null ? "" : query.trim();
        boolean show = text.length() > 0 && !reorderMode;
        if (show) {
            String label = getString(R.string.search_google_for, text);
            webText.setText(label);
            webRow.setContentDescription(label);
        }
        if ((webRow.getVisibility() == View.VISIBLE) != show) {
            webRow.setVisibility(show ? View.VISIBLE : View.GONE);
        }
        updateSmartBox(show ? text : "");
    }

    // ---------------------------------------------------------------- smart search

    private void updateSmartBox(final String text) {
        if (smartBox == null) {
            return;
        }
        if (text.equals(smartQuery) && (text.isEmpty() || smartBox.getChildCount() > 0)) {
            return;
        }
        smartQuery = text;
        smartBox.removeAllViews();
        if (text.isEmpty()) {
            smartBox.setVisibility(View.GONE);
            return;
        }
        final Double result = SmartSearch.calculate(text);
        if (result != null) {
            final String shown = SmartSearch.format(result);
            View row = smartRow(new Glyphs(Glyphs.CALCULATOR, textPrimary, dp(20.0f)), null, "\u2066= " + shown + "\u2069", getString(R.string.search_calc_copy),
                    v -> {
                        android.content.ClipboardManager clipboard = getSystemService(android.content.ClipboardManager.class);
                        if (clipboard != null) {
                            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("=", plainNumber(result)));
                        }
                        Toast.makeText(this, getString(R.string.search_calc_copied), Toast.LENGTH_SHORT).show();
                    });
            row.setTag("calc");
            smartBox.addView(row);
        }
        for (final SmartSearch.Answer answer : new SmartSearch.Answer[]{SmartSearch.zakat(text), SmartSearch.convert(this, text)}) {
            if (answer == null) {
                continue;
            }
            boolean zakat = answer == null ? false : text.contains("زك") || text.toLowerCase(Locale.ROOT).contains("zakat");
            String title = zakat ? getString(R.string.zakat_result, answer.question, answer.result) : answer.question + " = " + answer.result;
            smartBox.addView(smartRow(new Glyphs(Glyphs.CALCULATOR, textPrimary, dp(20.0f)), null, title,
                    getString(zakat ? R.string.zakat_hint : R.string.search_calc_copy), v -> {
                        android.content.ClipboardManager clipboard = getSystemService(android.content.ClipboardManager.class);
                        if (clipboard != null) {
                            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("=", answer.copy));
                        }
                        Toast.makeText(this, getString(zakat ? R.string.zakat_copied : R.string.search_calc_copied), Toast.LENGTH_LONG).show();
                    }));
        }
        for (final SmartSearch.Page page : SmartSearch.pages(text, 3)) {
            smartBox.addView(smartRow(new Glyphs(page.glyph, textPrimary, dp(20.0f)), null, getString(page.name),
                    getString(R.string.search_in_settings), v -> {
                        closeSearch();
                        startSafely(page.intent());
                    }));
        }
        if (result == null && text.length() >= 2) {
            if (SmartSearch.contactsAllowed(this)) {
                background(() -> {
                    final List<SmartSearch.Contact> found = SmartSearch.contacts(this, text, 3);
                    runOnUiThread(() -> {
                        if (!text.equals(smartQuery) || smartBox == null) {
                            return; // typing went on
                        }
                        for (final SmartSearch.Contact contact : found) {
                            smartBox.addView(smartRow(null, contact.name, contact.name, getString(R.string.search_contacts), v -> {
                                closeSearch();
                                startSafely(new Intent(Intent.ACTION_VIEW, contact.uri));
                            }));
                        }
                        smartBox.setVisibility(smartBox.getChildCount() > 0 ? View.VISIBLE : View.GONE);
                    });
                });
            } else if (text.length() >= 3 && !prefs.getBoolean("contacts_search_off", false)) {
                View ask = smartRow(new Glyphs(Glyphs.SHARE, textSecondary, dp(18.0f)), null, getString(R.string.search_contacts_allow), null,
                        v -> Permissions.ask(this, new String[]{android.Manifest.permission.READ_CONTACTS}, REQUEST_CONTACTS, R.string.perm_why_contacts));
                ask.setOnLongClickListener(v -> {
                    prefs.edit().putBoolean("contacts_search_off", true).apply();
                    smartQuery = "";
                    updateSmartBox(text);
                    return true;
                });
                smartBox.addView(ask);
            }
        }
        smartBox.setVisibility(smartBox.getChildCount() > 0 ? View.VISIBLE : View.GONE);
    }

    /** 12 rather than 12.0, and no Arabic digits, for the clipboard. */
    static String plainNumber(double value) {
        if (value == Math.rint(value) && Math.abs(value) < 1e15) {
            return String.valueOf((long) value);
        }
        String text = String.format(java.util.Locale.US, "%.8f", value);
        text = text.replaceAll("0+$", "");
        return text.endsWith(".") ? text.substring(0, text.length() - 1) : text;
    }

    /** One line of the smart box: a glyph (or a letter badge for a contact), the text, and a small hint. */
    private View smartRow(Drawable icon, String letterOf, String title, String hint, View.OnClickListener click) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16.0f), 0, dp(16.0f), 0);
        row.setMinimumHeight(dp(44.0f));
        if (icon != null) {
            ImageView image = new ImageView(this);
            image.setImageDrawable(icon);
            image.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            row.addView(image, new LinearLayout.LayoutParams(dp(20.0f), dp(20.0f)));
        } else {
            String first = letterOf == null || letterOf.isEmpty() ? "?" : letterOf.substring(0, letterOf.offsetByCodePoints(0, 1));
            TextView badge = label(first, 12, Color.WHITE, 700);
            badge.setGravity(Gravity.CENTER);
            badge.setBackground(pill(accent, 12));
            badge.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            row.addView(badge, new LinearLayout.LayoutParams(dp(24.0f), dp(24.0f)));
        }
        TextView main = label(title, 14, textPrimary, 500);
        main.setMaxLines(hint == null ? 2 : 1); // the contacts request is a sentence
        main.setEllipsize(TextUtils.TruncateAt.END);
        main.setPadding(0, dp(8.0f), 0, dp(8.0f));
        LinearLayout.LayoutParams mainParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
        mainParams.setMarginStart(dp(12.0f));
        row.addView(main, mainParams);
        if (hint != null) {
            TextView small = label(hint, 11, textSecondary, 400);
            small.setSingleLine(true);
            LinearLayout.LayoutParams smallParams = new LinearLayout.LayoutParams(-2, -2);
            smallParams.setMarginStart(dp(8.0f));
            row.addView(small, smallParams);
        }
        row.setBackground(new android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(withAlpha(textPrimary, 0.18f)), null,
                new android.graphics.drawable.ColorDrawable(Color.WHITE)));
        row.setContentDescription(hint == null ? title : title + getString(R.string.list_separator) + hint);
        row.setOnClickListener(click);
        return row;
    }

    /** Enter in the bar: open the app whose name starts with the text, else search Google. */
    void submitSearch() {
        String text = currentQuery().trim();
        if (text.length() == 0) {
            return;
        }
        String normalized = ArabicText.normalize(text);
        if (!filteredApps.isEmpty()) {
            AppEntry best = filteredApps.get(0);
            int score = ArabicText.matchScore(best.searchLabel, best.pkg, normalized);
            if (score == 0 || score == 1) {
                launch(best, grid == null ? null : grid.getChildAt(0));
                return;
            }
        }
        googleSearch(text);
    }

    /** Searches Google: in the Google app when it is installed, otherwise in the browser. */
    void googleSearch(String query) {
        String text = query == null ? "" : query.trim();
        if (text.length() == 0) {
            return;
        }
        Intent web = new Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, text);
        if (googleEntry() != null) {
            web.setPackage(GOOGLE_PKG);
        }
        try {
            startActivity(web);
            return;
        } catch (Exception ignored) {
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(text))));
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.no_browser), Toast.LENGTH_SHORT).show();
        }
    }

    /** The microphone: Google's voice search, which shows the results itself. */
    void voiceSearch() {
        Intent voice = new Intent(RecognizerIntent.ACTION_WEB_SEARCH);
        voice.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_WEB_SEARCH);
        if (googleEntry() != null) {
            voice.setPackage(GOOGLE_PKG);
        }
        try {
            startActivity(voice);
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.voice_unavailable), Toast.LENGTH_SHORT).show();
        }
    }

    /** Draws an adaptive icon's foreground so its safe zone fills the bounds (the layer is 1.5x the visible icon). */
    private static final class BleedDrawable extends Drawable {
        private final Drawable inner;

        BleedDrawable(Drawable inner) {
            this.inner = inner;
        }

        @Override
        public void draw(Canvas canvas) {
            android.graphics.Rect b = getBounds();
            int extraX = b.width() / 4;
            int extraY = b.height() / 4;
            inner.setBounds(b.left - extraX, b.top - extraY, b.right + extraX, b.bottom + extraY);
            inner.draw(canvas);
        }

        @Override
        public void setAlpha(int alpha) {
            inner.setAlpha(alpha);
        }

        @Override
        public void setColorFilter(ColorFilter filter) {
            inner.setColorFilter(filter);
        }

        @Override
        public int getOpacity() {
            return PixelFormat.TRANSLUCENT;
        }
    }

    private boolean isSearchOpen() {
        return search != null && (search.hasFocus() || search.length() > 0);
    }

    private void openSearch() {
        if (search == null) {
            return;
        }
        if (drawer != null && !drawer.isOpen()) {
            if (!drawerAllowed()) {
                return;
            }
            drawer.open(true);
        }
        search.requestFocus();
        offerClip();
        search.post(new Runnable() {
            @Override
            public void run() {
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (imm != null) {
                    imm.showSoftInput(search, InputMethodManager.SHOW_IMPLICIT);
                }
            }
        });
    }

    private void closeSearch() {
        if (search == null) {
            return;
        }
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(search.getWindowToken(), 0);
        }
        search.setText("");
        search.clearFocus();
        if (root != null) {
            root.requestFocus(); // park focus so the keyboard doesn't come back by itself
        }
    }

    // ---------------------------------------------------------------- wallpaper and theme

    private void applyWallpaper(LinearLayout target) {
        Window window = getWindow();
        if (Wallpapers.DEVICE.equals(wallpaperId)) {
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER);
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            target.setBackground(null);
            glass.blurred = null;
            darkWallpaper = isDeviceWallpaperDark();
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER);
            target.setBackground(wallpaperWithAmbience());
            darkWallpaper = Wallpapers.isDark(this, wallpaperId);
        }
        glass.dark = darkWallpaper;
        textPrimary = darkWallpaper ? Color.WHITE : 0xFF1C1B22;
        textSecondary = darkWallpaper ? 0xBFFFFFFF : 0x9E1C1B22;
    }

    private boolean isDeviceWallpaperDark() {
        if (Build.VERSION.SDK_INT < 27) {
            return true;
        }
        try {
            WallpaperColors colors = WallpaperManager.getInstance(this).getWallpaperColors(WallpaperManager.FLAG_SYSTEM);
            if (colors == null) {
                return true;
            }
            if (Build.VERSION.SDK_INT >= 31) {
                return (colors.getColorHints() & WallpaperColors.HINT_SUPPORTS_DARK_TEXT) == 0;
            }
            return colors.getPrimaryColor().luminance() < 0.5f;
        } catch (Exception e) {
            return true;
        }
    }

    /** Draws the wallpaper behind the status and navigation bars, with icons that stay readable on it. */
    private void applySystemBars() {
        Window window = getWindow();
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) {
            window.setNavigationBarContrastEnforced(false);
            window.setStatusBarContrastEnforced(false);
        }
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false);
            WindowInsetsController controller = window.getInsetsController();
            if (controller != null) {
                int light = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                controller.setSystemBarsAppearance(darkWallpaper ? 0 : light, light);
            }
        } else {
            View decor = window.getDecorView();
            int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
            if (!darkWallpaper) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            decor.setSystemUiVisibility(flags);
        }
    }

    private int blurGeneration;

    private void rebuildGlass() {
        if (root == null || root.getWidth() == 0 || root.getHeight() == 0) {
            return;
        }
        final int gen = ++blurGeneration;
        if (Wallpapers.DEVICE.equals(wallpaperId)) {
            glass.blurred = null;
            for (View view : glassViews) {
                view.invalidate();
            }
            return;
        }
        final int w = root.getWidth();
        final int h = root.getHeight();
        final String wallId = wallpaperId;
        final Ambience.State state = ambienceLayer != null ? ambienceLayer.state : null;
        if (appExecutor.isShutdown()) {
            return;
        }
        appExecutor.execute(() -> {
            final android.graphics.Bitmap result;
            if (state != null) {
                Drawable both = new android.graphics.drawable.LayerDrawable(new Drawable[]{Wallpapers.create(this, wallId),
                        new Ambience.Layer(state, false)});
                result = Wallpapers.blurredOf(both, w, h);
            } else {
                result = Wallpapers.blurred(this, wallId, w, h);
            }
            uiHandler.post(() -> {
                if (isDestroyed() || gen != blurGeneration) {
                    return;
                }
                glass.blurred = result;
                for (View view : glassViews) {
                    view.invalidate();
                }
            });
        });
    }

    /** Puts One UI 9 glass behind a view. */
    void glassify(View view, float radiusDp, boolean strong) {
        view.setBackground(new GlassDrawable(glass, view, dp(radiusDp), Math.max(1f, dp(0.8f)), strong));
        glassViews.add(view);
    }

    // ---------------------------------------------------------------- UI

    private void buildUI() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        // The dock stays on the right in every language; the home column follows the language.
        root.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        root.setFocusableInTouchMode(true);
        glass.root = root;
        applyWallpaper(root);
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
                int left;
                int top;
                int right;
                int bottom;
                if (Build.VERSION.SDK_INT >= 30) {
                    Insets insets = windowInsets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                    left = insets.left;
                    top = insets.top;
                    right = insets.right;
                    bottom = insets.bottom;
                    // Android's own bottom strip for going home: a swipe that starts there is never ours.
                    gestureBottom = windowInsets.getInsets(WindowInsets.Type.mandatorySystemGestures()).bottom;
                } else {
                    left = windowInsets.getSystemWindowInsetLeft();
                    top = windowInsets.getSystemWindowInsetTop();
                    right = windowInsets.getSystemWindowInsetRight();
                    bottom = windowInsets.getSystemWindowInsetBottom();
                }
                view.setPadding(left, top, right, bottom);
                return windowInsets;
            }
        });
        root.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override
            public void onLayoutChange(View v, int left, int top, int right, int bottom, int oldLeft, int oldTop, int oldRight, int oldBottom) {
                uiHandler.post(HomeActivity.this::placeControlCenterHandle);
                if (right - left != oldRight - oldLeft || bottom - top != oldBottom - oldTop) {
                    rebuildGlass();
                }
            }
        });
        buildHomeColumn(root);
        buildDock(root);
        frame = new FrameLayout(this);
        frame.addView(root, new FrameLayout.LayoutParams(-1, -1));
        if (drawer != null) {
            frame.addView(drawer.view, new FrameLayout.LayoutParams(-1, -1));
        }
        buildTodayPanel();
        notifications = new NotificationPanel(this);
        frame.addView(notifications.view, new FrameLayout.LayoutParams(-1, -1));
        controlCenter = new ControlCenter(this);
        frame.addView(controlCenter.view, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frame);
        if (twoPane) {
            fillToday();
        }
        applySystemBars(); // needs the window's decor view, which setContentView creates
        root.requestFocus();
        updateWidgets();
    }

    private void buildHomeColumn(LinearLayout parent) {
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setLayoutDirection(View.LAYOUT_DIRECTION_LOCALE);
        column.setPadding(dp(14.0f), dp(10.0f), dp(10.0f), dp(6.0f));
        ViewGroup apps = column; // where the search and the apps go: here, or in the drawer
        if (drawerMode) {
            // The bottom stays clear for the control centre's pull, wherever the cards are moved.
            column.setPadding(dp(14.0f), dp(10.0f), dp(10.0f), dp(92.0f));
            homeFrame = new GestureFrame(this);
            homeFrame.setCallback(homeGestures());
            homeFrame.addView(column, new FrameLayout.LayoutParams(-1, -1));
            parent.addView(homeFrame, new LinearLayout.LayoutParams(0, -1, 1.0f));
            drawer = new AppDrawer(this, AppDrawer.veilFor(darkWallpaper, !Wallpapers.DEVICE.equals(wallpaperId)));
            apps = drawer.column;
        } else {
            parent.addView(column, new LinearLayout.LayoutParams(0, -1, 1.0f));
        }

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        column.addView(titleRow, new LinearLayout.LayoutParams(-1, dp(48.0f)));
        defaultBanner = new LinearLayout(this);
        defaultBanner.setOrientation(LinearLayout.VERTICAL);
        defaultBanner.setPadding(dp(16.0f), dp(12.0f), dp(16.0f), dp(12.0f));
        glassify(defaultBanner, 22, true);
        defaultBanner.setVisibility(View.GONE);
        TextView why = label(getString(R.string.default_banner), 13, textPrimary, 500);
        defaultBanner.addView(why, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout bannerButtons = new LinearLayout(this);
        bannerButtons.setGravity(Gravity.CENTER_VERTICAL);
        bannerButtons.setPadding(0, dp(10.0f), 0, 0);
        TextView make = label(getString(R.string.default_make), 14, Color.WHITE, 600);
        make.setPadding(dp(16.0f), dp(7.0f), dp(16.0f), dp(8.0f));
        make.setBackground(pill(accent, 16));
        make.setOnClickListener(view -> DefaultHome.ask(this));
        bannerButtons.addView(make);
        TextView later = label(getString(R.string.default_later), 14, textPrimary, 500);
        later.setPadding(dp(16.0f), dp(7.0f), dp(16.0f), dp(8.0f));
        later.setOnClickListener(view -> {
            defaultBannerDismissed = true;
            updateDefaultBanner();
        });
        bannerButtons.addView(later);
        defaultBanner.addView(bannerButtons, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams bannerParams = new LinearLayout.LayoutParams(-1, -2);
        bannerParams.topMargin = dp(8.0f);
        column.addView(defaultBanner, bannerParams);
        addNowRow(column);
        // The time and the day in a glass chip, the same as the weather chip next to it.
        clockChip = new LinearLayout(this);
        clockChip.setGravity(Gravity.CENTER_VERTICAL);
        clockChip.setPadding(dp(11.0f), 0, dp(12.0f), 0);
        glassify(clockChip, 20, true);
        titleClock = label("", 17, textPrimary, 700);
        titleClock.setTextSize(TypedValue.COMPLEX_UNIT_DIP, chipText(17f));
        titleClock.setSingleLine(true);
        titleClock.setIncludeFontPadding(false);
        clockChip.addView(titleClock, new LinearLayout.LayoutParams(-2, -2));
        // Two short lines next to the time: the weekday over the date with the Gregorian month.
        titleDay = label("", 11, textSecondary, 500);
        titleDay.setTextSize(TypedValue.COMPLEX_UNIT_DIP, chipText(11f));
        titleDay.setMaxLines(2);
        titleDay.setIncludeFontPadding(false);
        titleDay.setLineSpacing(0f, 0.92f);
        titleDay.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams dayParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
        dayParams.setMarginStart(dp(7.0f));
        clockChip.addView(titleDay, dayParams);
        // When the chip is narrower (a smaller screen, a bigger font), the date gets smaller or shorter
        // instead of being cut off.
        titleDay.addOnLayoutChangeListener((v, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom) -> {
            if (right - left != oldRight - oldLeft) {
                v.post(this::fitTitleDay);
            }
        });
        clockChip.setOnClickListener(view -> openAlarms());
        clockChip.setOnLongClickListener(view -> {
            openToday();
            return true;
        });
        // The chip takes the room up to the weather chip, with the day and the month, so there's no gap.
        LinearLayout.LayoutParams clockParams = new LinearLayout.LayoutParams(0, dp(40.0f), 1.0f);
        clockParams.setMarginEnd(dp(6.0f));
        titleRow.addView(clockChip, clockParams);
        weatherChip = new LinearLayout(this);
        weatherChip.setGravity(Gravity.CENTER_VERTICAL);
        weatherChip.setPadding(dp(10.0f), 0, dp(11.0f), 0);
        glassify(weatherChip, 20, true);
        weatherIcon = new ImageView(this);
        weatherChip.addView(weatherIcon, new LinearLayout.LayoutParams(dp(22.0f), dp(22.0f)));
        weatherTemp = label("", 15, textPrimary, 600);
        weatherTemp.setTextSize(TypedValue.COMPLEX_UNIT_DIP, chipText(15f));
        weatherTemp.setSingleLine(true);
        LinearLayout.LayoutParams tempParams = new LinearLayout.LayoutParams(-2, -2);
        tempParams.setMarginStart(dp(5.0f));
        weatherChip.addView(weatherTemp, tempParams);
        weatherChip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openToday();
            }
        });
        LinearLayout.LayoutParams chipParams = new LinearLayout.LayoutParams(-2, dp(40.0f));
        chipParams.setMarginEnd(dp(6.0f));
        titleRow.addView(weatherChip, chipParams);
        updateWeatherChip();
        eyeButton = new ImageView(this);
        eyeButton.setScaleType(ImageView.ScaleType.CENTER);
        glassify(eyeButton, 20, true);
        LinearLayout.LayoutParams eyeParams = new LinearLayout.LayoutParams(dp(40.0f), dp(40.0f));
        eyeParams.setMarginEnd(dp(6.0f));
        titleRow.addView(eyeButton, eyeParams);
        eyeButton.setOnClickListener(view -> setPrivacyMode(!privacyMode));
        updateEyeButton();
        TextView menuButton = label("⋯", 20, textPrimary, 700);
        menuButton.setGravity(Gravity.CENTER);
        menuButton.setContentDescription(getString(R.string.home_options));
        glassify(menuButton, 20, true);
        titleRow.addView(menuButton, new LinearLayout.LayoutParams(dp(40.0f), dp(40.0f)));
        menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(HomeActivity.this, SettingsActivity.class));
            }
        });

        cardsRow = new LinearLayout(this);
        cardsRow.setOrientation(LinearLayout.VERTICAL);
        // Two cards across the whole width, one above the other: each short, with a ticker line.
        LinearLayout.LayoutParams widgetParams = new LinearLayout.LayoutParams(-1, dp(180.0f));
        widgetParams.topMargin = dp(10.0f);
        column.addView(cardsRow, widgetParams);
        fillCards();
        if (twoPane) {
            cardsRow.setVisibility(View.GONE); // the Today pane already shows the date and the news
        }

        // A Google search bar: the Google mark, the text field and a microphone. Typing still finds apps
        // straight away; anything else goes to Google (Enter, or the row that appears under the bar).
        searchBar = new LinearLayout(this);
        searchBar.setGravity(Gravity.CENTER_VERTICAL);
        searchBar.setPadding(dp(14.0f), 0, dp(4.0f), 0);
        glassify(searchBar, 24, true);
        searchBrand = new ImageView(this);
        searchBrand.setScaleType(ImageView.ScaleType.FIT_CENTER);
        searchBrand.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        searchBar.addView(searchBrand, new LinearLayout.LayoutParams(dp(24.0f), dp(24.0f)));
        search = new EditText(this);
        search.setBackground(null);
        search.setSingleLine(true);
        search.setTextSize(15.0f);
        search.setTypeface(font(400));
        // A narrow phone: the short hint, so it isn't cut in the middle of a word.
        search.setHint(getString(getResources().getConfiguration().screenWidthDp < 360 ? R.string.search_short : R.string.search_google));
        search.setHintTextColor(textSecondary);
        search.setTextColor(textPrimary);
        search.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        search.setPadding(dp(10.0f), 0, dp(4.0f), 0);
        search.setImeOptions(EditorInfo.IME_ACTION_SEARCH | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        searchBar.addView(search, new LinearLayout.LayoutParams(0, -1, 1.0f));
        micButton = new ImageView(this);
        micButton.setImageDrawable(new Glyphs(Glyphs.MIC, textPrimary, dp(22.0f)));
        micButton.setScaleType(ImageView.ScaleType.CENTER);
        micButton.setContentDescription(getString(R.string.voice_search));
        micButton.setBackground(new RippleDrawable(ColorStateList.valueOf(darkWallpaper ? 0x33FFFFFF : 0x22000000), null, null));
        micButton.setOnClickListener(view -> voiceSearch());
        searchBar.addView(micButton, new LinearLayout.LayoutParams(dp(40.0f), dp(40.0f)));
        searchBar.setOnClickListener(view -> openSearch());
        searchBar.setOnLongClickListener(view -> {
            if (!drawerMode) {
                new AlertDialog.Builder(this)
                        .setItems(new String[]{getString(R.string.search_bar_hide)}, (d, w) -> {
                            prefs.edit().putBoolean("show_search_bar", false).apply();
                            searchBar.setVisibility(View.GONE);
                        })
                        .setNegativeButton(getString(R.string.cancel), null)
                        .show();
                return true;
            }
            return false;
        });
        if (!drawerMode && !prefs.getBoolean("show_search_bar", true)) {
            searchBar.setVisibility(View.GONE);
        }
        LinearLayout searchRow = new LinearLayout(this);
        searchRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(-1, dp(drawerMode ? 52.0f : 48.0f));
        searchParams.topMargin = dp(drawerMode ? 2.0f : 12.0f);
        apps.addView(searchRow, searchParams);
        if (drawerMode) {
            styleDrawerSearch(apps);
        }
        searchRow.addView(searchBar, new LinearLayout.LayoutParams(0, -1, 1.0f));
        // Beside search: how apps are sorted and laid out, and automatic folders.
        ImageView viewButton = new ImageView(this);
        viewButton.setImageDrawable(new Glyphs(Glyphs.SORT, textPrimary, dp(22.0f)));
        viewButton.setScaleType(ImageView.ScaleType.CENTER);
        viewButton.setContentDescription(getString(R.string.view_options));
        glassify(viewButton, drawerMode ? 26 : 24, true);
        LinearLayout.LayoutParams viewParams = new LinearLayout.LayoutParams(dp(drawerMode ? 52.0f : 48.0f), dp(drawerMode ? 52.0f : 48.0f));
        viewParams.setMarginStart(dp(8.0f));
        searchRow.addView(viewButton, viewParams);
        viewButton.setOnClickListener(view -> showViewOptions(view));
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable editable) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                applyFilter(s.toString());
            }
        });
        // Enter opens the app when the text starts its name (or a word in it), so "وات" + Enter still
        // opens WhatsApp; anything else is searched on Google.
        search.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                boolean enter = event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER;
                if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_GO || enter) {
                    if (event != null && event.getAction() != KeyEvent.ACTION_DOWN) {
                        return true;
                    }
                    submitSearch();
                    return true;
                }
                return false;
            }
        });

        arrangeBar = new LinearLayout(this);
        arrangeBar.setOrientation(LinearLayout.HORIZONTAL);
        arrangeBar.setGravity(Gravity.CENTER_VERTICAL);
        arrangeBar.setPadding(dp(16.0f), dp(8.0f), dp(10.0f), dp(8.0f));
        glassify(arrangeBar, 22, true);
        arrangeBar.setVisibility(View.GONE);
        TextView arrangeTip = label(getString(R.string.reorder_tip), 12, textPrimary, 400);
        arrangeBar.addView(arrangeTip, new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView doneButton = label(getString(R.string.done), 13, Color.WHITE, 600);
        doneButton.setPadding(dp(14.0f), dp(6.0f), dp(14.0f), dp(6.0f));
        doneButton.setBackground(pill(accent, 16));
        arrangeBar.addView(doneButton);
        doneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setReorderMode(false);
            }
        });
        LinearLayout.LayoutParams arrangeParams = new LinearLayout.LayoutParams(-1, -2);
        arrangeParams.topMargin = dp(8.0f);
        apps.addView(arrangeBar, arrangeParams);

        webRow = new LinearLayout(this);
        webRow.setGravity(Gravity.CENTER_VERTICAL);
        webRow.setPadding(dp(16.0f), 0, dp(16.0f), 0);
        glassify(webRow, 22, true);
        webRow.setVisibility(View.GONE);
        webIcon = new ImageView(this);
        webIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        webIcon.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        webRow.addView(webIcon, new LinearLayout.LayoutParams(dp(20.0f), dp(20.0f)));
        webText = label("", 14, textPrimary, 500);
        webText.setSingleLine(true);
        webText.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams webTextParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
        webTextParams.setMarginStart(dp(12.0f));
        webRow.addView(webText, webTextParams);
        webRow.setOnClickListener(view -> googleSearch(currentQuery()));
        smartBox = new LinearLayout(this);
        smartBox.setOrientation(LinearLayout.VERTICAL);
        smartBox.setPadding(0, dp(4.0f), 0, dp(4.0f));
        glassify(smartBox, 22, true);
        smartBox.setClipToOutline(true);
        smartBox.setVisibility(View.GONE);
        LinearLayout.LayoutParams smartParams = new LinearLayout.LayoutParams(-1, -2);
        smartParams.topMargin = dp(8.0f);
        apps.addView(smartBox, smartParams);
        LinearLayout.LayoutParams webParams = new LinearLayout.LayoutParams(-1, dp(44.0f));
        webParams.topMargin = dp(8.0f);
        if (!drawerMode) {
            column.addView(webRow, webParams); // in the drawer it goes under the apps, near the thumb
        }
        updateSearchBrand();

        grid = new GridView(this);
        grid.setVerticalSpacing(0);
        grid.setHorizontalSpacing(0);
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(android.R.color.transparent);
        grid.setClipToPadding(false);
        grid.setOverScrollMode(View.OVER_SCROLL_NEVER);
        grid.setVerticalScrollBarEnabled(false);
        grid.setNumColumns(columns);
        adapter = new AppAdapter();
        grid.setAdapter(adapter);
        gridFrame = new GestureFrame(this);
        gridFrame.setOnDragListener((view, event) -> {
            Object state = event.getLocalState();
            if (!(state instanceof DockDrag) || reorderMode) {
                return false;
            }
            if (event.getAction() == DragEvent.ACTION_DROP) {
                AppEntry leaving = ((DockDrag) state).entry;
                List<String> favorites = getFavorites();
                if (favorites.remove(leaving.key)) {
                    saveFavorites(favorites);
                    Toast.makeText(this, getString(R.string.dock_removed, leaving.label), Toast.LENGTH_SHORT).show();
                }
            }
            return true;
        });
        gridFrame.setCallback(new GestureFrame.Callback() {
            @Override
            public void onSwipe(float dx) {
                if (appPopup != null && appPopup.isShowing()) {
                    return; // the finger slid off a held icon's menu; don't turn the page under it
                }
                // In right-to-left languages the next page is to the left, as in One UI.
                boolean rtl = grid.getLayoutDirection() == View.LAYOUT_DIRECTION_RTL;
                boolean towardStart = rtl ? dx > 0 : dx < 0;
                changePage(towardStart ? 1 : -1);
            }

            @Override
            public boolean tracksSwipe() {
                return !scrollLayout && !(appPopup != null && appPopup.isShowing());
            }

            @Override
            public void onSwipeDrag(float dx) {
                pageDrag(dx);
            }

            @Override
            public void onSwipeEnd(float dx, float velocityX) {
                pageRelease(dx, velocityX);
            }

            @Override
            public boolean tracksPull() {
                if (drawer != null) {
                    return true; // in the drawer, pulling the list down closes it
                }
                return prefs.getBoolean("pull_down_notifications", true) && prefs.getBoolean("sara_shade", true) && notifications != null;
            }

            @Override
            public void onPullDrag(float dy) {
                if (drawer != null) {
                    drawer.pullTo(dy);
                    return;
                }
                notifications.pullTo(dy);
            }

            @Override
            public void onPullEnd(float dy, float velocityY) {
                if (drawer != null) {
                    drawer.endPull(dy, velocityY);
                    return;
                }
                notifications.endPull(dy, velocityY);
            }

            @Override
            public void onPullDown() {
                if (drawer != null) {
                    closeDrawer(true);
                    return;
                }
                if (prefs.getBoolean("pull_down_notifications", true)) {
                    if (prefs.getBoolean("sara_shade", true) && notifications != null) {
                        notifications.open();
                        return;
                    }
                    if (expandNotifications()) {
                        return;
                    }
                }
                openSearch();
            }

            @Override
            public boolean canPushUp() {
                return !reorderMode && !scrollLayout && !isSearchOpen();
            }

            @Override
            public void onPushUp() {
                openSearch();
            }

            @Override
            public boolean canPullDown() {
                return !reorderMode && !grid.canScrollVertically(-1);
            }

            @Override
            public void onPinch(float scale) {
                setGridDense(scale < 1f, true); // fingers together: more apps; apart: bigger icons
            }

            @Override
            public boolean iconSwipeAt(float x, float y) {
                return !isSearchOpen() && swipeTarget(x, y) != null;
            }

            @Override
            public void onIconSwipe(float x, float y) {
                AppEntry entry = swipeTarget(x, y);
                if (entry != null) {
                    int position = grid.pointToPosition(Math.round(x - grid.getLeft()), Math.round(y - grid.getTop()));
                    View cell = grid.getChildAt(position - grid.getFirstVisiblePosition());
                    HomeActivity.this.onIconSwipe(entry, cell != null ? cell : grid);
                }
            }
        });
        gridFrame.addView(grid, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams gridParams = new LinearLayout.LayoutParams(-1, 0, 1.0f);
        gridParams.topMargin = dp(10.0f);
        apps.addView(gridFrame, gridParams);
        if (drawerMode) {
            addDrawerExtras(apps, webParams);
        }
        grid.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override
            public void onLayoutChange(View v, int left, int top, int right, int bottom, int oldLeft, int oldTop, int oldRight, int oldBottom) {
                fitGrid(right - left - grid.getPaddingLeft() - grid.getPaddingRight(), bottom - top);
            }
        });
        pageDots = new LinearLayout(this);
        pageDots.setGravity(Gravity.CENTER);
        apps.addView(pageDots, new LinearLayout.LayoutParams(-1, dp(26.0f)));
        updatePageIndicator();
        if (drawerMode) {
            addHomeSearchPill(column);
        }
    }

    private void fitGrid(int width, int height) {
        fitGrid(width, height, false);
    }

    /**
     * Picks columns and rows that fill the space, so the grid spreads over the screen like One UI.
     * Roomy cells are at least 64 x 96 dp (4 x 5 on most phones); compact adds a column and a row.
     */
    private void fitGrid(int width, int height, boolean force) {
        if (width <= 0 || height <= 0) {
            return;
        }
        // Phones get 4 or 5 columns and up to 6 rows; a tablet or an open foldable gets 6 and 7.
        // A tablet's cells are wider (84dp), so its icons grow instead of crowding in more columns.
        boolean large = getResources().getConfiguration().smallestScreenWidthDp >= 600;
        int fitColumns = Math.max(large ? 4 : 3, Math.min(width >= dp(520.0f) ? 6 : 5, width / dp(large ? 84.0f : 64.0f)));
        int fitRows = Math.max(3, Math.min(height >= dp(760.0f) ? 7 : 6, height / dp(96.0f)));
        if (gridDense) {
            fitColumns = Math.min(fitColumns + 1, Math.max(fitColumns, width / dp(48.0f)));
            fitRows = Math.min(fitRows + 1, Math.max(fitRows, height / dp(76.0f)));
        }
        int fitCell = height / fitRows;
        int fitIcon = iconFrameFor(width / fitColumns, fitCell);
        if (!force && fitColumns == columns && fitRows == rows && fitCell == cellHeight && fitIcon == iconFrame) {
            return;
        }
        columns = fitColumns;
        rows = fitRows;
        cellHeight = fitCell;
        iconFrame = fitIcon;
        pageCapacity = columns * rows;
        grid.post(new Runnable() {
            @Override
            public void run() {
                grid.setNumColumns(columns);
                applyFilter(currentQuery());
            }
        });
    }

    /** The icon's frame in a grid cell: as big as the cell allows with its name under it, from small phones to tablets. */
    private int iconFrame = 0;

    int iconFrameFor(int cellWidth, int cellHeightPx) {
        int label = hideLabels ? 0 : dp(6.0f) + Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP,
                gridDense ? 11 : 12, getResources().getDisplayMetrics()) * 1.4f);
        int frame = Math.min(Math.round(cellWidth * 0.80f), cellHeightPx - label - dp(6.0f));
        return Math.max(dp(34.0f), Math.min(dp(gridDense ? 60.0f : 76.0f), frame));
    }

    /** Frame and icon size (dp) in the grid now; the usual 60 and 54 until the grid has measured itself. */
    private int gridFrame() {
        return iconFrame > 0 ? iconFrame : dp(gridDense ? 52.0f : 60.0f);
    }

    private int gridIconDp() {
        return Math.round(gridFrame() / getResources().getDisplayMetrics().density * 0.9f);
    }

    private View clockCard() {
        dateCard = wideBase();
        dateCard.setOrientation(LinearLayout.HORIZONTAL);
        dateCard.setGravity(Gravity.CENTER_VERTICAL);
        dateCard.setOnClickListener(view -> openToday());
        clock = label("", 42, textPrimary, 600);
        clock.setIncludeFontPadding(false);
        clock.setLetterSpacing(-0.02f);
        clock.setSingleLine(true);
        dateCard.addView(clock, new LinearLayout.LayoutParams(-2, -2));
        LinearLayout side = new LinearLayout(this);
        side.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams sideParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
        sideParams.setMarginStart(dp(16.0f));
        dateCard.addView(side, sideParams);
        dateLine = cardLine("", 15, textPrimary, 600);
        side.addView(dateLine, new LinearLayout.LayoutParams(-1, -2));
        prayerLine = cardLine("", 13, accentOnWallpaper(), 600);
        hijriDate = cardLine("", 13, textSecondary, 500);
        hijriDate.setOnClickListener(v -> HijriMonth.show(this));
        // The next prayer, the Hijri date and the day's occasion take turns under the date.
        clockLines = ticker(1);
        LinearLayout.LayoutParams linesParams = new LinearLayout.LayoutParams(-1, -2);
        linesParams.topMargin = dp(4.0f);
        side.addView(clockLines, linesParams);
        return dateCard;
    }

    private View newsCardPage() {
        newsCard = wideBase();
        newsCard.setPaddingRelative(dp(16.0f), dp(8.0f), dp(22.0f), dp(8.0f));
        newsCard.setContentDescription(getString(R.string.news_card_description));
        newsCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (newsItems.isEmpty()) {
                    refreshAllNews();
                }
            }
        });
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        newsCard.addView(header, new LinearLayout.LayoutParams(-1, -2));
        newsLiveDot = new View(this);
        newsLiveDot.setBackground(pill(0xFFFF4D5E, 4));
        header.addView(newsLiveDot, new LinearLayout.LayoutParams(dp(8.0f), dp(8.0f)));
        TextView live = label(getString(R.string.news_live), 12, textPrimary, 600);
        LinearLayout.LayoutParams liveParams = new LinearLayout.LayoutParams(-2, -2);
        liveParams.setMarginStart(dp(6.0f));
        header.addView(live, liveParams);
        header.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1.0f));
        newsUpdated = label("", 11, textSecondary, 400);
        newsUpdated.setSingleLine(true);
        header.addView(newsUpdated);
        // One headline at a time, the next sliding in from the right on the common beat.
        newsList = ticker(1);
        LinearLayout.LayoutParams listParams = new LinearLayout.LayoutParams(-1, 0, 1.0f);
        listParams.topMargin = dp(2.0f);
        newsCard.addView(newsList, listParams);
        if (newsItems.isEmpty()) {
            loadCachedNews();
        }
        renderNews();
        return newsCard;
    }

    // ---------------------------------------------------------------- clock chip

    private void updateTitleClock() {
        updateTitleClock(System.currentTimeMillis());
    }

    /**
     * The time with the day and the Gregorian month. From five minutes before a prayer until five
     * minutes after its adhan the clock takes the prayer colour and says which prayer it is.
     */
    void updateTitleClock(long at) {
        if (titleClock == null) {
            return;
        }
        Date now = new Date(at);
        Locale locale = Locale.getDefault();
        titleClock.setText(new SimpleDateFormat(android.text.format.DateFormat.is24HourFormat(this) ? "H:mm" : "h:mm", locale).format(now));
        String full = new SimpleDateFormat(android.text.format.DateFormat.getBestDateTimePattern(locale, "EEEEdMMMM"), locale).format(now);
        String twoLines = new SimpleDateFormat("EEEE", locale).format(now) + "\n"
                + new SimpleDateFormat(android.text.format.DateFormat.getBestDateTimePattern(locale, "dMMMM"), locale).format(now);
        String prayer = prayerOn ? prayerNear(at) : null;
        if (prayer != null) {
            int ink = darkWallpaper ? 0xFFFFD27A : 0xFF8F5200;
            titleClock.setTextColor(ink);
            titleDay.setTextColor(ink);
            setTitleDay(prayer, prayer);
            clockChip.setForeground(pill(withAlpha(ink, darkWallpaper ? 0.22f : 0.16f), 20));
        } else if (prayerOn && ramadanLine(at) != null) {
            prayer = ramadanLine(at);
            titleClock.setTextColor(textPrimary);
            titleDay.setTextColor(accentOnWallpaper());
            setTitleDay(prayer, prayer); // "الإفطار" over "بعد ٢ س ١٠ د"
            clockChip.setForeground(null);
        } else {
            titleClock.setTextColor(textPrimary);
            titleDay.setTextColor(textSecondary);
            // "السبت" over "١٤ نوفمبر"; if that can't fit, "السبت" over "١٤".
            setTitleDay(twoLines, new SimpleDateFormat("EEEE", locale).format(now) + "\n" + new SimpleDateFormat("d", locale).format(now));
            clockChip.setForeground(null);
        }
        String hijri = hijriText(now);
        clockChip.setContentDescription(titleClock.getText() + "، " + (prayer != null ? prayer.replace('\n', ' ') + "، " : "") + full
                + (hijri.length() == 0 ? "" : "، " + hijri) + ". " + getString(R.string.clock_chip_hint));
    }

    // ---------------------------------------------------------------- fitting the clock chip

    /**
     * The chips' text sizes follow the phone's font size, but only up to 10% larger: the chips are 40 dp
     * high and share one row, so a bigger font would push the date out of its chip.
     */
    float chipText(float size) {
        float scale = getResources().getConfiguration().fontScale;
        return size * Math.max(0.85f, Math.min(scale, 1.1f));
    }

    private String dayFull = "";
    private String dayShort = "";

    private void setTitleDay(String full, String shorter) {
        dayFull = full == null ? "" : full;
        dayShort = shorter == null ? dayFull : shorter;
        fitTitleDay();
    }

    /** The full date at the largest size that fits the chip, else smaller, else the shorter text. */
    void fitTitleDay() {
        if (titleDay == null) {
            return;
        }
        int room = titleDay.getWidth() - titleDay.getPaddingLeft() - titleDay.getPaddingRight();
        float density = getResources().getDisplayMetrics().density;
        String weekday = dayShort.contains("\n") ? dayShort.substring(0, dayShort.indexOf('\n')) : dayShort;
        Object[] fit = room <= 0 ? new Object[] {dayFull, chipText(11f)}
                : fitText(new android.text.TextPaint(titleDay.getPaint()), density, room, chipText(11f), 8.5f, dayFull, dayShort, weekday);
        String text = (String) fit[0];
        float size = (Float) fit[1];
        if (Math.abs(titleDay.getTextSize() - size * density) > 0.5f) {
            titleDay.setTextSize(TypedValue.COMPLEX_UNIT_DIP, size);
        }
        if (!text.contentEquals(titleDay.getText())) {
            titleDay.setText(text);
        }
    }

    /**
     * The first of {@code choices} whose widest line fits {@code room} pixels at a size from {@code top}
     * down to {@code bottom} (dp), as {text, size}; the last choice at the bottom size when none fits.
     */
    static Object[] fitText(android.text.TextPaint paint, float density, int room, float top, float bottom, String... choices) {
        String last = "";
        for (String choice : choices) {
            if (choice == null || choice.isEmpty()) {
                continue;
            }
            last = choice;
            for (float size = top; size >= bottom - 0.01f; size -= 0.5f) {
                paint.setTextSize(size * density);
                float widest = 0f;
                for (String line : choice.split("\n")) {
                    widest = Math.max(widest, paint.measureText(line));
                }
                if (widest <= room) {
                    return new Object[] {choice, size};
                }
            }
        }
        return new Object[] {last, bottom};
    }

    /** "auto" (in Ramadan only), "on" or "off". */
    String ramadanMode() {
        return prefs.getString("ramadan_mode", "auto");
    }

    /**
     * In Ramadan mode: "الإفطار" over its countdown from Fajr to Maghrib, "الإمساك" over the countdown to
     * the next Fajr otherwise; null when the mode is off, or outside Ramadan in "auto".
     */
    String ramadanLine(long at) {
        String mode = ramadanMode();
        if ("off".equals(mode)) {
            return null;
        }
        long[] today = Prayers.timesFor(prefs, at);
        long fajr = today[PrayerTimes.FAJR];
        long maghrib = today[PrayerTimes.MAGHRIB];
        boolean auto = !"on".equals(mode);
        if (at < fajr) {
            return auto && !HijriEvents.isRamadan(at) ? null : getString(R.string.ramadan_imsak) + "\n" + Prayers.countdown(this, fajr - at);
        }
        if (at < maghrib) {
            return auto && !HijriEvents.isRamadan(at) ? null : getString(R.string.ramadan_iftar) + "\n" + Prayers.countdown(this, maghrib - at);
        }
        long tomorrow = at + 86400000L;
        if (auto && !HijriEvents.isRamadan(tomorrow)) {
            return null;
        }
        long nextFajr = Prayers.timesFor(prefs, tomorrow)[PrayerTimes.FAJR];
        return getString(R.string.ramadan_imsak) + "\n" + Prayers.countdown(this, nextFajr - at);
    }

    /** "العصر" over "بعد ٣ د" in the five minutes before a prayer, over "حان الآن" in the five after; otherwise null. */
    private String prayerNear(long now) {
        long[] times = Prayers.timesFor(prefs, now);
        for (int i = 0; i < times.length; i++) {
            if (i == PrayerTimes.SUNRISE) {
                continue;
            }
            long left = times[i] - now;
            String name = getString(Prayers.NAMES[i]);
            if (left > 0 && left <= 5 * 60000L) {
                return name + "\n" + Prayers.countdown(this, left);
            }
            if (left <= 0 && left > -5 * 60000L) {
                return name + "\n" + getString(R.string.prayer_time_now);
            }
        }
        return null;
    }

    /** The phone's clock app on its alarms, or the clock app itself. */
    private void openAlarms() {
        try {
            startActivity(new Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                        .setPackage("com.sec.android.app.clockpackage"));
            } catch (Exception ignored) {
                openToday();
            }
        }
    }

    // ---------------------------------------------------------------- home cards

    /** A card's own layout inside a stack; the stack gives it the glass. */
    // ---------------------------------------------------------------- wide cards and their ticker lines

    /** The ticker line of the clock card: the next prayer, the Hijri date, the day's occasion. */
    private Ticker clockLines;
    /** Every ticker line on the home cards; they all move on the same beat. */
    private final ArrayList<Ticker> tickers = new ArrayList<>();

    private final Runnable tickerBeat = new Runnable() {
        @Override
        public void run() {
            beatTickers(System.currentTimeMillis());
            scheduleTickerBeat();
        }
    };

    /** A card across the whole width, short; the end side leaves room for the stack's dots. */
    private LinearLayout wideBase() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPaddingRelative(dp(16.0f), dp(10.0f), dp(22.0f), dp(10.0f));
        card.setClickable(true);
        card.setFocusable(true);
        return card;
    }

    /** A small glyph and the card's name; something short at the end (a time, a place). */
    private LinearLayout wideHeader(int glyph, String title, String end) {
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        if (glyph >= 0) {
            ImageView icon = new ImageView(this);
            icon.setImageDrawable(new Glyphs(glyph, accentOnWallpaper(), dp(13.0f)));
            icon.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            header.addView(icon, new LinearLayout.LayoutParams(dp(13.0f), dp(13.0f)));
        }
        TextView name = cardLine(title, 12, textSecondary, 600);
        LinearLayout.LayoutParams nameParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
        if (glyph >= 0) {
            nameParams.setMarginStart(dp(6.0f));
        }
        header.addView(name, nameParams);
        if (end != null && end.length() > 0) {
            header.addView(cardLine(end, 11, textSecondary, 500));
        }
        return header;
    }

    /** A ticker line for a card; it joins the common beat. */
    Ticker ticker(int perPage) {
        Ticker ticker = new Ticker(this, perPage);
        tickers.add(ticker);
        return ticker;
    }

    /** The next beat on the clock's four-second marks, so every line turns at the same moment. */
    void scheduleTickerBeat() {
        uiHandler.removeCallbacks(tickerBeat);
        long now = System.currentTimeMillis();
        uiHandler.postDelayed(tickerBeat, Ticker.BEAT_MS - now % Ticker.BEAT_MS + 15L);
    }

    void stopTickerBeat() {
        uiHandler.removeCallbacks(tickerBeat);
    }

    /**
     * Turns every ticker in view to the item of this beat. With the phone's animations off the items
     * change without sliding; while TalkBack explores the screen they stay still (the card reads them all).
     */
    void beatTickers(long now) {
        AccessibilityManager accessibility = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
        if (accessibility != null && accessibility.isTouchExplorationEnabled()) {
            return;
        }
        boolean slide = ValueAnimator.areAnimatorsEnabled();
        for (int i = tickers.size() - 1; i >= 0; i--) {
            Ticker ticker = tickers.get(i);
            if (ticker.getParent() == null && !ticker.isAttachedToWindow()) {
                tickers.remove(i); // its card was built again
                continue;
            }
            if (ticker.isShown() && !ticker.touching()) {
                ticker.sync(now, slide);
            }
        }
    }

    private LinearLayout cardBase() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16.0f), dp(14.0f), dp(16.0f), dp(14.0f));
        card.setClickable(true);
        card.setFocusable(true);
        return card;
    }

    static boolean isCardType(String type) {
        for (String known : CARD_TYPES) {
            if (known.equals(type)) {
                return true;
            }
        }
        return type != null && type.startsWith("widget:");
    }

    /** What the stack in this slot shows (0 the narrow one, 1 the wide one), in order. */
    List<String> cardTypes(int slot) {
        ArrayList<String> list = new ArrayList<>();
        String raw = prefs.contains("cards_" + slot) ? prefs.getString("cards_" + slot, "") : CARD_DEFAULTS[slot];
        for (String part : raw.split(",")) {
            if (part.length() > 0 && !list.contains(part) && isCardType(part)) {
                list.add(part);
            }
        }
        return list;
    }

    private void saveCardTypes(int slot, List<String> types) {
        prefs.edit().putString("cards_" + slot, TextUtils.join(",", types)).apply();
    }

    /** The calendar was read in the background: show what it holds. */
    void agendaRead() {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        runCardUpdater("agenda");
        runCardUpdater("morning");
        if (todayOpen || twoPane) {
            fillToday();
        }
        SaraWallpaper.redrawAll();
    }

    /** Under 600dp of height (small phones, phones on their side) one card stack instead of two. */
    /** The cards' size: 85, 100 (as designed), 120 or 140 percent (Settings, or a pinch on the home screen). */
    static final int[] CARD_SIZES = {85, 100, 120, 140};

    float cardScale() {
        int size = prefs.getInt("card_size", 100);
        for (int known : CARD_SIZES) {
            if (known == size) {
                return size / 100f;
            }
        }
        return 1f;
    }

    /** One size up or down; false when it is already the biggest or smallest. */
    boolean stepCardSize(int direction) {
        int size = Math.round(cardScale() * 100);
        int index = 1;
        for (int i = 0; i < CARD_SIZES.length; i++) {
            if (CARD_SIZES[i] == size) {
                index = i;
            }
        }
        int next = Math.max(0, Math.min(CARD_SIZES.length - 1, index + direction));
        if (next == index) {
            return false;
        }
        prefs.edit().putInt("card_size", CARD_SIZES[next]).apply();
        fillCards();
        rebuildGlass();
        Toast.makeText(this, getString(R.string.card_size_now, getString(cardSizeName(CARD_SIZES[next]))), Toast.LENGTH_SHORT).show();
        return true;
    }

    static int cardSizeName(int size) {
        switch (size) {
            case 85:
                return R.string.card_size_small;
            case 120:
                return R.string.card_size_large;
            case 140:
                return R.string.card_size_huge;
            default:
                return R.string.card_size_normal;
        }
    }

    boolean singleStack() {
        // With the apps in the drawer, the home screen has room for both stacks on all but the shortest screens.
        return getResources().getConfiguration().screenHeightDp < (drawerMode ? 460 : 600);
    }

    /** Builds both stacks again from the saved choice. */
    private void fillCards() {
        if (cardsRow == null) {
            return;
        }
        forgetGlass(cardGlass);
        cardsRow.removeAllViews();
        cardStacks.clear();
        cardUpdaters.clear();
        clock = null;
        dateCard = null;
        newsCard = null;
        newsList = null;
        clockLines = null;
        tickers.clear();
        newsLiveDot = null;
        newsUpdated = null;
        cardRing = null;
        java.util.HashSet<String> used = new java.util.HashSet<>();
        // A short screen (under 600dp tall) keeps one card, holding both stacks' cards, so the apps keep their room.
        final boolean single = singleStack();
        final float scale = cardScale();
        for (int slot = 0; slot < (single ? 1 : 2); slot++) {
            List<String> types = new ArrayList<>(cardTypes(slot));
            if (single) {
                types.addAll(cardTypes(1));
            }
            if (types.isEmpty()) {
                continue;
            }
            CardStack stack = new CardStack(this, slot, dp(24.0f) / scale);
            ScaleFrame sized = null;
            if (scale != 1f) {
                sized = new ScaleFrame(this, scale, dp(24.0f));
                glassTracked(sized, 24, false, cardGlass);
                sized.addView(stack);
            } else {
                glassTracked(stack, 24, false, cardGlass);
            }
            stack.setVerticalDots(true);
            stack.setDotColors(withAlpha(textPrimary, 0.92f), withAlpha(textPrimary, 0.32f));
            for (String type : types) {
                if (used.add(type)) {
                    View page = cardPage(type, slot);
                    if (page != null) {
                        stack.addPage(type, page, !"news".equals(type) && !type.startsWith("widget:"));
                    }
                }
            }
            if (stack.size() == 0) {
                continue;
            }
            stack.setIndex(prefs.getInt("card_page_" + slot, 0));
            stack.setListener(new CardStack.Listener() {
                @Override
                public void onPageChanged(CardStack changed, int index) {
                    if (!changed.turningBySelf) {
                        prefs.edit().putInt("card_page_" + changed.slot, index).apply();
                    }
                    runCardUpdater(changed.currentType());
                }

                @Override
                public void onLongPress(CardStack held) {
                    cardMenu(single && !cardTypes(0).contains(held.currentType()) ? 1 : held.slot);
                }
            });
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, 0, 1f);
            if (cardsRow.getChildCount() > 0) {
                params.topMargin = dp(8.0f);
            }
            cardsRow.addView(sized != null ? sized : stack, params);
            cardStacks.add(stack);
        }
        int visibleStacks = cardsRow.getChildCount();
        if (visibleStacks == 0 || twoPane) {
            cardsRow.setVisibility(View.GONE);
        } else {
            cardsRow.setVisibility(View.VISIBLE);
            ViewGroup.LayoutParams rowSize = cardsRow.getLayoutParams();
            if (rowSize != null) {
                boolean one = visibleStacks == 1;
                rowSize.height = Math.round(dp(one ? 108.0f : 222.0f) * scale + (one ? 0 : dp(8.0f) * (1f - scale)));
                cardsRow.setLayoutParams(rowSize);
            }
        }
        updateWidgets();
        for (Runnable update : new ArrayList<>(cardUpdaters.values())) {
            update.run();
        }
    }

    // ================================================================ 3.9: messages, answered from the home screen

    /** A reply is being typed in the messages card: it isn't rebuilt under the user's fingers. */
    boolean replying;

    /** The newest message that can be answered (or just read), from the notifications Sara can see. */
    static StatusBarNotificationPick latestMessage(StatusBarNotification[] all) {
        StatusBarNotificationPick best = null;
        int count = 0;
        for (StatusBarNotification sbn : all) {
            Notification n = sbn.getNotification();
            if (n == null || (n.flags & Notification.FLAG_GROUP_SUMMARY) != 0 || (n.flags & Notification.FLAG_ONGOING_EVENT) != 0) {
                continue;
            }
            Notification.Action reply = replyAction(n);
            boolean message = Notification.CATEGORY_MESSAGE.equals(n.category) || reply != null
                    || (n.extras != null && n.extras.containsKey(Notification.EXTRA_MESSAGES));
            if (!message) {
                continue;
            }
            count++;
            if (best == null || sbn.getPostTime() > best.sbn.getPostTime()) {
                best = new StatusBarNotificationPick(sbn, reply);
            }
        }
        if (best != null) {
            best.count = count;
        }
        return best;
    }

    static final class StatusBarNotificationPick {
        final StatusBarNotification sbn;
        final Notification.Action reply;
        int count;

        StatusBarNotificationPick(StatusBarNotification sbn, Notification.Action reply) {
            this.sbn = sbn;
            this.reply = reply;
        }
    }

    static Notification.Action replyAction(Notification n) {
        if (n.actions == null) {
            return null;
        }
        for (Notification.Action action : n.actions) {
            if (action.getRemoteInputs() != null && action.getRemoteInputs().length > 0 && action.actionIntent != null) {
                return action;
            }
        }
        return null;
    }

    private View messagesCard() {
        final LinearLayout card = wideBase();
        card.setOrientation(LinearLayout.VERTICAL);
        cardUpdaters.put("messages", () -> {
            card.removeAllViews();
            boolean access = DotsService.accessGranted(this);
            final StatusBarNotificationPick pick = access ? latestMessage(DotsService.active()) : null;
            String end = pick != null && pick.count > 1 ? NowBar.number(this, pick.count) : null;
            card.addView(wideHeader(Glyphs.SEND, getString(R.string.card_messages), end));
            if (!access) {
                TextView ask = cardLine(getString(R.string.messages_need_access), 13, textSecondary, 500);
                ask.setPadding(0, dp(8.0f), 0, 0);
                card.addView(ask);
                card.setOnClickListener(v -> startSafely(new Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
                return;
            }
            if (pick == null) {
                TextView none = cardLine(getString(R.string.messages_none), 14, textSecondary, 500);
                none.setPadding(0, dp(8.0f), 0, 0);
                card.addView(none);
                card.setOnClickListener(null);
                return;
            }
            final Notification n = pick.sbn.getNotification();
            String who = n.extras == null ? null : String.valueOf(n.extras.getCharSequence(Notification.EXTRA_TITLE, ""));
            String what = n.extras == null ? null : String.valueOf(n.extras.getCharSequence(Notification.EXTRA_TEXT, ""));
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(6.0f), 0, 0);
            AppEntry app = null;
            for (AppEntry entry : apps) {
                if (entry.pkg.equals(pick.sbn.getPackageName())) {
                    app = entry;
                    break;
                }
            }
            if (app != null) {
                ImageView icon = new ImageView(this);
                icon.setImageDrawable(shownIcon(app));
                LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(30.0f), dp(30.0f));
                iconParams.setMarginEnd(dp(10.0f));
                row.addView(icon, iconParams);
            }
            LinearLayout words = new LinearLayout(this);
            words.setOrientation(LinearLayout.VERTICAL);
            boolean hide = privacyMode;
            words.addView(cardLine(hide ? getString(R.string.messages_hidden_who) : (who == null || who.isEmpty() ? appName(pick.sbn.getPackageName()) : who),
                    14, textPrimary, 700));
            words.addView(cardLine(hide ? getString(R.string.messages_hidden_what) : what, 13, textSecondary, 400));
            row.addView(words, new LinearLayout.LayoutParams(0, -2, 1f));
            if (pick.reply != null) {
                TextView answer = label(getString(R.string.messages_reply), 13, Color.WHITE, 600);
                answer.setGravity(Gravity.CENTER);
                answer.setPadding(dp(14.0f), 0, dp(14.0f), 0);
                answer.setBackground(pill(accent, 16));
                answer.setOnClickListener(v -> openReply(card, pick));
                LinearLayout.LayoutParams answerParams = new LinearLayout.LayoutParams(-2, dp(32.0f));
                answerParams.setMarginStart(dp(8.0f));
                row.addView(answer, answerParams);
            }
            card.addView(row, new LinearLayout.LayoutParams(-1, -2));
            card.setOnClickListener(v -> {
                if (n.contentIntent != null) {
                    try {
                        n.contentIntent.send();
                    } catch (Exception ignored) {
                    }
                }
            });
            card.setContentDescription(getString(R.string.card_messages) + (hide ? "" : getString(R.string.list_separator) + who));
        });
        return card;
    }

    /** The card turns into a reply box: type, send, and it goes back to the message. */
    private void openReply(final LinearLayout card, final StatusBarNotificationPick pick) {
        replying = true;
        card.removeAllViews();
        final android.app.RemoteInput input = pick.reply.getRemoteInputs()[0];
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        final EditText field = new EditText(this);
        field.setBackground(pill(withAlpha(textPrimary, 0.12f), 18));
        field.setPadding(dp(14.0f), 0, dp(14.0f), 0);
        field.setTextColor(textPrimary);
        field.setHintTextColor(textSecondary);
        field.setTextSize(15.0f);
        field.setSingleLine(true);
        field.setHint(input.getLabel() != null ? input.getLabel().toString() : getString(R.string.notif_reply_hint));
        field.setImeOptions(EditorInfo.IME_ACTION_SEND | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        row.addView(field, new LinearLayout.LayoutParams(0, dp(42.0f), 1f));
        ImageView send = new ImageView(this);
        send.setImageDrawable(new Glyphs(Glyphs.SEND, Color.WHITE, dp(20.0f)));
        send.setScaleType(ImageView.ScaleType.CENTER);
        send.setBackground(pill(accent, 21));
        send.setContentDescription(getString(R.string.messages_send));
        LinearLayout.LayoutParams sendParams = new LinearLayout.LayoutParams(dp(42.0f), dp(42.0f));
        sendParams.setMarginStart(dp(8.0f));
        row.addView(send, sendParams);
        TextView to = cardLine(getString(R.string.messages_replying_to, appName(pick.sbn.getPackageName())), 12, textSecondary, 500);
        to.setPadding(0, 0, 0, dp(6.0f));
        card.addView(to);
        card.addView(row, new LinearLayout.LayoutParams(-1, -2));
        final Runnable done = () -> {
            replying = false;
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) {
                imm.hideSoftInputFromWindow(field.getWindowToken(), 0);
            }
            runCardUpdater("messages");
        };
        View.OnClickListener sendIt = v -> {
            String text = field.getText().toString().trim();
            if (text.isEmpty()) {
                done.run();
                return;
            }
            if (sendReply(pick.reply, text)) {
                Toast.makeText(this, getString(R.string.messages_sent), Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, getString(R.string.messages_not_sent), Toast.LENGTH_SHORT).show();
            }
            done.run();
        };
        send.setOnClickListener(sendIt);
        field.setOnEditorActionListener((v, actionId, event) -> {
            sendIt.onClick(v);
            return true;
        });
        card.setOnClickListener(null);
        field.requestFocus();
        field.post(() -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) {
                imm.showSoftInput(field, InputMethodManager.SHOW_IMPLICIT);
            }
        });
    }

    /** Hands the text to the app the way Android's own notification reply does. */
    boolean sendReply(Notification.Action action, String text) {
        try {
            Intent result = new Intent();
            Bundle answers = new Bundle();
            for (android.app.RemoteInput input : action.getRemoteInputs()) {
                answers.putCharSequence(input.getResultKey(), text);
            }
            android.app.RemoteInput.addResultsToIntent(action.getRemoteInputs(), result, answers);
            action.actionIntent.send(this, 0, result);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // ================================================================ 3.9: moving in from Nova

    static final int REQUEST_LAYOUT_IMPORT = 7760;

    /** Asks for the backup file (Nova: Settings → Backup and import → Backup). */
    void startLayoutImport() {
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
        try {
            startActivityForResult(pick, REQUEST_LAYOUT_IMPORT);
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.import_no_picker), Toast.LENGTH_LONG).show();
        }
    }

    void importLayout(final Uri uri) {
        Toast.makeText(this, getString(R.string.import_reading), Toast.LENGTH_SHORT).show();
        appExecutor.execute(() -> {
            final NovaImport.Layout layout = NovaImport.read(getApplicationContext(), uri);
            uiHandler.post(() -> applyLayout(layout));
        });
    }

    /** The app on this phone that a component from another launcher stands for (the same screen, or the same app). */
    private AppEntry entryFor(ComponentName component) {
        AppEntry samePackage = null;
        for (AppEntry entry : apps) {
            if (entry.component.equals(component)) {
                return entry;
            }
            if (samePackage == null && entry.pkg.equals(component.getPackageName()) && android.os.Process.myUserHandle().equals(entry.user)) {
                samePackage = entry;
            }
        }
        return samePackage;
    }

    /** Puts the imported dock first in the dock, makes the folders, and (in your own order) the home pages' order. */
    void applyLayout(NovaImport.Layout layout) {
        if (layout == null || layout.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle(getString(R.string.import_title))
                    .setMessage(getString(R.string.import_nothing))
                    .setPositiveButton(getString(R.string.done), null)
                    .show();
            return;
        }
        int docked = 0;
        int dockPageBefore = dockPage;
        dockPage = 0;
        List<String> favorites = getFavorites();
        ArrayList<String> newDock = new ArrayList<>();
        for (ComponentName component : layout.dock) {
            AppEntry entry = entryFor(component);
            if (entry != null && !newDock.contains(entry.key)) {
                newDock.add(entry.key);
                if (!favorites.contains(entry.key)) {
                    docked++;
                }
            }
        }
        for (String key : favorites) {
            if (!newDock.contains(key)) {
                newDock.add(key);
            }
        }
        if (!newDock.equals(favorites)) {
            saveFavorites(newDock);
        }
        dockPage = dockPageBefore;
        int madeFolders = 0;
        for (Map.Entry<String, List<ComponentName>> imported : layout.folders.entrySet()) {
            ArrayList<String> keys = new ArrayList<>();
            for (ComponentName component : imported.getValue()) {
                AppEntry entry = entryFor(component);
                if (entry != null && !keys.contains(entry.key) && Folders.folderOf(folders, entry.key) == null) {
                    keys.add(entry.key);
                }
            }
            if (keys.size() < 2) {
                continue; // a folder of one isn't worth making
            }
            String name = imported.getKey().startsWith("#") ? getString(R.string.import_folder_n, imported.getKey().substring(1)) : imported.getKey();
            Folders.Folder folder = new Folders.Folder(Folders.newId(), name);
            folder.keys.addAll(keys);
            folders.add(folder);
            madeFolders++;
        }
        if (madeFolders > 0) {
            Folders.save(prefs, folders);
        }
        boolean ordered = false;
        if (SORT_MANUAL.equals(sortMode()) && !layout.desktop.isEmpty()) {
            ArrayList<AppEntry> first = new ArrayList<>();
            for (ComponentName component : layout.desktop) {
                AppEntry entry = entryFor(component);
                if (entry != null && !first.contains(entry)) {
                    first.add(entry);
                }
            }
            if (!first.isEmpty()) {
                ArrayList<AppEntry> rest = new ArrayList<>(apps);
                rest.removeAll(first);
                apps.clear();
                apps.addAll(first);
                apps.addAll(rest);
                saveAppOrder();
                ordered = true;
            }
        }
        applyFilter(currentQuery());
        refreshDock();
        StringBuilder message = new StringBuilder(getString(R.string.import_done, NowBar.number(this, docked), NowBar.number(this, madeFolders)));
        if (ordered) {
            message.append("\n").append(getString(R.string.import_ordered));
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.import_title))
                .setMessage(message.toString())
                .setPositiveButton(getString(R.string.done), null)
                .show();
    }

    // ================================================================ 3.9: moving the cards

    private View cardsAbove;
    private View cardsBelow;
    /** Moving the cards: a drag on them, or the arrows, puts them higher or lower on the home screen. */
    boolean movingCards;
    private LinearLayout moveBar;
    private float moveDownY;
    private float moveStartPos;
    private boolean moveDragging;

    /** Held card: change what's in it, move it, or its size. */
    void cardMenu(final int slot) {
        final ArrayList<String> names = new ArrayList<>();
        final ArrayList<Runnable> actions = new ArrayList<>();
        names.add(getString(R.string.cards_edit));
        actions.add(() -> editCards(slot));
        if (cardsAbove != null) {
            names.add(getString(R.string.cards_move));
            actions.add(this::startMovingCards);
        }
        if (cardStacks.size() > 1) {
            names.add(getString(R.string.cards_swap));
            actions.add(this::swapCardStacks);
        }
        names.add(getString(R.string.card_size));
        actions.add(this::pickCardSize);
        names.add(getString(R.string.cards_hide));
        actions.add(() -> {
            saveCardTypes(slot, new ArrayList<>());
            fillCards();
            rebuildGlass();
        });
        new AlertDialog.Builder(this)
                .setItems(names.toArray(new String[0]), (dialog, which) -> actions.get(which).run())
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void pickCardSize() {
        String[] names = new String[CARD_SIZES.length];
        int selected = 1;
        for (int i = 0; i < CARD_SIZES.length; i++) {
            names[i] = getString(cardSizeName(CARD_SIZES[i]));
            if (CARD_SIZES[i] == Math.round(cardScale() * 100)) {
                selected = i;
            }
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.card_size))
                .setSingleChoiceItems(names, selected, (dialog, which) -> {
                    prefs.edit().putInt("card_size", CARD_SIZES[which]).apply();
                    fillCards();
                    rebuildGlass();
                    dialog.dismiss();
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    /** The first stack becomes the second and the second the first, each keeping its cards and the card on show. */
    void swapCardStacks() {
        String first = prefs.getString("cards_0", null);
        String second = prefs.getString("cards_1", null);
        List<String> a = cardTypes(0);
        List<String> b = cardTypes(1);
        int pageA = prefs.getInt("card_page_0", 0);
        int pageB = prefs.getInt("card_page_1", 0);
        prefs.edit().putString("cards_0", second != null ? second : TextUtils.join(",", b))
                .putString("cards_1", first != null ? first : TextUtils.join(",", a))
                .putInt("card_page_0", pageB).putInt("card_page_1", pageA).apply();
        fillCards();
        rebuildGlass();
    }

    /** Where the cards sit in the free part of the home screen: 0 at the top, 1 at the bottom. */
    void placeCards(float position) {
        if (cardsAbove == null || cardsBelow == null) {
            return;
        }
        float at = Math.max(0f, Math.min(1f, position));
        LinearLayout.LayoutParams above = (LinearLayout.LayoutParams) cardsAbove.getLayoutParams();
        LinearLayout.LayoutParams below = (LinearLayout.LayoutParams) cardsBelow.getLayoutParams();
        above.weight = at;
        below.weight = 1f - at;
        cardsAbove.setLayoutParams(above);
        cardsBelow.setLayoutParams(below);
    }

    float cardsPosition() {
        if (cardsAbove == null) {
            return 0f;
        }
        return ((LinearLayout.LayoutParams) cardsAbove.getLayoutParams()).weight;
    }

    void startMovingCards() {
        if (cardsAbove == null || movingCards) {
            return;
        }
        movingCards = true;
        GradientDrawable outline = new GradientDrawable();
        outline.setColor(Color.TRANSPARENT);
        outline.setCornerRadius(dp(26.0f));
        outline.setStroke(Math.max(2, dp(2.0f)), withAlpha(textPrimary, 0.85f), dp(8.0f), dp(6.0f));
        cardsRow.setForeground(outline);
        moveBar = new LinearLayout(this);
        moveBar.setGravity(Gravity.CENTER_VERTICAL);
        moveBar.setPadding(dp(10.0f), 0, dp(6.0f), 0);
        glassify(moveBar, 26, true);
        TextView hint = label(getString(R.string.cards_move_hint), 13, textPrimary, 500);
        hint.setSingleLine(true);
        hint.setEllipsize(TextUtils.TruncateAt.END);
        moveBar.addView(hint, new LinearLayout.LayoutParams(0, -2, 1f));
        moveBar.addView(moveButton(Glyphs.CHEVRON_UP, R.string.cards_move_up, () -> nudgeCards(-0.1f)));
        View down = moveButton(Glyphs.CHEVRON_UP, R.string.cards_move_down, () -> nudgeCards(0.1f));
        ((ImageView) down).setRotation(180f);
        moveBar.addView(down);
        if (cardStacks.size() > 1) {
            moveBar.addView(moveButton(Glyphs.SORT, R.string.cards_swap, this::swapCardStacks));
        }
        TextView done = label(getString(R.string.done), 14, Color.WHITE, 600);
        done.setGravity(Gravity.CENTER);
        done.setPadding(dp(16.0f), 0, dp(16.0f), 0);
        done.setBackground(pill(accent, 18));
        done.setOnClickListener(v -> stopMovingCards());
        LinearLayout.LayoutParams doneParams = new LinearLayout.LayoutParams(-2, dp(36.0f));
        doneParams.setMarginStart(dp(6.0f));
        moveBar.addView(done, doneParams);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(-1, dp(52.0f), Gravity.BOTTOM);
        params.setMargins(dp(14.0f), 0, dp(14.0f), Math.max(root.getPaddingBottom(), gestureBottom) + dp(22.0f));
        frame.addView(moveBar, params);
    }

    private View moveButton(int glyph, int name, final Runnable action) {
        ImageView button = new ImageView(this);
        button.setImageDrawable(new Glyphs(glyph, textPrimary, dp(20.0f)));
        button.setScaleType(ImageView.ScaleType.CENTER);
        button.setContentDescription(getString(name));
        button.setBackground(new RippleDrawable(ColorStateList.valueOf(withAlpha(textPrimary, 0.25f)), null, null));
        button.setOnClickListener(v -> action.run());
        button.setLayoutParams(new LinearLayout.LayoutParams(dp(44.0f), dp(44.0f)));
        return button;
    }

    void nudgeCards(float by) {
        placeCards(cardsPosition() + by);
    }

    void stopMovingCards() {
        if (!movingCards) {
            return;
        }
        movingCards = false;
        moveDragging = false;
        if (cardsRow != null) {
            cardsRow.setForeground(null);
        }
        if (moveBar != null) {
            glassViews.remove(moveBar);
            frame.removeView(moveBar);
            moveBar = null;
        }
        prefs.edit().putFloat("cards_pos", cardsPosition()).apply();
    }

    /** While moving: a finger on the cards drags them up and down; elsewhere, nothing else happens. */
    private boolean moveCardsGesture(MotionEvent event) {
        if (moveBar != null) {
            int[] bar = new int[2];
            moveBar.getLocationOnScreen(bar);
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN && event.getRawY() >= bar[1] && event.getRawY() <= bar[1] + moveBar.getHeight()) {
                moveDragging = false;
                return false; // the bar's own buttons
            }
        }
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                int[] at = new int[2];
                cardsRow.getLocationOnScreen(at);
                moveDragging = event.getRawY() >= at[1] && event.getRawY() <= at[1] + cardsRow.getHeight();
                moveDownY = event.getRawY();
                moveStartPos = cardsPosition();
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (moveDragging) {
                    float free = freeHomeSpace();
                    if (free > 0) {
                        placeCards(moveStartPos + (event.getRawY() - moveDownY) / free);
                    }
                }
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                moveDragging = false;
                return true;
            default:
                return true;
        }
    }

    /** The empty height of the home screen that the cards can move through. */
    float freeHomeSpace() {
        if (cardsAbove == null) {
            return 0f;
        }
        return cardsAbove.getHeight() + cardsBelow.getHeight();
    }

    // ================================================================ 3.9: the usage breaker

    /** The app the breaker's pause just let through (the next launch of it goes ahead). */
    private AppEntry breakerLetThrough;
    AlertDialog breakerDialog;

    /** A short pause before a watched app: how often it was opened today, and a few seconds to think. */
    private void showBreaker(final AppEntry entry, final View source) {
        int opened = Breaker.openedToday(prefs, entry.pkg, System.currentTimeMillis());
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(24.0f), dp(22.0f), dp(24.0f), dp(6.0f));
        ImageView icon = new ImageView(this);
        icon.setImageDrawable(shownIcon(entry));
        box.addView(icon, new LinearLayout.LayoutParams(dp(56.0f), dp(56.0f)));
        boolean night = nightMode();
        int ink = night ? 0xFFF2F2F2 : 0xFF17171A;
        TextView title = label(getString(R.string.breaker_pause_title, entry.label), 18, ink, 700);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(14.0f), 0, dp(6.0f));
        box.addView(title, new LinearLayout.LayoutParams(-1, -2));
        TextView body = label(opened == 0 ? getString(R.string.breaker_first_today)
                : getString(R.string.breaker_opened_today, NowBar.number(this, opened)), 14, withAlpha(ink, 0.75f), 400);
        body.setGravity(Gravity.CENTER);
        box.addView(body, new LinearLayout.LayoutParams(-1, -2));
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(box)
                .setPositiveButton(getString(R.string.breaker_open_in, NowBar.number(this, Breaker.PAUSE_SECONDS)), null)
                .setNegativeButton(getString(R.string.breaker_not_now), null)
                .create();
        dialog.setOnShowListener(d -> {
            final android.widget.Button open = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            open.setEnabled(false);
            final int[] left = {Breaker.PAUSE_SECONDS};
            final Runnable[] tick = new Runnable[1];
            tick[0] = () -> {
                if (!dialog.isShowing()) {
                    return;
                }
                left[0]--;
                if (left[0] <= 0) {
                    open.setEnabled(true);
                    open.setText(getString(R.string.breaker_open));
                } else {
                    open.setText(getString(R.string.breaker_open_in, NowBar.number(this, left[0])));
                    uiHandler.postDelayed(tick[0], 1000L);
                }
            };
            uiHandler.postDelayed(tick[0], 1000L);
            open.setOnClickListener(v -> {
                dialog.dismiss();
                breakerLetThrough = entry;
                launch(entry, source);
            });
        });
        dialog.show();
        breakerDialog = dialog;
    }

    // ================================================================ 3.9: "now"

    private android.widget.HorizontalScrollView nowScroll;
    private LinearLayout nowRow;
    private String nowStamp = "";
    boolean torchOn;
    private String torchId;
    private android.hardware.camera2.CameraManager.TorchCallback nowTorch;
    private final Runnable nowRefresher = () -> {
        refreshNow();
        if (!replying) {
            runCardUpdater("messages");
        }
    };

    private void addNowRow(LinearLayout column) {
        nowScroll = new android.widget.HorizontalScrollView(this);
        nowScroll.setHorizontalScrollBarEnabled(false);
        nowScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        nowScroll.setVisibility(View.GONE);
        nowRow = new LinearLayout(this);
        nowRow.setOrientation(LinearLayout.HORIZONTAL);
        nowRow.setGravity(Gravity.CENTER_VERTICAL);
        nowScroll.addView(nowRow, new FrameLayout.LayoutParams(-2, -1));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(36.0f));
        params.topMargin = dp(8.0f);
        column.addView(nowScroll, params);
    }

    /** Follows the torch, so "the torch is on" shows up whichever way it was turned on. */
    private void watchTorch(boolean on) {
        android.hardware.camera2.CameraManager cameras = getSystemService(android.hardware.camera2.CameraManager.class);
        if (cameras == null) {
            return;
        }
        try {
            if (on && nowTorch == null) {
                torchId = NowBar.torchCamera(this);
                nowTorch = new android.hardware.camera2.CameraManager.TorchCallback() {
                    @Override
                    public void onTorchModeChanged(String cameraId, boolean enabled) {
                        if (cameraId.equals(torchId) && enabled != torchOn) {
                            torchOn = enabled;
                            refreshNow();
                        }
                    }
                };
                cameras.registerTorchCallback(nowTorch, uiHandler);
            } else if (!on && nowTorch != null) {
                cameras.unregisterTorchCallback(nowTorch);
                nowTorch = null;
            }
        } catch (Exception ignored) {
        }
    }

    void refreshNow() {
        if (nowRow == null) {
            return;
        }
        long now = System.currentTimeMillis();
        List<NowBar.Item> items = prefs.getBoolean("now_bar", true) && !kidsShowing()
                ? NowBar.items(this, now, torchOn, prayerOn ? prayerNear(now) : null) : Collections.<NowBar.Item>emptyList();
        StringBuilder stamp = new StringBuilder();
        for (NowBar.Item item : items) {
            stamp.append(item.kind).append(':').append(item.text).append(':').append(item.chronoBase / 1000).append('|');
        }
        stamp.append(accent).append(darkWallpaper);
        if (stamp.toString().equals(nowStamp)) {
            return;
        }
        nowStamp = stamp.toString();
        nowRow.removeAllViews();
        for (final NowBar.Item item : items) {
            nowRow.addView(nowChip(item));
        }
        nowScroll.setVisibility(items.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private View nowChip(final NowBar.Item item) {
        LinearLayout chip = new LinearLayout(this);
        chip.setGravity(Gravity.CENTER_VERTICAL);
        chip.setPadding(dp(11.0f), 0, dp(13.0f), 0);
        boolean urgent = item.kind == NowBar.CALL || item.kind == NowBar.MISSED || item.kind == NowBar.TORCH;
        GradientDrawable shape = pill(urgent ? withAlpha(accent, 0.85f) : withAlpha(textPrimary, 0.13f), 17);
        if (!urgent) {
            shape.setStroke(Math.max(1, dp(0.8f)), withAlpha(textPrimary, 0.18f));
        }
        chip.setBackground(shape);
        int ink = urgent ? Color.WHITE : textPrimary;
        ImageView glyph = new ImageView(this);
        glyph.setImageDrawable(new Glyphs(item.glyph(), ink, dp(16.0f)));
        chip.addView(glyph, new LinearLayout.LayoutParams(dp(16.0f), dp(16.0f)));
        TextView text = label(item.text, 13, ink, 600);
        text.setSingleLine(true);
        text.setEllipsize(TextUtils.TruncateAt.END);
        text.setMaxWidth(dp(190.0f));
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(-2, -2);
        textParams.setMarginStart(dp(7.0f));
        chip.addView(text, textParams);
        String spoken = item.text;
        if (item.chrono) {
            android.widget.Chronometer clock = new android.widget.Chronometer(this);
            clock.setBase(item.chronoBase);
            if (Build.VERSION.SDK_INT >= 24) {
                clock.setCountDown(item.countDown);
            }
            clock.setTextColor(ink);
            clock.setTextSize(13.0f);
            clock.setTypeface(font(700));
            LinearLayout.LayoutParams clockParams = new LinearLayout.LayoutParams(-2, -2);
            clockParams.setMarginStart(dp(6.0f));
            chip.addView(clock, clockParams);
            clock.start();
        }
        chip.setContentDescription(spoken);
        chip.setOnClickListener(v -> nowTapped(item));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, dp(34.0f));
        params.setMarginEnd(dp(7.0f));
        chip.setLayoutParams(params);
        chip.setTag(item.kind);
        return chip;
    }

    /** A tap on a pill: the torch goes off; anything else opens where it came from. */
    void nowTapped(NowBar.Item item) {
        if (item.kind == NowBar.TORCH) {
            try {
                if (torchId != null) {
                    getSystemService(android.hardware.camera2.CameraManager.class).setTorchMode(torchId, false);
                }
            } catch (Exception ignored) {
            }
            torchOn = false;
            refreshNow();
            return;
        }
        if (item.open != null) {
            try {
                item.open.send();
                return;
            } catch (Exception ignored) {
            }
        }
        if (item.kind == NowBar.ALARM) {
            openAlarms();
        } else if (item.kind == NowBar.PRAYER) {
            openToday();
        } else if (item.kind == NowBar.MISSED) {
            startSafely(new Intent(Intent.ACTION_VIEW, android.provider.CallLog.Calls.CONTENT_URI));
        }
    }

    // ================================================================ 3.9: television

    /** The TV screen, when Sara runs on a TV (or the TV layout is turned on). */
    TvHome tv;
    AlertDialog tvDialog;

    String wallpaperForTv() {
        return Wallpapers.DEVICE.equals(wallpaperId) ? Wallpapers.DEFAULT : wallpaperId; // a TV has no wallpaper of its own
    }

    /** Every app that isn't hidden, in the order chosen (favourites too: a TV shows them in both rows). */
    List<AppEntry> tvApps() {
        Set<String> hidden = hiddenKeys();
        Set<String> locked = lockedKeys();
        ArrayList<AppEntry> list = new ArrayList<>();
        for (AppEntry entry : apps) {
            if (!hidden.contains(entry.key) && !locked.contains(entry.key)) {
                list.add(entry);
            }
        }
        final Collator collator = labelCollator();
        String mode = sortMode();
        if (SORT_ALPHA.equals(mode)) {
            Collections.sort(list, (a, b) -> collator.compare(a.label, b.label));
        } else if (SORT_USAGE.equals(mode)) {
            Collections.sort(list, (a, b) -> {
                int byUse = usage.total(b.key) - usage.total(a.key);
                return byUse != 0 ? byUse : collator.compare(a.label, b.label);
            });
        }
        return list;
    }

    List<AppEntry> tvFavorites() {
        ArrayList<AppEntry> list = new ArrayList<>();
        String saved = prefs.getString("favorites", null);
        if (saved == null) {
            return list; // a TV starts with no favourites: the remote's held OK adds them
        }
        for (String key : getFavorites()) {
            AppEntry entry = findByKey(key);
            if (entry != null) {
                list.add(entry);
            }
        }
        return list;
    }

    boolean tvIsFavorite(AppEntry entry) {
        return prefs.contains("favorites") && getFavorites().contains(entry.key);
    }

    void tvSetFavorite(AppEntry entry, boolean on) {
        List<String> list = prefs.contains("favorites") ? getFavorites() : new ArrayList<>();
        list.remove(entry.key);
        if (on) {
            list.add(entry.key);
        }
        prefs.edit().putString("favorites", TextUtils.join("|", list)).apply();
        tv.appsChanged();
    }

    void tvAppInfo(AppEntry entry) {
        openAppInfo(entry);
    }

    void tvUninstall(AppEntry entry) {
        uninstall(entry);
    }

    void tvHide(AppEntry entry) {
        hideApp(entry);
        tv.appsChanged();
    }

    // ================================================================ 3.9: the app drawer

    boolean drawerMode;
    AppDrawer drawer;
    private GestureFrame homeFrame;
    private LinearLayout homeSearchPill;
    private View drawerButton;
    private android.widget.HorizontalScrollView chipScroll;
    private LinearLayout chipRow;
    /** The category shown in the drawer; null for every app. */
    String drawerCategory;
    private TextView drawerEmpty;
    private LinearLayout storeRow;
    private TextView storeText;
    private ImageView searchClear;
    private GradientDrawable searchRing;
    private boolean drawerDragging;
    private String chipsStamp = "";
    static final String CATEGORY_FREQUENT = "frequent";

    boolean animationsOn() {
        return ValueAnimator.areAnimatorsEnabled();
    }

    /** The drawer may come up: nothing else is open over the home screen. */
    boolean drawerAllowed() {
        return drawer != null && !(controlCenter != null && controlCenter.isShowing())
                && !(notifications != null && notifications.isOpen()) && !todayOpen && folderPopup == null
                && !(appPopup != null && appPopup.isShowing()) && !kidsShowing() && !driveShowing();
    }

    void openDrawer(boolean withSearch) {
        if (drawer == null || !drawerAllowed()) {
            return;
        }
        drawer.open(true);
        if (withSearch) {
            openSearch();
        }
    }

    void closeDrawer(boolean animate) {
        if (drawer == null) {
            return;
        }
        drawer.close(animate);
    }

    void onDrawerOpened() {
        dismissAppPopup();
        refreshChips();
    }

    void onDrawerClosed() {
        drawerDragging = false;
        if (isSearchOpen()) {
            closeSearch();
        }
        if (reorderMode) {
            setReorderMode(false);
        }
        if (drawerCategory != null) {
            drawerCategory = null;
            refreshChips();
            applyFilter(currentQuery());
        }
        dismissFolderPopup();
    }

    /** The home screen fades back as the drawer comes up over it. */
    void drawerProgress(float shown) {
        if (root != null) {
            root.setAlpha(1f - 0.85f * shown);
            float scale = 1f - 0.035f * shown;
            root.setScaleX(scale);
            root.setScaleY(scale);
        }
        if (ccHandle != null) {
            ccHandle.setAlpha(1f - shown);
        }
    }

    /** Swipes on the home screen: down for the notifications, up for the drawer (following the finger). */
    private GestureFrame.Callback homeGestures() {
        return new GestureFrame.Callback() {
            @Override
            public void onSwipe(float dx) {
            }

            @Override
            public boolean tracksPull() {
                return prefs.getBoolean("pull_down_notifications", true) && prefs.getBoolean("sara_shade", true) && notifications != null;
            }

            @Override
            public void onPullDrag(float dy) {
                notifications.pullTo(dy);
            }

            @Override
            public void onPullEnd(float dy, float velocityY) {
                notifications.endPull(dy, velocityY);
            }

            @Override
            public void onPullDown() {
                if (prefs.getBoolean("pull_down_notifications", true)) {
                    if (prefs.getBoolean("sara_shade", true) && notifications != null) {
                        notifications.open();
                        return;
                    }
                    expandNotifications();
                }
            }

            @Override
            public boolean canPullDown() {
                return prefs.getBoolean("pull_down_notifications", true) && !(drawer != null && drawer.isOpen())
                        && !(notifications != null && notifications.isOpen());
            }

            @Override
            public boolean canPushUp() {
                return drawerAllowed() && !drawer.isOpen();
            }

            @Override
            public boolean tracksPush() {
                return true;
            }

            @Override
            public void onPushDrag(float up) {
                if (!drawerDragging) {
                    drawerDragging = true;
                    drawer.beginDrag();
                }
                drawer.dragTo(up);
            }

            @Override
            public void onPushEnd(float up, float velocityY) {
                if (!drawerDragging) {
                    return;
                }
                drawerDragging = false;
                drawer.endDrag(velocityY);
            }

            @Override
            public void onPushUp() {
                openDrawer(false);
            }

            @Override
            public void onPinch(float scale) {
                stepCardSize(scale > 1f ? 1 : -1); // fingers apart: bigger cards; together: smaller
            }
        };
    }

    /** The drawer's search: taller, rounder, with a ring while typing and a button that clears it. */
    private void styleDrawerSearch(ViewGroup apps) {
        glassify(searchBar, 26, true);
        searchBar.setPadding(dp(16.0f), 0, dp(6.0f), 0);
        searchBrand.setLayoutParams(new LinearLayout.LayoutParams(dp(22.0f), dp(22.0f)));
        search.setHint(getString(R.string.drawer_search_hint));
        search.setTextSize(16.0f);
        searchRing = new GradientDrawable();
        searchRing.setCornerRadius(dp(26.0f));
        searchRing.setStroke(Math.max(2, dp(1.6f)), darkWallpaper ? mix(accent, Color.WHITE, 0.45f) : accent);
        searchRing.setAlpha(0);
        searchBar.setForeground(searchRing);
        search.setOnFocusChangeListener((v, focused) -> {
            ObjectAnimator ring = ObjectAnimator.ofInt(searchRing, "alpha", searchRing.getAlpha(), focused ? 255 : 0);
            ring.setDuration(180);
            ring.addUpdateListener(a -> searchBar.invalidate());
            ring.start();
        });
        searchClear = new ImageView(this);
        searchClear.setImageDrawable(new Glyphs(Glyphs.CLOSE, textPrimary, dp(16.0f)));
        searchClear.setScaleType(ImageView.ScaleType.CENTER);
        searchClear.setBackground(pill(withAlpha(textPrimary, 0.14f), 15));
        searchClear.setContentDescription(getString(R.string.search_clear));
        searchClear.setVisibility(View.GONE);
        searchClear.setOnClickListener(v -> {
            search.setText("");
            search.requestFocus();
        });
        LinearLayout.LayoutParams clearParams = new LinearLayout.LayoutParams(dp(30.0f), dp(30.0f));
        clearParams.setMarginEnd(dp(5.0f));
        searchBar.addView(searchClear, searchBar.indexOfChild(micButton), clearParams);
        // The categories, under the search: everything, the most used, then the kinds of app on the phone.
        chipScroll = new android.widget.HorizontalScrollView(this);
        chipScroll.setHorizontalScrollBarEnabled(false);
        chipScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        chipScroll.setClipToPadding(false);
        chipRow = new LinearLayout(this);
        chipRow.setOrientation(LinearLayout.HORIZONTAL);
        chipRow.setGravity(Gravity.CENTER_VERTICAL);
        chipScroll.addView(chipRow, new FrameLayout.LayoutParams(-2, -1));
        LinearLayout.LayoutParams chipsParams = new LinearLayout.LayoutParams(-1, dp(36.0f));
        chipsParams.topMargin = dp(10.0f);
        apps.addView(chipScroll, chipsParams);
    }

    /** Under the grid: a word when nothing matches, then Google and the store, close to the keyboard. */
    private void addDrawerExtras(ViewGroup apps, LinearLayout.LayoutParams webParams) {
        drawerEmpty = label(getString(R.string.drawer_no_match), 15, textSecondary, 500);
        drawerEmpty.setGravity(Gravity.CENTER);
        drawerEmpty.setVisibility(View.GONE);
        drawerEmpty.setPadding(dp(24.0f), 0, dp(24.0f), 0);
        gridFrame.addView(drawerEmpty, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));
        apps.addView(webRow, webParams);
        storeRow = new LinearLayout(this);
        storeRow.setGravity(Gravity.CENTER_VERTICAL);
        storeRow.setPadding(dp(16.0f), 0, dp(16.0f), 0);
        glassify(storeRow, 22, true);
        storeRow.setVisibility(View.GONE);
        ImageView bag = new ImageView(this);
        bag.setImageDrawable(new Glyphs(Glyphs.BAG, textPrimary, dp(20.0f)));
        storeRow.addView(bag, new LinearLayout.LayoutParams(dp(20.0f), dp(20.0f)));
        storeText = label("", 14, textPrimary, 500);
        storeText.setSingleLine(true);
        storeText.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams storeTextParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
        storeTextParams.setMarginStart(dp(12.0f));
        storeRow.addView(storeText, storeTextParams);
        storeRow.setOnClickListener(v -> searchStore(currentQuery()));
        LinearLayout.LayoutParams storeParams = new LinearLayout.LayoutParams(-1, dp(44.0f));
        storeParams.topMargin = dp(6.0f);
        apps.addView(storeRow, storeParams);
    }

    /** The home screen's search: a glass pill that opens the drawer ready to type. */
    private void addHomeSearchPill(LinearLayout column) {
        homeSearchPill = new LinearLayout(this);
        homeSearchPill.setGravity(Gravity.CENTER_VERTICAL);
        homeSearchPill.setPadding(dp(14.0f), 0, dp(4.0f), 0);
        glassify(homeSearchPill, 24, true);
        ImageView mark = new ImageView(this);
        Drawable google = googleMark();
        mark.setImageDrawable(google != null ? google : new Glyphs(Glyphs.SEARCH, textSecondary, dp(22.0f)));
        mark.setScaleType(ImageView.ScaleType.FIT_CENTER);
        homeSearchPill.addView(mark, new LinearLayout.LayoutParams(dp(24.0f), dp(24.0f)));
        TextView hint = label(getString(getResources().getConfiguration().screenWidthDp < 360 ? R.string.search_short : R.string.search_google),
                15, textSecondary, 400);
        hint.setSingleLine(true);
        hint.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams hintParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
        hintParams.setMarginStart(dp(10.0f));
        homeSearchPill.addView(hint, hintParams);
        ImageView mic = new ImageView(this);
        mic.setImageDrawable(new Glyphs(Glyphs.MIC, textPrimary, dp(22.0f)));
        mic.setScaleType(ImageView.ScaleType.CENTER);
        mic.setContentDescription(getString(R.string.voice_search));
        mic.setBackground(new RippleDrawable(ColorStateList.valueOf(darkWallpaper ? 0x33FFFFFF : 0x22000000), null, null));
        mic.setOnClickListener(view -> voiceSearch());
        homeSearchPill.addView(mic, new LinearLayout.LayoutParams(dp(40.0f), dp(40.0f)));
        homeSearchPill.setContentDescription(getString(R.string.search_google));
        homeSearchPill.setOnClickListener(view -> openDrawer(true));
        LinearLayout.LayoutParams pillParams = new LinearLayout.LayoutParams(-1, dp(48.0f));
        pillParams.topMargin = dp(12.0f);
        column.addView(homeSearchPill, pillParams);
        // The rest stays open: the wallpaper, and room for a swipe up to bring the drawer.
        View rest = new View(this);
        column.addView(rest, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        cardsBelow = rest;
        // Room above the cards, so they can be moved down the screen (none until they are).
        cardsAbove = new View(this);
        column.addView(cardsAbove, column.indexOfChild(cardsRow), new LinearLayout.LayoutParams(-1, 0, 0f));
        placeCards(prefs.getFloat("cards_pos", 0f));
    }

    /** Searches the store (Google Play, or whichever store opens market links) for apps with this name. */
    void searchStore(String query) {
        String text = query == null ? "" : query.trim();
        if (text.isEmpty()) {
            return;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=" + Uri.encode(text) + "&c=apps")));
            return;
        } catch (Exception ignored) {
        }
        startSafely(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=" + Uri.encode(text) + "&c=apps")));
    }

    /** The drawer category of an app, worked out once from its package, name and declared kind. */
    String groupOf(AppEntry entry) {
        if (!entry.grouped) {
            entry.group = AutoFolders.categorize(entry.pkg, entry.label, entry.category);
            entry.grouped = true;
        }
        return entry.group;
    }

    /** The apps in a drawer category, A to Z (the most used: by use). Docked and foldered apps show too. */
    private List<AppEntry> appsInCategory(String category, Set<String> hidden) {
        ArrayList<AppEntry> list = new ArrayList<>();
        Set<String> locked = privateUnlocked ? Collections.<String>emptySet() : lockedKeys();
        final Collator collator = labelCollator();
        if (CATEGORY_FREQUENT.equals(category)) {
            for (AppEntry entry : apps) {
                if (!hidden.contains(entry.key) && !locked.contains(entry.key) && usage.total(entry.key) > 0) {
                    list.add(entry);
                }
            }
            Collections.sort(list, (a, b) -> {
                int byUse = usage.total(b.key) - usage.total(a.key);
                return byUse != 0 ? byUse : collator.compare(a.label, b.label);
            });
            return list.size() > 16 ? new ArrayList<>(list.subList(0, 16)) : list;
        }
        for (AppEntry entry : apps) {
            if (!hidden.contains(entry.key) && !locked.contains(entry.key) && category.equals(groupOf(entry))) {
                list.add(entry);
            }
        }
        Collections.sort(list, (a, b) -> collator.compare(a.label, b.label));
        return list;
    }

    /** The chips: all, most used (once there's history), then each kind with at least two apps. */
    void refreshChips() {
        if (chipRow == null) {
            return;
        }
        Set<String> hidden = hiddenKeys();
        LinkedHashMap<String, Integer> counts = new LinkedHashMap<>();
        boolean frequent = false;
        for (AppEntry entry : apps) {
            if (hidden.contains(entry.key)) {
                continue;
            }
            if (!frequent && usage.total(entry.key) > 0) {
                frequent = true;
            }
            String group = groupOf(entry);
            if (group != null) {
                Integer old = counts.get(group);
                counts.put(group, old == null ? 1 : old + 1);
            }
        }
        ArrayList<String> ids = new ArrayList<>();
        if (frequent) {
            ids.add(CATEGORY_FREQUENT);
        }
        for (String id : AutoFolders.ORDER) {
            Integer count = counts.get(id);
            if (count != null && count >= 2) {
                ids.add(id);
            }
        }
        if (drawerCategory != null && !ids.contains(drawerCategory)) {
            drawerCategory = null;
        }
        String stamp = ids + "|" + drawerCategory + "|" + accent + "|" + darkWallpaper;
        if (stamp.equals(chipsStamp) && chipRow.getChildCount() > 0) {
            return;
        }
        chipsStamp = stamp;
        chipRow.removeAllViews();
        chipRow.addView(chip(null, getString(R.string.drawer_all)));
        for (String id : ids) {
            chipRow.addView(chip(id, getString(CATEGORY_FREQUENT.equals(id) ? R.string.drawer_frequent : AutoFolders.nameRes(id))));
        }
        chipScroll.setVisibility(ids.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private TextView chip(final String id, String name) {
        boolean selected = id == null ? drawerCategory == null : id.equals(drawerCategory);
        TextView chip = label(name, 13, selected ? Color.WHITE : textPrimary, selected ? 600 : 500);
        chip.setGravity(Gravity.CENTER);
        chip.setSingleLine(true);
        chip.setPadding(dp(15.0f), 0, dp(15.0f), 0);
        GradientDrawable shape = pill(selected ? accent : withAlpha(textPrimary, 0.10f), 17);
        if (!selected) {
            shape.setStroke(Math.max(1, dp(0.8f)), withAlpha(textPrimary, 0.16f));
        }
        chip.setBackground(shape);
        chip.setSelected(selected);
        chip.setTag(id == null ? "all" : id);
        chip.setOnClickListener(v -> setDrawerCategory(id));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, dp(34.0f));
        params.setMarginEnd(dp(7.0f));
        chip.setLayoutParams(params);
        return chip;
    }

    void setDrawerCategory(String id) {
        if (id == null ? drawerCategory == null : id.equals(drawerCategory)) {
            return;
        }
        drawerCategory = id;
        refreshChips();
        applyFilter(currentQuery());
        if (grid != null) {
            grid.setSelection(0);
        }
    }

    /** After each filter: the clear button, the chips while typing, the word for no match and the store row. */
    private void afterDrawerFilter(String normalized) {
        boolean typing = normalized.length() > 0;
        if (searchClear != null) {
            searchClear.setVisibility(typing ? View.VISIBLE : View.GONE);
            micButton.setVisibility(typing ? View.GONE : View.VISIBLE);
        }
        if (chipScroll != null && chipRow.getChildCount() > 1) {
            chipScroll.setVisibility(typing ? View.GONE : View.VISIBLE);
        }
        boolean none = typing && filteredApps.isEmpty();
        if (drawerEmpty != null) {
            drawerEmpty.setVisibility(none ? View.VISIBLE : View.GONE);
        }
        if (storeRow != null) {
            boolean show = typing && !reorderMode;
            if (show) {
                String label = getString(R.string.search_store_for, currentQuery().trim());
                storeText.setText(label);
                storeRow.setContentDescription(label);
            }
            storeRow.setVisibility(show ? View.VISIBLE : View.GONE);
        }
    }

    /** The app Enter would open now: the first match when its name (or a word in it) starts with the text. */
    AppEntry topHit() {
        String normalized = ArabicText.normalize(currentQuery().trim());
        if (normalized.isEmpty() || filteredApps.isEmpty()) {
            return null;
        }
        AppEntry best = filteredApps.get(0);
        int score = ArabicText.matchScore(best.searchLabel, best.pkg, normalized);
        return score == 0 || score == 1 ? best : null;
    }

    /**
     * The part of a name that matches the search, in the accent colour. Colour only: a bold part would be
     * shaped on its own, and Arabic letters would stop joining across it.
     */
    CharSequence highlighted(String label) {
        String query = currentQuery().trim();
        if (query.isEmpty() || drawer == null) {
            return label;
        }
        int[] range = ArabicText.matchRange(label, query);
        if (range == null) {
            return label;
        }
        android.text.SpannableString text = new android.text.SpannableString(label);
        int color = darkWallpaper ? mix(accent, Color.WHITE, 0.38f) : mix(accent, Color.BLACK, 0.2f);
        text.setSpan(new android.text.style.ForegroundColorSpan(color), range[0], range[1], android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return text;
    }

    // ================================================================ 3.7

    // ---------------------------------------------------------------- the light of the hour on the wallpaper

    private Ambience.Layer ambienceLayer;
    private String ambienceStamp = "";

    /** Built-in art takes the hour's light, the weather and the occasions; a photo or the phone's own wallpaper doesn't. */
    private boolean ambienceApplies() {
        return !Wallpapers.DEVICE.equals(wallpaperId) && !Wallpapers.PHOTO.equals(wallpaperId);
    }

    private Drawable wallpaperWithAmbience() {
        Drawable art = Wallpapers.create(this, wallpaperId);
        if (!ambienceApplies()) {
            ambienceLayer = null;
            return art;
        }
        Ambience.State state = Ambience.now(this, prefs, System.currentTimeMillis(), !Wallpapers.isDark(this, wallpaperId));
        ambienceStamp = state.stamp();
        ambienceLayer = new Ambience.Layer(state, false);
        return new android.graphics.drawable.LayerDrawable(new Drawable[]{art, ambienceLayer});
    }

    /** Each minute: when the light, the weather or the occasion changed, redraw the wallpaper and the glass. */
    void updateAmbience(long now) {
        if (ambienceLayer == null || !ambienceApplies()) {
            return;
        }
        Ambience.State state = Ambience.now(this, prefs, now, !Wallpapers.isDark(this, wallpaperId));
        String stamp = state.stamp();
        ambienceLayer.state = state;
        if (!stamp.equals(ambienceStamp)) {
            ambienceStamp = stamp;
            if (root != null) {
                root.invalidate();
                if (root.getBackground() != null) {
                    root.getBackground().invalidateSelf();
                }
            }
            rebuildGlass();
        }
    }

    // ---------------------------------------------------------------- headphones and the car

    private boolean headphonesOn;
    private boolean carOn;
    private String carName = "";
    private android.media.AudioDeviceCallback audioCallback;
    private FrameLayout drivePanel;

    private void watchAudioRoutes() {
        android.media.AudioManager audio = getSystemService(android.media.AudioManager.class);
        if (audio == null) {
            return;
        }
        audioCallback = new android.media.AudioDeviceCallback() {
            @Override
            public void onAudioDevicesAdded(android.media.AudioDeviceInfo[] added) {
                audioRoutesChanged();
            }

            @Override
            public void onAudioDevicesRemoved(android.media.AudioDeviceInfo[] removed) {
                audioRoutesChanged();
            }
        };
        try {
            audio.registerAudioDeviceCallback(audioCallback, uiHandler);
        } catch (Exception ignored) {
        }
    }

    /** Works out headphones and the car from the outputs now connected, and acts on a change. */
    void audioRoutesChanged() {
        android.media.AudioManager audio = getSystemService(android.media.AudioManager.class);
        if (audio == null) {
            return;
        }
        boolean phones = false;
        boolean car = false;
        String carDevice = "";
        for (android.media.AudioDeviceInfo device : audio.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)) {
            int type = device.getType();
            String name = device.getProductName() == null ? "" : device.getProductName().toString();
            if (AudioRoutes.bluetooth(type)) {
                AudioRoutes.remember(prefs, name);
                if (AudioRoutes.isCar(prefs, name)) {
                    car = true;
                    carDevice = name;
                } else {
                    phones = true;
                }
            } else if (AudioRoutes.wired(type)) {
                phones = true;
            }
        }
        applyRoutes(phones, car, carDevice);
    }

    /** Acts on the headphones and the car coming and going. */
    void applyRoutes(boolean phones, boolean car, String carDevice) {
        boolean wasCar = carOn;
        boolean changed = phones != headphonesOn || car != carOn;
        headphonesOn = phones;
        carOn = car;
        carName = carDevice;
        if (!changed) {
            return;
        }
        boostForContext();
        refreshSuggestions();
        smartStacks(System.currentTimeMillis());
        runCardUpdater("music");
        if (car && !wasCar && prefs.getBoolean(AudioRoutes.PREF_DRIVE, true) && !Kids.on(prefs)) {
            showDrivePanel();
        } else if (!car && wasCar) {
            hideDrivePanel();
            if (prefs.getBoolean(AudioRoutes.PREF_PARKING, true)) {
                rememberParking();
            }
        }
    }

    /** Music apps come first in the suggestions with headphones on; maps and music in the car. */
    private void boostForContext() {
        if (usage == null) {
            return;
        }
        HashSet<String> boosted = new HashSet<>();
        if (headphonesOn || carOn) {
            for (AppEntry entry : apps) {
                int category = appCategory(entry);
                boolean audioApp = category == android.content.pm.ApplicationInfo.CATEGORY_AUDIO || musicName(entry.pkg);
                boolean maps = category == android.content.pm.ApplicationInfo.CATEGORY_MAPS || entry.pkg.contains("waze")
                        || entry.pkg.equals("com.google.android.apps.maps");
                if (audioApp || (carOn && maps)) {
                    boosted.add(entry.key);
                }
            }
        }
        usage.boosted = boosted;
    }

    private static boolean musicName(String pkg) {
        String p = pkg.toLowerCase(Locale.ROOT);
        return p.contains("spotify") || p.contains("anghami") || p.contains("music") || p.contains("podcast") || p.contains("deezer")
                || p.contains("soundcloud") || p.contains("audible") || p.contains("radio") || p.contains("quran") && p.contains("audio");
    }

    private final HashMap<String, Integer> categories = new HashMap<>();

    int appCategory(AppEntry entry) {
        if (entry.category >= 0) {
            return entry.category;
        }
        Integer known = categories.get(entry.pkg);
        if (known != null) {
            return known;
        }
        int category = -1;
        try {
            category = getPackageManager().getApplicationInfo(entry.pkg, 0).category;
        } catch (Exception ignored) {
        }
        categories.put(entry.pkg, category);
        return category;
    }

    /** The first installed app of these packages or of this category. */
    private AppEntry firstApp(int category, String... packages) {
        for (String pkg : packages) {
            for (AppEntry entry : apps) {
                if (entry.pkg.equals(pkg)) {
                    return entry;
                }
            }
        }
        AppEntry best = null;
        for (AppEntry entry : apps) {
            if (category >= 0 && appCategory(entry) == category && (best == null || usage.total(entry.key) > usage.total(best.key))) {
                best = entry;
            }
        }
        return best;
    }

    /** Driving: four big buttons (maps, phone, music, WhatsApp), the time, and a way out. */
    void showDrivePanel() {
        if (frame == null) {
            return;
        }
        hideDrivePanel();
        drivePanel = new FrameLayout(this);
        drivePanel.setBackgroundColor(0xFA0B0B12);
        drivePanel.setClickable(true);
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setGravity(Gravity.CENTER_HORIZONTAL);
        boolean low = getResources().getConfiguration().screenHeightDp < 520; // a phone on its side in the car mount
        column.setPadding(dp(20.0f), dp(low ? 12.0f : 48.0f), dp(20.0f), dp(low ? 10.0f : 28.0f));
        TextView title = label(getString(R.string.drive_title), 16, 0xBFFFFFFF, 600);
        title.setGravity(Gravity.CENTER);
        column.addView(title, new LinearLayout.LayoutParams(-1, -2));
        TextView time = label(android.text.format.DateFormat.getTimeFormat(this).format(new Date()), low ? 32 : 56, Color.WHITE, 700);
        time.setGravity(Gravity.CENTER);
        column.addView(time, new LinearLayout.LayoutParams(-1, -2));
        if (!carName.isEmpty()) {
            TextView device = label(carName, 13, 0x99FFFFFF, 400);
            device.setGravity(Gravity.CENTER);
            column.addView(device, new LinearLayout.LayoutParams(-1, -2));
        }
        AppEntry maps = firstApp(android.content.pm.ApplicationInfo.CATEGORY_MAPS, "com.google.android.apps.maps", "com.waze");
        AppEntry music = firstApp(android.content.pm.ApplicationInfo.CATEGORY_AUDIO, "com.spotify.music", "com.anghami");
        AppEntry whatsapp = firstApp(-1, "com.whatsapp", "com.whatsapp.w4b");
        LinearLayout grid2 = new LinearLayout(this);
        grid2.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams gridParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        gridParams.topMargin = dp(low ? 6.0f : 24.0f);
        column.addView(grid2, gridParams);
        Object[][] buttons = {
                {getString(R.string.drive_maps), Glyphs.LOCATION, maps},
                {getString(R.string.drive_phone), Glyphs.PHONE, null},
                {getString(R.string.drive_music), Glyphs.MUSIC, music},
                {whatsapp != null ? whatsapp.label : getString(R.string.drive_messages), Glyphs.SHARE, whatsapp},
        };
        LinearLayout row = null;
        for (int i = 0; i < buttons.length; i++) {
            if (i % 2 == 0) {
                row = new LinearLayout(this);
                LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1, 0, 1f);
                grid2.addView(row, rowParams);
            }
            final AppEntry target = (AppEntry) buttons[i][2];
            final boolean phone = i == 1;
            LinearLayout tile = new LinearLayout(this);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setGravity(Gravity.CENTER);
            tile.setBackground(pill(0x24FFFFFF, 28));
            ImageView glyph = new ImageView(this);
            if (target != null) {
                glyph.setImageDrawable(target.icon);
            } else {
                glyph.setImageDrawable(new Glyphs((Integer) buttons[i][1], Color.WHITE, dp(44.0f)));
            }
            tile.addView(glyph, new LinearLayout.LayoutParams(dp(low ? 40.0f : 64.0f), dp(low ? 40.0f : 64.0f)));
            TextView name = label((String) buttons[i][0], low ? 15 : 18, Color.WHITE, 600);
            name.setGravity(Gravity.CENTER);
            name.setPadding(0, dp(10.0f), 0, 0);
            tile.addView(name, new LinearLayout.LayoutParams(-2, -2));
            tile.setContentDescription((String) buttons[i][0]);
            tile.setOnClickListener(v -> {
                if (phone) {
                    startSafely(new Intent(Intent.ACTION_DIAL));
                } else if (target != null) {
                    launch(target, v);
                }
            });
            LinearLayout.LayoutParams tileParams = new LinearLayout.LayoutParams(0, -1, 1f);
            tileParams.setMargins(dp(6.0f), dp(6.0f), dp(6.0f), dp(6.0f));
            row.addView(tile, tileParams);
        }
        TextView exit = label(getString(R.string.drive_exit), 16, Color.WHITE, 600);
        exit.setGravity(Gravity.CENTER);
        exit.setBackground(pill(0x33FFFFFF, 24));
        exit.setPadding(dp(24.0f), dp(14.0f), dp(24.0f), dp(14.0f));
        exit.setOnClickListener(v -> hideDrivePanel());
        LinearLayout.LayoutParams exitParams = new LinearLayout.LayoutParams(-2, -2);
        exitParams.topMargin = dp(low ? 6.0f : 20.0f);
        column.addView(exit, exitParams);
        drivePanel.addView(column, new FrameLayout.LayoutParams(-1, -1));
        frame.addView(drivePanel, new FrameLayout.LayoutParams(-1, -1));
        drivePanel.setAlpha(0f);
        drivePanel.animate().alpha(1f).setDuration(220L).withLayer().start();
    }

    void hideDrivePanel() {
        if (drivePanel != null) {
            final View panel = drivePanel;
            drivePanel = null;
            panel.animate().alpha(0f).setDuration(180L).withLayer().withEndAction(() -> frame.removeView(panel)).start();
        }
    }

    boolean driveShowing() {
        return drivePanel != null;
    }

    /** The car's Bluetooth went: keep where the phone is now, which is where the car was left. */
    void rememberParking() {
        final long at = System.currentTimeMillis();
        prefs.edit().putLong("parking_pending", at).apply();
        if (!Places.permitted(this)) {
            return;
        }
        android.location.LocationManager manager = getSystemService(android.location.LocationManager.class);
        try {
            if (Build.VERSION.SDK_INT >= 30 && manager != null) {
                String provider = manager.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER) && Places.precise(this)
                        ? android.location.LocationManager.GPS_PROVIDER : android.location.LocationManager.NETWORK_PROVIDER;
                manager.getCurrentLocation(provider, null, getMainExecutor(), location -> {
                    if (location != null) {
                        AudioRoutes.park(prefs, location.getLatitude(), location.getLongitude(), at);
                    } else if (Places.hasFix(prefs) && at - prefs.getLong("loc_time", 0L) < 10 * 60000L) {
                        AudioRoutes.park(prefs, prefs.getFloat("loc_lat", 0f), prefs.getFloat("loc_lng", 0f), at);
                    }
                    if (todayOpen || twoPane) {
                        fillToday();
                    }
                });
                return;
            }
        } catch (Exception ignored) {
        }
        if (Places.hasFix(prefs) && at - prefs.getLong("loc_time", 0L) < 10 * 60000L) {
            AudioRoutes.park(prefs, prefs.getFloat("loc_lat", 0f), prefs.getFloat("loc_lng", 0f), at);
        }
    }

    private void addParkingCard() {
        if (!AudioRoutes.hasParking(prefs)) {
            return;
        }
        final float lat = prefs.getFloat("parking_lat", 0f);
        final float lng = prefs.getFloat("parking_lng", 0f);
        LinearLayout card = todayCard();
        CharSequence ago = android.text.format.DateUtils.getRelativeTimeSpanString(prefs.getLong("parking_time", 0L),
                System.currentTimeMillis(), android.text.format.DateUtils.MINUTE_IN_MILLIS);
        todayCardHeader(card, getString(R.string.parking_title), ago.toString());
        if (Places.hasFix(prefs)) {
            double km = Places.distanceKm(lat, lng, prefs.getFloat("loc_lat", 0f), prefs.getFloat("loc_lng", 0f));
            String away = km < 1 ? getString(R.string.parking_m, localDigits(String.valueOf(Math.round(km * 1000 / 10) * 10)))
                    : getString(R.string.parking_km, localDigits(String.format(Locale.US, "%.1f", km)));
            card.addView(label(away, 15, textPrimary, 600));
        }
        LinearLayout actions = new LinearLayout(this);
        actions.setPadding(0, dp(10.0f), 0, 0);
        TextView open = pillButton(getString(R.string.parking_open));
        open.setOnClickListener(v -> startSafely(new Intent(Intent.ACTION_VIEW,
                Uri.parse("geo:" + lat + "," + lng + "?q=" + lat + "," + lng + "(" + Uri.encode(getString(R.string.parking_title)) + ")"))));
        actions.addView(open);
        TextView done = pillButton(getString(R.string.parking_done));
        done.setOnClickListener(v -> {
            AudioRoutes.clearParking(prefs);
            fillToday();
        });
        LinearLayout.LayoutParams doneParams = new LinearLayout.LayoutParams(-2, -2);
        doneParams.setMarginStart(dp(8.0f));
        actions.addView(done, doneParams);
        card.addView(actions);
    }

    /** A small rounded button for the cards. */
    TextView pillButton(String text) {
        TextView button = label(text, 13, textPrimary, 600);
        button.setBackground(pill(withAlpha(textPrimary, 0.14f), 16));
        button.setPadding(dp(14.0f), dp(8.0f), dp(14.0f), dp(8.0f));
        button.setGravity(Gravity.CENTER);
        return button;
    }

    // ---------------------------------------------------------------- music

    /** Now playing (with notification access), the play and skip keys, and the music app used most. */
    private View musicCard(int slot) {
        final LinearLayout card = wideBase();
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        cardUpdaters.put("music", () -> {
            card.removeAllViews();
            String title = null;
            String artist = null;
            boolean playing = false;
            try {
                android.media.session.MediaSessionManager sessions = getSystemService(android.media.session.MediaSessionManager.class);
                List<android.media.session.MediaController> list = sessions.getActiveSessions(new ComponentName(this, DotsService.class));
                for (android.media.session.MediaController controller : list) {
                    android.media.MediaMetadata meta = controller.getMetadata();
                    if (meta != null) {
                        title = meta.getString(android.media.MediaMetadata.METADATA_KEY_TITLE);
                        artist = meta.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST);
                        playing = controller.getPlaybackState() != null
                                && controller.getPlaybackState().getState() == android.media.session.PlaybackState.STATE_PLAYING;
                        break;
                    }
                }
            } catch (Exception ignored) {
                // no notification access: the keys still work
            }
            LinearLayout side = new LinearLayout(this);
            side.setOrientation(LinearLayout.VERTICAL);
            side.addView(wideHeader(Glyphs.MUSIC, getString(headphonesOn ? R.string.music_headphones : R.string.card_music), null));
            TextView song = cardLine(title != null ? title : getString(R.string.music_nothing), 16, textPrimary, 700);
            song.setPadding(0, dp(4.0f), 0, 0);
            side.addView(song);
            if (artist != null) {
                side.addView(cardLine(artist, 12, textSecondary, 400));
            }
            card.addView(side, new LinearLayout.LayoutParams(0, -2, 1.0f));
            int[][] glyphs = {{Glyphs.CHEVRON_RIGHT, android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS},
                    {playing ? Glyphs.PAUSE : Glyphs.PLAY, android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE},
                    {Glyphs.CHEVRON_LEFT, android.view.KeyEvent.KEYCODE_MEDIA_NEXT}};
            int[] names = {R.string.music_previous, R.string.music_play, R.string.music_next};
            for (int i = 0; i < glyphs.length; i++) {
                final int code = glyphs[i][1];
                ImageView key = new ImageView(this);
                key.setImageDrawable(new Glyphs(glyphs[i][0], textPrimary, dp(i == 1 ? 24.0f : 18.0f)));
                key.setScaleType(ImageView.ScaleType.CENTER);
                key.setBackground(i == 1 ? pill(withAlpha(textPrimary, 0.16f), 21) : null);
                key.setContentDescription(getString(names[i]));
                key.setOnClickListener(v -> {
                    mediaKey(code);
                    uiHandler.postDelayed(() -> runCardUpdater("music"), 400L);
                });
                LinearLayout.LayoutParams keyParams = new LinearLayout.LayoutParams(dp(42.0f), dp(42.0f));
                keyParams.setMarginStart(dp(4.0f));
                card.addView(key, keyParams);
            }
            card.setContentDescription(getString(R.string.card_music) + (title == null ? "" : getString(R.string.list_separator) + title));
        });
        card.setOnClickListener(v -> {
            AppEntry app = firstApp(android.content.pm.ApplicationInfo.CATEGORY_AUDIO, "com.spotify.music", "com.anghami");
            if (app != null) {
                launch(app, v);
            }
        });
        return card;
    }

    /** Play, pause and skip go to whatever is playing: Android hands media keys to the active player. */
    void mediaKey(int code) {
        android.media.AudioManager audio = getSystemService(android.media.AudioManager.class);
        if (audio == null) {
            return;
        }
        audio.dispatchMediaKeyEvent(new android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, code));
        audio.dispatchMediaKeyEvent(new android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, code));
    }

    // ---------------------------------------------------------------- Makkah and Madinah

    private void addHaramCard() {
        String city = Haram.here(prefs);
        if (city == null) {
            return;
        }
        LinearLayout card = todayCard();
        todayCardHeader(card, getString(Haram.MAKKAH.equals(city) ? R.string.haram_makkah : R.string.haram_madinah),
                getString(prefs.getBoolean("haram_silenced", false) ? R.string.haram_silenced : R.string.haram_welcome));
        for (Haram.Dua dua : Haram.duas(city)) {
            TextView when = label(getString(dua.when), 12, accentOnWallpaper(), 600);
            when.setPadding(0, dp(12.0f), 0, dp(2.0f));
            card.addView(when);
            TextView text = label(dua.text, 17, textPrimary, 500);
            text.setLineSpacing(0f, 1.25f);
            card.addView(text);
            TextView source = label(getString(dua.source), 11, textSecondary, 400);
            source.setPadding(0, dp(2.0f), 0, 0);
            card.addView(source);
        }
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (prefs.getBoolean(Haram.PREF_SILENCE, true) && manager != null && !manager.isNotificationPolicyAccessGranted()) {
            TextView allow = pillButton(getString(R.string.haram_allow_silence));
            allow.setOnClickListener(v -> startSafely(new Intent(android.provider.Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)));
            LinearLayout.LayoutParams allowParams = new LinearLayout.LayoutParams(-2, -2);
            allowParams.topMargin = dp(12.0f);
            card.addView(allow, allowParams);
        }
    }

    // ---------------------------------------------------------------- countdowns

    private View countdownCard(int slot) {
        final LinearLayout card = wideBase();
        card.setOnClickListener(v -> editCountdowns());
        cardUpdaters.put("countdown", () -> {
            card.removeAllViews();
            long now = System.currentTimeMillis();
            List<Countdowns.Event> list = Countdowns.all(prefs, getString(R.string.countdown_salary), now);
            card.addView(wideHeader(Glyphs.TIMER, getString(R.string.card_countdown), null));
            if (list.isEmpty()) {
                TextView empty = cardLine(getString(R.string.countdown_empty), 14, textSecondary, 400);
                empty.setPadding(0, dp(8.0f), 0, 0);
                card.addView(empty);
                card.setContentDescription(getString(R.string.card_countdown) + getString(R.string.list_separator) + empty.getText());
                return;
            }
            // Each day you wait for in turn: how long is left, big; what it is and the date under it.
            Ticker days = ticker(1);
            LinearLayout.LayoutParams daysParams = new LinearLayout.LayoutParams(-1, -2);
            daysParams.topMargin = dp(4.0f);
            card.addView(days, daysParams);
            StringBuilder spoken = new StringBuilder(getString(R.string.card_countdown));
            for (int i = 0; i < Math.min(5, list.size()); i++) {
                Countdowns.Event event = list.get(i);
                int left = Countdowns.daysUntil(event.day, now);
                String when = left == 0 ? getString(event.salary ? R.string.countdown_salary_today : R.string.countdown_today)
                        : left == 1 ? getString(R.string.countdown_tomorrow) : daysAfter(left);
                LinearLayout item = new LinearLayout(this);
                item.setOrientation(LinearLayout.VERTICAL);
                item.addView(cardLine(event.name + "، " + when, 17, event.salary && left == 0 ? accentOnWallpaper() : textPrimary, 700));
                item.addView(cardLine(new SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(new Date(event.day)), 12, textSecondary, 400));
                days.addItem(item);
                spoken.append(getString(R.string.list_separator)).append(event.name).append(" ").append(when);
            }
            card.setContentDescription(spoken.toString());
        });
        return card;
    }

    /** The nearest day big ("الراتب بعد ٩ أيام"), and the next ones small. */
    private void fillCountdowns(LinearLayout card, int count, boolean header) {
        long now = System.currentTimeMillis();
        List<Countdowns.Event> list = Countdowns.all(prefs, getString(R.string.countdown_salary), now);
        if (header) {
            card.addView(cardLine(getString(R.string.card_countdown), 12, textSecondary, 600));
        }
        if (list.isEmpty()) {
            card.addView(cardLine(getString(R.string.countdown_empty), 14, textSecondary, 400));
            return;
        }
        for (int i = 0; i < Math.min(count, list.size()); i++) {
            Countdowns.Event event = list.get(i);
            int days = Countdowns.daysUntil(event.day, now);
            String left = days == 0 ? getString(event.salary ? R.string.countdown_salary_today : R.string.countdown_today)
                    : days == 1 ? getString(R.string.countdown_tomorrow) : daysAfter(days);
            if (i == 0) {
                TextView big = cardLine(left, 22, event.salary && days == 0 ? accentOnWallpaper() : textPrimary, 700);
                big.setPadding(0, dp(6.0f), 0, 0);
                card.addView(big);
                card.addView(cardLine(event.name + getString(R.string.list_separator)
                        + new SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(new Date(event.day)), 13, textSecondary, 400));
            } else {
                TextView small = cardLine(event.name + getString(R.string.list_separator) + left, 13, textPrimary, 500);
                small.setPadding(0, dp(6.0f), 0, 0);
                card.addView(small);
            }
        }
        card.setContentDescription(getString(R.string.card_countdown) + getString(R.string.list_separator) + list.get(0).name);
    }

    private void addCountdownCard() {
        LinearLayout card = todayCard();
        fillCountdowns(card, 4, true);
        card.setOnClickListener(v -> editCountdowns());
    }

    /** Salary day and the user's own days: add, remove. */
    void editCountdowns() {
        final long now = System.currentTimeMillis();
        final List<Countdowns.Event> own = Countdowns.events(prefs, now);
        ArrayList<String> items = new ArrayList<>();
        items.add(getString(R.string.countdown_add));
        items.add(getString(R.string.countdown_salary_day, localDigits(String.valueOf(Countdowns.salaryDay(prefs))))
                + (prefs.getBoolean(Countdowns.PREF_SALARY_ON, true) ? "" : getString(R.string.list_separator) + getString(R.string.state_off)));
        for (Countdowns.Event event : own) {
            items.add(getString(R.string.countdown_remove, event.name));
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.card_countdown))
                .setItems(items.toArray(new String[0]), (dialog, which) -> {
                    if (which == 0) {
                        addCountdown();
                    } else if (which == 1) {
                        pickSalaryDay();
                    } else {
                        Countdowns.Event event = own.get(which - 2);
                        Countdowns.remove(prefs, event.name, event.day);
                        afterCountdowns();
                    }
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void addCountdown() {
        final EditText name = new EditText(this);
        name.setHint(getString(R.string.countdown_name_hint));
        name.setSingleLine(true);
        FrameLayout box = new FrameLayout(this);
        box.setPadding(dp(22.0f), dp(8.0f), dp(22.0f), 0);
        box.addView(name);
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.countdown_add))
                .setView(box)
                .setPositiveButton(getString(R.string.countdown_pick_day), (dialog, which) -> {
                    final String title = name.getText().toString().trim().isEmpty() ? getString(R.string.countdown_default_name)
                            : name.getText().toString().trim();
                    Calendar today = Calendar.getInstance();
                    android.app.DatePickerDialog picker = new android.app.DatePickerDialog(this, (view, year, month, day) -> {
                        Calendar chosen = Calendar.getInstance();
                        chosen.set(year, month, day, 12, 0, 0);
                        Countdowns.add(prefs, title, chosen.getTimeInMillis());
                        afterCountdowns();
                    }, today.get(Calendar.YEAR), today.get(Calendar.MONTH), today.get(Calendar.DAY_OF_MONTH));
                    picker.getDatePicker().setMinDate(today.getTimeInMillis());
                    picker.show();
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void pickSalaryDay() {
        String[] days = new String[29];
        days[0] = getString(R.string.countdown_salary_off);
        for (int i = 1; i <= 28; i++) {
            days[i] = localDigits(String.valueOf(i));
        }
        int selected = prefs.getBoolean(Countdowns.PREF_SALARY_ON, true) ? Math.min(28, Countdowns.salaryDay(prefs)) : 0;
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.countdown_salary_pick))
                .setSingleChoiceItems(days, selected, (dialog, which) -> {
                    if (which == 0) {
                        prefs.edit().putBoolean(Countdowns.PREF_SALARY_ON, false).apply();
                    } else {
                        prefs.edit().putBoolean(Countdowns.PREF_SALARY_ON, true).putInt(Countdowns.PREF_SALARY, which).apply();
                    }
                    dialog.dismiss();
                    afterCountdowns();
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void afterCountdowns() {
        runCardUpdater("countdown");
        runCardUpdater("morning");
        if (todayOpen || twoPane) {
            fillToday();
        }
    }

    /** "بعد ٣ أيام"، "بعد ١٢ يومًا": Arabic counts take their own forms. */
    String daysAfter(int days) {
        return getResources().getQuantityString(R.plurals.days_after, days, localDigits(String.valueOf(days)));
    }

    // ---------------------------------------------------------------- the khatma

    private View khatmaCard(int slot) {
        final LinearLayout card = wideBase();
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        cardUpdaters.put("khatma", () -> {
            card.removeAllViews();
            card.setOnLongClickListener(null);
            LinearLayout side = new LinearLayout(this);
            side.setOrientation(LinearLayout.VERTICAL);
            card.addView(side, new LinearLayout.LayoutParams(0, -2, 1.0f));
            side.addView(wideHeader(-1, getString(R.string.card_khatma), null));
            if (!Khatma.active(prefs)) {
                TextView start = cardLine(getString(R.string.khatma_start), 16, textPrimary, 700);
                start.setPadding(0, dp(4.0f), 0, 0);
                side.addView(start);
                side.addView(cardLine(getString(R.string.khatma_start_hint), 12, textSecondary, 400));
                card.setOnClickListener(v -> startKhatma());
                card.setContentDescription(getString(R.string.card_khatma) + getString(R.string.list_separator) + start.getText());
                return;
            }
            long now = System.currentTimeMillis();
            int done = Khatma.doneHalves(prefs);
            boolean finished = done >= 60;
            TextView today = cardLine(finished ? getString(R.string.khatma_finished) : Khatma.portion(this, prefs), 17, textPrimary, 700);
            today.setPadding(0, dp(3.0f), 0, 0);
            side.addView(today);
            // How far, and whether on time, in turn.
            Ticker lines = ticker(1);
            lines.addItem(cardLine(getString(R.string.khatma_progress, localDigits(String.valueOf(done / 2))), 12, textSecondary, 500));
            int due = Khatma.dueHalves(prefs, now);
            int behind = (due - done + 1) / 2;
            if (!finished) {
                lines.addItem(cardLine(done >= due || behind <= 0 ? getString(R.string.khatma_on_track)
                        : getResources().getQuantityString(R.plurals.juz_behind, behind, localDigits(String.valueOf(behind))), 12,
                        done >= due || behind <= 0 ? textSecondary : (darkWallpaper ? 0xFFFFD27A : 0xFF8F5200), 600));
            }
            side.addView(lines, new LinearLayout.LayoutParams(-1, -2));
            android.widget.ProgressBar bar = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            bar.setMax(60);
            bar.setProgress(done);
            bar.setProgressTintList(ColorStateList.valueOf(accentOnWallpaper()));
            bar.setProgressBackgroundTintList(ColorStateList.valueOf(withAlpha(textPrimary, 0.3f)));
            LinearLayout.LayoutParams barParams = new LinearLayout.LayoutParams(-1, dp(4.0f));
            barParams.topMargin = dp(4.0f);
            side.addView(bar, barParams);
            if (!finished) {
                TextView read = pillButton(getString(R.string.khatma_read));
                read.setOnClickListener(v -> {
                    boolean all = Khatma.readToday(prefs);
                    Toast.makeText(this, getString(all ? R.string.khatma_finished : R.string.khatma_saved), Toast.LENGTH_SHORT).show();
                    runCardUpdater("khatma");
                    runCardUpdater("morning");
                    if (todayOpen || twoPane) {
                        fillToday();
                    }
                });
                LinearLayout.LayoutParams readParams = new LinearLayout.LayoutParams(-2, -2);
                readParams.setMarginStart(dp(12.0f));
                card.addView(read, readParams);
            }
            final Intent quran = Khatma.quranApp(this);
            card.setOnClickListener(v -> {
                if (quran != null) {
                    startSafely(quran);
                }
            });
            card.setOnLongClickListener(v -> {
                khatmaOptions();
                return true;
            });
            card.setContentDescription(getString(R.string.card_khatma) + getString(R.string.list_separator) + today.getText());
        });
        return card;
    }

    private void addKhatmaCard() {
        if (!Khatma.active(prefs)) {
            return;
        }
        fillKhatma(todayCard());
    }

    private void fillKhatma(LinearLayout card) {
        card.addView(cardLine(getString(R.string.card_khatma), 12, textSecondary, 600));
        if (!Khatma.active(prefs)) {
            TextView start = cardLine(getString(R.string.khatma_start), 16, textPrimary, 700);
            start.setPadding(0, dp(8.0f), 0, 0);
            card.addView(start);
            card.addView(cardLine(getString(R.string.khatma_start_hint), 13, textSecondary, 400));
            card.setOnClickListener(v -> startKhatma());
            return;
        }
        long now = System.currentTimeMillis();
        int done = Khatma.doneHalves(prefs);
        boolean finished = done >= 60;
        TextView today = cardLine(finished ? getString(R.string.khatma_finished) : Khatma.portion(this, prefs), 18, textPrimary, 700);
        today.setPadding(0, dp(6.0f), 0, 0);
        card.addView(today);
        int due = Khatma.dueHalves(prefs, now);
        int behind = (due - done + 1) / 2;
        String pace = finished ? "" : done >= due || behind <= 0 ? getString(R.string.khatma_on_track)
                : getResources().getQuantityString(R.plurals.juz_behind, behind, localDigits(String.valueOf(behind)));
        TextView progress = cardLine(getString(R.string.khatma_progress, localDigits(String.valueOf(done / 2)))
                + (pace.isEmpty() ? "" : getString(R.string.list_separator) + pace), 12, textSecondary, 400);
        progress.setSingleLine(false);
        progress.setMaxLines(2);
        card.addView(progress);
        // Progress: thirty marks, filled as read.
        android.widget.ProgressBar bar = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(60);
        bar.setProgress(done);
        bar.setProgressTintList(ColorStateList.valueOf(accentOnWallpaper()));
        bar.setProgressBackgroundTintList(ColorStateList.valueOf(withAlpha(textPrimary, 0.3f)));
        LinearLayout.LayoutParams barParams = new LinearLayout.LayoutParams(-1, dp(6.0f));
        barParams.topMargin = dp(8.0f);
        card.addView(bar, barParams);
        LinearLayout actions = new LinearLayout(this);
        actions.setPadding(0, dp(10.0f), 0, 0);
        if (!finished) {
            TextView read = pillButton(getString(R.string.khatma_read));
            read.setOnClickListener(v -> {
                boolean all = Khatma.readToday(prefs);
                Toast.makeText(this, getString(all ? R.string.khatma_finished : R.string.khatma_saved), Toast.LENGTH_SHORT).show();
                runCardUpdater("khatma");
                runCardUpdater("morning");
                if (todayOpen || twoPane) {
                    fillToday();
                }
            });
            actions.addView(read);
        }
        final Intent quran = Khatma.quranApp(this);
        if (quran != null) {
            TextView open = pillButton(getString(R.string.khatma_open));
            open.setOnClickListener(v -> startSafely(quran));
            LinearLayout.LayoutParams openParams = new LinearLayout.LayoutParams(-2, -2);
            openParams.setMarginStart(dp(8.0f));
            actions.addView(open, openParams);
        }
        card.addView(actions);
        card.setOnLongClickListener(v -> {
            khatmaOptions();
            return true;
        });
        card.setContentDescription(getString(R.string.card_khatma) + getString(R.string.list_separator) + today.getText());
    }

    void startKhatma() {
        String[] plans = new String[Khatma.PLANS.length];
        for (int i = 0; i < plans.length; i++) {
            plans[i] = getResources().getQuantityString(R.plurals.days_in, Khatma.PLANS[i], localDigits(String.valueOf(Khatma.PLANS[i])));
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.khatma_start))
                .setItems(plans, (dialog, which) -> {
                    Khatma.start(prefs, Khatma.PLANS[which], System.currentTimeMillis());
                    ReminderReceiver.scheduleKhatma(this);
                    runCardUpdater("khatma");
                    runCardUpdater("morning");
                    if (todayOpen || twoPane) {
                        fillToday();
                    }
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void khatmaOptions() {
        String[] items = {getString(R.string.khatma_restart), getString(R.string.khatma_remind_time), getString(R.string.khatma_stop)};
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.card_khatma))
                .setItems(items, (dialog, which) -> {
                    if (which == 0) {
                        startKhatma();
                    } else if (which == 1) {
                        int at = Khatma.remindAt(prefs);
                        new android.app.TimePickerDialog(this, (view, hour, minute) -> {
                            prefs.edit().putInt(Khatma.PREF_REMIND, hour * 60 + minute).apply();
                            ReminderReceiver.scheduleKhatma(this);
                        }, Math.max(0, at) / 60, Math.max(0, at) % 60, android.text.format.DateFormat.is24HourFormat(this)).show();
                    } else {
                        Khatma.stop(prefs);
                        ReminderReceiver.scheduleKhatma(this);
                        runCardUpdater("khatma");
                        if (todayOpen || twoPane) {
                            fillToday();
                        }
                    }
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    // ---------------------------------------------------------------- good morning

    /** From Fajr to ten in the morning. */
    boolean morningNow(long now) {
        long fajr = Prayers.timesFor(prefs, now)[PrayerTimes.FAJR];
        Calendar ten = Calendar.getInstance();
        ten.setTimeInMillis(now);
        ten.set(Calendar.HOUR_OF_DAY, 10);
        ten.set(Calendar.MINUTE, 0);
        return now >= fajr && now < ten.getTimeInMillis();
    }

    /** The day in one look: weather, the first event, your club's match, the salary, the day's reading, a headline. */
    private View morningCard(int slot) {
        final LinearLayout card = wideBase();
        cardUpdaters.put("morning", () -> {
            card.removeAllViews();
            long now = System.currentTimeMillis();
            int hour = Usage.hourOf(now);
            String hello = getString(hour < 12 ? R.string.morning_hello : hour < 17 ? R.string.morning_afternoon : R.string.morning_evening);
            card.addView(cardLine(hello, 16, textPrimary, 700));
            ArrayList<String> lines = new ArrayList<>();
            String occasion = Ambience.greeting(this, Ambience.occasion(now), now);
            if (occasion != null) {
                lines.add(occasion);
            }
            Weather.Now weather = Weather.cached(prefs);
            if (weatherOn && weather != null) {
                Weather.Alert alert = Weather.alertsOn(prefs) ? Weather.cachedAlert(prefs, now) : null;
                lines.add(alert != null ? Weather.alertText(this, alert)
                        : getString(R.string.morning_weather, Weather.degrees(weather.temp), getString(Weather.descriptionRes(weather.code)),
                        Weather.degrees(weather.max)));
            }
            try {
                if (Agenda.permitted(this)) {
                    for (Agenda.Event event : Agenda.recent(this, now, 1, this::agendaRead)) {
                        if (event.begin - now > 16 * 3600000L) {
                            continue; // not today
                        }
                        lines.add(getString(R.string.morning_event, event.title,
                                event.allDay ? getString(R.string.agenda_all_day) : android.text.format.DateFormat.getTimeFormat(this).format(new Date(event.begin))));
                    }
                }
            } catch (Exception ignored) {
            }
            Matches.Match match = Matches.nextFavourite(prefs, now);
            if (match != null && match.time - now < 24 * 3600000L && match.time > now - 2 * 3600000L) {
                lines.add(getString(R.string.morning_match, Matches.arabic(match.home), Matches.arabic(match.away),
                        android.text.format.DateFormat.getTimeFormat(this).format(new Date(match.time))));
            }
            if (Khatma.active(prefs) && Khatma.doneHalves(prefs) < 60) {
                lines.add(getString(R.string.morning_khatma, Khatma.portion(this, prefs)));
            }
            if (prefs.getBoolean(Countdowns.PREF_SALARY_ON, true)) {
                int days = Countdowns.daysUntil(Countdowns.nextSalary(prefs, now), now);
                lines.add(days == 0 ? getString(R.string.countdown_salary_today)
                        : getString(R.string.morning_salary, daysAfter(days)));
            }
            // The day's lines in turn, like a ticker.
            StringBuilder spoken = new StringBuilder(hello);
            Ticker ticker = ticker(1);
            LinearLayout.LayoutParams tickerParams = new LinearLayout.LayoutParams(-1, -2);
            tickerParams.topMargin = dp(6.0f);
            card.addView(ticker, tickerParams);
            for (String line : lines) {
                TextView text = cardLine(line, 14, textPrimary, 500);
                text.setSingleLine(false);
                text.setMaxLines(2);
                ticker.addItem(text);
                spoken.append(getString(R.string.list_separator)).append(line);
            }
            card.setContentDescription(spoken.toString());
        });
        card.setOnClickListener(v -> openToday());
        return card;
    }

    // ---------------------------------------------------------------- an icon swiped up

    /** Package/activity key to the shortcut id that a swipe up on the icon opens. */
    private org.json.JSONObject swipeActions() {
        try {
            return new org.json.JSONObject(prefs.getString("icon_swipe", "{}"));
        } catch (Exception e) {
            return new org.json.JSONObject();
        }
    }

    /** The grid app under this point of the grid frame, when it has a swipe-up action. */
    AppEntry swipeTarget(float x, float y) {
        if (grid == null || scrollLayout || reorderMode) {
            return null;
        }
        int position = grid.pointToPosition(Math.round(x - grid.getLeft()), Math.round(y - grid.getTop()));
        if (position < 0 || position >= pageTiles.size()) {
            return null;
        }
        Tile tile = pageTiles.get(position);
        if (tile.app == null) {
            return null;
        }
        return swipeActions().has(tile.app.key) ? tile.app : null;
    }

    void onIconSwipe(AppEntry entry, View anchor) {
        String id = swipeActions().optString(entry.key, "");
        for (ShortcutInfo shortcut : shortcutsFor(entry)) {
            if (shortcut.getId().equals(id)) {
                try {
                    performHapticFeedback(anchor);
                    launcherApps.startShortcut(shortcut, null, null);
                    recordLaunch(entry);
                    return;
                } catch (Exception ignored) {
                }
            }
        }
        launch(entry, anchor); // the shortcut is gone: open the app
    }

    private void performHapticFeedback(View view) {
        if (view != null) {
            view.performHapticFeedback(android.view.HapticFeedbackConstants.CONFIRM);
        }
    }

    /** From the long-press menu: which of the app's shortcuts a swipe up opens. */
    private void chooseSwipe(final AppEntry entry) {
        final List<ShortcutInfo> shortcuts = shortcutsFor(entry);
        if (shortcuts.isEmpty()) {
            Toast.makeText(this, getString(R.string.swipe_none), Toast.LENGTH_LONG).show();
            return;
        }
        String[] names = new String[shortcuts.size() + 1];
        names[0] = getString(R.string.swipe_off);
        String current = swipeActions().optString(entry.key, "");
        int selected = 0;
        for (int i = 0; i < shortcuts.size(); i++) {
            CharSequence label = shortcuts.get(i).getShortLabel();
            names[i + 1] = label == null ? shortcuts.get(i).getId() : label.toString();
            if (shortcuts.get(i).getId().equals(current)) {
                selected = i + 1;
            }
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.swipe_title, entry.label))
                .setSingleChoiceItems(names, selected, (dialog, which) -> {
                    org.json.JSONObject all = swipeActions();
                    try {
                        if (which == 0) {
                            all.remove(entry.key);
                        } else {
                            all.put(entry.key, shortcuts.get(which - 1).getId());
                        }
                    } catch (Exception ignored) {
                    }
                    prefs.edit().putString("icon_swipe", all.toString()).apply();
                    dialog.dismiss();
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    // ---------------------------------------------------------------- the clipboard in search

    /** Search opened: offer what was just copied. */
    void offerClip() {
        if (smartBox == null || currentQuery().length() > 0 || privacyMode) {
            return;
        }
        final ClipSuggest.Clip clip = ClipSuggest.fresh(this, prefs);
        if (clip == null) {
            return;
        }
        smartBox.removeAllViews();
        smartQuery = "";
        String shown = clip.text.length() > 40 ? clip.text.substring(0, 40) + "…" : clip.text;
        switch (clip.kind) {
            case ClipSuggest.PHONE:
                smartBox.addView(smartRow(new Glyphs(Glyphs.PHONE, textPrimary, dp(20.0f)), null, "⁦" + shown + "⁩",
                        getString(R.string.clip_call), v -> clipAct(ClipSuggest.call(clip.text))));
                smartBox.addView(smartRow(new Glyphs(Glyphs.SHARE, textPrimary, dp(20.0f)), null, getString(R.string.clip_whatsapp),
                        "\u2066" + shown + "\u2069", v -> clipAct(ClipSuggest.whatsapp(clip.text))));
                break;
            case ClipSuggest.LINK:
                smartBox.addView(smartRow(new Glyphs(Glyphs.LINK, textPrimary, dp(20.0f)), null, "⁦" + shown + "⁩",
                        getString(R.string.clip_open), v -> clipAct(ClipSuggest.open(clip.text))));
                break;
            case ClipSuggest.EMAIL:
                smartBox.addView(smartRow(new Glyphs(Glyphs.SHARE, textPrimary, dp(20.0f)), null, "⁦" + shown + "⁩",
                        getString(R.string.clip_email), v -> clipAct(ClipSuggest.email(clip.text))));
                break;
            case ClipSuggest.PARCEL:
                smartBox.addView(smartRow(new Glyphs(Glyphs.SEARCH, textPrimary, dp(20.0f)), null, "⁦" + shown + "⁩",
                        getString(R.string.clip_track), v -> clipAct(ClipSuggest.track(clip.text))));
                break;
            default:
                smartBox.addView(smartRow(new Glyphs(Glyphs.SEARCH, textPrimary, dp(20.0f)), null, shown, getString(R.string.clip_search), v -> {
                    ClipSuggest.done(prefs);
                    search.setText(clip.text);
                    search.setSelection(search.getText().length());
                }));
                break;
        }
        smartBox.setVisibility(View.VISIBLE);
        // Offered once per copy: Android tells the user each time an app reads the clipboard, so don't read it again.
        ClipSuggest.done(prefs);
    }

    private void clipAct(Intent intent) {
        ClipSuggest.done(prefs);
        closeSearch();
        startSafely(intent);
    }

    // ---------------------------------------------------------------- the place in suggestions

    /** The place cell for the suggestions, from a location less than an hour old. */
    void updateUsagePlace() {
        if (usage == null) {
            return;
        }
        usage.here = Places.hasFix(prefs) && System.currentTimeMillis() - prefs.getLong("loc_time", 0L) < 3600000L
                ? Usage.cell(prefs.getFloat("loc_lat", 0f), prefs.getFloat("loc_lng", 0f)) : null;
    }

    // ---------------------------------------------------------------- children's mode

    private FrameLayout kidsPanel;

    /** Choose the apps, then start. */
    void setUpKids() {
        final ArrayList<AppEntry> sorted = new ArrayList<>(apps);
        Collections.sort(sorted, (a, b) -> a.label.compareToIgnoreCase(b.label));
        final java.util.Set<String> chosen = new java.util.LinkedHashSet<>(Kids.apps(prefs));
        String[] names = new String[sorted.size()];
        boolean[] checked = new boolean[sorted.size()];
        for (int i = 0; i < sorted.size(); i++) {
            names[i] = sorted.get(i).label;
            checked[i] = chosen.contains(sorted.get(i).key);
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.kids_pick))
                .setMultiChoiceItems(names, checked, (dialog, which, on) -> {
                    if (on) {
                        chosen.add(sorted.get(which).key);
                    } else {
                        chosen.remove(sorted.get(which).key);
                    }
                })
                .setPositiveButton(getString(R.string.kids_start), (dialog, which) -> {
                    if (chosen.isEmpty()) {
                        Toast.makeText(this, getString(R.string.kids_none), Toast.LENGTH_LONG).show();
                        return;
                    }
                    Kids.saveApps(prefs, chosen);
                    prefs.edit().putBoolean(Kids.PREF_ON, true).apply();
                    showKids();
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    /** The children's screen over Home: their apps in big tiles, and a small lock to leave. */
    void showKids() {
        if (frame == null || !Kids.on(prefs)) {
            return;
        }
        hideDrivePanel();
        if (todayOpen) {
            closeToday();
        }
        if (kidsPanel != null) {
            frame.removeView(kidsPanel);
        }
        kidsPanel = new FrameLayout(this);
        kidsPanel.setClickable(true);
        kidsPanel.setBackground(Wallpapers.create(this, wallpaperId));
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setPadding(dp(18.0f), dp(56.0f), dp(18.0f), dp(24.0f));
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label(getString(R.string.kids_title), 22, textPrimary, 700);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        ImageView lock = new ImageView(this);
        lock.setImageDrawable(new Glyphs(Glyphs.LOCK, textPrimary, dp(20.0f)));
        lock.setScaleType(ImageView.ScaleType.CENTER);
        glassify(lock, 20, true);
        lock.setContentDescription(getString(R.string.kids_exit));
        lock.setOnClickListener(v -> askToLeaveKids());
        head.addView(lock, new LinearLayout.LayoutParams(dp(44.0f), dp(44.0f)));
        column.addView(head, new LinearLayout.LayoutParams(-1, -2));
        android.widget.GridLayout tiles = new android.widget.GridLayout(this);
        int kidsColumns = Math.max(3, Math.min(6, getResources().getConfiguration().screenWidthDp / 130));
        tiles.setColumnCount(kidsColumns);
        LinearLayout.LayoutParams tilesParams = new LinearLayout.LayoutParams(-1, -2);
        tilesParams.topMargin = dp(24.0f);
        column.addView(tiles, tilesParams);
        int width = (getResources().getDisplayMetrics().widthPixels - dp(36.0f)) / kidsColumns;
        for (String key : Kids.apps(prefs)) {
            final AppEntry entry = findByKey(key);
            if (entry == null) {
                continue;
            }
            LinearLayout tile = new LinearLayout(this);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setGravity(Gravity.CENTER);
            tile.setPadding(0, dp(12.0f), 0, dp(12.0f));
            ImageView icon = new ImageView(this);
            icon.setImageDrawable(shownIcon(entry));
            tile.addView(icon, new LinearLayout.LayoutParams(dp(76.0f), dp(76.0f)));
            TextView name = label(entry.label, 15, textPrimary, 600);
            name.setGravity(Gravity.CENTER);
            name.setMaxLines(2);
            name.setPadding(dp(4.0f), dp(8.0f), dp(4.0f), 0);
            tile.addView(name, new LinearLayout.LayoutParams(-1, -2));
            tile.setContentDescription(entry.label);
            tile.setOnClickListener(v -> launch(entry, v));
            android.widget.GridLayout.LayoutParams params = new android.widget.GridLayout.LayoutParams();
            params.width = width;
            tiles.addView(tile, params);
        }
        ScrollView scroll = new ScrollView(this);
        scroll.addView(column);
        kidsPanel.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
        frame.addView(kidsPanel, new FrameLayout.LayoutParams(-1, -1));
    }

    boolean kidsShowing() {
        return kidsPanel != null;
    }

    /** The phone's own fingerprint, face or PIN, so only a parent can leave. */
    void askToLeaveKids() {
        android.app.KeyguardManager km = getSystemService(android.app.KeyguardManager.class);
        if (km == null || !km.isDeviceSecure()) {
            Toast.makeText(this, getString(R.string.kids_no_lock), Toast.LENGTH_LONG).show();
            return;
        }
        if (Build.VERSION.SDK_INT < 28) {
            Intent confirm = km.createConfirmDeviceCredentialIntent(getString(R.string.kids_exit), getString(R.string.kids_exit_hint));
            if (confirm != null) {
                pendingAuth = this::leaveKids;
                startActivityForResult(confirm, REQUEST_CONFIRM);
            }
            return;
        }
        try {
            android.hardware.biometrics.BiometricPrompt.Builder builder = new android.hardware.biometrics.BiometricPrompt.Builder(this)
                    .setTitle(getString(R.string.kids_exit))
                    .setSubtitle(getString(R.string.kids_exit_hint));
            if (Build.VERSION.SDK_INT >= 30) {
                builder.setAllowedAuthenticators(android.hardware.biometrics.BiometricManager.Authenticators.BIOMETRIC_WEAK
                        | android.hardware.biometrics.BiometricManager.Authenticators.DEVICE_CREDENTIAL);
            } else {
                builder.setDeviceCredentialAllowed(true);
            }
            builder.build().authenticate(new android.os.CancellationSignal(), getMainExecutor(),
                    new android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
                        @Override
                        public void onAuthenticationSucceeded(android.hardware.biometrics.BiometricPrompt.AuthenticationResult result) {
                            leaveKids();
                        }
                    });
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.kids_exit_hint), Toast.LENGTH_SHORT).show();
        }
    }

    void leaveKids() {
        prefs.edit().putBoolean(Kids.PREF_ON, false).apply();
        if (kidsPanel != null) {
            frame.removeView(kidsPanel);
            kidsPanel = null;
        }
    }

    // ---------------------------------------------------------------- smart stacks

    static final long SMART_QUIET_MS = 10 * 60000L;

    boolean smartStacksOn() {
        return prefs.getBoolean("smart_stack", true);
    }

    /**
     * Each stack turns by itself to the card that matters now, unless the user turned it in the last ten
     * minutes; once the moment has passed it goes back to the card the user left it on.
     */
    void smartStacks(long now) {
        if (!smartStacksOn()) {
            return;
        }
        String wanted = null;
        for (CardStack stack : cardStacks) {
            if (stack.size() < 2 || now - stack.lastUserChange < SMART_QUIET_MS) {
                continue;
            }
            String target = smartCard(now, stack.types());
            if (target != null) {
                int at = stack.indexOf(target);
                if (at != stack.index()) {
                    if (stack.homeIndex < 0) {
                        stack.homeIndex = stack.index();
                    }
                    stack.turnBySelf(at);
                }
            } else if (stack.homeIndex >= 0) {
                int back = stack.homeIndex;
                stack.homeIndex = -1;
                stack.turnBySelf(back);
            }
        }
    }

    /** The first of these that holds and has a card in {@code available}, or null. */
    String smartCard(long now, List<String> available) {
        if (available.contains("music") && (headphonesOn || carOn)) {
            return "music";
        }
        if (available.contains("matches") && matchSoon(now)) {
            return "matches";
        }
        if (available.contains("prayers") && prayerOn && prayerWithin(now, 20 * 60000L)) {
            return "prayers";
        }
        if (available.contains("battery") && batteryLevelNow >= 0 && batteryLevelNow <= 20 && !batteryCharging) {
            return "battery";
        }
        if (available.contains("agenda") && eventWithin(now, 30 * 60000L)) {
            return "agenda";
        }
        if (available.contains("weather") && weatherOn) {
            Weather.Alert alert = Weather.cachedAlert(prefs, now);
            if (alert != null && alert.from - now <= 3 * 3600000L) {
                return "weather";
            }
        }
        if (available.contains("morning") && morningNow(now)) {
            return "morning";
        }
        return null;
    }

    /** One of the shown matches is being played, or kicks off within the hour. */
    boolean matchSoon(long now) {
        for (Matches.Match match : Matches.upcoming(prefs, Matches.cached(prefs), now, 3)) {
            if (match.live || (match.time > now && match.time - now <= 60 * 60000L)) {
                return true;
            }
        }
        return false;
    }

    boolean prayerWithin(long now, long window) {
        long[] times = Prayers.timesFor(prefs, now);
        for (int i = 0; i < times.length; i++) {
            if (i != PrayerTimes.SUNRISE && times[i] > now && times[i] - now <= window) {
                return true;
            }
        }
        return false;
    }

    private long eventsCheckedAt;
    private boolean eventSoon;

    boolean eventWithin(long now, long window) {
        if (!Agenda.permitted(this)) {
            return false;
        }
        if (now - eventsCheckedAt > 5 * 60000L || now < eventsCheckedAt) {
            eventsCheckedAt = now;
            eventSoon = false;
            try {
                for (Agenda.Event event : Agenda.recent(this, now, 3, this::agendaRead)) {
                    if (!event.allDay && event.begin > now && event.begin - now <= window) {
                        eventSoon = true;
                        break;
                    }
                }
            } catch (Exception ignored) {
            }
        }
        return eventSoon;
    }

    private void runCardUpdater(String type) {
        Runnable update = cardUpdaters.get(type);
        if (update != null) {
            update.run();
        }
    }

    private View cardPage(String type, int slot) {
        switch (type) {
            case "matches":
                return matchesCard(slot);
            case "clock":
                return clockCard();
            case "news":
                return newsCardPage();
            case "weather":
                return weatherCard(slot);
            case "prayers":
                return prayersCard();
            case "agenda":
                return agendaCard();
            case "battery":
                return batteryCard();
            case "table":
                return tableCard(slot);
            case "morning":
                return morningCard(slot);
            case "countdown":
                return countdownCard(slot);
            case "khatma":
                return khatmaCard(slot);
            case "music":
                return musicCard(slot);
            case "messages":
                return messagesCard();
            default:
                return type.startsWith("widget:") ? appWidgetCard(type) : null;
        }
    }

    private String cardName(String type) {
        switch (type) {
            case "matches":
                return getString(R.string.card_matches);
            case "clock":
                return getString(R.string.card_clock);
            case "news":
                return getString(R.string.card_news);
            case "weather":
                return getString(R.string.card_weather);
            case "prayers":
                return getString(R.string.card_prayers);
            case "agenda":
                return getString(R.string.card_agenda);
            case "battery":
                return getString(R.string.card_battery);
            case "table":
                return getString(R.string.card_table);
            case "morning":
                return getString(R.string.card_morning);
            case "countdown":
                return getString(R.string.card_countdown);
            case "khatma":
                return getString(R.string.card_khatma);
            case "music":
                return getString(R.string.card_music);
            case "messages":
                return getString(R.string.card_messages);
            default:
                try {
                    AppWidgetProviderInfo info = widgetManager.getAppWidgetInfo(Integer.parseInt(type.substring(7)));
                    if (info != null) {
                        return getString(R.string.card_widget_named, appName(info.provider.getPackageName()));
                    }
                } catch (Exception ignored) {
                }
                return getString(R.string.card_widget_named, "");
        }
    }

    // ---------------------------------------------------------------- table card

    private boolean tableLoading;
    private long tableFailedAt;

    /**
     * The league table of the first favourite club (or the first chosen league): the top of it and the
     * favourite clubs' rows, with the points. A tap opens the whole table.
     */
    private View tableCard(int slot) {
        final LinearLayout card = wideBase();
        card.setOnClickListener(view -> MatchPage.showTable(this, Standings.league(prefs)));
        cardUpdaters.put("table", () -> {
            card.removeAllViews();
            long now = System.currentTimeMillis();
            final String league = Standings.league(prefs);
            LinearLayout header = wideHeader(Glyphs.TROPHY, getString(R.string.table_of, Matches.leagueShort(league)), null);
            TextView played = cardLine(getString(R.string.table_played), 11, textSecondary, 500);
            played.setGravity(Gravity.CENTER);
            header.addView(played, new LinearLayout.LayoutParams(dp(26.0f), -2));
            TextView pointsTitle = cardLine(getString(R.string.table_points), 11, textSecondary, 500);
            pointsTitle.setGravity(Gravity.END);
            header.addView(pointsTitle, new LinearLayout.LayoutParams(dp(34.0f), -2));
            card.addView(header, new LinearLayout.LayoutParams(-1, -2));
            List<Standings.Row> rows = Standings.cached(prefs, league);
            if (Standings.stale(prefs, league, now) && now - tableFailedAt > 5 * 60000L) {
                refreshTable(league);
            }
            if (rows.isEmpty()) {
                TextView wait = cardLine(getString(tableFailedAt > 0 && !tableLoading ? R.string.table_failed : R.string.table_loading), 13,
                        textSecondary, 400);
                wait.setPadding(0, dp(8.0f), 0, 0);
                card.addView(wait);
                card.setContentDescription(getString(R.string.table_of, Matches.leagueName(league)) + getString(R.string.list_separator) + wait.getText());
                return;
            }
            java.util.Set<String> favourites = Matches.teamIds(prefs);
            // Two rows at a time on the beat: the top of the table, then a favourite club further down.
            List<Standings.Row> shown = Standings.excerpt(rows, favourites, 4);
            if (shown.size() > 4) {
                shown = Standings.excerpt(rows, favourites, 3);
            }
            while (shown.size() > 4) {
                shown.remove(3);
            }
            Ticker pages = ticker(2);
            LinearLayout.LayoutParams pagesParams = new LinearLayout.LayoutParams(-1, -2);
            pagesParams.topMargin = dp(3.0f);
            card.addView(pages, pagesParams);
            StringBuilder spoken = new StringBuilder(getString(R.string.table_of, Matches.leagueName(league)));
            for (Standings.Row row : shown) {
                boolean mine = favourites.contains(row.teamId);
                LinearLayout line = new LinearLayout(this);
                line.setGravity(Gravity.CENTER_VERTICAL);
                line.setPadding(dp(4.0f), dp(2.0f), dp(4.0f), dp(2.0f));
                if (mine) {
                    line.setBackground(pill(withAlpha(accentOnWallpaper(), 0.20f), 8));
                }
                TextView rank = label(localDigits(String.valueOf(row.rank)), 12, textSecondary, 600);
                rank.setGravity(Gravity.CENTER);
                line.addView(rank, new LinearLayout.LayoutParams(dp(18.0f), -2));
                ImageView crest = new ImageView(this);
                crest.setImageDrawable(crestFor(row.teamId, Matches.arabic(row.name), dp(18.0f)));
                LinearLayout.LayoutParams crestParams = new LinearLayout.LayoutParams(dp(18.0f), dp(18.0f));
                crestParams.setMarginStart(dp(4.0f));
                line.addView(crest, crestParams);
                TextView name = cardLine(Matches.arabic(row.name), 13, textPrimary, mine ? 700 : 500);
                LinearLayout.LayoutParams nameParams = new LinearLayout.LayoutParams(0, -2, 1f);
                nameParams.setMarginStart(dp(6.0f));
                line.addView(name, nameParams);
                TextView games = label(localDigits(String.valueOf(row.played)), 11, textSecondary, 400);
                games.setGravity(Gravity.CENTER);
                line.addView(games, new LinearLayout.LayoutParams(dp(22.0f), -2));
                TextView points = label(localDigits(String.valueOf(row.points)), 13, textPrimary, 700);
                points.setGravity(Gravity.END);
                line.addView(points, new LinearLayout.LayoutParams(dp(30.0f), -2));
                pages.addItem(line);
                spoken.append(getString(R.string.list_separator)).append(row.rank).append(' ').append(Matches.arabic(row.name))
                        .append(' ').append(row.points).append(' ').append(getString(R.string.table_points));
            }
            card.setContentDescription(spoken.toString());
        });
        return card;
    }

    void refreshTable(final String league) {
        if (tableLoading) {
            return;
        }
        tableLoading = true;
        background(() -> {
            boolean ok = false;
            try {
                List<Standings.Row> rows = Standings.fetch(league);
                if (!rows.isEmpty()) {
                    Standings.store(prefs, league, rows, System.currentTimeMillis());
                    ok = true;
                    java.util.LinkedHashMap<String, String> crests = new java.util.LinkedHashMap<>();
                    for (Standings.Row row : Standings.excerpt(rows, Matches.teamIds(prefs), 4)) {
                        crests.put(row.teamId, row.logo);
                    }
                    Matches.fetchCrests(this, crests, 8);
                }
            } catch (Exception ignored) {
            }
            final boolean fetched = ok;
            runOnUiThread(() -> {
                tableLoading = false;
                tableFailedAt = fetched ? 0L : System.currentTimeMillis();
                runCardUpdater("table");
            });
        });
    }

    private TextView cardLine(String text, int size, int color, int weight) {
        TextView view = label(text, size, color, weight);
        view.setSingleLine(true);
        view.setEllipsize(TextUtils.TruncateAt.END);
        return view;
    }

    /**
     * The coming matches. The first one large: both crests with the kick-off time and a countdown between
     * them, or the score and the minute while it is played, or the result just after; the league and the
     * channel above, the clubs below. Then one or two more in a line each.
     */
    private View matchesCard(int slot) {
        final LinearLayout card = wideBase();
        card.setOnClickListener(view -> matchSettings());
        final Ticker list = ticker(1);
        card.addView(list, new LinearLayout.LayoutParams(-1, -2));
        cardUpdaters.put("matches", () -> {
            list.clear();
            long now = System.currentTimeMillis();
            List<Matches.Match> shown = Matches.upcoming(prefs, Matches.cached(prefs), now, 4);
            if (shown.isEmpty()) {
                LinearLayout box = new LinearLayout(this);
                box.setOrientation(LinearLayout.VERTICAL);
                box.addView(wideHeader(Glyphs.TROPHY, getString(R.string.card_matches), null));
                boolean never = prefs.getLong("matches_time", 0L) == 0L;
                TextView empty = label(getString(never ? R.string.card_matches_loading : R.string.card_matches_none), 13, textSecondary, 400);
                empty.setMaxLines(2);
                empty.setEllipsize(TextUtils.TruncateAt.END);
                empty.setPadding(0, dp(4.0f), 0, 0);
                box.addView(empty);
                list.addItem(box);
                card.setContentDescription(getString(R.string.card_matches) + "، " + empty.getText());
                return;
            }
            Set<String> favourites = Matches.teamIds(prefs);
            int live = 0xFFFF5A6A;
            StringBuilder spoken = new StringBuilder(getString(R.string.card_matches));
            // One match at a time on the beat, each with its league, channel, crests and score or kick-off.
            for (final Matches.Match match : shown) {
                LinearLayout item = new LinearLayout(this);
                item.setOrientation(LinearLayout.VERTICAL);
                String channel = Matches.channel(match.league);
                String top = Matches.leagueName(match.league) + (channel.length() == 0 || match.finished() ? "" : getString(R.string.list_separator) + channel);
                TextView header = cardLine(match.live ? "● " + getString(R.string.match_live_short) + getString(R.string.list_separator) + top : top,
                        10, match.live ? live : textSecondary, 600);
                header.setGravity(Gravity.CENTER);
                item.addView(header, new LinearLayout.LayoutParams(-1, -2));
                LinearLayout row = new LinearLayout(this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                int crest = dp(30.0f);
                boolean mine = match.involves(favourites);
                ImageView homeCrest = new ImageView(this);
                homeCrest.setImageDrawable(crestFor(match.homeId, Matches.arabic(match.home), crest));
                homeCrest.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
                row.addView(homeCrest, new LinearLayout.LayoutParams(crest, crest));
                TextView homeName = cardLine(Matches.arabic(match.home), 13, textPrimary, mine ? 700 : 600);
                homeName.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
                LinearLayout.LayoutParams homeParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
                homeParams.setMarginStart(dp(6.0f));
                row.addView(homeName, homeParams);
                LinearLayout middle = new LinearLayout(this);
                middle.setOrientation(LinearLayout.VERTICAL);
                middle.setGravity(Gravity.CENTER);
                middle.setPadding(dp(8.0f), 0, dp(8.0f), 0);
                String spokenMiddle;
                if (match.hasScore()) {
                    LinearLayout score = new LinearLayout(this);
                    score.setGravity(Gravity.CENTER);
                    score.addView(label(localDigits(match.homeScore), 19, textPrimary, 700));
                    TextView dash = label("–", 14, textSecondary, 500);
                    dash.setPadding(dp(4.0f), 0, dp(4.0f), 0);
                    score.addView(dash);
                    score.addView(label(localDigits(match.awayScore), 19, textPrimary, 700));
                    middle.addView(score);
                    String state = match.live ? matchClock(match.clock) : getString(R.string.match_full_time);
                    middle.addView(cardLine(state, 10, match.live ? live : textSecondary, 700));
                    spokenMiddle = localDigits(match.homeScore) + " " + getString(R.string.match_to) + " " + localDigits(match.awayScore) + "، " + state;
                } else {
                    String kickoff = android.text.format.DateFormat.getTimeFormat(this).format(new Date(match.time));
                    TextView time = cardLine(kickoff, 15, textPrimary, 700);
                    time.setGravity(Gravity.CENTER);
                    middle.addView(time);
                    long left = match.time - now;
                    String when = left > 0 && left < 3 * 3600000L ? shortCountdown(left) : matchDay(match.time, now);
                    TextView sub = cardLine(when, 10, left > 0 && left < 3 * 3600000L ? accentOnWallpaper() : textSecondary, 600);
                    sub.setGravity(Gravity.CENTER);
                    middle.addView(sub);
                    spokenMiddle = when + " " + kickoff;
                }
                row.addView(middle, new LinearLayout.LayoutParams(-2, -2));
                TextView awayName = cardLine(Matches.arabic(match.away), 13, textPrimary, mine ? 700 : 600);
                awayName.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
                LinearLayout.LayoutParams awayParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
                awayParams.setMarginEnd(dp(6.0f));
                row.addView(awayName, awayParams);
                ImageView awayCrest = new ImageView(this);
                awayCrest.setImageDrawable(crestFor(match.awayId, Matches.arabic(match.away), crest));
                awayCrest.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
                row.addView(awayCrest, new LinearLayout.LayoutParams(crest, crest));
                LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1, -2);
                rowParams.topMargin = dp(3.0f);
                item.addView(row, rowParams);
                item.setOnClickListener(view -> openMatch(match));
                list.addItem(item);
                String teams = Matches.arabic(match.home) + " × " + Matches.arabic(match.away);
                spoken.append("، ").append(mine ? "★ " : "").append(header.getText()).append("، ").append(teams).append("، ").append(spokenMiddle);
            }
            card.setContentDescription(spoken);
        });
        return card;
    }

    /** Arabic-Indic digits when the phone is in Arabic, as the rest of the screen. */
    String localDigits(String text) {
        if (!"ar".equals(Locale.getDefault().getLanguage())) {
            return text;
        }
        StringBuilder out = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            out.append(c >= '0' && c <= '9' ? (char) ('٠' + (c - '0')) : c);
        }
        return out.toString();
    }

    /** "بعد ٤٥ د" under an hour, otherwise whole hours: "بعد ٢ س". Short enough for the narrow card. */
    String shortCountdown(long left) {
        long minutes = Math.max(1L, (left + 59999L) / 60000L);
        return minutes < 60 ? getString(R.string.in_minutes, (int) minutes) : getString(R.string.in_hours, (int) (minutes / 60));
    }

    /** "٦٧'" while played (kept left to right, so the minute mark stays after the number), "استراحة" at half time. */
    String matchClock(String clock) {
        if (clock == null || clock.length() == 0) {
            return getString(R.string.match_live_short);
        }
        if (clock.equals("HT")) {
            return getString(R.string.match_half_time);
        }
        if (clock.equals("FT") || clock.startsWith("AET") || clock.startsWith("FT")) {
            return getString(R.string.match_full_time);
        }
        return "\u2066" + localDigits(clock) + "\u2069";
    }

    /** "اليوم", "غدًا" or the weekday of a kick-off. */
    String matchDay(long time, long now) {
        java.util.Calendar a = java.util.Calendar.getInstance();
        a.setTimeInMillis(now);
        java.util.Calendar b = java.util.Calendar.getInstance();
        b.setTimeInMillis(time);
        int days = (b.get(java.util.Calendar.YEAR) - a.get(java.util.Calendar.YEAR)) * 366
                + b.get(java.util.Calendar.DAY_OF_YEAR) - a.get(java.util.Calendar.DAY_OF_YEAR);
        if (days <= 0) {
            return getString(R.string.agenda_today);
        }
        if (days == 1) {
            return getString(R.string.agenda_tomorrow);
        }
        return new SimpleDateFormat("EEEE", Locale.getDefault()).format(new Date(time));
    }

    private final HashMap<String, Bitmap> crests = new HashMap<>();

    /** The club's crest once it has been downloaded; until then its first letter in a soft circle. */
    Drawable crestFor(String teamId, String name, int size) {
        Bitmap bitmap = crests.get(teamId);
        if (bitmap == null) {
            java.io.File file = Matches.crestFile(this, teamId);
            if (file.exists()) {
                bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
                if (bitmap != null) {
                    crests.put(teamId, bitmap);
                }
            }
        }
        if (bitmap != null) {
            return new BitmapDrawable(getResources(), bitmap);
        }
        final String letter = name == null || name.isEmpty() ? "?" : name.replaceFirst("^ال", "").substring(0, 1);
        final int ring = withAlpha(textPrimary, 0.16f);
        final int ink = textPrimary;
        return new Drawable() {
            private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

            @Override
            public void draw(Canvas canvas) {
                android.graphics.Rect b = getBounds();
                float r = Math.min(b.width(), b.height()) / 2f;
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(ring);
                canvas.drawCircle(b.exactCenterX(), b.exactCenterY(), r, paint);
                paint.setColor(ink);
                paint.setTextAlign(Paint.Align.CENTER);
                paint.setTextSize(r * 0.95f);
                paint.setTypeface(font(700));
                Paint.FontMetrics metrics = paint.getFontMetrics();
                canvas.drawText(letter, b.exactCenterX(), b.exactCenterY() - (metrics.ascent + metrics.descent) / 2f, paint);
            }

            @Override
            public void setAlpha(int alpha) {
                paint.setAlpha(alpha);
            }

            @Override
            public void setColorFilter(android.graphics.ColorFilter filter) {
                paint.setColorFilter(filter);
            }

            @Override
            public int getOpacity() {
                return android.graphics.PixelFormat.TRANSLUCENT;
            }

            @Override
            public int getIntrinsicWidth() {
                return size;
            }

            @Override
            public int getIntrinsicHeight() {
                return size;
            }
        };
    }

    /** "اليوم ٩:٠٠ م", "غدًا ٩:٠٠ م" or "الجمعة ٩:٠٠ م", in the phone's own time. */
    private String matchWhen(long time, long now) {
        java.util.Calendar a = java.util.Calendar.getInstance();
        a.setTimeInMillis(now);
        java.util.Calendar b = java.util.Calendar.getInstance();
        b.setTimeInMillis(time);
        int days = (b.get(java.util.Calendar.YEAR) - a.get(java.util.Calendar.YEAR)) * 366
                + b.get(java.util.Calendar.DAY_OF_YEAR) - a.get(java.util.Calendar.DAY_OF_YEAR);
        String clock = android.text.format.DateFormat.getTimeFormat(this).format(new Date(time));
        String day;
        if (days <= 0) {
            day = getString(R.string.agenda_today);
        } else if (days == 1) {
            day = getString(R.string.agenda_tomorrow);
        } else {
            day = new SimpleDateFormat("EEEE", Locale.getDefault()).format(new Date(time));
        }
        return day + " " + clock;
    }

    /** The match's own page inside Sara Home: goals, cards, numbers, the table. */
    private void openMatch(Matches.Match match) {
        MatchPage.show(this, match);
    }

    /** Work off the main thread (network, files). */
    void background(Runnable work) {
        if (!newsExecutor.isShutdown()) {
            newsExecutor.execute(work);
        }
    }

    /** Google's own match card, in Arabic, for "الهلال ضد النصر". */
    void searchMatch(Matches.Match match) {
        String query = Matches.arabic(match.home) + " ضد " + Matches.arabic(match.away);
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))));
        } catch (Exception ignored) {
        }
    }

    private boolean matchesShown() {
        return cardTypes(0).contains("matches") || cardTypes(1).contains("matches");
    }

    /** Every half hour; every five minutes while a match is on or about to start. */
    private void refreshMatches(boolean force) {
        if (matchesLoading || newsExecutor.isShutdown() || !matchesShown()) {
            return;
        }
        long now = System.currentTimeMillis();
        long last = prefs.getLong("matches_time", 0L);
        // Every minute while a match of the card is being played (for the score), every two minutes
        // around a kick-off, otherwise every half hour.
        long every = Matches.REFRESH_MS;
        for (Matches.Match match : Matches.cached(prefs)) {
            if (match.live) {
                every = 60000L;
                break;
            }
            if ("pre".equals(match.state) && match.time > now - 30 * 60000L && match.time < now + 15 * 60000L) {
                every = Math.min(every, 2L * 60000L);
            }
        }
        if (!force && last != 0L && now - last < every) {
            return;
        }
        matchesLoading = true;
        final Set<String> leagues = Matches.toFetch(prefs);
        newsExecutor.execute(() -> {
            try {
                List<Matches.Match> found = Matches.fetch(leagues, System.currentTimeMillis());
                Matches.store(prefs, found, System.currentTimeMillis());
                ReminderReceiver.checkScores(HomeActivity.this, found);
                // Crests of what the card will show first, and of every match of the favourite clubs.
                ArrayList<Matches.Match> crestsFor = new ArrayList<>(Matches.upcoming(prefs, found, System.currentTimeMillis(), 10));
                Set<String> favourites = Matches.teamIds(prefs);
                for (Matches.Match match : found) {
                    if (match.involves(favourites)) {
                        crestsFor.add(match);
                    }
                }
                Matches.fetchCrests(HomeActivity.this, crestsFor, 24);
            } catch (Exception ignored) {
                // offline: the card keeps what it had and tries again later
            }
            runOnUiThread(() -> {
                matchesLoading = false;
                try {
                    ReminderReceiver.scheduleMatch(HomeActivity.this);
                    ReminderReceiver.scheduleWatch(HomeActivity.this, 0L);
                } catch (Exception ignored) {
                }
                if (!isDestroyed()) {
                    runCardUpdater("matches");
                    runCardUpdater("table");
                    smartStacks(System.currentTimeMillis());
                }
            });
        });
    }

    /** The card's settings: which leagues, which clubs, and where the times and channels come from. */
    void matchSettings() {
        List<Matches.Team> teams = Matches.teams(prefs);
        StringBuilder chosen = new StringBuilder();
        for (Matches.Team team : teams) {
            chosen.append(chosen.length() == 0 ? "" : "، ").append(Matches.arabic(team.name));
        }
        int alert = Matches.alertMinutes(prefs);
        String[] items = {getString(R.string.match_pick_leagues),
                teams.isEmpty() ? getString(R.string.match_pick_teams) : getString(R.string.match_pick_teams_with, chosen),
                getString(R.string.match_alert_value, alert <= 0 ? getString(R.string.match_alert_off) : getString(R.string.match_alert_minutes, alert)),
                getString(R.string.match_goal_alerts) + getString(R.string.list_separator)
                        + getString(ReminderReceiver.goalAlerts(prefs) ? R.string.state_on : R.string.state_off),
                getString(R.string.table_of, Matches.leagueShort(Standings.league(prefs))),
                getString(R.string.match_source)};
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.card_matches))
                .setItems(items, (dialog, which) -> {
                    if (which == 0) {
                        pickMatchLeagues();
                    } else if (which == 1) {
                        pickFavouriteLeague();
                    } else if (which == 2) {
                        pickMatchAlert();
                    } else if (which == 3) {
                        boolean on = !ReminderReceiver.goalAlerts(prefs);
                        prefs.edit().putBoolean("match_goal_alerts", on).apply();
                        if (on && Build.VERSION.SDK_INT >= 33 && !ReminderReceiver.canNotify(this)) {
                            Permissions.ask(this, new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 7305, R.string.perm_why_notifications);
                        }
                        if (on && Matches.teamIds(prefs).isEmpty()) {
                            Toast.makeText(this, getString(R.string.match_alert_needs_team), Toast.LENGTH_LONG).show();
                        }
                        ReminderReceiver.scheduleWatch(this, 0L);
                        Toast.makeText(this, getString(R.string.match_goal_alerts) + getString(R.string.list_separator)
                                + getString(on ? R.string.state_on : R.string.state_off), Toast.LENGTH_SHORT).show();
                    } else if (which == 4) {
                        MatchPage.showTable(this, Standings.league(prefs));
                    } else {
                        new AlertDialog.Builder(this)
                                .setTitle(getString(R.string.match_source))
                                .setMessage(getString(R.string.match_source_text))
                                .setPositiveButton(getString(R.string.done), null)
                                .show();
                    }
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    /** Minutes before a favourite club's match for the alert. */
    private void pickMatchAlert() {
        final int[] choices = Matches.ALERT_CHOICES;
        String[] names = new String[choices.length];
        int current = 0;
        for (int i = 0; i < choices.length; i++) {
            names[i] = choices[i] == 0 ? getString(R.string.match_alert_off) : getString(R.string.match_alert_minutes, choices[i]);
            if (choices[i] == Matches.alertMinutes(prefs)) {
                current = i;
            }
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.match_alert_pick))
                .setSingleChoiceItems(names, current, (dialog, which) -> {
                    prefs.edit().putInt(Matches.PREF_ALERT, choices[which]).apply();
                    dialog.dismiss();
                    if (choices[which] > 0 && Build.VERSION.SDK_INT >= 33 && !ReminderReceiver.canNotify(this)) {
                        Permissions.ask(this, new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 7305, R.string.perm_why_notifications);
                    }
                    if (choices[which] > 0 && Matches.teamIds(prefs).isEmpty()) {
                        Toast.makeText(this, getString(R.string.match_alert_needs_team), Toast.LENGTH_LONG).show();
                    }
                    ReminderReceiver.scheduleMatch(this);
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void pickMatchLeagues() {
        final Set<String> current = Matches.leagues(prefs);
        final String[] names = new String[Matches.LEAGUES.length];
        final boolean[] checked = new boolean[Matches.LEAGUES.length];
        for (int i = 0; i < names.length; i++) {
            names[i] = Matches.LEAGUES[i][2].isEmpty() ? Matches.LEAGUES[i][1]
                    : Matches.LEAGUES[i][1] + getString(R.string.list_separator) + Matches.LEAGUES[i][2];
            checked[i] = current.contains(Matches.LEAGUES[i][0]);
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.match_pick_leagues))
                .setMultiChoiceItems(names, checked, (dialog, which, isChecked) -> checked[which] = isChecked)
                .setPositiveButton(getString(R.string.done), (dialog, which) -> {
                    java.util.LinkedHashSet<String> leagues = new java.util.LinkedHashSet<>();
                    for (int i = 0; i < checked.length; i++) {
                        if (checked[i]) {
                            leagues.add(Matches.LEAGUES[i][0]);
                        }
                    }
                    Matches.saveLeagues(prefs, leagues);
                    runCardUpdater("matches");
                    refreshMatches(true);
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    /** Favourite clubs are picked league by league, from ESPN's list of that league's clubs. */
    private void pickFavouriteLeague() {
        final String[] slugs = Matches.TEAM_SOURCES;
        ArrayList<String> names = new ArrayList<>();
        for (String slug : slugs) {
            if (slug.equals("uefa.champions")) {
                names.add(getString(R.string.match_teams_from_ucl));
            } else if (slug.equals("afc.champions")) {
                names.add(getString(R.string.match_teams_from_acl));
            } else if (slug.equals("afc.asian.cup")) {
                names.add(getString(R.string.match_teams_national));
            } else {
                names.add(Matches.leagueName(slug));
            }
        }
        final boolean any = !Matches.teams(prefs).isEmpty();
        if (any) {
            names.add(getString(R.string.match_clear_teams));
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.match_pick_teams))
                .setItems(names.toArray(new String[0]), (dialog, which) -> {
                    if (which < slugs.length) {
                        loadTeams(slugs[which]);
                    } else {
                        Matches.saveTeams(prefs, new ArrayList<>());
                        runCardUpdater("matches");
                        refreshMatches(true);
                    }
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void loadTeams(final String league) {
        Toast.makeText(this, getString(R.string.match_loading_teams), Toast.LENGTH_SHORT).show();
        newsExecutor.execute(() -> {
            List<String[]> found = null;
            try {
                found = Matches.fetchTeams(league);
            } catch (Exception ignored) {
            }
            final List<String[]> clubs = found;
            runOnUiThread(() -> {
                if (isDestroyed()) {
                    return;
                }
                if (clubs == null || clubs.isEmpty()) {
                    Toast.makeText(this, getString(R.string.match_teams_failed), Toast.LENGTH_LONG).show();
                    return;
                }
                pickTeams(league, clubs);
            });
        });
    }

    void pickTeams(final String league, final List<String[]> clubs) {
        Set<String> mine = Matches.teamIds(prefs);
        String[] names = new String[clubs.size()];
        final boolean[] checked = new boolean[clubs.size()];
        for (int i = 0; i < clubs.size(); i++) {
            names[i] = Matches.arabic(clubs.get(i)[1]);
            checked[i] = mine.contains(clubs.get(i)[0]);
        }
        new AlertDialog.Builder(this)
                .setTitle(Matches.leagueName(league))
                .setMultiChoiceItems(names, checked, (dialog, which, isChecked) -> checked[which] = isChecked)
                .setPositiveButton(getString(R.string.done), (dialog, which) -> {
                    ArrayList<Matches.Team> teams = new ArrayList<>();
                    java.util.HashSet<String> here = new java.util.HashSet<>();
                    for (String[] club : clubs) {
                        here.add(club[0]);
                    }
                    for (Matches.Team team : Matches.teams(prefs)) {
                        if (!here.contains(team.id)) {
                            teams.add(team); // clubs from other leagues stay
                        }
                    }
                    for (int i = 0; i < clubs.size(); i++) {
                        if (checked[i]) {
                            teams.add(new Matches.Team(clubs.get(i)[0], clubs.get(i)[1], league));
                        }
                    }
                    Matches.saveTeams(prefs, teams);
                    runCardUpdater("matches");
                    refreshMatches(true);
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    /** Weather now, today's high and low, and the next few hours. */
    private View weatherCard(int slot) {
        final LinearLayout card = wideBase();
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setOnClickListener(view -> openToday());
        final ImageView icon = new ImageView(this);
        card.addView(icon, new LinearLayout.LayoutParams(dp(36.0f), dp(36.0f)));
        final TextView temp = cardLine("", 32, textPrimary, 500);
        temp.setIncludeFontPadding(false);
        LinearLayout.LayoutParams tempParams = new LinearLayout.LayoutParams(-2, -2);
        tempParams.setMarginStart(dp(8.0f));
        card.addView(temp, tempParams);
        LinearLayout side = new LinearLayout(this);
        side.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams sideParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
        sideParams.setMarginStart(dp(16.0f));
        card.addView(side, sideParams);
        final TextView desc = cardLine("", 14, textPrimary, 600);
        side.addView(desc, new LinearLayout.LayoutParams(-1, -2));
        // The high and low, a dust or rain warning, and the coming hours take turns.
        final Ticker lines = ticker(1);
        LinearLayout.LayoutParams linesParams = new LinearLayout.LayoutParams(-1, -2);
        linesParams.topMargin = dp(4.0f);
        side.addView(lines, linesParams);
        cardUpdaters.put("weather", () -> {
            Weather.Now now = weatherOn ? Weather.cached(prefs) : null;
            lines.clear();
            if (now == null) {
                icon.setImageDrawable(new Weather.Icon(Weather.PARTLY, withAlpha(textPrimary, 0.55f), dp(36.0f)));
                temp.setText("--°");
                desc.setText(getString(weatherOn ? R.string.card_weather_waiting : R.string.card_weather_off));
                desc.setSingleLine(false);
                desc.setMaxLines(3);
                card.setContentDescription(getString(R.string.card_weather) + "، " + desc.getText());
                return;
            }
            desc.setSingleLine(true);
            icon.setImageDrawable(new Weather.Icon(Weather.iconType(now.code, now.day), textPrimary, dp(36.0f)));
            temp.setText(Weather.degrees(now.temp));
            desc.setText(getString(Weather.descriptionRes(now.code)));
            StringBuilder spoken = new StringBuilder(getString(R.string.card_weather)).append("، ").append(temp.getText())
                    .append("، ").append(desc.getText());
            Weather.Alert alert = Weather.alertsOn(prefs) ? Weather.cachedAlert(prefs, System.currentTimeMillis()) : null;
            if (alert != null) {
                // Dust or rain coming: first in line, in amber.
                TextView warn = cardLine(Weather.alertText(this, alert), 12, darkWallpaper ? 0xFFFFD27A : 0xFF8F5200, 600);
                warn.setSingleLine(false);
                warn.setMaxLines(2);
                lines.addItem(warn);
                spoken.append("، ").append(warn.getText());
            }
            TextView range = cardLine(getString(R.string.card_weather_range, Weather.degrees(now.max), Weather.degrees(now.min)),
                    13, textSecondary, 500);
            lines.addItem(range);
            spoken.append("، ").append(range.getText());
            java.text.SimpleDateFormat hourFormat = new java.text.SimpleDateFormat(
                    android.text.format.DateFormat.is24HourFormat(this) ? "H:mm" : "h a", Locale.getDefault());
            LinearLayout hours = new LinearLayout(this);
            hours.setTag("hours");
            for (Weather.Hour hour : Weather.upcoming(now, System.currentTimeMillis(), 3)) {
                LinearLayout cell = new LinearLayout(this);
                cell.setGravity(Gravity.CENTER_VERTICAL);
                TextView when = cardLine(hourFormat.format(new Date(hour.time)), 10, textSecondary, 500);
                cell.addView(when);
                ImageView small = new ImageView(this);
                small.setImageDrawable(new Weather.Icon(Weather.iconType(hour.code, hour.day), textPrimary, dp(13.0f)));
                LinearLayout.LayoutParams smallParams = new LinearLayout.LayoutParams(dp(13.0f), dp(13.0f));
                smallParams.setMarginStart(dp(3.0f));
                cell.addView(small, smallParams);
                TextView degrees = cardLine(Weather.degrees(hour.temp), 12, textPrimary, 600);
                LinearLayout.LayoutParams degreesParams = new LinearLayout.LayoutParams(-2, -2);
                degreesParams.setMarginStart(dp(3.0f));
                cell.addView(degrees, degreesParams);
                hours.addView(cell, new LinearLayout.LayoutParams(0, -2, 1.0f));
                spoken.append("، ").append(when.getText()).append(" ").append(degrees.getText());
            }
            if (hours.getChildCount() > 0) {
                lines.addItem(hours);
            }
            card.setContentDescription(spoken);
        });
        return card;
    }

    /** The five prayers of today, the next one marked, with how long until it. */
    private View prayersCard() {
        final LinearLayout card = wideBase();
        card.setOnClickListener(view -> openToday());
        final TextView next = cardLine("", 13, accentOnWallpaper(), 700);
        card.addView(next, new LinearLayout.LayoutParams(-1, -2));
        // The five prayers across the card, the next one marked.
        final LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rowsParams = new LinearLayout.LayoutParams(-1, -2);
        rowsParams.topMargin = dp(6.0f);
        card.addView(rows, rowsParams);
        cardUpdaters.put("prayers", () -> {
            long now = System.currentTimeMillis();
            long[] times = Prayers.timesFor(prefs, now);
            long[] coming = Prayers.next(prefs, now);
            next.setText(Prayers.nextText(this, prefs, now));
            rows.removeAllViews();
            StringBuilder spoken = new StringBuilder(getString(R.string.card_prayers)).append("، ").append(next.getText());
            for (int i = 0; i < times.length; i++) {
                if (i == PrayerTimes.SUNRISE) {
                    continue;
                }
                boolean isNext = i == coming[0];
                boolean past = !isNext && times[i] <= now;
                int color = past ? textSecondary : textPrimary;
                LinearLayout cell = new LinearLayout(this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER);
                String name = getString(Prayers.NAMES[i]);
                String at = Prayers.timeText(this, prefs, isNext ? coming[1] : times[i]);
                TextView nameView = cardLine(name, 11, color, isNext ? 700 : 500);
                nameView.setGravity(Gravity.CENTER);
                cell.addView(nameView, new LinearLayout.LayoutParams(-1, -2));
                TextView atView = cardLine(at, 12, color, isNext ? 700 : 500);
                atView.setGravity(Gravity.CENTER);
                cell.addView(atView, new LinearLayout.LayoutParams(-1, -2));
                if (isNext) {
                    cell.setBackground(pill(withAlpha(accentOnWallpaper(), darkWallpaper ? 0.30f : 0.20f), 11));
                }
                LinearLayout.LayoutParams cellParams = new LinearLayout.LayoutParams(0, dp(38.0f), 1.0f);
                cellParams.setMargins(dp(1.5f), 0, dp(1.5f), 0);
                rows.addView(cell, cellParams);
                spoken.append("، ").append(name).append(" ").append(at);
            }
            card.setContentDescription(spoken);
        });
        return card;
    }

    /** The calendar's next events, today and tomorrow. */
    private View agendaCard() {
        final LinearLayout card = wideBase();
        card.setOnClickListener(view -> openCalendar());
        card.addView(wideHeader(Glyphs.CALENDAR, getString(R.string.card_agenda), null), new LinearLayout.LayoutParams(-1, -2));
        final Ticker list = ticker(1);
        LinearLayout.LayoutParams listParams = new LinearLayout.LayoutParams(-1, -2);
        listParams.topMargin = dp(6.0f);
        card.addView(list, listParams);
        cardUpdaters.put("agenda", () -> {
            list.clear();
            if (!Agenda.permitted(this)) {
                LinearLayout ask = new LinearLayout(this);
                ask.setOrientation(LinearLayout.VERTICAL);
                TextView why = cardLine(getString(R.string.card_agenda_ask), 13, textPrimary, 400);
                ask.addView(why);
                TextView allow = cardLine(getString(R.string.card_agenda_allow), 13, accentOnWallpaper(), 700);
                allow.setPadding(0, dp(2.0f), 0, 0);
                ask.addView(allow);
                ask.setOnClickListener(view -> Permissions.ask(this, new String[]{android.Manifest.permission.READ_CALENDAR}, REQUEST_CALENDAR, R.string.perm_why_calendar));
                list.addItem(ask);
                card.setContentDescription(getString(R.string.card_agenda) + "، " + why.getText());
                return;
            }
            long now = System.currentTimeMillis();
            List<Agenda.Event> events = Agenda.recent(this, now, 4, this::agendaRead);
            if (events.isEmpty()) {
                TextView empty = cardLine(getString(R.string.agenda_empty), 13, textSecondary, 400);
                list.addItem(empty);
                card.setContentDescription(getString(R.string.card_agenda) + "، " + empty.getText());
                return;
            }
            StringBuilder spoken = new StringBuilder(getString(R.string.card_agenda));
            for (final Agenda.Event event : events) {
                LinearLayout row = new LinearLayout(this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                View bar = new View(this);
                bar.setBackground(pill(event.color != 0 ? (event.color | 0xFF000000) : accent, 2));
                row.addView(bar, new LinearLayout.LayoutParams(dp(3.0f), dp(30.0f)));
                LinearLayout texts = new LinearLayout(this);
                texts.setOrientation(LinearLayout.VERTICAL);
                texts.addView(cardLine(event.title, 14, textPrimary, 600));
                String day = getString(Agenda.dayOffset(event.begin, now) == 0 ? R.string.agenda_today : R.string.agenda_tomorrow);
                String when = event.allDay ? getString(R.string.agenda_all_day) : timeText(event.begin);
                texts.addView(cardLine(day + getString(R.string.list_separator) + when, 12, textSecondary, 400));
                LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(0, -2, 1f);
                textParams.setMarginStart(dp(8.0f));
                row.addView(texts, textParams);
                row.setOnClickListener(view -> {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Agenda.eventUri(event.id)));
                    } catch (Exception ignored) {
                    }
                });
                list.addItem(row);
                spoken.append("، ").append(event.title).append("، ").append(day).append(" ").append(when);
            }
            card.setContentDescription(spoken);
        });
        return card;
    }

    /** A big battery ring with the percentage, what it's doing, and the Wi-Fi state. */
    private View batteryCard() {
        final LinearLayout card = wideBase();
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setOnClickListener(view -> openBatterySettings());
        ImageView ring = new ImageView(this);
        cardRing = new StatusRing(textPrimary, dp(58.0f));
        cardRing.setNetworkVisible(false);
        ring.setImageDrawable(cardRing);
        card.addView(ring, new LinearLayout.LayoutParams(dp(58.0f), dp(58.0f)));
        LinearLayout side = new LinearLayout(this);
        side.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams sideParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
        sideParams.setMarginStart(dp(16.0f));
        card.addView(side, sideParams);
        final TextView state = cardLine("", 15, textPrimary, 600);
        side.addView(state, new LinearLayout.LayoutParams(-1, -2));
        final TextView extra = cardLine("", 12, textSecondary, 400);
        LinearLayout.LayoutParams extraParams = new LinearLayout.LayoutParams(-1, -2);
        extraParams.topMargin = dp(3.0f);
        side.addView(extra, extraParams);
        cardUpdaters.put("battery", () -> {
            if (cardRing == null) {
                return;
            }
            cardRing.setBattery(batteryLevelNow, batteryCharging, batterySaver);
            String text;
            if (batteryCharging) {
                long left = -1L;
                BatteryManager manager = getSystemService(BatteryManager.class);
                if (manager != null && Build.VERSION.SDK_INT >= 28) {
                    left = manager.computeChargeTimeRemaining();
                }
                text = batteryLevelNow >= 100 ? getString(R.string.card_battery_full)
                        : left > 0 ? getString(R.string.card_battery_full_in, Prayers.countdown(this, left))
                        : getString(R.string.card_battery_charging);
            } else if (batterySaver) {
                text = getString(R.string.card_battery_saver);
            } else if (batteryLevelNow >= 0 && batteryLevelNow <= 20) {
                text = getString(R.string.card_battery_low);
            } else {
                text = getString(R.string.card_battery_ok);
            }
            state.setText(text);
            extra.setText(getString(wifiOn ? R.string.card_wifi_on : R.string.card_wifi_off));
            String percent = batteryLevelNow < 0 ? "" : java.text.NumberFormat.getPercentInstance().format(batteryLevelNow / 100.0) + "، ";
            card.setContentDescription(getString(R.string.card_battery) + "، " + percent + text + "، " + extra.getText());
        });
        return card;
    }

    /** A widget from another app, living in one of the stacks. */
    private View appWidgetCard(String type) {
        int id;
        try {
            id = Integer.parseInt(type.substring(7));
        } catch (Exception e) {
            return null;
        }
        FrameLayout page = new FrameLayout(this);
        page.setPadding(dp(6.0f), dp(6.0f), dp(6.0f), dp(10.0f));
        AppWidgetProviderInfo info = null;
        try {
            info = widgetManager.getAppWidgetInfo(id);
        } catch (Exception ignored) {
        }
        AppWidgetHostView view = info == null ? null : widgetViews.get(id);
        if (info != null && view == null) {
            try {
                view = widgetHost.createView(getApplicationContext(), id, info);
                widgetViews.put(id, view);
            } catch (Exception ignored) {
            }
        }
        if (view == null) {
            TextView gone = label(getString(R.string.card_widget_gone), 13, textSecondary, 400);
            gone.setGravity(Gravity.CENTER);
            gone.setPadding(dp(10.0f), 0, dp(10.0f), 0);
            page.addView(gone, new FrameLayout.LayoutParams(-1, -1));
            page.setContentDescription(gone.getText());
            return page;
        }
        if (view.getParent() instanceof ViewGroup) {
            ((ViewGroup) view.getParent()).removeView(view);
        }
        page.addView(view, new FrameLayout.LayoutParams(-1, -1));
        page.setContentDescription(getString(R.string.card_widget_named, appName(info.provider.getPackageName())));
        final AppWidgetHostView host = view;
        final float density = getResources().getDisplayMetrics().density;
        page.addOnLayoutChangeListener((v, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom) -> {
            if (right - left != oldRight - oldLeft || bottom - top != oldBottom - oldTop) {
                int width = Math.round((right - left) / density);
                int height = Math.round((bottom - top) / density);
                try {
                    host.updateAppWidgetSize(null, width, height, width, height);
                } catch (Exception ignored) {
                }
            }
        });
        return page;
    }

    /** Holding a stack: choose which cards it shows, or put another app's widget in it. */
    void editCards(final int slot) {
        final List<String> mine = cardTypes(slot);
        final List<String> other = cardTypes(1 - slot);
        final ArrayList<String> entries = new ArrayList<>(mine);
        for (String type : CARD_TYPES) {
            if (!entries.contains(type)) {
                entries.add(type);
            }
        }
        final boolean[] checked = new boolean[entries.size()];
        String[] names = new String[entries.size()];
        for (int i = 0; i < entries.size(); i++) {
            String type = entries.get(i);
            checked[i] = mine.contains(type);
            names[i] = other.contains(type) ? getString(R.string.cards_in_other, cardName(type)) : cardName(type);
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.cards_edit_title))
                .setMultiChoiceItems(names, checked, (dialog, which, isChecked) -> checked[which] = isChecked)
                .setPositiveButton(getString(R.string.done), (dialog, which) -> applyCardChoice(slot, entries, checked))
                .setNeutralButton(getString(R.string.cards_add_widget), (dialog, which) -> pickWidget(slot))
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    void applyCardChoice(int slot, List<String> entries, boolean[] checked) {
        List<String> mine = cardTypes(slot);
        ArrayList<String> other = new ArrayList<>(cardTypes(1 - slot));
        ArrayList<String> chosen = new ArrayList<>();
        for (int i = 0; i < entries.size(); i++) {
            if (checked[i]) {
                chosen.add(entries.get(i));
            }
        }
        boolean refused = false;
        for (String type : new ArrayList<>(chosen)) {
            other.remove(type);
        }
        for (String type : mine) {
            if (type.startsWith("widget:") && !chosen.contains(type)) {
                try {
                    int id = Integer.parseInt(type.substring(7));
                    widgetViews.remove(id);
                    widgetHost.deleteAppWidgetId(id);
                } catch (Exception ignored) {
                }
            }
        }
        String current = slot < cardStacks.size() ? cardStacks.get(slot).currentType() : "";
        saveCardTypes(slot, chosen);
        saveCardTypes(1 - slot, other);
        prefs.edit().putInt("card_page_" + slot, Math.max(0, chosen.indexOf(current))).apply();
        fillCards();
    }

    // ---------------------------------------------------------------- app icons

    /** Long press, "Change icon": a picture of the user's own, an icon from a pack, or the original back. */
    void chooseIcon(final AppEntry entry) {
        final ArrayList<Integer> options = new ArrayList<>();
        ArrayList<String> names = new ArrayList<>();
        options.add(0);
        names.add(getString(R.string.icon_from_picture));
        final Map<String, String> packs = IconPack.installed(this);
        if (!packs.isEmpty()) {
            options.add(1);
            names.add(getString(R.string.icon_from_pack));
        }
        if (CustomIcons.has(prefs, entry.key)) {
            options.add(2);
            names.add(getString(R.string.icon_restore));
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.change_icon_title, entry.label))
                .setItems(names.toArray(new String[0]), (dialog, which) -> {
                    int option = options.get(which);
                    if (option == 0) {
                        pickIconPicture(entry);
                    } else if (option == 1) {
                        choosePack(entry, packs);
                    } else {
                        CustomIcons.clear(this, prefs, entry.key);
                        scheduleAppReload();
                        Toast.makeText(this, getString(R.string.icon_restored), Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void pickIconPicture(AppEntry entry) {
        pendingIconKey = entry.key;
        prefs.edit().putString("pending_icon", entry.key).apply();
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*");
        try {
            startActivityForResult(intent, REQUEST_ICON_PICTURE);
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.cannot_open), Toast.LENGTH_SHORT).show();
        }
    }

    private void iconPictureChosen(int resultCode, Intent data) {
        final String key = pendingIconKey != null ? pendingIconKey : prefs.getString("pending_icon", null);
        pendingIconKey = null;
        prefs.edit().remove("pending_icon").apply();
        if (resultCode != RESULT_OK || data == null || data.getData() == null || key == null) {
            return;
        }
        final Uri picture = data.getData();
        appExecutor.execute(() -> {
            final boolean saved = CustomIcons.saveFromPicture(this, picture, key);
            runOnUiThread(() -> {
                if (saved) {
                    scheduleAppReload();
                } else {
                    Toast.makeText(this, getString(R.string.icon_failed), Toast.LENGTH_SHORT).show();
                }
            });
        });
    }

    private void choosePack(final AppEntry entry, Map<String, String> packs) {
        final ArrayList<String> ids = new ArrayList<>(packs.keySet());
        if (ids.size() == 1) {
            showPackIcons(entry, ids.get(0));
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.icon_pack_choose))
                .setItems(packs.values().toArray(new String[0]), (dialog, which) -> showPackIcons(entry, ids.get(which)))
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    /** Every icon in the pack, with a search box that starts on the app's name (e.g. "twitter" for X). */
    private void showPackIcons(final AppEntry entry, String packName) {
        final IconPack pack = IconPack.load(this, packName);
        if (pack == null) {
            Toast.makeText(this, getString(R.string.icon_pack_unreadable), Toast.LENGTH_SHORT).show();
            return;
        }
        final List<String> all = pack.allDrawables();
        final String mapped = pack.nameFor(entry.component);
        if (mapped != null) {
            all.remove(mapped);
            all.add(0, mapped);
        }
        final ArrayList<String> shown = new ArrayList<>();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18.0f), dp(6.0f), dp(18.0f), 0);
        final EditText filter = new EditText(this);
        filter.setSingleLine(true);
        filter.setHint(getString(R.string.icon_search_hint));
        box.addView(filter, new LinearLayout.LayoutParams(-1, -2));
        final TextView empty = label(getString(R.string.icon_pack_empty), 14, 0xFF888888, 400);
        empty.setPadding(0, dp(12.0f), 0, dp(12.0f));
        empty.setVisibility(View.GONE);
        box.addView(empty, new LinearLayout.LayoutParams(-1, -2));
        final GridView icons = new GridView(this);
        icons.setNumColumns(GridView.AUTO_FIT);
        icons.setColumnWidth(dp(64.0f));
        icons.setVerticalSpacing(dp(6.0f));
        icons.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        box.addView(icons, new LinearLayout.LayoutParams(-1, dp(340.0f)));
        final HashMap<String, Drawable> cache = new HashMap<>();
        final BaseAdapter adapter = new BaseAdapter() {
            @Override
            public int getCount() {
                return shown.size();
            }

            @Override
            public Object getItem(int position) {
                return shown.get(position);
            }

            @Override
            public long getItemId(int position) {
                return position;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                ImageView image = convertView instanceof ImageView ? (ImageView) convertView : new ImageView(HomeActivity.this);
                image.setLayoutParams(new AbsListView.LayoutParams(-1, dp(60.0f)));
                image.setPadding(dp(4.0f), dp(4.0f), dp(4.0f), dp(4.0f));
                image.setScaleType(ImageView.ScaleType.FIT_CENTER);
                String name = shown.get(position);
                Drawable drawable = cache.get(name);
                if (drawable == null && !cache.containsKey(name)) {
                    drawable = pack.drawableNamed(name);
                    if (cache.size() > 160) {
                        cache.clear();
                    }
                    cache.put(name, drawable);
                }
                image.setImageDrawable(drawable);
                image.setContentDescription(name.replace('_', ' '));
                return image;
            }
        };
        icons.setAdapter(adapter);
        final Runnable apply = () -> {
            String query = filter.getText().toString().trim().toLowerCase(Locale.ROOT).replace(' ', '_');
            shown.clear();
            for (String name : all) {
                if (query.length() == 0 || name.toLowerCase(Locale.ROOT).contains(query)) {
                    shown.add(name);
                }
            }
            empty.setVisibility(shown.isEmpty() ? View.VISIBLE : View.GONE);
            adapter.notifyDataSetChanged();
        };
        String hint = CustomIcons.searchHint(entry.pkg);
        filter.setText(hint);
        apply.run();
        if (shown.isEmpty() || (mapped != null && !shown.contains(mapped))) {
            filter.setText("");
            apply.run();
        }
        filter.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence text, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence text, int start, int before, int count) {
                apply.run();
            }

            @Override
            public void afterTextChanged(Editable text) {
            }
        });
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(getString(R.string.change_icon_title, entry.label))
                .setView(box)
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
        icons.setOnItemClickListener((parent, view, position, id) -> {
            final Drawable chosen = pack.drawableNamed(shown.get(position));
            dialog.dismiss();
            if (chosen == null) {
                Toast.makeText(this, getString(R.string.icon_failed), Toast.LENGTH_SHORT).show();
                return;
            }
            if (CustomIcons.saveFromDrawable(this, chosen, entry.key)) {
                scheduleAppReload();
            } else {
                Toast.makeText(this, getString(R.string.icon_failed), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void openCalendar() {
        try {
            startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("content://com.android.calendar/time")));
            } catch (Exception e2) {
                Toast.makeText(this, getString(R.string.no_calendar), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void buildDock(LinearLayout parent) {
        dock = new LinearLayout(this);
        dock.setOrientation(LinearLayout.VERTICAL);
        dock.setGravity(Gravity.CENTER_HORIZONTAL);
        dock.setPadding(0, dp(12.0f), 0, dp(12.0f));
        glassify(dock, 34, false);
        dockPage = Math.max(0, Math.min(dockPages() - 1, prefs.getInt("dock_page", 0)));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dp(dockColumns() == 2 ? 124.0f : 68.0f), -1);
        params.setMargins(0, dp(10.0f), dp(10.0f), dp(12.0f));
        parent.addView(dock, params);
        refreshDock();
    }

    private void refreshDock() {
        if (dock == null) {
            return;
        }
        dock.removeAllViews();
        // Status gauge at the top of the dock: the ring is the battery with its percentage at the top,
        // Wi-Fi sits in the middle and five dots along the bottom show the mobile signal.
        // It sits straight on the dock's glass, like the reference, with a round ripple for touch.
        FrameLayout battery = new FrameLayout(this);
        battery.setBackground(new RippleDrawable(ColorStateList.valueOf(darkWallpaper ? 0x33FFFFFF : 0x22000000), null, null));
        ImageView batteryImage = new ImageView(this);
        if (statusRing == null) {
            statusRing = new StatusRing(textPrimary, dp(60.0f));
        }
        batteryImage.setImageDrawable(statusRing);
        battery.addView(batteryImage, new FrameLayout.LayoutParams(dp(60.0f), dp(60.0f), Gravity.CENTER));
        battery.setOnClickListener(view -> openBatterySettings());
        battery.setOnLongClickListener(view -> {
            openWifiSettings();
            return true;
        });
        battery.setAccessibilityDelegate(new View.AccessibilityDelegate() {
            @Override
            public void onInitializeAccessibilityNodeInfo(View host, AccessibilityNodeInfo info) {
                super.onInitializeAccessibilityNodeInfo(host, info);
                info.addAction(new AccessibilityNodeInfo.AccessibilityAction(AccessibilityNodeInfo.ACTION_CLICK,
                        getString(R.string.open_battery_settings)));
                info.addAction(new AccessibilityNodeInfo.AccessibilityAction(AccessibilityNodeInfo.ACTION_LONG_CLICK,
                        getString(R.string.open_wifi_settings)));
            }
        });
        batteryView = battery;
        dock.addView(battery, new LinearLayout.LayoutParams(dp(62.0f), dp(62.0f)));
        updateBattery(null);
        updateNetwork();
        updateSignal(lastSignal);
        if (dockPages() > 1) {
            dock.addView(dockPageDots(), new LinearLayout.LayoutParams(-1, dp(22.0f)));
        }
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        if (dockPages() > 1) {
            // A sideways flick on the dock turns its page.
            final android.view.GestureDetector flick = new android.view.GestureDetector(this, new android.view.GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                    if (Math.abs(vx) > Math.abs(vy) * 1.3f && Math.abs(vx) > dp(300.0f)) {
                        boolean rtl = getResources().getConfiguration().getLayoutDirection() == View.LAYOUT_DIRECTION_RTL;
                        int step = (vx < 0) != rtl ? 1 : -1;
                        setDockPage((dockPage + step + dockPages()) % dockPages());
                        return true;
                    }
                    return false;
                }
            });
            scroll.setOnTouchListener((v, event) -> {
                flick.onTouchEvent(event);
                return false;
            });
        }
        LinearLayout items = new LinearLayout(this);
        items.setOrientation(LinearLayout.VERTICAL);
        items.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        scroll.addView(items, new FrameLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(-1, 0, 1.0f);
        scrollParams.topMargin = dp(8.0f);
        scrollParams.bottomMargin = dp(8.0f);
        dock.addView(scroll, scrollParams);
        // Dropping an icon below the last one moves it to the end of the dock.
        scroll.setOnDragListener((view, event) -> dockDrop(event, null, view));
        for (String key : getFavorites()) {
            final AppEntry entry = findByKey(key);
            if (entry == null) {
                continue;
            }
            final FrameLayout item = new FrameLayout(this);
            item.setPadding(0, dp(5.0f), 0, dp(5.0f));
            final FrameLayout icon = iconWithDot(entry, 46);
            item.addView(icon, new FrameLayout.LayoutParams(dp(52.0f), dp(52.0f), Gravity.CENTER));
            item.setContentDescription(icon.getTag() == Boolean.TRUE ? getString(R.string.has_notifications, entry.label) : entry.label);
            item.setOnClickListener(view -> animateLaunch(entry, view));
            item.setOnLongClickListener(view -> {
                // Keep the dock from scrolling while the finger stays down, so sliding drags the icon.
                if (view.getParent() != null) {
                    view.getParent().requestDisallowInterceptTouchEvent(true);
                }
                dockHeld = entry;
                showAppPopup(entry, icon, PLACE_DOCK);
                return true;
            });
            // Hold, then slide up or down: the menu closes and the icon follows the finger to its new place.
            item.setOnTouchListener((view, event) -> {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        dockTouchY = event.getRawY();
                        dockHeld = null;
                        break;
                    case MotionEvent.ACTION_MOVE:
                        if (dockHeld == entry && Math.abs(event.getRawY() - dockTouchY) > dp(10.0f)) {
                            dockHeld = null;
                            startDockDrag(entry, item, icon);
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        dockHeld = null;
                        break;
                    default:
                        break;
                }
                return false;
            });
            item.setOnDragListener((view, event) -> dockDrop(event, entry.key, view));
            if (dockColumns() == 2) {
                // Two across: a new row every other app.
                LinearLayout row = items.getChildCount() == 0 ? null : (LinearLayout) items.getChildAt(items.getChildCount() - 1);
                if (row == null || row.getChildCount() >= 2) {
                    row = new LinearLayout(this);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    row.setGravity(Gravity.CENTER);
                    items.addView(row, new LinearLayout.LayoutParams(-1, -2));
                }
                row.addView(item, new LinearLayout.LayoutParams(0, -2, 1f));
            } else {
                items.addView(item, new LinearLayout.LayoutParams(-1, -2));
            }
        }
        suggestBox = new LinearLayout(this);
        suggestBox.setOrientation(LinearLayout.VERTICAL);
        suggestBox.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout.LayoutParams suggestParams = new LinearLayout.LayoutParams(-1, -2);
        suggestParams.bottomMargin = dp(8.0f);
        dock.addView(suggestBox, suggestParams);
        refreshSuggestions();
        if (drawerMode) {
            ImageView all = new ImageView(this);
            all.setImageDrawable(new Glyphs(Glyphs.APPS, textPrimary, dp(22.0f)));
            all.setScaleType(ImageView.ScaleType.CENTER);
            all.setContentDescription(getString(R.string.drawer_open));
            glassify(all, 22, true);
            all.setOnClickListener(view -> openDrawer(false));
            LinearLayout.LayoutParams allParams = new LinearLayout.LayoutParams(dp(44.0f), dp(44.0f));
            allParams.bottomMargin = dp(8.0f);
            dock.addView(all, allParams);
            drawerButton = all;
        }
        TextView add = label("+", 24, textPrimary, 400);
        add.setGravity(Gravity.CENTER);
        add.setContentDescription(getString(R.string.add_favorite));
        glassify(add, 22, true);
        dock.addView(add, new LinearLayout.LayoutParams(dp(44.0f), dp(44.0f)));
        add.setOnClickListener(view -> showFavoritePicker());
    }

    /** One dot a dock page; the lit one is on show, a tap goes to another. */
    private View dockPageDots() {
        LinearLayout dots = new LinearLayout(this);
        dots.setGravity(Gravity.CENTER);
        for (int i = 0; i < dockPages(); i++) {
            final int page = i;
            FrameLayout target = new FrameLayout(this);
            View dot = new View(this);
            boolean on = i == dockPage;
            dot.setBackground(pill(withAlpha(textPrimary, on ? 0.92f : 0.35f), 4));
            target.addView(dot, new FrameLayout.LayoutParams(dp(on ? 14.0f : 7.0f), dp(7.0f), Gravity.CENTER));
            target.setContentDescription(getString(R.string.dock_page_n, NowBar.number(this, i + 1)));
            target.setOnClickListener(v -> setDockPage(page));
            dots.addView(target, new LinearLayout.LayoutParams(dp(20.0f), dp(22.0f)));
        }
        return dots;
    }

    /** What a dock drag carries, so the grid's own drop targets ignore it. */
    private static final class DockDrag {
        final AppEntry entry;

        DockDrag(AppEntry entry) {
            this.entry = entry;
        }
    }

    void startGridDrag(AppEntry entry, View cell, View icon) {
        dismissAppPopup();
        try {
            boolean started = cell.startDragAndDrop(ClipData.newPlainText("app", entry.key), new View.DragShadowBuilder(icon), new GridDrag(entry), 0);
            if (started && drawer != null && drawer.isOpen()) {
                closeDrawer(true); // the drawer steps aside so the icon can go to the dock
            }
        } catch (Exception ignored) {
        }
    }

    private void startDockDrag(AppEntry entry, View item, View icon) {
        dismissAppPopup();
        try {
            if (item.startDragAndDrop(ClipData.newPlainText("dock", entry.key), new View.DragShadowBuilder(icon), new DockDrag(entry), 0)) {
                item.setAlpha(0.35f);
            }
        } catch (Exception ignored) {
        }
    }

    /** Dock icons take other dock icons (to reorder) and, while arranging, apps dragged from the grid. */
    private boolean dockDrop(DragEvent event, String anchorKey, View target) {
        Object state = event.getLocalState();
        boolean fromDock = state instanceof DockDrag;
        boolean fromGrid = (state instanceof AppEntry && reorderMode) || state instanceof GridDrag;
        switch (event.getAction()) {
            case DragEvent.ACTION_DRAG_STARTED:
                return fromDock || fromGrid;
            case DragEvent.ACTION_DRAG_ENTERED:
                if (anchorKey != null) {
                    target.setBackground(pill(withAlpha(textPrimary, 0.18f), 18));
                }
                return true;
            case DragEvent.ACTION_DRAG_EXITED:
                target.setBackground(null);
                return true;
            case DragEvent.ACTION_DROP: {
                target.setBackground(null);
                AppEntry moving = fromDock ? ((DockDrag) state).entry : state instanceof GridDrag ? ((GridDrag) state).entry : (AppEntry) state;
                boolean after = anchorKey != null && event.getY() > target.getHeight() / 2f;
                boolean added = !getFavorites().contains(moving.key);
                moveFavorite(moving.key, anchorKey, after);
                if (added) {
                    Toast.makeText(this, getString(R.string.dock_added, moving.label), Toast.LENGTH_SHORT).show();
                }
                return true;
            }
            case DragEvent.ACTION_DRAG_ENDED:
                target.setBackground(null);
                target.setAlpha(1f);
                return true;
            default:
                return true;
        }
    }

    /** Puts a dock app before or after another one (or at the end when there's no anchor). */
    void moveFavorite(String key, String anchorKey, boolean after) {
        if (key.equals(anchorKey)) {
            return;
        }
        List<String> favorites = getFavorites();
        favorites.remove(key);
        int to = anchorKey == null ? -1 : favorites.indexOf(anchorKey);
        if (to < 0) {
            favorites.add(key);
        } else {
            favorites.add(after ? to + 1 : to, key);
        }
        saveFavorites(favorites);
    }

    private Set<String> noSuggestKeys() {
        HashSet<String> keys = new HashSet<>();
        for (String key : prefs.getString("no_suggest", "").split("\\|")) {
            if (key.length() > 0) {
                keys.add(key);
            }
        }
        return keys;
    }

    /** Apps usually opened around this hour, leaving out dock apps, hidden ones and ones the user turned down. */
    List<AppEntry> suggestedApps(int count) {
        ArrayList<AppEntry> result = new ArrayList<>();
        if (!appsLoaded || usage == null || privacyMode || !prefs.getBoolean("dock_suggestions", true)) {
            return result;
        }
        Set<String> skip = new HashSet<>(getFavorites());
        skip.addAll(lockedKeys());
        skip.addAll(hiddenKeys());
        skip.addAll(noSuggestKeys());
        ArrayList<String> candidates = new ArrayList<>();
        for (AppEntry entry : apps) {
            if (!skip.contains(entry.key)) {
                candidates.add(entry.key);
            }
        }
        for (String key : usage.suggestions(candidates, System.currentTimeMillis(), count)) {
            AppEntry entry = findByKey(key);
            if (entry != null) {
                result.add(entry);
            }
        }
        return result;
    }

    private void refreshSuggestions() {
        if (suggestBox == null) {
            return;
        }
        suggestBox.removeAllViews();
        suggestHour = Usage.hourOf(System.currentTimeMillis());
        List<AppEntry> picks = suggestedApps(3);
        if (picks.isEmpty()) {
            suggestBox.setVisibility(View.GONE);
            return;
        }
        suggestBox.setVisibility(View.VISIBLE);
        View line = new View(this);
        line.setBackground(pill(withAlpha(textPrimary, 0.28f), 1));
        LinearLayout.LayoutParams lineParams = new LinearLayout.LayoutParams(dp(26.0f), Math.max(1, dp(1.5f)));
        lineParams.bottomMargin = dp(7.0f);
        suggestBox.addView(line, lineParams);
        ImageView spark = new ImageView(this);
        spark.setImageDrawable(new Glyphs(Glyphs.SPARK, withAlpha(textPrimary, 0.85f), dp(12.0f)));
        spark.setContentDescription(getString(R.string.suggested_now));
        suggestBox.addView(spark, new LinearLayout.LayoutParams(dp(12.0f), dp(12.0f)));
        for (final AppEntry entry : picks) {
            FrameLayout item = new FrameLayout(this);
            item.setPadding(0, dp(4.0f), 0, dp(4.0f));
            final FrameLayout icon = iconWithDot(entry, 42);
            item.addView(icon, new FrameLayout.LayoutParams(dp(48.0f), dp(48.0f), Gravity.CENTER));
            item.setContentDescription(getString(R.string.suggested_app, entry.label));
            item.setOnClickListener(view -> animateLaunch(entry, view));
            item.setOnLongClickListener(view -> {
                showAppPopup(entry, icon, PLACE_SUGGESTED);
                return true;
            });
            suggestBox.addView(item, new LinearLayout.LayoutParams(-1, -2));
        }
    }

    private void openWifiSettings() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                // The quick panel: Wi-Fi and mobile data without leaving the home screen.
                startActivity(new Intent(android.provider.Settings.Panel.ACTION_INTERNET_CONNECTIVITY));
            } else {
                startActivity(new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS));
            }
        } catch (Exception e) {
            try {
                startActivity(new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS));
            } catch (Exception ignored) {
            }
        }
    }

    // ---------------------------------------------------------------- view options and automatic folders

    private interface Choice {
        void on(int which);
    }

    private TextView popupCaption(String text, int color) {
        TextView caption = label(text, 13, color, 500);
        caption.setPadding(dp(18.0f), dp(2.0f), dp(18.0f), dp(4.0f));
        return caption;
    }

    private View popupDivider(int color) {
        View divider = new View(this);
        divider.setBackgroundColor(color);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, Math.max(1, dp(0.6f)));
        params.setMargins(dp(18.0f), dp(6.0f), dp(18.0f), dp(6.0f));
        divider.setLayoutParams(params);
        return divider;
    }

    /** Two side-by-side choices; the picked one is filled with the accent colour. */
    private View segmented(String first, String second, int selected, int ink, final Choice choice) {
        LinearLayout row = new LinearLayout(this);
        row.setPadding(dp(14.0f), dp(4.0f), dp(14.0f), dp(4.0f));
        String[] names = {first, second};
        for (int i = 0; i < 2; i++) {
            final int which = i;
            boolean on = i == selected;
            TextView option = label(names[i], 14, on ? Color.WHITE : ink, on ? 600 : 400);
            option.setGravity(Gravity.CENTER);
            option.setSingleLine(true);
            option.setBackground(pill(on ? accent : withAlpha(ink, 0.07f), 19));
            option.setContentDescription(on ? names[i] + "، " + getString(R.string.selected) : names[i]);
            option.setOnClickListener(view -> choice.on(which));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(38.0f), 1f);
            if (i == 1) {
                params.setMarginStart(dp(8.0f));
            }
            row.addView(option, params);
        }
        return row;
    }

    private void showViewOptions(View anchor) {
        dismissAppPopup();
        boolean night = nightMode();
        int ink = night ? 0xFFF2F2F2 : 0xFF17171A;
        int muted = night ? 0xFF9C9CA3 : 0xFF6E6E76;
        int line = night ? 0x1FFFFFFF : 0x14000000;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(12.0f), 0, dp(8.0f));
        final PopupWindow popup = new PopupWindow(box, dp(260.0f), ViewGroup.LayoutParams.WRAP_CONTENT, true);
        box.addView(popupCaption(getString(R.string.sort_title), muted));
        String mode = sortMode();
        for (final String option : SORT_MODES) {
            boolean on = option.equals(mode);
            View row = popupRow(on ? new Glyphs(Glyphs.CHECK, accent, dp(22.0f)) : null, getString(sortLabel(option)), ink, view -> {
                popup.dismiss();
                setSortMode(option);
            });
            if (on) {
                row.setContentDescription(getString(sortLabel(option)) + "، " + getString(R.string.selected));
            }
            box.addView(row);
        }
        box.addView(popupDivider(line));
        box.addView(popupCaption(getString(R.string.layout_title), muted));
        box.addView(segmented(getString(R.string.layout_pages), getString(R.string.layout_scroll), scrollLayout ? 1 : 0, ink, which -> {
            popup.dismiss();
            setScrollLayout(which == 1);
        }));
        box.addView(segmented(getString(R.string.density_roomy), getString(R.string.density_compact), gridDense ? 1 : 0, ink, which -> {
            popup.dismiss();
            setGridDense(which == 1, false);
        }));
        box.addView(popupDivider(line));
        box.addView(popupRow(new Glyphs(Glyphs.FOLDER, ink, dp(22.0f)), getString(R.string.auto_folders), ink, view -> {
            popup.dismiss();
            offerAutoFolders();
        }));
        if (!drawerMode) {
            boolean searchShown = prefs.getBoolean("show_search_bar", true);
            box.addView(popupRow(searchShown ? new Glyphs(Glyphs.CHECK, accent, dp(22.0f)) : null, getString(R.string.search_bar_toggle), ink, view -> {
                popup.dismiss();
                boolean next = !prefs.getBoolean("show_search_bar", true);
                prefs.edit().putBoolean("show_search_bar", next).apply();
                if (searchBar != null) {
                    searchBar.setVisibility(next ? View.VISIBLE : View.GONE);
                }
            }));
            if (cardTypes(0).isEmpty() || cardTypes(1).isEmpty()) {
                box.addView(popupRow(null, getString(R.string.cards_restore), ink, view -> {
                    popup.dismiss();
                    prefs.edit().remove("cards_0").remove("cards_1").apply();
                    fillCards();
                    rebuildGlass();
                }));
            }
        }
        showPopupNear(popup, box, anchor, night);
        appPopup = popup;
    }

    private Folders.Folder folderNamed(String name) {
        for (Folders.Folder folder : folders) {
            if (name.equals(folder.name)) {
                return folder;
            }
        }
        return null;
    }

    /** Which apps would go in which ready-made folder. Dock apps and apps already in folders stay put. */
    LinkedHashMap<String, List<AppEntry>> autoFolderPlan() {
        Set<String> skip = new HashSet<>(getFavorites());
        skip.addAll(hiddenKeys());
        LinkedHashMap<String, List<AppEntry>> plan = new LinkedHashMap<>();
        for (String id : AutoFolders.ORDER) {
            plan.put(id, new ArrayList<AppEntry>());
        }
        for (AppEntry entry : apps) {
            if (skip.contains(entry.key) || Folders.folderOf(folders, entry.key) != null) {
                continue;
            }
            String id = AutoFolders.categorize(entry.pkg, entry.label, entry.category);
            if (id != null) {
                plan.get(id).add(entry);
            }
        }
        for (Iterator<Map.Entry<String, List<AppEntry>>> it = plan.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<String, List<AppEntry>> group = it.next();
            // A new folder needs two apps; one app can still join a folder of that name that already exists.
            int least = folderNamed(getString(AutoFolders.nameRes(group.getKey()))) != null ? 1 : 2;
            if (group.getValue().size() < least) {
                it.remove();
            }
        }
        return plan;
    }

    private void offerAutoFolders() {
        final LinkedHashMap<String, List<AppEntry>> plan = autoFolderPlan();
        if (plan.isEmpty()) {
            Toast.makeText(this, getString(R.string.auto_folders_none), Toast.LENGTH_LONG).show();
            return;
        }
        StringBuilder text = new StringBuilder(getString(R.string.auto_folders_intro));
        for (Map.Entry<String, List<AppEntry>> group : plan.entrySet()) {
            text.append("\n\n• ").append(getString(AutoFolders.nameRes(group.getKey()))).append(": ");
            List<AppEntry> members = group.getValue();
            for (int i = 0; i < Math.min(3, members.size()); i++) {
                if (i > 0) {
                    text.append(getString(R.string.list_separator));
                }
                text.append(members.get(i).label);
            }
            if (members.size() > 3) {
                text.append(getString(R.string.auto_folders_more, members.size() - 3));
            }
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.auto_folders))
                .setMessage(text.toString())
                .setPositiveButton(getString(R.string.auto_folders_apply), (dialog, which) -> applyAutoFolders(plan))
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    void applyAutoFolders(Map<String, List<AppEntry>> plan) {
        // Keep the folders as they were, so Settings can undo this in one tap.
        prefs.edit().putString("folders_before_auto", prefs.getString("folders", "[]")).apply();
        String stamp = Long.toString(System.currentTimeMillis(), 36);
        for (Map.Entry<String, List<AppEntry>> group : plan.entrySet()) {
            String name = getString(AutoFolders.nameRes(group.getKey()));
            Folders.Folder folder = folderNamed(name);
            if (folder == null) {
                folder = new Folders.Folder(stamp + "-" + group.getKey(), name);
                folders.add(folder);
            }
            for (AppEntry entry : group.getValue()) {
                if (!folder.keys.contains(entry.key)) {
                    folder.keys.add(entry.key);
                }
            }
        }
        saveFolders();
        Toast.makeText(this, getString(R.string.auto_folders_done, plan.size()), Toast.LENGTH_SHORT).show();
    }

    void undoAutoFolders() {
        String before = prefs.getString("folders_before_auto", null);
        if (before == null) {
            return;
        }
        prefs.edit().putString("folders", before).remove("folders_before_auto").apply();
        folders.clear();
        folders.addAll(Folders.load(prefs));
        applyFilter(currentQuery());
        Toast.makeText(this, getString(R.string.auto_folders_undone), Toast.LENGTH_SHORT).show();
    }

    // ---------------------------------------------------------------- pages that follow the finger

    /** The next or previous page, drawn beside the grid while the finger drags. */
    private GridView peekGrid;
    private final List<Tile> peekTiles = new ArrayList<>();
    private int peekPage = -1;

    private int pageCount() {
        return Math.max(1, (tiles.size() + pageCapacity - 1) / pageCapacity);
    }

    /** The page a swipe in this direction lands on: -1 for Today (back from the first page). */
    private int neighbourPage(int direction) {
        int next = currentPage + direction;
        if (next < 0) {
            return -1;
        }
        return next >= pageCount() ? 0 : next;
    }

    private int swipeDirection(float dx) {
        boolean rtl = grid.getLayoutDirection() == View.LAYOUT_DIRECTION_RTL;
        return (rtl ? dx > 0 : dx < 0) ? 1 : -1;
    }

    private void showPeek(int page) {
        if (peekGrid == null) {
            peekGrid = new GridView(this);
            peekGrid.setVerticalSpacing(0);
            peekGrid.setHorizontalSpacing(0);
            peekGrid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
            peekGrid.setSelector(android.R.color.transparent);
            peekGrid.setClipToPadding(false);
            peekGrid.setOverScrollMode(View.OVER_SCROLL_NEVER);
            peekGrid.setVerticalScrollBarEnabled(false);
            peekGrid.setEnabled(false);
            peekGrid.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
            peekGrid.setAdapter(new AppAdapter(peekTiles));
            peekGrid.setVisibility(View.GONE);
            gridFrame.addView(peekGrid, new FrameLayout.LayoutParams(-1, -1));
        }
        if (peekGrid.getNumColumns() != columns) {
            peekGrid.setNumColumns(columns);
        }
        peekGrid.setPadding(grid.getPaddingLeft(), grid.getPaddingTop(), grid.getPaddingRight(), grid.getPaddingBottom());
        if (page != peekPage || peekGrid.getVisibility() != View.VISIBLE) {
            peekPage = page;
            peekTiles.clear();
            for (int i = page * pageCapacity; i < Math.min(tiles.size(), (page + 1) * pageCapacity); i++) {
                peekTiles.add(tiles.get(i));
            }
            ((BaseAdapter) peekGrid.getAdapter()).notifyDataSetChanged();
        }
        peekGrid.animate().cancel();
        peekGrid.setVisibility(View.VISIBLE);
    }

    private void hidePeek() {
        if (peekGrid != null) {
            peekGrid.animate().cancel();
            peekGrid.setVisibility(View.GONE);
            peekGrid.setTranslationX(0f);
        }
        peekPage = -1;
    }

    /** The finger drags the page sideways: the page goes with it and the next one comes in beside it. */
    void pageDrag(float dx) {
        grid.animate().cancel();
        float width = Math.max(1, grid.getWidth());
        int target = neighbourPage(swipeDirection(dx));
        if (target < 0 || target == currentPage || dx == 0f) {
            // Today, or only one page: the grid gives a little and comes back.
            grid.setTranslationX(dx * 0.32f);
            hidePeek();
            return;
        }
        showPeek(target);
        grid.setTranslationX(dx);
        peekGrid.setTranslationX(dx - Math.signum(dx) * width);
    }

    /** The finger let go: on to the next page if it went a quarter of the way or flicked, otherwise back. */
    void pageRelease(float dx, float velocityX) {
        float width = Math.max(1, grid.getWidth());
        int direction = swipeDirection(dx);
        int target = neighbourPage(direction);
        boolean flick = Math.abs(velocityX) > dp(500.0f) && Math.signum(velocityX) == Math.signum(dx) && Math.abs(dx) > dp(16.0f);
        boolean go = dx != 0f && (Math.abs(dx) > width * 0.25f || flick);
        if (go && target < 0) {
            settleGrid();
            openToday(); // back from the first page: Today, like One UI's left screen
            return;
        }
        if (!go || target == currentPage || peekGrid == null || peekGrid.getVisibility() != View.VISIBLE) {
            settleGrid();
            return;
        }
        final int landing = target;
        float end = Math.signum(dx) * width;
        long time = Math.max(120L, Math.min(260L, (long) (260L * (1f - Math.abs(dx) / width))));
        grid.animate().translationX(end).setDuration(time).setInterpolator(new DecelerateInterpolator()).withLayer().start();
        peekGrid.animate().translationX(0f).setDuration(time).setInterpolator(new DecelerateInterpolator()).withLayer()
                .withEndAction(() -> {
                    // The grid takes the new page where the peek is: the same picture, so no jump.
                    currentPage = landing;
                    prefs.edit().putInt("page", currentPage).apply();
                    showPage();
                    grid.setTranslationX(0f);
                    hidePeek();
                }).start();
    }

    private void settleGrid() {
        grid.animate().translationX(0f).setDuration(180L).setInterpolator(new DecelerateInterpolator()).start();
        if (peekGrid != null && peekGrid.getVisibility() == View.VISIBLE) {
            float width = Math.max(1, grid.getWidth());
            float side = Math.signum(peekGrid.getTranslationX());
            peekGrid.animate().translationX(side * width).setDuration(180L).setInterpolator(new DecelerateInterpolator())
                    .withEndAction(this::hidePeek).start();
        }
    }

    private void changePage(int direction) {
        if (scrollLayout) {
            if (direction < 0) {
                openToday(); // the scrolling list has no pages; swiping back still shows Today
            }
            return;
        }
        int pages = Math.max(1, (tiles.size() + pageCapacity - 1) / pageCapacity);
        int next = currentPage + direction;
        if (next < 0) {
            openToday(); // going back from the first page shows Today, like One UI's left screen
            return;
        }
        if (next >= pages) {
            next = 0;
        }
        currentPage = next;
        prefs.edit().putInt("page", currentPage).apply();
        showPage();
    }

    private void updatePageIndicator() {
        if (pageDots == null) {
            return;
        }
        pageDots.removeAllViews();
        if (scrollLayout) {
            return;
        }
        int pageCount = Math.max(1, (tiles.size() + pageCapacity - 1) / pageCapacity);
        if (pageCount < 2) {
            return;
        }
        for (int page = 0; page < pageCount; page++) {
            final int targetPage = page;
            FrameLayout touch = new FrameLayout(this);
            View dot = new View(this);
            boolean current = page == currentPage;
            dot.setBackground(pill(current ? textPrimary : withAlpha(textPrimary, 0.4f), 4));
            touch.addView(dot, new FrameLayout.LayoutParams(dp(current ? 18.0f : 7.0f), dp(7.0f), Gravity.CENTER));
            touch.setContentDescription(getString(R.string.page_label, page + 1, pageCount));
            touch.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    currentPage = targetPage;
                    prefs.edit().putInt("page", targetPage).apply();
                    showPage();
                }
            });
            pageDots.addView(touch, new LinearLayout.LayoutParams(dp(current ? 30.0f : 18.0f), -1));
        }
    }

    private void scheduleClockTick() {
        clockHandler.removeCallbacks(clockUpdater);
        long now = System.currentTimeMillis();
        // Tick right after the minute changes instead of drifting up to 59 s behind.
        clockHandler.postDelayed(clockUpdater, 60000L - (now % 60000L) + 50L);
    }

    private void updateWidgets() {
        updateTitleClock();
        updateAmbience(System.currentTimeMillis());
        smartStacks(System.currentTimeMillis());
        runCardUpdater("prayers");
        runCardUpdater("agenda");
        runCardUpdater("matches");
        refreshMatches(false);
        if (clock == null) {
            return;
        }
        Date now = new Date();
        Locale locale = Locale.getDefault();
        String clockPattern = android.text.format.DateFormat.is24HourFormat(this) ? "H:mm" : "h:mm";
        clock.setText(new SimpleDateFormat(clockPattern, locale).format(now));
        dateLine.setText(new SimpleDateFormat(android.text.format.DateFormat.getBestDateTimePattern(locale, "EEEEdMMMM"), locale).format(now));
        String hijri = hijriText(now);
        hijriDate.setText(hijri);
        String prayer = nextPrayerText(now.getTime());
        prayerLine.setText(prayer);
        String occasion = prefs.getBoolean(Ambience.PREF_OCCASIONS, true)
                ? Ambience.greeting(this, Ambience.occasion(now.getTime()), now.getTime()) : null;
        if (clockLines != null) {
            clockLines.clear();
            if (prayer.length() > 0) {
                clockLines.addItem(prayerLine);
            }
            if (hijri.length() > 0) {
                clockLines.addItem(hijriDate);
            }
            if (occasion != null) {
                clockLines.addItem(cardLine(occasion, 13, accentOnWallpaper(), 700));
            }
        }
        dateCard.setContentDescription(clock.getText() + "، " + (prayer.length() == 0 ? "" : prayer + "، ") + dateLine.getText()
                + (hijri.length() == 0 ? "" : "، " + hijri) + (occasion == null ? "" : "، " + occasion) + ". "
                + getString(R.string.open_today_hint));
    }

    /** Umm al-Qura Hijri date, e.g. "٣ جمادى الآخرة ١٤٤٨ هـ". Empty if ICU can't provide it. */
    private static String hijriText(Date date) {
        try {
            android.icu.util.ULocale locale = new android.icu.util.ULocale("ar@calendar=islamic-umalqura");
            android.icu.util.IslamicCalendar calendar = new android.icu.util.IslamicCalendar(locale);
            calendar.setCalculationType(android.icu.util.IslamicCalendar.CalculationType.ISLAMIC_UMALQURA);
            android.icu.text.DateFormat format = android.icu.text.DateFormat.getDateInstance(calendar, android.icu.text.DateFormat.LONG, locale);
            return format.format(date);
        } catch (Throwable error) {
            return "";
        }
    }

    // ---------------------------------------------------------------- news

    private void refreshAllNews() {
        for (NewsSources.Source source : sources) {
            refreshNewsFeed(source);
        }
    }

    private void refreshNewsFeed(final NewsSources.Source source) {
        if (newsExecutor.isShutdown()) {
            return;
        }
        newsExecutor.execute(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection connection = null;
                try {
                    connection = (HttpURLConnection) new URL(source.url).openConnection();
                    connection.setConnectTimeout(9000);
                    connection.setReadTimeout(11000);
                    connection.setInstanceFollowRedirects(true);
                    connection.setRequestProperty("User-Agent", "SaraHome/" + VERSION_NAME + " (Android RSS reader)");
                    connection.setRequestProperty("Accept", "application/rss+xml, application/atom+xml, application/xml, text/xml");
                    InputStream stream = connection.getInputStream();
                    ArrayList<NewsItem> found = new ArrayList<>();
                    try {
                        XmlPullParser parser = Xml.newPullParser();
                        parser.setInput(stream, null); // honour the feed's declared encoding
                        String title = "";
                        String link = "";
                        String published = "";
                        boolean inItem = false;
                        int event;
                        while ((event = parser.next()) != XmlPullParser.END_DOCUMENT) {
                            if (event == XmlPullParser.START_TAG) {
                                String tag = parser.getName();
                                if ("item".equalsIgnoreCase(tag) || "entry".equalsIgnoreCase(tag)) {
                                    inItem = true;
                                    title = "";
                                    link = "";
                                    published = "";
                                } else if (inItem && "title".equalsIgnoreCase(tag)) {
                                    title = parser.nextText().trim();
                                } else if (inItem && "link".equalsIgnoreCase(tag)) {
                                    String href = parser.getAttributeValue(null, "href");
                                    if (href != null && link.length() == 0) {
                                        link = href.trim();
                                    } else if (link.length() == 0) {
                                        link = parser.nextText().trim();
                                    }
                                } else if (inItem && ("guid".equalsIgnoreCase(tag) || "id".equalsIgnoreCase(tag)) && link.length() == 0) {
                                    link = parser.nextText().trim();
                                } else if (inItem && ("pubDate".equalsIgnoreCase(tag) || "published".equalsIgnoreCase(tag) || "updated".equalsIgnoreCase(tag) || "date".equalsIgnoreCase(tag))) {
                                    published = parser.nextText().trim();
                                }
                            } else if (event == XmlPullParser.END_TAG && ("item".equalsIgnoreCase(parser.getName()) || "entry".equalsIgnoreCase(parser.getName()))) {
                                String safeLink = secureArticleUrl(link, source.url);
                                if (title.length() > 0 && safeLink.length() > 0) {
                                    found.add(new NewsItem(source.name, title, safeLink, parseNewsDate(published)));
                                }
                                inItem = false;
                            }
                        }
                    } finally {
                        stream.close();
                    }
                    if (found.isEmpty()) {
                        throw new IllegalStateException("Empty RSS feed");
                    }
                    Collections.sort(found, NEWEST_FIRST);
                    while (found.size() > NEWS_PER_SOURCE) {
                        found.remove(found.size() - 1);
                    }
                    final List<NewsItem> result = found;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!isDestroyed()) {
                                replaceSourceNews(source.id, result);
                            }
                        }
                    });
                } catch (Exception error) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!isDestroyed() && newsItems.isEmpty() && newsList != null) {
                                newsFailed = true;
                                newsSignature = "";
                                renderNews();
                            }
                        }
                    });
                } finally {
                    if (connection != null) {
                        connection.disconnect();
                    }
                }
            }
        });
    }

    private static final Comparator<NewsItem> NEWEST_FIRST = new Comparator<NewsItem>() {
        @Override
        public int compare(NewsItem a, NewsItem b) {
            return Long.compare(b.published, a.published);
        }
    };

    private NewsSources.Source sourceById(String id) {
        for (NewsSources.Source source : NewsSources.ALL) {
            if (source.id.equals(id)) {
                return source;
            }
        }
        return null;
    }

    /** Removes the per-index cache keys used before 2.0 (they're replaced by per-source ones). */
    private void dropLegacyNewsCache() {
        SharedPreferences.Editor editor = null;
        for (String key : prefs.getAll().keySet()) {
            if (key.matches("news_\\d+_\\d+_.*")) {
                if (editor == null) {
                    editor = prefs.edit();
                }
                editor.remove(key);
            }
        }
        if (editor != null) {
            editor.apply();
        }
    }

    private void replaceSourceNews(String sourceId, List<NewsItem> list) {
        NewsSources.Source source = sourceById(sourceId);
        if (source == null) {
            return;
        }
        synchronized (newsItems) {
            for (int i = newsItems.size() - 1; i >= 0; i--) {
                if (newsItems.get(i).source.equals(source.name)) {
                    newsItems.remove(i);
                }
            }
            newsItems.addAll(list);
        }
        SharedPreferences.Editor editor = prefs.edit();
        for (int i = 0; i < NEWS_PER_SOURCE; i++) {
            String prefix = "news_" + source.id + "_" + i + "_";
            if (i < list.size()) {
                NewsItem item = list.get(i);
                editor.putString(prefix + "title", item.title).putString(prefix + "link", item.link).putLong(prefix + "time", item.published);
            } else {
                editor.remove(prefix + "title").remove(prefix + "link").remove(prefix + "time");
            }
        }
        editor.putLong("news_refresh", System.currentTimeMillis()).apply();
        newsFailed = false;
        renderNews();
    }

    private void loadCachedNews() {
        for (NewsSources.Source source : sources) {
            for (int i = 0; i < NEWS_PER_SOURCE; i++) {
                String prefix = "news_" + source.id + "_" + i + "_";
                String title = prefs.getString(prefix + "title", "");
                String link = prefs.getString(prefix + "link", "");
                if (title.length() > 0 && link.length() > 0) {
                    newsItems.add(new NewsItem(source.name, title, link, prefs.getLong(prefix + "time", 0L)));
                }
            }
        }
    }

    private ArrayList<NewsItem> orderedNews() {
        ArrayList<NewsItem> ordered = new ArrayList<>();
        synchronized (newsItems) {
            ordered.addAll(newsItems);
        }
        Collections.sort(ordered, NEWEST_FIRST);
        return ordered;
    }

    /**
     * Shows every headline as one live list, newest first. The list is laid out twice in a row so the
     * automatic glide can loop back to the start without a visible jump. Only rebuilt when the set of
     * headlines changes; otherwise just the "x min ago" labels are refreshed.
     */
    private void renderNews() {
        if (newsList == null) {
            return;
        }
        if (privacyMode) {
            if (!"private".equals(newsSignature)) {
                newsSignature = "private";
                newsList.clear();
                newsTimeViews.clear();
                newsTimeItems.clear();
                TextView message = label(getString(R.string.privacy_hidden), 13, textSecondary, 400);
                message.setPadding(0, dp(6.0f), 0, 0);
                newsList.addItem(message);
            }
            return;
        }
        newsUpdated.setText(lastRefreshText());
        ArrayList<NewsItem> ordered = orderedNews();
        StringBuilder links = new StringBuilder();
        for (NewsItem item : ordered) {
            links.append(item.link).append('\n');
        }
        String signature = links.toString();
        if (signature.equals(newsSignature) && newsList.getChildCount() > 0) {
            for (int i = 0; i < newsTimeViews.size(); i++) {
                newsTimeViews.get(i).setText(formatNewsTime(newsTimeItems.get(i).published));
            }
            return;
        }
        if (newsList.touching()) {
            return; // never change the headlines under someone's finger; the next refresh will catch up
        }
        newsSignature = signature;
        newsList.clear();
        newsTimeViews.clear();
        newsTimeItems.clear();
        if (ordered.isEmpty()) {
            newsLooping = false;
            TextView message = label(getString(newsFailed ? R.string.news_failed : R.string.news_loading), 13, textSecondary, 400);
            message.setPadding(0, dp(6.0f), 0, 0);
            newsList.addItem(message);
            return;
        }
        boolean firstFill = seenNewsLinks.isEmpty();
        HashSet<String> fresh = new HashSet<>();
        for (NewsItem item : ordered) {
            if (!firstFill && !seenNewsLinks.contains(item.link)) {
                fresh.add(item.link);
            }
            seenNewsLinks.add(item.link);
        }
        newsLooping = ordered.size() >= 2;
        int firstFresh = -1;
        for (int i = 0; i < ordered.size(); i++) {
            NewsItem item = ordered.get(i);
            boolean isFresh = fresh.contains(item.link);
            if (isFresh && firstFresh < 0) {
                firstFresh = i;
            }
            newsList.addItem(newsRow(item, false, isFresh));
        }
        if (firstFresh >= 0) {
            newsList.showNow(firstFresh); // a headline that has just arrived shows at once, then the beat goes on
            pulseLiveDot();
        }
        scheduleTickerBeat();
    }

    private View newsRow(final NewsItem item, boolean divider, boolean fresh) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        if (divider) {
            View line = new View(this);
            line.setBackgroundColor(withAlpha(textPrimary, 0.14f));
            row.addView(line, new LinearLayout.LayoutParams(-1, Math.max(1, dp(0.6f))));
        }
        LinearLayout meta = new LinearLayout(this);
        meta.setGravity(Gravity.CENTER_VERTICAL);
        meta.setPadding(0, 0, 0, 0);
        meta.addView(label(item.source, 11, sourceColor(), 700));
        TextView time = label(formatNewsTime(item.published), 11, textSecondary, 400);
        LinearLayout.LayoutParams timeParams = new LinearLayout.LayoutParams(-2, -2);
        timeParams.setMarginStart(dp(8.0f));
        meta.addView(time, timeParams);
        newsTimeViews.add(time);
        newsTimeItems.add(item);
        row.addView(meta, new LinearLayout.LayoutParams(-1, -2));
        TextView title = label(item.title, 13, textPrimary, 500);
        title.setMaxLines(2);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setLineSpacing(0, 1.06f);
        title.setPadding(0, dp(1.0f), 0, 0);
        row.addView(title, new LinearLayout.LayoutParams(-1, -2));
        row.setBackground(new RippleDrawable(ColorStateList.valueOf(withAlpha(textPrimary, 0.16f)), null, pill(Color.WHITE, 12)));
        row.setContentDescription(getString(R.string.news_description, item.source, formatNewsTime(item.published), item.title));
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openNews(item);
            }
        });
        row.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                showNewsActions(item);
                return true;
            }
        });
        if (fresh) {
            // A just-arrived headline glows in the accent colour, then settles.
            final GradientDrawable glow = pill(withAlpha(accent, 0.45f), 12);
            row.setForeground(glow);
            ValueAnimator fade = ValueAnimator.ofInt(255, 0);
            fade.setStartDelay(600L);
            fade.setDuration(2400L);
            fade.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator animation) {
                    glow.setAlpha((Integer) animation.getAnimatedValue());
                }
            });
            fade.start();
        }
        return row;
    }

    private int sourceColor() {
        return accentOnWallpaper();
    }

    /** The accent, lightened on dark wallpapers so small accent text stays readable on glass. */
    int accentOnWallpaper() {
        if (!darkWallpaper) {
            return accent;
        }
        return Color.rgb((Color.red(accent) + 255) / 2, (Color.green(accent) + 255) / 2, (Color.blue(accent) + 255) / 2);
    }

    private String lastRefreshText() {
        long last = prefs.getLong("news_refresh", 0L);
        if (last <= 0) {
            return "";
        }
        long age = Math.max(0L, System.currentTimeMillis() - last);
        if (age < 90000L) {
            return getString(R.string.updated_now);
        }
        if (age < 3600000L) {
            return getString(R.string.updated_minutes_ago, age / 60000L);
        }
        return getString(R.string.updated_hours_ago, age / 3600000L);
    }

    private void pulseLiveDot() {
        if (newsLiveDot == null || !ValueAnimator.areAnimatorsEnabled()) {
            return;
        }
        ObjectAnimator pulse = ObjectAnimator.ofFloat(newsLiveDot, View.ALPHA, 1f, 0.2f);
        pulse.setDuration(450L);
        pulse.setRepeatCount(5);
        pulse.setRepeatMode(ValueAnimator.REVERSE);
        pulse.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                newsLiveDot.setAlpha(1f);
            }
        });
        pulse.start();
    }



    /** No automatic motion when the phone's animations are off or TalkBack is exploring the screen. */
    private boolean newsMotionAllowed() {
        if (!ValueAnimator.areAnimatorsEnabled()) {
            return false;
        }
        AccessibilityManager accessibility = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
        return accessibility == null || !accessibility.isTouchExplorationEnabled();
    }









    private long parseNewsDate(String value) {
        if (value == null || value.length() == 0) {
            return 0L;
        }
        String[] patterns = {"EEE, dd MMM yyyy HH:mm:ss Z", "EEE, d MMM yyyy HH:mm:ss Z", "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd HH:mm:ss"};
        for (String pattern : patterns) {
            try {
                SimpleDateFormat format = new SimpleDateFormat(pattern, Locale.US);
                format.setLenient(true);
                if (pattern.endsWith("'Z'")) {
                    format.setTimeZone(TimeZone.getTimeZone("UTC"));
                }
                Date date = format.parse(value, new ParsePosition(0));
                if (date != null) {
                    return date.getTime();
                }
            } catch (Exception ignored) {
            }
        }
        return 0L;
    }

    private String formatNewsTime(long time) {
        if (time <= 0) {
            return "";
        }
        long age = Math.max(0L, System.currentTimeMillis() - time);
        if (age < 3600000L) {
            return getString(R.string.minutes_ago, Math.max(1L, age / 60000L));
        }
        if (age < 86400000L) {
            return getString(R.string.hours_ago, age / 3600000L);
        }
        return new SimpleDateFormat("d MMM", Locale.getDefault()).format(new Date(time));
    }

    private String secureArticleUrl(String link, String feedUrl) {
        try {
            URL url = new URL(new URL(feedUrl), link.trim());
            String protocol = url.getProtocol();
            String host = url.getHost().toLowerCase(Locale.ROOT);
            if ((!"http".equalsIgnoreCase(protocol) && !"https".equalsIgnoreCase(protocol)) || host.length() == 0) {
                return "";
            }
            int port = url.getPort();
            if (port == 80 || port == 443) {
                port = -1;
            }
            return new URL("https", host, port, url.getFile()).toString();
        } catch (Exception e) {
            return "";
        }
    }

    private void openNews(NewsItem item) {
        Intent web = ClipSuggest.web(item.link);
        if (web == null) {
            return; // a feed's link that isn't a web page (file:, intent:, javascript:) is never opened
        }
        try {
            startActivity(web);
        } catch (Exception ignored) {
        }
    }

    private void showNewsActions(final NewsItem item) {
        for (CardStack stack : cardStacks) {
            stack.cancelPendingLongPress();
        }
        String[] actions = {getString(R.string.news_open), getString(R.string.news_share)};
        new AlertDialog.Builder(this)
                .setTitle(item.source)
                .setItems(actions, (dialog, which) -> {
                    if (which == 0) {
                        openNews(item);
                    } else {
                        Intent send = new Intent(Intent.ACTION_SEND)
                                .setType("text/plain")
                                .putExtra(Intent.EXTRA_TEXT, item.title + "\n" + item.link);
                        try {
                            startActivity(Intent.createChooser(send, getString(R.string.news_share)));
                        } catch (Exception ignored) {
                        }
                    }
                })
                .show();
    }

    // ---------------------------------------------------------------- dialogs

    private void showFavoritePicker() {
        List<String> favorites = getFavorites();
        final ArrayList<AppEntry> candidates = new ArrayList<>();
        for (AppEntry entry : apps) {
            if (!favorites.contains(entry.key)) {
                candidates.add(entry);
            }
        }
        if (candidates.isEmpty()) {
            Toast.makeText(this, getString(R.string.no_more_apps), Toast.LENGTH_SHORT).show();
            return;
        }
        String[] labels = new String[candidates.size()];
        for (int i = 0; i < candidates.size(); i++) {
            labels[i] = candidates.get(i).label;
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.choose_favorite))
                .setItems(labels, (dialog, which) -> {
                    List<String> current = getFavorites();
                    current.add(candidates.get(which).key);
                    saveFavorites(current);
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    /** The actions offered when holding an app, in the order they appear. */
    private List<Integer> appActions(AppEntry entry, boolean inDock) {
        return appActions(entry, inDock ? PLACE_DOCK : PLACE_GRID);
    }

    private List<Integer> appActions(AppEntry entry, int place) {
        ArrayList<Integer> actions = new ArrayList<>();
        actions.add(ACTION_INFO);
        if (place == PLACE_DOCK) {
            actions.add(ACTION_UNDOCK);
        } else if (place == PLACE_SUGGESTED) {
            actions.add(ACTION_FAVORITE);
            actions.add(ACTION_NO_SUGGEST);
        } else {
            if (!getFavorites().contains(entry.key)) {
                actions.add(ACTION_FAVORITE);
            }
            actions.add(Folders.folderOf(folders, entry.key) == null ? ACTION_FOLDER : ACTION_UNFOLDER);
            actions.add(ACTION_HIDE);
            actions.add(ACTION_ARRANGE);
        }
        if (place != PLACE_SUGGESTED) {
            actions.add(ACTION_ICON);
        }
        if (place == PLACE_GRID) {
            actions.add(ACTION_SWIPE);
        }
        if (place != PLACE_SUGGESTED) {
            actions.add(ACTION_BREAKER);
        }
        if (!entry.system) {
            actions.add(ACTION_UNINSTALL);
        }
        return actions;
    }

    private int actionLabel(int action) {
        switch (action) {
            case ACTION_INFO:
                return R.string.app_info;
            case ACTION_FAVORITE:
                return R.string.add_favorite;
            case ACTION_UNDOCK:
                return R.string.remove_from_dock;
            case ACTION_HIDE:
                return R.string.hide_app;
            case ACTION_ARRANGE:
                return R.string.reorder_apps;
            case ACTION_FOLDER:
                return R.string.folder_add;
            case ACTION_UNFOLDER:
                return R.string.folder_remove;
            case ACTION_NO_SUGGEST:
                return R.string.no_suggest;
            case ACTION_ICON:
                return R.string.change_icon;
            case ACTION_SWIPE:
                return R.string.swipe_menu;
            case ACTION_BREAKER:
                return R.string.breaker_title;
            default:
                return R.string.uninstall;
        }
    }

    private int actionGlyph(int action) {
        switch (action) {
            case ACTION_INFO:
                return Glyphs.INFO;
            case ACTION_FAVORITE:
                return Glyphs.DOCK_ADD;
            case ACTION_UNDOCK:
                return Glyphs.DOCK_REMOVE;
            case ACTION_HIDE:
                return Glyphs.HIDE;
            case ACTION_ARRANGE:
                return Glyphs.ARRANGE;
            case ACTION_FOLDER:
            case ACTION_UNFOLDER:
                return Glyphs.FOLDER;
            case ACTION_NO_SUGGEST:
                return Glyphs.CLOSE;
            case ACTION_ICON:
                return Glyphs.SPARK;
            case ACTION_SWIPE:
                return Glyphs.CHEVRON_UP;
            case ACTION_BREAKER:
                return Glyphs.HOURGLASS;
            default:
                return Glyphs.UNINSTALL;
        }
    }

    /** The app's own shortcuts (e.g. "New chat"); Android only shares them with the default home app. */
    private List<ShortcutInfo> shortcutsFor(AppEntry entry) {
        ArrayList<ShortcutInfo> result = new ArrayList<>();
        try {
            if (!launcherApps.hasShortcutHostPermission()) {
                return result;
            }
            // Recent conversations too (Android 11+), as the phone's own launcher lists them for chat apps.
            int flags = LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC | LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST;
            if (Build.VERSION.SDK_INT >= 30) {
                flags |= LauncherApps.ShortcutQuery.FLAG_MATCH_CACHED;
            }
            LauncherApps.ShortcutQuery query = new LauncherApps.ShortcutQuery();
            query.setPackage(entry.pkg);
            query.setActivity(entry.component);
            query.setQueryFlags(flags);
            List<ShortcutInfo> found = launcherApps.getShortcuts(query, entry.user);
            if (found == null || found.isEmpty()) {
                // Some apps tie their shortcuts to another of their screens: take the whole app's.
                LauncherApps.ShortcutQuery wide = new LauncherApps.ShortcutQuery();
                wide.setPackage(entry.pkg);
                wide.setQueryFlags(flags);
                found = launcherApps.getShortcuts(wide, entry.user);
            }
            if (found == null) {
                return result;
            }
            for (ShortcutInfo info : found) {
                if (info.isEnabled()) {
                    result.add(info);
                }
            }
            Collections.sort(result, new Comparator<ShortcutInfo>() {
                @Override
                public int compare(ShortcutInfo a, ShortcutInfo b) {
                    if (a.isDeclaredInManifest() != b.isDeclaredInManifest()) {
                        return a.isDeclaredInManifest() ? -1 : 1;
                    }
                    return a.getRank() - b.getRank();
                }
            });
            while (result.size() > 4) {
                result.remove(result.size() - 1);
            }
        } catch (Exception ignored) {
        }
        return result;
    }

    boolean nightMode() {
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

    private void dismissAppPopup() {
        if (appPopup != null) {
            appPopup.dismiss();
            appPopup = null;
        }
    }

    /** One UI style menu next to the held icon: the app's shortcuts first, then Duo Home's actions. */
    private void showAppPopup(final AppEntry entry, final View anchor, boolean inDock) {
        showAppPopup(entry, anchor, inDock ? PLACE_DOCK : PLACE_GRID);
    }

    private void showAppPopup(final AppEntry entry, final View anchor, int place) {
        dismissAppPopup();
        boolean night = nightMode();
        int surface = night ? 0xF2252529 : 0xF7FBFBFD;
        int ink = night ? 0xFFF2F2F2 : 0xFF17171A;
        int line = night ? 0x1FFFFFFF : 0x14000000;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(8.0f), 0, dp(8.0f));
        final PopupWindow popup = new PopupWindow(box, dp(236.0f), ViewGroup.LayoutParams.WRAP_CONTENT, true);
        List<ShortcutInfo> shortcuts = shortcutsFor(entry);
        for (final ShortcutInfo shortcut : shortcuts) {
            Drawable icon = null;
            try {
                icon = launcherApps.getShortcutIconDrawable(shortcut, getResources().getDisplayMetrics().densityDpi);
            } catch (Exception ignored) {
            }
            CharSequence title = shortcut.getShortLabel() != null ? shortcut.getShortLabel() : shortcut.getLongLabel();
            box.addView(popupRow(icon, String.valueOf(title), ink, new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    popup.dismiss();
                    try {
                        launcherApps.startShortcut(shortcut, launchBounds(anchor), launchOptions(anchor));
                    } catch (Exception e) {
                        Toast.makeText(HomeActivity.this, getString(R.string.cannot_open), Toast.LENGTH_SHORT).show();
                    }
                }
            }));
        }
        if (!shortcuts.isEmpty()) {
            View divider = new View(this);
            divider.setBackgroundColor(line);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, Math.max(1, dp(0.6f)));
            params.setMargins(dp(18.0f), dp(6.0f), dp(18.0f), dp(6.0f));
            box.addView(divider, params);
        }
        for (final int action : appActions(entry, place)) {
            box.addView(popupRow(new Glyphs(actionGlyph(action), ink, dp(22.0f)), getString(actionLabel(action)), ink, new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    popup.dismiss();
                    handleAppAction(entry, action);
                }
            }));
        }
        showPopupNear(popup, box, anchor, night);
        appPopup = popup;
    }

    /** Shows a small menu above or below the held item, kept on screen, like One UI's popups. */
    private void showPopupNear(PopupWindow popup, View box, View anchor, boolean night) {
        popup.setBackgroundDrawable(pill(night ? 0xF2252529 : 0xF7FBFBFD, 24));
        popup.setElevation(dp(16.0f));
        popup.setOutsideTouchable(true);
        popup.setAnimationStyle(android.R.style.Animation_Dialog);
        int width = popup.getWidth();
        box.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        int height = box.getMeasuredHeight();
        int[] at = new int[2];
        anchor.getLocationOnScreen(at);
        int[] base = new int[2];
        root.getLocationOnScreen(base);
        at[0] -= base[0];
        at[1] -= base[1];
        int x = Math.max(dp(8.0f), Math.min(root.getWidth() - width - dp(8.0f), at[0] + anchor.getWidth() / 2 - width / 2));
        boolean lowerHalf = at[1] + anchor.getHeight() / 2 > root.getHeight() / 2;
        int above = at[1] - height - dp(6.0f);
        int below = at[1] + anchor.getHeight() + dp(6.0f);
        int y = lowerHalf && above > dp(24.0f) ? above : Math.min(below, root.getHeight() - height - dp(16.0f));
        popup.showAtLocation(root, Gravity.NO_GRAVITY, x, Math.max(dp(24.0f), y));
    }

    private View popupRow(Drawable icon, String text, int color, View.OnClickListener click) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(18.0f), 0, dp(18.0f), 0);
        row.setMinimumHeight(dp(48.0f));
        ImageView image = new ImageView(this);
        image.setImageDrawable(icon);
        row.addView(image, new LinearLayout.LayoutParams(dp(22.0f), dp(22.0f)));
        TextView label = label(text, 15, color, 400);
        label.setSingleLine(true);
        label.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, -2, 1f);
        params.setMarginStart(dp(14.0f));
        row.addView(label, params);
        row.setBackground(new RippleDrawable(ColorStateList.valueOf(withAlpha(color, 0.12f)), null, null));
        row.setOnClickListener(click);
        return row;
    }

    private void handlePendingAction() {
        if (!appsLoaded) {
            return; // runs again once the app list has loaded
        }
        String action = prefs.getString("pending_action", null);
        if (action == null) {
            return;
        }
        prefs.edit().remove("pending_action").apply();
        switch (action) {
            case "nova_import":
                startLayoutImport();
                break;
            case "reorder":
                if (drawer != null) {
                    drawer.open(false); // the apps are arranged where they live
                }
                setReorderMode(true);
                break;
            case "hidden":
                if (prefs.getBoolean("lock_hidden", true)) {
                    authenticate(getString(R.string.auth_hidden), this::showHiddenApps);
                } else {
                    showHiddenApps();
                }
                break;
            case "add_favorite":
                showFavoritePicker();
                break;
            case "auto_folders":
                offerAutoFolders();
                break;
            case "undo_auto_folders":
                undoAutoFolders();
                break;
            case "edit_cards":
                editCards(0);
                break;
            case "match_settings":
                matchSettings();
                break;
            case "countdowns":
                editCountdowns();
                break;
            case "khatma":
                if (Khatma.active(prefs)) {
                    khatmaOptions();
                } else {
                    startKhatma();
                }
                break;
            case "kids":
                setUpKids();
                break;
            case "edit_control_center":
                ControlCenter.edit(this, () -> {
                    if (controlCenter != null) {
                        controlCenter.fill();
                    }
                });
                break;
            default:
                break;
        }
    }

    private void handleAppAction(AppEntry entry, int action) {
        switch (action) {
            case ACTION_BREAKER: {
                boolean on = Breaker.toggle(prefs, entry.pkg);
                Toast.makeText(this, on ? getString(R.string.breaker_on, entry.label, NowBar.number(this, Breaker.minutes(prefs)))
                        : getString(R.string.breaker_off, entry.label), Toast.LENGTH_LONG).show();
                return;
            }
            case ACTION_FAVORITE: {
                List<String> favorites = getFavorites();
                if (favorites.contains(entry.key)) {
                    Toast.makeText(this, getString(R.string.already_favorite), Toast.LENGTH_SHORT).show();
                } else {
                    favorites.add(entry.key);
                    saveFavorites(favorites);
                }
                break;
            }
            case ACTION_EARLIER:
                moveApp(entry, -1);
                break;
            case ACTION_LATER:
                moveApp(entry, 1);
                break;
            case ACTION_HIDE:
                hideApp(entry);
                break;
            case ACTION_INFO:
                openAppInfo(entry);
                break;
            case ACTION_UNINSTALL:
                uninstall(entry);
                break;
            case ACTION_UNDOCK: {
                List<String> favorites = getFavorites();
                favorites.remove(entry.key);
                saveFavorites(favorites);
                break;
            }
            case ACTION_ARRANGE:
                setReorderMode(true);
                break;
            case ACTION_FOLDER:
                chooseFolder(entry);
                break;
            case ACTION_UNFOLDER:
                removeFromFolder(entry);
                break;
            case ACTION_NO_SUGGEST: {
                Set<String> keys = noSuggestKeys();
                keys.add(entry.key);
                prefs.edit().putString("no_suggest", TextUtils.join("|", keys)).apply();
                refreshSuggestions();
                break;
            }
            case ACTION_ICON:
                chooseIcon(entry);
                break;
            case ACTION_SWIPE:
                chooseSwipe(entry);
                break;
            default:
                break;
        }
    }

    private void setReorderMode(boolean enabled) {
        if (enabled) {
            ensureManualOrder();
        }
        reorderMode = enabled;
        updateWebRow(currentQuery());
        if (arrangeBar != null) {
            arrangeBar.setVisibility(enabled ? View.VISIBLE : View.GONE);
        }
    }

    // ---------------------------------------------------------------- folders

    /** One cell of the grid: either an app or a folder of apps. */
    private static final class Tile {
        final AppEntry app;
        final Folders.Folder folder;
        final List<AppEntry> members;

        Tile(AppEntry app, Folders.Folder folder, List<AppEntry> members) {
            this.app = app;
            this.folder = folder;
            this.members = members;
        }
    }

    /** Groups the visible apps into folders; a folder sits where its first app would be. Search shows apps one by one. */
    private void buildTiles(boolean searching) {
        tiles.clear();
        if (searching || folders.isEmpty()) {
            for (AppEntry entry : filteredApps) {
                tiles.add(new Tile(entry, null, null));
            }
            return;
        }
        HashMap<String, AppEntry> byKey = new HashMap<>();
        for (AppEntry entry : filteredApps) {
            byKey.put(entry.key, entry);
        }
        HashSet<String> placed = new HashSet<>();
        for (AppEntry entry : filteredApps) {
            Folders.Folder folder = Folders.folderOf(folders, entry.key);
            if (folder == null) {
                tiles.add(new Tile(entry, null, null));
                continue;
            }
            if (!placed.add(folder.id)) {
                continue;
            }
            ArrayList<AppEntry> members = new ArrayList<>();
            for (String key : folder.keys) {
                AppEntry member = byKey.get(key);
                if (member != null) {
                    members.add(member);
                }
            }
            tiles.add(new Tile(null, folder, members));
        }
    }

    private List<AppEntry> membersOf(Folders.Folder folder) {
        ArrayList<AppEntry> members = new ArrayList<>();
        Set<String> hidden = hiddenKeys();
        for (String key : folder.keys) {
            AppEntry entry = findByKey(key);
            if (entry != null && !hidden.contains(entry.key)) {
                members.add(entry);
            }
        }
        return members;
    }

    private void saveFolders() {
        for (int i = folders.size() - 1; i >= 0; i--) {
            if (folders.get(i).keys.isEmpty()) {
                folders.remove(i);
            }
        }
        Folders.save(prefs, folders);
        applyFilter(currentQuery());
    }

    private void addToFolder(Folders.Folder folder, AppEntry entry) {
        for (Folders.Folder other : folders) {
            other.keys.remove(entry.key);
        }
        if (!folders.contains(folder)) {
            folders.add(folder);
        }
        folder.keys.add(entry.key);
        saveFolders();
    }

    private void removeFromFolder(AppEntry entry) {
        Folders.Folder folder = Folders.folderOf(folders, entry.key);
        if (folder == null) {
            return;
        }
        folder.keys.remove(entry.key);
        saveFolders();
        if (folderPopup != null) {
            dismissFolderPopup();
            if (!folder.keys.isEmpty()) {
                openFolder(folder);
            }
        }
    }

    private interface NameCallback {
        void onName(String name);
    }

    private void promptName(String title, String initial, final NameCallback callback) {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText(initial);
        input.setSelectAllOnFocus(true);
        input.setHint(getString(R.string.folder_name_hint));
        FrameLayout box = new FrameLayout(this);
        box.setPadding(dp(22.0f), dp(8.0f), dp(22.0f), 0);
        box.addView(input);
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(box)
                .setPositiveButton(getString(R.string.done), (dialog, which) -> {
                    String name = input.getText().toString().trim();
                    callback.onName(name.length() == 0 ? getString(R.string.folder_default_name) : name);
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
        input.requestFocus();
    }

    private void chooseFolder(final AppEntry entry) {
        String[] names = new String[folders.size() + 1];
        for (int i = 0; i < folders.size(); i++) {
            names[i] = folders.get(i).name;
        }
        names[folders.size()] = getString(R.string.folder_new);
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.folder_choose))
                .setItems(names, (dialog, which) -> {
                    if (which < folders.size()) {
                        addToFolder(folders.get(which), entry);
                    } else {
                        promptName(getString(R.string.folder_new), getString(R.string.folder_default_name), name ->
                                addToFolder(new Folders.Folder(Folders.newId(), name), entry));
                    }
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void renameFolder(final Folders.Folder folder) {
        promptName(getString(R.string.folder_rename), folder.name, name -> {
            folder.name = name;
            saveFolders();
            if (folderPopup != null) {
                dismissFolderPopup();
                openFolder(folder);
            }
        });
    }

    private void ungroupFolder(Folders.Folder folder) {
        folders.remove(folder);
        saveFolders();
    }

    private void dismissFolderPopup() {
        if (folderPopup != null) {
            folderPopup.dismiss();
            folderPopup = null;
        }
    }

    private Folders.Icon folderIcon(List<AppEntry> members) {
        ArrayList<Drawable> icons = new ArrayList<>();
        for (AppEntry member : members) {
            icons.add(shownIcon(member));
        }
        return new Folders.Icon(icons, darkWallpaper ? 0x47FFFFFF : 0xA6FFFFFF, darkWallpaper ? 0x66FFFFFF : 0xE6FFFFFF);
    }

    /** The open folder: a One UI style card in the middle of the screen with the folder's apps. */
    private void openFolder(final Folders.Folder folder) {
        if (folder.locked && !privateUnlocked) {
            authenticate(getString(R.string.auth_folder, folder.name), () -> openFolder(folder));
            return;
        }
        dismissAppPopup();
        dismissFolderPopup();
        List<AppEntry> members = membersOf(folder);
        boolean night = nightMode();
        int surface = night ? 0xF2252529 : 0xF7FBFBFD;
        int ink = night ? 0xFFF2F2F2 : 0xFF17171A;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14.0f), dp(18.0f), dp(14.0f), dp(16.0f));
        TextView title = label(folder.name, 20, ink, 600);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(12.0f));
        title.setContentDescription(getString(R.string.folder_rename) + "، " + folder.name);
        title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                renameFolder(folder);
            }
        });
        box.addView(title, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout row = null;
        for (int i = 0; i < members.size(); i++) {
            if (i % 4 == 0) {
                row = new LinearLayout(this);
                box.addView(row, new LinearLayout.LayoutParams(-1, -2));
            }
            final AppEntry entry = members.get(i);
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(0, dp(6.0f), 0, dp(8.0f));
            final FrameLayout icon = iconWithDot(entry, 50);
            cell.addView(icon, new LinearLayout.LayoutParams(dp(56.0f), dp(56.0f)));
            TextView name = label(entry.label, 12, ink, 400);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.END);
            name.setGravity(Gravity.CENTER);
            name.setPadding(dp(2.0f), dp(4.0f), dp(2.0f), 0);
            cell.addView(name, new LinearLayout.LayoutParams(-1, -2));
            cell.setContentDescription(entry.label);
            cell.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    dismissFolderPopup();
                    launch(entry, icon);
                }
            });
            cell.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    showAppPopup(entry, icon, false);
                    return true;
                }
            });
            row.addView(cell, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        if (row != null) {
            for (int i = members.size() % 4; i != 0 && i < 4; i++) {
                row.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
            }
        }
        ScrollView scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.addView(box);
        int width = Math.min(dp(340.0f), root.getWidth() - dp(32.0f));
        box.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        int height = Math.min(box.getMeasuredHeight(), (int) (root.getHeight() * 0.65f));
        PopupWindow popup = new PopupWindow(scroll, width, height, true);
        popup.setBackgroundDrawable(pill(surface, 28));
        popup.setElevation(dp(20.0f));
        popup.setOutsideTouchable(true);
        popup.setAnimationStyle(android.R.style.Animation_Dialog);
        popup.showAtLocation(root, Gravity.CENTER, 0, 0);
        folderPopup = popup;
    }

    private void showFolderMenu(final Folders.Folder folder, View anchor) {
        dismissAppPopup();
        boolean night = nightMode();
        int ink = night ? 0xFFF2F2F2 : 0xFF17171A;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(8.0f), 0, dp(8.0f));
        final PopupWindow popup = new PopupWindow(box, dp(236.0f), ViewGroup.LayoutParams.WRAP_CONTENT, true);
        box.addView(popupRow(new Glyphs(Glyphs.FOLDER, ink, dp(22.0f)), getString(R.string.folder_rename), ink, new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popup.dismiss();
                renameFolder(folder);
            }
        }));
        box.addView(popupRow(new Glyphs(Glyphs.LOCK, ink, dp(22.0f)),
                getString(folder.locked ? R.string.folder_unlock : R.string.folder_lock), ink, view -> {
                    popup.dismiss();
                    setFolderLocked(folder, !folder.locked);
                }));
        box.addView(popupRow(new Glyphs(Glyphs.CLOSE, ink, dp(22.0f)), getString(R.string.folder_ungroup), ink, new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popup.dismiss();
                if (folder.locked && !privateUnlocked) {
                    authenticate(getString(R.string.auth_folder, folder.name), () -> ungroupFolder(folder));
                } else {
                    ungroupFolder(folder);
                }
            }
        }));
        showPopupNear(popup, box, anchor, night);
        appPopup = popup;
    }

    private View folderCell(final LinearLayout cell, final Tile tile) {
        FrameLayout frame = new FrameLayout(this);
        ImageView icon = new ImageView(this);
        icon.setImageDrawable(tile.folder.locked ? lockedFolderIcon() : folderIcon(tile.members));
        frame.addView(icon, new FrameLayout.LayoutParams(dp(gridIconDp()), dp(gridIconDp()), Gravity.CENTER));
        boolean news = false;
        for (AppEntry member : tile.members) {
            news |= dotsShown() && !tile.folder.locked && DotsService.has(member.pkg, member.user);
        }
        if (news) {
            View dot = new View(this);
            GradientDrawable circle = new GradientDrawable();
            circle.setShape(GradientDrawable.OVAL);
            circle.setColor(0xFFFF7A2F);
            circle.setStroke(Math.max(1, dp(1.5f)), darkWallpaper ? 0xFF1A1630 : Color.WHITE);
            dot.setBackground(circle);
            frame.addView(dot, new FrameLayout.LayoutParams(dp(14.0f), dp(14.0f), Gravity.TOP | Gravity.END));
        }
        cell.addView(frame, new LinearLayout.LayoutParams(gridFrame(), gridFrame()));
        TextView name = label(tile.folder.name, gridDense ? 11 : 12, textPrimary, 400);
        if (hideLabels) {
            name.setVisibility(View.INVISIBLE);
        }
        name.setGravity(Gravity.CENTER);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.END);
        name.setPadding(0, dp(6.0f), 0, 0);
        shadowOnWallpaper(name);
        cell.addView(name, new LinearLayout.LayoutParams(-1, -2));
        cell.setContentDescription(getString(R.string.folder_description, tile.folder.name, tile.members.size()));
        final View anchor = frame;
        cell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openFolder(tile.folder);
            }
        });
        cell.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                if (reorderMode) {
                    return false;
                }
                showFolderMenu(tile.folder, anchor);
                return true;
            }
        });
        // In arrange mode, dropping an app on a folder puts it inside.
        cell.setOnDragListener(new View.OnDragListener() {
            @Override
            public boolean onDrag(View view, DragEvent event) {
                switch (event.getAction()) {
                    case DragEvent.ACTION_DRAG_STARTED:
                        return reorderMode && (event.getLocalState() instanceof AppEntry);
                    case DragEvent.ACTION_DROP:
                        cell.setBackground(null);
                        addToFolder(tile.folder, (AppEntry) event.getLocalState());
                        return true;
                    case DragEvent.ACTION_DRAG_ENTERED:
                        cell.setBackground(pill(withAlpha(accent, 0.35f), 20));
                        return true;
                    case DragEvent.ACTION_DRAG_ENDED:
                    case DragEvent.ACTION_DRAG_EXITED:
                        cell.setBackground(null);
                        return true;
                    default:
                        return true;
                }
            }
        });
        return cell;
    }

    // ---------------------------------------------------------------- widgets

    private List<Integer> widgetIds() {
        ArrayList<Integer> ids = new ArrayList<>();
        for (String part : prefs.getString("widgets", "").split(",")) {
            if (part.length() > 0) {
                try {
                    ids.add(Integer.parseInt(part));
                } catch (NumberFormatException ignored) {
                }
            }
        }
        return ids;
    }

    private void saveWidgetIds(List<Integer> ids) {
        prefs.edit().putString("widgets", TextUtils.join(",", ids)).apply();
    }

    private void clearPendingStack() {
        pendingStackSlot = -1;
        prefs.edit().remove("pending_stack_slot").apply();
    }

    private void addWidget(int id) {
        int slot = pendingStackSlot >= 0 ? pendingStackSlot : prefs.getInt("pending_stack_slot", -1);
        clearPendingStack();
        if (slot == 0 || slot == 1) {
            List<String> types = cardTypes(slot);
            String type = "widget:" + id;
            if (!types.contains(type)) {
                types.add(type);
            }
            saveCardTypes(slot, types);
            prefs.edit().putInt("card_page_" + slot, types.indexOf(type)).apply();
            fillCards();
            return;
        }
        List<Integer> ids = widgetIds();
        if (!ids.contains(id)) {
            ids.add(id);
            saveWidgetIds(ids);
        }
        if (twoPane) {
            fillToday();
        } else if (todayOpen) {
            fillToday();
        } else {
            openToday();
        }
    }

    private void removeWidget(final int id, String name) {
        new AlertDialog.Builder(this)
                .setTitle(name)
                .setMessage(getString(R.string.widget_remove_question))
                .setPositiveButton(getString(R.string.remove), (dialog, which) -> {
                    List<Integer> ids = widgetIds();
                    ids.remove(Integer.valueOf(id));
                    saveWidgetIds(ids);
                    widgetViews.remove(id);
                    try {
                        widgetHost.deleteAppWidgetId(id);
                    } catch (Exception ignored) {
                    }
                    fillToday();
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private String appName(String packageName) {
        try {
            return String.valueOf(getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(packageName, 0)));
        } catch (Exception e) {
            return packageName;
        }
    }

    /** Lists every widget the installed apps offer, grouped by app name. */
    private void pickWidget() {
        pickWidget(-1);
    }

    /** {@code slot} 0 or 1 puts the widget in that home stack; -1 on the Today page. */
    private void pickWidget(final int slot) {
        List<AppWidgetProviderInfo> found;
        try {
            found = widgetManager.getInstalledProviders();
        } catch (Exception e) {
            found = new ArrayList<>();
        }
        final ArrayList<AppWidgetProviderInfo> providers = new ArrayList<>(found);
        if (providers.isEmpty()) {
            Toast.makeText(this, getString(R.string.widget_none), Toast.LENGTH_SHORT).show();
            return;
        }
        final HashMap<AppWidgetProviderInfo, String> names = new HashMap<>();
        for (AppWidgetProviderInfo info : providers) {
            String app = appName(info.provider.getPackageName());
            String widget = info.loadLabel(getPackageManager());
            names.put(info, widget == null || widget.equals(app) ? app : app + "، " + widget);
        }
        final Collator collator = labelCollator();
        Collections.sort(providers, new Comparator<AppWidgetProviderInfo>() {
            @Override
            public int compare(AppWidgetProviderInfo a, AppWidgetProviderInfo b) {
                return collator.compare(names.get(a), names.get(b));
            }
        });
        String[] labels = new String[providers.size()];
        for (int i = 0; i < providers.size(); i++) {
            labels[i] = names.get(providers.get(i));
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.widget_choose))
                .setItems(labels, (dialog, which) -> {
                    pendingStackSlot = slot;
                    prefs.edit().putInt("pending_stack_slot", slot).apply();
                    bindWidget(providers.get(which));
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void bindWidget(AppWidgetProviderInfo info) {
        int id = widgetHost.allocateAppWidgetId();
        boolean allowed = false;
        try {
            allowed = widgetManager.bindAppWidgetIdIfAllowed(id, info.getProfile(), info.provider, null);
        } catch (Exception ignored) {
        }
        if (allowed) {
            configureWidget(id, info);
            return;
        }
        // Android asks the user once whether Duo Home may show this app's widgets.
        pendingWidgetId = id;
        Intent intent = new Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER_PROFILE, info.getProfile());
        try {
            startActivityForResult(intent, REQUEST_BIND_WIDGET);
        } catch (Exception e) {
            widgetHost.deleteAppWidgetId(id);
            pendingWidgetId = -1;
            clearPendingStack();
            Toast.makeText(this, getString(R.string.cannot_open), Toast.LENGTH_SHORT).show();
        }
    }

    private void configureWidget(int id, AppWidgetProviderInfo info) {
        if (info.configure != null) {
            pendingWidgetId = id;
            try {
                widgetHost.startAppWidgetConfigureActivityForResult(this, id, 0, REQUEST_CONFIGURE_WIDGET, null);
                return;
            } catch (Exception ignored) {
                // some widgets declare a settings screen that can't be opened from outside; add it as is
            }
        }
        pendingWidgetId = -1;
        addWidget(id);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_LAYOUT_IMPORT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                importLayout(data.getData());
            }
            return;
        }
        if (requestCode == DefaultHome.REQUEST) {
            if (!DefaultHome.isDefault(this)) {
                DefaultHome.openSettings(this); // the question was turned down or skipped: the settings page still works
            }
            updateDefaultBanner();
            return;
        }
        if (requestCode == REQUEST_CONFIRM) {
            authInProgress = false;
            Runnable then = pendingAuth;
            pendingAuth = null;
            if (resultCode == RESULT_OK && then != null) {
                privateUnlocked = true;
                then.run();
            }
            return;
        }
        if (requestCode == REQUEST_ICON_PICTURE) {
            iconPictureChosen(resultCode, data);
            return;
        }
        if (requestCode != REQUEST_BIND_WIDGET && requestCode != REQUEST_CONFIGURE_WIDGET) {
            return;
        }
        int id = data != null ? data.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidgetId) : pendingWidgetId;
        pendingWidgetId = -1;
        if (id < 0) {
            clearPendingStack();
            return;
        }
        if (resultCode != RESULT_OK) {
            clearPendingStack();
            try {
                widgetHost.deleteAppWidgetId(id);
            } catch (Exception ignored) {
            }
            return;
        }
        if (requestCode == REQUEST_BIND_WIDGET) {
            AppWidgetProviderInfo info = widgetManager.getAppWidgetInfo(id);
            if (info == null) {
                widgetHost.deleteAppWidgetId(id);
                clearPendingStack();
                return;
            }
            configureWidget(id, info);
        } else {
            addWidget(id);
        }
    }

    /** The user's widgets on the Today page, each with a small header to remove it, then an add button. */
    private void addWidgetsCard() {
        LinearLayout card = todayCard();
        todayCardHeader(card, getString(R.string.widgets_title), null);
        List<Integer> ids = widgetIds();
        if (ids.size() >= 2) {
            final boolean stacked = prefs.getBoolean("widget_stack", true);
            TextView mode = label(getString(stacked ? R.string.widget_show_list : R.string.widget_show_stack), 13, accentOnWallpaper(), 600);
            mode.setPadding(0, 0, 0, dp(8.0f));
            mode.setOnClickListener(view -> {
                prefs.edit().putBoolean("widget_stack", !stacked).apply();
                fillToday();
            });
            card.addView(mode, new LinearLayout.LayoutParams(-2, -2));
            if (stacked) {
                addWidgetStack(card, ids);
                addWidgetButton(card);
                return;
            }
        }
        for (final int id : ids) {
            AppWidgetProviderInfo info = widgetManager.getAppWidgetInfo(id);
            if (info == null) {
                continue;
            }
            AppWidgetHostView view = widgetViews.get(id);
            if (view == null) {
                try {
                    view = widgetHost.createView(getApplicationContext(), id, info);
                } catch (Exception e) {
                    continue;
                }
                widgetViews.put(id, view);
            }
            if (view.getParent() instanceof ViewGroup) {
                ((ViewGroup) view.getParent()).removeView(view);
            }
            final String name = appName(info.provider.getPackageName());
            LinearLayout header = new LinearLayout(this);
            header.setGravity(Gravity.CENTER_VERTICAL);
            header.addView(label(name, 12, textSecondary, 500), new LinearLayout.LayoutParams(0, -2, 1f));
            ImageView remove = new ImageView(this);
            remove.setImageDrawable(new Glyphs(Glyphs.CLOSE, textSecondary, dp(14.0f)));
            remove.setScaleType(ImageView.ScaleType.CENTER);
            remove.setContentDescription(getString(R.string.widget_remove) + "، " + name);
            remove.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    removeWidget(id, name);
                }
            });
            header.addView(remove, new LinearLayout.LayoutParams(dp(32.0f), dp(32.0f)));
            card.addView(header, new LinearLayout.LayoutParams(-1, -2));
            int height = Math.max(dp(110.0f), Math.min(dp(420.0f), info.minHeight));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, height);
            params.bottomMargin = dp(10.0f);
            card.addView(view, params);
        }
        addWidgetButton(card);
    }

    private void addWidgetButton(LinearLayout card) {
        LinearLayout add = new LinearLayout(this);
        add.setGravity(Gravity.CENTER);
        add.setMinimumHeight(dp(44.0f));
        add.setBackground(new RippleDrawable(ColorStateList.valueOf(withAlpha(textPrimary, 0.16f)), pill(withAlpha(textPrimary, 0.08f), 22), null));
        ImageView icon = new ImageView(this);
        icon.setImageDrawable(new Glyphs(Glyphs.WIDGET, textPrimary, dp(20.0f)));
        add.addView(icon, new LinearLayout.LayoutParams(dp(20.0f), dp(20.0f)));
        TextView text = label(getString(R.string.widget_add), 15, textPrimary, 500);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(-2, -2);
        textParams.setMarginStart(dp(8.0f));
        add.addView(text, textParams);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickWidget();
            }
        });
        card.addView(add, new LinearLayout.LayoutParams(-1, -2));
    }

    // ---------------------------------------------------------------- battery

    /** Battery changes are a sticky system broadcast, so registering also returns the current state. */
    private void watchBattery() {
        if (batteryRegistered) {
            return;
        }
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        filter.addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED);
        filter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        filter.addAction(WifiManager.RSSI_CHANGED_ACTION);
        filter.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        filter.addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED);
        try {
            // System broadcasts only (battery, Wi-Fi, network): closed to other apps on Android 13+.
            Intent sticky = Build.VERSION.SDK_INT >= 33 ? registerReceiver(batteryReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
                    : registerReceiver(batteryReceiver, filter);
            batteryRegistered = true;
            updateBattery(sticky);
        } catch (Exception ignored) {
        }
        updateNetwork();
        watchSignal();
    }

    // Wi-Fi and mobile signal follow the approach of James Fenn's open-source Status app
    // (github.com/fennifith/Status, Apache 2.0): Wi-Fi strength from the RSSI split into levels,
    // mobile signal from a PhoneStateListener on signal strengths.

    /** Wi-Fi: connected when any network uses Wi-Fi; strength 0..3 from its RSSI. */
    private void updateNetwork() {
        if (statusRing == null) {
            return;
        }
        boolean connected = false;
        int level = 0;
        try {
            ConnectivityManager cm = getSystemService(ConnectivityManager.class);
            NetworkCapabilities wifi = null;
            if (cm != null) {
                Network active = cm.getActiveNetwork();
                NetworkCapabilities caps = active == null ? null : cm.getNetworkCapabilities(active);
                if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                    wifi = caps;
                } else {
                    for (Network network : cm.getAllNetworks()) {
                        NetworkCapabilities other = cm.getNetworkCapabilities(network);
                        if (other != null && other.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                            wifi = other;
                            break;
                        }
                    }
                }
            }
            if (wifi != null) {
                connected = true;
                int rssi = Integer.MIN_VALUE;
                if (Build.VERSION.SDK_INT >= 29) {
                    rssi = wifi.getSignalStrength();
                }
                if (rssi == Integer.MIN_VALUE) {
                    WifiManager manager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    if (manager != null && manager.getConnectionInfo() != null) {
                        rssi = manager.getConnectionInfo().getRssi();
                    }
                }
                level = wifiLevel(rssi);
            }
        } catch (Exception ignored) {
        }
        wifiOn = connected;
        wifiBars = level;
        statusRing.setWifi(connected, level);
        describeStatus();
    }

    /**
     * RSSI to 0..3 arcs, with the same linear scale AOSP uses (-100 dBm empty, -55 dBm full).
     * Unknown strength (or the -127 placeholder) counts as full, since we are connected.
     */
    static int wifiLevel(int rssi) {
        if (rssi == Integer.MIN_VALUE || rssi <= -127 || rssi >= 0) {
            return 3;
        }
        if (rssi <= -100) {
            return 0;
        }
        if (rssi >= -55) {
            return 3;
        }
        return (int) ((rssi + 100) * 3f / 45f);
    }

    private void watchSignal() {
        if (signalListener != null) {
            return;
        }
        try {
            telephony = getSystemService(TelephonyManager.class);
            if (telephony == null) {
                return;
            }
            signalListener = new PhoneStateListener() {
                @Override
                public void onSignalStrengthsChanged(SignalStrength strength) {
                    lastSignal = strength;
                    updateSignal(strength);
                }
            };
            telephony.listen(signalListener, PhoneStateListener.LISTEN_SIGNAL_STRENGTHS);
            if (Build.VERSION.SDK_INT >= 28 && lastSignal == null) {
                lastSignal = telephony.getSignalStrength();
            }
        } catch (Exception e) {
            signalListener = null;
        }
        updateSignal(lastSignal);
    }

    private void stopSignal() {
        if (telephony != null && signalListener != null) {
            try {
                telephony.listen(signalListener, PhoneStateListener.LISTEN_NONE);
            } catch (Exception ignored) {
            }
        }
        signalListener = null;
    }

    /** Mobile signal 0..4, or -1 (all dots dim) with no SIM, no service or in airplane mode. */
    private void updateSignal(SignalStrength strength) {
        if (statusRing == null) {
            return;
        }
        int level = -1;
        try {
            boolean airplane = android.provider.Settings.Global.getInt(getContentResolver(),
                    android.provider.Settings.Global.AIRPLANE_MODE_ON, 0) != 0;
            if (strength != null && !airplane && telephony != null
                    && telephony.getSimState() == TelephonyManager.SIM_STATE_READY) {
                level = Math.max(0, Math.min(4, strength.getLevel()));
            }
        } catch (Exception ignored) {
        }
        signalBars = level;
        statusRing.setSignal(level);
        describeStatus();
    }

    /** One spoken description for the whole gauge: battery, then Wi-Fi, then mobile signal. */
    private void describeStatus() {
        if (batteryView == null) {
            return;
        }
        StringBuilder text = new StringBuilder(batteryText);
        text.append(wifiOn ? getString(R.string.status_wifi_on, wifiBars, 3) : getString(R.string.status_wifi_off));
        if (signalBars >= 0) {
            text.append(getString(R.string.status_signal, signalBars, 4));
        }
        batteryView.setContentDescription(text.toString());
    }

    private void updateBattery(Intent intent) {
        if (statusRing == null) {
            return;
        }
        if (intent == null || !Intent.ACTION_BATTERY_CHANGED.equals(intent.getAction())) {
            try {
                intent = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            } catch (Exception e) {
                intent = null;
            }
        }
        if (intent == null) {
            return;
        }
        int raw = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int level = raw < 0 || scale <= 0 ? -1 : Math.round(raw * 100f / scale);
        int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        boolean charging = status == BatteryManager.BATTERY_STATUS_CHARGING
                || (status == BatteryManager.BATTERY_STATUS_FULL && intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0);
        PowerManager power = getSystemService(PowerManager.class);
        boolean saver = power != null && power.isPowerSaveMode();
        statusRing.setBattery(level, charging, saver);
        batteryLevelNow = level;
        batteryCharging = charging;
        batterySaver = saver;
        runCardUpdater("battery");
        if (level >= 0) {
            String text = getString(R.string.battery_description, java.text.NumberFormat.getPercentInstance().format(level / 100.0));
            if (charging) {
                text += getString(R.string.battery_charging);
            } else if (saver) {
                text += getString(R.string.battery_saver);
            }
            batteryText = text;
        }
        describeStatus();
    }

    private void openBatterySettings() {
        try {
            startActivity(new Intent(Intent.ACTION_POWER_USAGE_SUMMARY));
        } catch (Exception e) {
            try {
                startActivity(new Intent(android.provider.Settings.ACTION_BATTERY_SAVER_SETTINGS));
            } catch (Exception ignored) {
            }
        }
    }

    // ---------------------------------------------------------------- Today page

    private long[] prayerTimesFor(long day) {
        double[] place = Places.latLng(prefs);
        return PrayerTimes.forDay(day, place[0], place[1], Places.zone(prefs), Prayers.method(prefs),
                prefs.getBoolean("asr_hanafi", false), HijriEvents.isRamadan(day));
    }

    /** Index of the next prayer today (sunrise is not a prayer), or -1 after Isha. */
    private static int nextPrayerIndex(long[] times, long now) {
        for (int i = 0; i < times.length; i++) {
            if (i != PrayerTimes.SUNRISE && times[i] > now) {
                return i;
            }
        }
        return -1;
    }

    private String timeText(long when) {
        java.text.DateFormat format = android.text.format.DateFormat.getTimeFormat(this);
        format.setTimeZone(Places.zone(prefs));
        return format.format(new Date(when));
    }

    private String countdown(long millis) {
        long minutes = Math.max(1L, (millis + 59999L) / 60000L);
        if (minutes < 60) {
            return getString(R.string.in_minutes, minutes);
        }
        if (minutes % 60 == 0) {
            return getString(R.string.in_hours, minutes / 60);
        }
        return getString(R.string.in_hours_minutes, minutes / 60, minutes % 60);
    }

    /** "العصر بعد ٢٥ د" when it's close, otherwise "العصر ٢:٤٥ م". Empty when prayer times are off. */
    private String nextPrayerText(long now) {
        if (!prayerOn) {
            return "";
        }
        long[] times = prayerTimesFor(now);
        int next = nextPrayerIndex(times, now);
        long at;
        if (next < 0) {
            next = PrayerTimes.FAJR;
            at = prayerTimesFor(now + 86400000L)[PrayerTimes.FAJR];
        } else {
            at = times[next];
        }
        long left = at - now;
        return getString(PRAYER_NAMES[next]) + " " + (left <= 2 * 3600000L ? countdown(left) : timeText(at));
    }

    private void updateWeatherChip() {
        runCardUpdater("weather");
        if (weatherChip == null) {
            return;
        }
        Weather.Now now = weatherOn ? Weather.cached(prefs) : null;
        if (now == null) {
            weatherChip.setVisibility(View.GONE);
            return;
        }
        weatherChip.setVisibility(View.VISIBLE);
        weatherIcon.setImageDrawable(new Weather.Icon(Weather.iconType(now.code, now.day), textPrimary, dp(22.0f)));
        weatherTemp.setText(Weather.degrees(now.temp));
        weatherChip.setContentDescription(Weather.degrees(now.temp) + " " + getString(Weather.descriptionRes(now.code)));
    }

    static final int REQUEST_LOCATION_HOME = 7742;

    /**
     * Weather by GPS: a fresh fix when Home comes back (at most every fifteen minutes), and the weather
     * again when the phone has moved. The first time, Android asks for the location permission.
     */
    void followLocation(boolean now) {
        if (!Places.wantsLocation(prefs)) {
            return;
        }
        if (!Places.permitted(this)) {
            boolean wanted = (Places.weatherGps(prefs) && weatherOn) || (Places.prayerGps(prefs) && prayerOn);
            if (wanted && !prefs.getBoolean("weather_gps_asked", false)) {
                prefs.edit().putBoolean("weather_gps_asked", true).apply();
                requestPermissions(new String[] {android.Manifest.permission.ACCESS_FINE_LOCATION,
                        android.Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_LOCATION_HOME);
            }
            return;
        }
        if (!now && !Places.stale(prefs)) {
            return;
        }
        Places.refresh(this, prefs, () -> {
            if (isDestroyed()) {
                return;
            }
            updateWidgets(); // the prayer times of the new place, in the clock chip and the card
            refreshWeather(false); // fetches again only if the phone moved, or the reading is old
            ReminderReceiver.schedulePrayer(this); // the alerts at the new place's times
            Haram.check(this, prefs); // silence in the Holy Mosques, sound back outside
            updateUsagePlace();
            refreshSuggestions();
            updateAmbience(System.currentTimeMillis());
            if (todayOpen || twoPane) {
                fillToday();
            }
        });
    }

    private void refreshWeather(boolean force) {
        if (!weatherOn || newsExecutor.isShutdown()) {
            return;
        }
        final double[] place = Places.here(prefs);
        Weather.Now cached = Weather.cached(prefs);
        boolean moved = Weather.placeMoved(prefs, place[0], place[1]);
        if (!force && !moved && cached != null && System.currentTimeMillis() - cached.time < Weather.REFRESH_MS) {
            return;
        }
        newsExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    Weather.Now fresh = Weather.fetch(place[0], place[1]);
                    Weather.store(prefs, fresh);
                    Weather.storePlace(prefs, place[0], place[1]);
                    if (Weather.alertsOn(prefs)) {
                        List<double[]> dust = null;
                        try {
                            dust = Weather.fetchDust(place[0], place[1]);
                        } catch (Exception ignored) {
                            // the rain part still counts
                        }
                        Weather.Alert alert = Weather.alert(fresh, dust, System.currentTimeMillis());
                        Weather.storeAlert(prefs, alert);
                        ReminderReceiver.notifyWeather(HomeActivity.this, alert);
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!isDestroyed()) {
                                updateWeatherChip();
                                runCardUpdater("weather");
                                smartStacks(System.currentTimeMillis());
                                if (todayOpen || twoPane) {
                                    fillToday();
                                }
                            }
                        }
                    });
                } catch (Exception ignored) {
                    // keep the last reading; try again next time Home comes back
                }
            }
        });
    }

    void padForSystemBars(View view, WindowInsets windowInsets) {
        if (Build.VERSION.SDK_INT >= 30) {
            Insets insets = windowInsets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
            view.setPadding(insets.left, insets.top, insets.right, insets.bottom);
        } else {
            view.setPadding(windowInsets.getSystemWindowInsetLeft(), windowInsets.getSystemWindowInsetTop(),
                    windowInsets.getSystemWindowInsetRight(), windowInsets.getSystemWindowInsetBottom());
        }
    }

    /** A full page of today's details over the home screen, like One UI's screen to the left of Home. */
    private void buildTodayPanel() {
        todayPanel = new ScrollView(this);
        todayPanel.setVisibility(View.GONE);
        todayPanel.setFillViewport(true);
        todayPanel.setVerticalScrollBarEnabled(false);
        todayPanel.setOverScrollMode(View.OVER_SCROLL_NEVER);
        todayPanel.setBackgroundColor(darkWallpaper ? 0x66000000 : 0x4DFFFFFF);
        todayPanel.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View view, WindowInsets insets) {
                padForSystemBars(view, insets);
                return insets;
            }
        });
        todayPanel.setOnScrollChangeListener(new View.OnScrollChangeListener() {
            @Override
            public void onScrollChange(View v, int x, int y, int oldX, int oldY) {
                for (View glassView : todayGlass) {
                    glassView.invalidate(); // keep the frosted wallpaper lined up while scrolling
                }
            }
        });
        todayPanel.setOnTouchListener(new View.OnTouchListener() {
            private float startX;
            private float startY;

            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    startX = event.getX();
                    startY = event.getY();
                } else if (event.getActionMasked() == MotionEvent.ACTION_UP) {
                    float dx = event.getX() - startX;
                    float dy = event.getY() - startY;
                    boolean rtl = todayContent.getLayoutDirection() == View.LAYOUT_DIRECTION_RTL;
                    boolean towardHome = rtl ? dx > 0 : dx < 0;
                    if (Math.abs(dx) > dp(80.0f) && Math.abs(dx) > Math.abs(dy) * 1.5f && towardHome) {
                        closeToday();
                        return true;
                    }
                }
                return false;
            }
        });
        todayContent = new LinearLayout(this);
        todayContent.setOrientation(LinearLayout.VERTICAL);
        todayContent.setLayoutDirection(View.LAYOUT_DIRECTION_LOCALE);
        todayContent.setPadding(dp(16.0f), dp(8.0f), dp(16.0f), dp(24.0f));
        todayPanel.addView(todayContent, new FrameLayout.LayoutParams(-1, -2));
        if (twoPane) {
            // Wide screen: Today is always there, as a pane beside the apps.
            todayPanel.setVisibility(View.VISIBLE);
            todayPanel.setBackground(null);
            todayPanel.setOnApplyWindowInsetsListener(null);
            todayPanel.setOnTouchListener(null);
            todayContent.setPadding(dp(14.0f), dp(10.0f), dp(4.0f), dp(16.0f));
            root.addView(todayPanel, 0, new LinearLayout.LayoutParams(0, -1, 0.85f));
            return;
        }
        frame.addView(todayPanel, new FrameLayout.LayoutParams(-1, -1));
    }

    private void openToday() {
        if (twoPane && todayPanel != null) {
            todayPanel.smoothScrollTo(0, 0);
            return;
        }
        if (todayPanel == null || todayOpen) {
            return;
        }
        dismissAppPopup();
        if (isSearchOpen()) {
            closeSearch();
        }
        todayOpen = true;
        fillToday();
        todayPanel.scrollTo(0, 0);
        todayPanel.setVisibility(View.VISIBLE);
        boolean rtl = todayContent.getLayoutDirection() == View.LAYOUT_DIRECTION_RTL;
        todayPanel.setAlpha(0f);
        todayPanel.setTranslationX(dp(56.0f) * (rtl ? 1 : -1));
        todayPanel.animate().alpha(1f).translationX(0f).setDuration(240L).setInterpolator(new DecelerateInterpolator()).withLayer().start();
        for (int i = 0; i < root.getChildCount(); i++) {
            root.getChildAt(i).animate().alpha(0f).setDuration(180L).withLayer().start();
        }
    }

    private void closeToday() {
        if (!todayOpen) {
            return;
        }
        todayOpen = false;
        boolean rtl = todayContent.getLayoutDirection() == View.LAYOUT_DIRECTION_RTL;
        todayPanel.animate().alpha(0f).translationX(dp(56.0f) * (rtl ? 1 : -1)).setDuration(200L).withLayer()
                .withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        if (!todayOpen) {
                            todayPanel.setVisibility(View.GONE);
                        }
                    }
                }).start();
        for (int i = 0; i < root.getChildCount(); i++) {
            root.getChildAt(i).animate().alpha(1f).setDuration(200L).withLayer().start();
        }
    }

    private void glassToday(View view, float radiusDp, boolean strong) {
        glassify(view, radiusDp, strong);
        todayGlass.add(view);
    }

    /** The Qibla: a compass that turns with the phone and says which way to turn, with the bearing for phones without one. */
    private void addQiblaCard() {
        double[] place = Places.here(prefs); // from where the phone is, not the prayer city
        final double bearing = Qibla.bearing(place[0], place[1]);
        long km = Math.round(Qibla.distanceKm(place[0], place[1]));
        LinearLayout card = todayCard();
        todayCardHeader(card, getString(R.string.card_qibla), Places.hereName(this, prefs));
        final Qibla.Compass compass = new Qibla.Compass(this, (float) bearing, textPrimary, textSecondary, accentOnWallpaper());
        compass.setLocation(place[0], place[1]);
        LinearLayout.LayoutParams compassParams = new LinearLayout.LayoutParams(dp(176.0f), dp(176.0f));
        compassParams.gravity = Gravity.CENTER_HORIZONTAL;
        compassParams.topMargin = dp(4.0f);
        card.addView(compass, compassParams);
        final TextView status = label("", 16, textPrimary, 600);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(10.0f), 0, 0);
        card.addView(status, new LinearLayout.LayoutParams(-1, -2));
        java.text.NumberFormat number = java.text.NumberFormat.getIntegerInstance(Locale.getDefault());
        TextView where = label(getString(R.string.qibla_bearing, number.format(Math.round(bearing)), number.format(km)), 13, textSecondary, 400);
        where.setGravity(Gravity.CENTER);
        where.setPadding(0, dp(4.0f), 0, 0);
        card.addView(where, new LinearLayout.LayoutParams(-1, -2));
        if (!compass.hasSensor()) {
            status.setText(getString(R.string.qibla_no_sensor));
            status.setTextSize(14);
            return;
        }
        status.setText(getString(R.string.qibla_hold));
        compass.setListener((heading, facing) -> status.setText(qiblaHint(bearing, heading, facing)));
    }

    /** "أنت باتجاه القبلة", or which way to turn and by how much. */
    String qiblaHint(double bearing, float heading, boolean facing) {
        if (facing) {
            return getString(R.string.qibla_facing);
        }
        double turn = ((bearing - heading) % 360 + 540) % 360 - 180; // -180..180, positive = clockwise
        String degrees = localDigits(String.valueOf(Math.round(Math.abs(turn))));
        return getString(turn > 0 ? R.string.qibla_turn_right : R.string.qibla_turn_left, degrees);
    }

    private LinearLayout todayCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18.0f), dp(16.0f), dp(18.0f), dp(16.0f));
        glassToday(card, 26, false);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(12.0f);
        todayContent.addView(card, params);
        return card;
    }

    private void todayCardHeader(LinearLayout card, String title, String end) {
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(label(title, 17, textPrimary, 600), new LinearLayout.LayoutParams(0, -2, 1f));
        if (end != null && end.length() > 0) {
            header.addView(label(end, 13, textSecondary, 400));
        }
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.bottomMargin = dp(8.0f);
        card.addView(header, params);
    }

    /** Rebuilds the Today page with fresh numbers; cheap enough to run every minute while it's open. */
    private void fillToday() {
        glassViews.removeAll(todayGlass);
        todayGlass.clear();
        todayContent.removeAllViews();
        long now = System.currentTimeMillis();
        Date date = new Date(now);
        Locale locale = Locale.getDefault();

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label(getString(R.string.today_title), 28, textPrimary, 700);
        shadowOnWallpaper(title);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        ImageView close = new ImageView(this);
        close.setImageDrawable(new Glyphs(Glyphs.CLOSE, textPrimary, dp(18.0f)));
        close.setScaleType(ImageView.ScaleType.CENTER);
        close.setContentDescription(getString(R.string.close));
        glassToday(close, 20, true);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                closeToday();
            }
        });
        if (!twoPane) {
            header.addView(close, new LinearLayout.LayoutParams(dp(40.0f), dp(40.0f)));
        }
        todayContent.addView(header, new LinearLayout.LayoutParams(-1, dp(56.0f)));

        // Date, Hijri date and weather.
        LinearLayout hero = todayCard();
        hero.addView(label(new SimpleDateFormat(android.text.format.DateFormat.getBestDateTimePattern(locale, "EEEEdMMMMy"), locale).format(date),
                22, textPrimary, 600));
        TextView hijri = label(hijriText(date), 14, accentOnWallpaper(), 500);
        hijri.setPadding(0, dp(4.0f), 0, dp(4.0f));
        hijri.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, new Glyphs(Glyphs.CALENDAR, accentOnWallpaper(), dp(14.0f)), null);
        hijri.setCompoundDrawablePadding(dp(6.0f));
        hijri.setContentDescription(hijriText(date) + getString(R.string.list_separator) + getString(R.string.hijri_open));
        hijri.setOnClickListener(v -> HijriMonth.show(this));
        LinearLayout.LayoutParams hijriLine = new LinearLayout.LayoutParams(-2, -2);
        hero.addView(hijri, hijriLine);
        String greeting = Ambience.greeting(this, Ambience.occasion(now), now);
        if (greeting != null && prefs.getBoolean(Ambience.PREF_OCCASIONS, true)) {
            TextView festive = label(greeting, 14, Color.WHITE, 700);
            festive.setPadding(dp(14.0f), dp(7.0f), dp(14.0f), dp(7.0f));
            String occasionNow = Ambience.occasion(now);
            festive.setBackground(pill(Ambience.NATIONAL.equals(occasionNow) ? 0xFF00875A : Ambience.FOUNDING.equals(occasionNow) ? 0xFF8B5A2B
                    : 0xFFB8862E, 16));
            LinearLayout.LayoutParams festiveParams = new LinearLayout.LayoutParams(-2, -2);
            festiveParams.topMargin = dp(10.0f);
            hero.addView(festive, festiveParams);
        }
        Weather.Now weather = weatherOn ? Weather.cached(prefs) : null;
        if (weather != null) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(14.0f), 0, 0);
            ImageView icon = new ImageView(this);
            icon.setImageDrawable(new Weather.Icon(Weather.iconType(weather.code, weather.day), textPrimary, dp(44.0f)));
            row.addView(icon, new LinearLayout.LayoutParams(dp(44.0f), dp(44.0f)));
            TextView temp = label(Weather.degrees(weather.temp), 38, textPrimary, 600);
            LinearLayout.LayoutParams tempParams = new LinearLayout.LayoutParams(-2, -2);
            tempParams.setMarginStart(dp(10.0f));
            row.addView(temp, tempParams);
            LinearLayout details = new LinearLayout(this);
            details.setOrientation(LinearLayout.VERTICAL);
            details.addView(label(getString(Weather.descriptionRes(weather.code)), 15, textPrimary, 500));
            details.addView(label(getString(R.string.wx_high_low, Weather.degrees(weather.max), Weather.degrees(weather.min)), 13, textSecondary, 400));
            LinearLayout.LayoutParams detailParams = new LinearLayout.LayoutParams(0, -2, 1f);
            detailParams.setMarginStart(dp(14.0f));
            row.addView(details, detailParams);
            hero.addView(row);
            Weather.Alert alert = Weather.alertsOn(prefs) ? Weather.cachedAlert(prefs, now) : null;
            if (alert != null) {
                int warm = darkWallpaper ? 0xFFFFD27A : 0xFF8F5200;
                TextView warning = label(Weather.alertText(this, alert), 14, warm, 600);
                warning.setPadding(dp(12.0f), dp(8.0f), dp(12.0f), dp(8.0f));
                warning.setBackground(pill(withAlpha(warm, 0.16f), 14));
                LinearLayout.LayoutParams warningParams = new LinearLayout.LayoutParams(-1, -2);
                warningParams.topMargin = dp(12.0f);
                hero.addView(warning, warningParams);
            }
        }
        LinearLayout place = new LinearLayout(this);
        place.setGravity(Gravity.CENTER_VERTICAL);
        place.setPadding(0, dp(12.0f), 0, 0);
        ImageView pin = new ImageView(this);
        pin.setImageDrawable(new Glyphs(Glyphs.LOCATION, textSecondary, dp(16.0f)));
        place.addView(pin, new LinearLayout.LayoutParams(dp(16.0f), dp(16.0f)));
        TextView placeName = label(Places.hereName(this, prefs), 13, textSecondary, 400);
        LinearLayout.LayoutParams placeParams = new LinearLayout.LayoutParams(-2, -2);
        placeParams.setMarginStart(dp(6.0f));
        place.addView(placeName, placeParams);
        // Location turned off in the phone: the weather, prayer times and Qibla stay where they were, so say so.
        if (Places.wantsLocation(prefs) && Places.permitted(this) && !Places.servicesOn(this)) {
            TextView off = label(getString(R.string.location_off), 13, darkWallpaper ? 0xFFFFD27A : 0xFF8F5200, 600);
            LinearLayout.LayoutParams offParams = new LinearLayout.LayoutParams(-2, -2);
            offParams.setMarginStart(dp(8.0f));
            place.addView(off, offParams);
            place.setContentDescription(placeName.getText() + getString(R.string.list_separator) + off.getText());
            place.setOnClickListener(v -> startSafely(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS)));
        }
        hero.addView(place);

        // Prayer times, the next one highlighted with its countdown.
        if (prayerOn) {
            LinearLayout card = todayCard();
            todayCardHeader(card, getString(R.string.prayer_times), getString(TodaySettings.methodName(Prayers.method(prefs))));
            long[] times = prayerTimesFor(now);
            int next = nextPrayerIndex(times, now);
            for (int i = 0; i < times.length; i++) {
                LinearLayout row = new LinearLayout(this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(12.0f), 0, dp(12.0f), 0);
                row.setMinimumHeight(dp(42.0f));
                boolean upcoming = i == next;
                boolean passed = times[i] <= now && !upcoming;
                int color = passed ? textSecondary : textPrimary;
                row.addView(label(getString(PRAYER_NAMES[i]), 15, color, upcoming ? 700 : 400));
                if (upcoming) {
                    TextView left = label(countdown(times[i] - now), 12, Color.WHITE, 600);
                    left.setPadding(dp(8.0f), dp(2.0f), dp(8.0f), dp(3.0f));
                    left.setBackground(pill(accent, 10));
                    LinearLayout.LayoutParams leftParams = new LinearLayout.LayoutParams(-2, -2);
                    leftParams.setMarginStart(dp(8.0f));
                    row.addView(left, leftParams);
                    row.setBackground(pill(withAlpha(textPrimary, 0.10f), 14));
                }
                row.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
                row.addView(label(timeText(times[i]), 15, color, upcoming ? 700 : 500));
                card.addView(row, new LinearLayout.LayoutParams(-1, -2));
            }
        }

        addHaramCard();
        addParkingCard();

        addAgendaCard(now);

        addKhatmaCard();
        addCountdownCard();

        if (prayerOn) {
            addQiblaCard();
        }

        // Upcoming occasions.
        List<HijriEvents.Occasion> occasions = HijriEvents.upcoming(now, 5);
        if (!occasions.isEmpty()) {
            LinearLayout card = todayCard();
            todayCardHeader(card, getString(R.string.occasions_title), null);
            for (HijriEvents.Occasion occasion : occasions) {
                LinearLayout row = new LinearLayout(this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(0, dp(6.0f), 0, dp(6.0f));
                LinearLayout names = new LinearLayout(this);
                names.setOrientation(LinearLayout.VERTICAL);
                names.addView(label(getString(HijriEvents.nameRes(occasion.kind)), 15, textPrimary, 500));
                names.addView(label(HijriEvents.hijriLabel(occasion.start), 12, textSecondary, 400));
                row.addView(names, new LinearLayout.LayoutParams(0, -2, 1f));
                row.addView(label(HijriEvents.whenText(this, occasion.daysLeft), 13, accentOnWallpaper(), 600));
                card.addView(row, new LinearLayout.LayoutParams(-1, -2));
            }
        }

        // All headlines, newest first (not in privacy mode).
        ArrayList<NewsItem> news = privacyMode ? new ArrayList<NewsItem>() : orderedNews();
        if (!news.isEmpty()) {
            LinearLayout card = todayCard();
            todayCardHeader(card, getString(R.string.news_title), lastRefreshText());
            int shown = 0;
            for (final NewsItem item : news) {
                if (shown++ >= 15) {
                    break;
                }
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.VERTICAL);
                row.setPadding(0, dp(8.0f), 0, dp(8.0f));
                LinearLayout meta = new LinearLayout(this);
                meta.addView(label(item.source, 12, accentOnWallpaper(), 700));
                TextView time = label(formatNewsTime(item.published), 12, textSecondary, 400);
                LinearLayout.LayoutParams timeParams = new LinearLayout.LayoutParams(-2, -2);
                timeParams.setMarginStart(dp(8.0f));
                meta.addView(time, timeParams);
                row.addView(meta);
                TextView headline = label(item.title, 15, textPrimary, 500);
                headline.setPadding(0, dp(2.0f), 0, 0);
                row.addView(headline);
                row.setBackground(new RippleDrawable(ColorStateList.valueOf(withAlpha(textPrimary, 0.16f)), null, pill(Color.WHITE, 12)));
                row.setContentDescription(getString(R.string.news_description, item.source, formatNewsTime(item.published), item.title));
                row.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        openNews(item);
                    }
                });
                row.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View view) {
                        showNewsActions(item);
                        return true;
                    }
                });
                card.addView(row);
            }
        }

        addWidgetsCard();

        LinearLayout calendar = new LinearLayout(this);
        calendar.setGravity(Gravity.CENTER);
        glassToday(calendar, 24, true);
        ImageView calendarIcon = new ImageView(this);
        calendarIcon.setImageDrawable(new Glyphs(Glyphs.CALENDAR, textPrimary, dp(20.0f)));
        calendar.addView(calendarIcon, new LinearLayout.LayoutParams(dp(20.0f), dp(20.0f)));
        TextView calendarText = label(getString(R.string.open_calendar), 15, textPrimary, 500);
        LinearLayout.LayoutParams calendarTextParams = new LinearLayout.LayoutParams(-2, -2);
        calendarTextParams.setMarginStart(dp(8.0f));
        calendar.addView(calendarText, calendarTextParams);
        calendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openCalendar();
            }
        });
        LinearLayout.LayoutParams calendarParams = new LinearLayout.LayoutParams(-1, dp(52.0f));
        calendarParams.topMargin = dp(12.0f);
        todayContent.addView(calendar, calendarParams);
    }


    // ---------------------------------------------------------------- view helpers

    Typeface font(int weight) {
        return Fonts.of(weight);
    }

    TextView label(String value, int sizeSp, int color, int weight) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sizeSp);
        view.setTextColor(color);
        view.setTypeface(font(weight));
        return view;
    }

    /** Text drawn straight on the wallpaper gets a soft shadow on dark wallpapers so it never disappears. */
    void shadowOnWallpaper(TextView view) {
        if (darkWallpaper) {
            view.setShadowLayer(dp(4.0f), 0, dp(1.0f), 0x59000000);
        }
    }

    GradientDrawable pill(int color, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }

    static int withAlpha(int color, float alpha) {
        return Color.argb((int) (Color.alpha(color) * alpha), Color.red(color), Color.green(color), Color.blue(color));
    }

    /** The icon to show: the app's own, or its one-colour version when themed icons are on (Android 13+). */
    Drawable shownIcon(AppEntry entry) {
        Drawable base = themedIcon(entry);
        String shape = iconShape;
        if (IconShapes.SYSTEM.equals(shape) || entry.packed) {
            return base;
        }
        if (entry.shaped == null || entry.shapedFrom != base || !shape.equals(entry.shapedAs)) {
            entry.shaped = IconShapes.apply(base, shape);
            entry.shapedFrom = base;
            entry.shapedAs = shape;
        }
        return entry.shaped;
    }

    /** The chosen icon shape (Settings → look). */
    String iconShape = IconShapes.SYSTEM;

    /** Normal, one colour, tinted or clear (Settings → look → icon colours). */
    String iconStyle = IconTint.NORMAL;

    private Drawable themedIcon(AppEntry entry) {
        if (!themedIcons || entry.packed) {
            return entry.icon;
        }
        if (entry.themed == null) {
            entry.themed = IconTint.apply(getResources(), entry.icon, iconStyle, accent, darkWallpaper);
        }
        return entry.themed;
    }

    private static int mix(int color, int toward, float amount) {
        float keep = 1f - amount;
        return Color.rgb((int) (Color.red(color) * keep + Color.red(toward) * amount),
                (int) (Color.green(color) * keep + Color.green(toward) * amount),
                (int) (Color.blue(color) * keep + Color.blue(toward) * amount));
    }

    /** An icon with One UI's notification dot in its top corner when the app has something new. */
    private FrameLayout iconWithDot(AppEntry entry, int sizeDp) {
        FrameLayout frame = new FrameLayout(this);
        ImageView icon = new ImageView(this);
        icon.setImageDrawable(shownIcon(entry));
        icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        frame.addView(icon, new FrameLayout.LayoutParams(dp(sizeDp), dp(sizeDp), Gravity.CENTER));
        if (entry.state != STATE_READY) {
            // Paused, archived or work-off: grey and faded, with a small sign, as the phone's own launcher shows them.
            android.graphics.ColorMatrix grey = new android.graphics.ColorMatrix();
            grey.setSaturation(0f);
            icon.setColorFilter(new android.graphics.ColorMatrixColorFilter(grey));
            icon.setImageAlpha(entry.state == STATE_ARCHIVED ? 200 : 150);
            ImageView sign = new ImageView(this);
            sign.setImageDrawable(new Glyphs(entry.state == STATE_ARCHIVED ? Glyphs.CHEVRON_UP : Glyphs.PAUSE, Color.WHITE, dp(10.0f)));
            if (entry.state == STATE_ARCHIVED) {
                sign.setRotation(180f); // a down arrow: download it again
            }
            sign.setScaleType(ImageView.ScaleType.CENTER);
            sign.setBackground(pill(0xE6303036, 9));
            frame.addView(sign, new FrameLayout.LayoutParams(dp(18.0f), dp(18.0f), Gravity.BOTTOM | Gravity.END));
        }
        if (dotsShown() && DotsService.has(entry.pkg, entry.user)) {
            View dot = new View(this);
            GradientDrawable circle = new GradientDrawable();
            circle.setShape(GradientDrawable.OVAL);
            circle.setColor(0xFFFF7A2F);
            circle.setStroke(Math.max(1, dp(1.5f)), darkWallpaper ? 0xFF1A1630 : Color.WHITE);
            dot.setBackground(circle);
            frame.addView(dot, new FrameLayout.LayoutParams(dp(14.0f), dp(14.0f), Gravity.TOP | Gravity.END));
            frame.setTag(Boolean.TRUE);
        }
        return frame;
    }

    int dp(float value) {
        return (int) ((value * getResources().getDisplayMetrics().density) + 0.5f);
    }

    /** Magnifier glyph drawn in code so it matches the text colour and weight. */
    private static final class SearchIcon extends Drawable {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int size;

        SearchIcon(int color, int sizePx) {
            size = sizePx;
            paint.setColor(color);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeWidth(sizePx * 0.11f);
        }

        @Override
        public void draw(Canvas canvas) {
            Rect b = getBounds();
            float s = Math.min(b.width(), b.height());
            float r = s * 0.32f;
            float cx = b.left + s * 0.42f;
            float cy = b.top + s * 0.42f;
            canvas.drawCircle(cx, cy, r, paint);
            float d = r * 0.7071f;
            canvas.drawLine(cx + d, cy + d, b.left + s * 0.88f, b.top + s * 0.88f, paint);
        }

        @Override
        public int getIntrinsicWidth() {
            return size;
        }

        @Override
        public int getIntrinsicHeight() {
            return size;
        }

        @Override
        public void setAlpha(int alpha) {
            paint.setAlpha(alpha);
        }

        @Override
        public void setColorFilter(ColorFilter colorFilter) {
            paint.setColorFilter(colorFilter);
        }

        @Override
        public int getOpacity() {
            return PixelFormat.TRANSLUCENT;
        }
    }

    // ---------------------------------------------------------------- model

    private static final class NewsItem {
        final String link;
        final long published;
        final String source;
        final String title;

        NewsItem(String source, String title, String link, long published) {
            this.source = source;
            this.title = title;
            this.link = link;
            this.published = published;
        }
    }

    static final int STATE_READY = 0;
    static final int STATE_PAUSED = 1;
    static final int STATE_ARCHIVED = 2;
    static final int STATE_PROFILE_OFF = 3;

    /** Android 15's archived apps (the icon kept, the app removed until it's opened again). */
    static boolean archived(ApplicationInfo info) {
        if (info == null || Build.VERSION.SDK_INT < 35) {
            return false;
        }
        try {
            return ApplicationInfo.class.getField("isArchived").getBoolean(info);
        } catch (Exception e) {
            return false;
        }
    }

    static final class AppEntry {
        final String label;
        final String searchLabel;
        final String pkg;
        final String key;
        final ComponentName component;
        final UserHandle user;
        final Drawable icon;
        final boolean system;
        Drawable themed;
        /** The icon cut to the chosen shape, and what it was cut from. */
        Drawable shaped;
        Drawable shapedFrom;
        String shapedAs;
        /** The icon comes from the chosen icon pack (themed icons leave it alone). */
        boolean packed;
        int category = -1;
        long installed;
        /** The drawer category this app falls in (null: none), worked out once. */
        String group;
        boolean grouped;
        /** On a TV: the app's wide banner, and whether this is its TV screen (opened as a TV app). */
        Drawable banner;
        boolean leanback;
        /** Paused (Digital Wellbeing, focus mode, a parental or "freezer" app), archived, or its profile turned off. */
        int state = STATE_READY;

        AppEntry(String label, ComponentName component, UserHandle user, String key, Drawable icon, boolean system) {
            this.label = label;
            this.searchLabel = ArabicText.normalize(label);
            this.component = component;
            this.pkg = component.getPackageName();
            this.user = user;
            this.key = key;
            this.icon = icon;
            this.system = system;
        }
    }

    private final class AppAdapter extends BaseAdapter {
        private final List<Tile> pageTiles;

        AppAdapter() {
            this(HomeActivity.this.pageTiles);
        }

        /** The grid's own page, or another page (the one that slides in beside it). */
        AppAdapter(List<Tile> source) {
            pageTiles = source;
        }

        @Override
        public int getCount() {
            return pageTiles.size();
        }

        @Override
        public Object getItem(int position) {
            return pageTiles.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            final LinearLayout cell = convertView instanceof LinearLayout ? (LinearLayout) convertView : new LinearLayout(HomeActivity.this);
            cell.removeAllViews();
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER);
            cell.setPadding(dp(2.0f), 0, dp(2.0f), 0);
            cell.setLayoutParams(new AbsListView.LayoutParams(-1, cellHeight > 0 ? cellHeight : dp(96.0f)));
            cell.setOnDragListener(null);
            cell.setBackground(null);
            Tile tile = pageTiles.get(position);
            if (tile.folder != null) {
                folderCell(cell, tile);
                return cell;
            }
            final AppEntry entry = tile.app;
            final FrameLayout icon = iconWithDot(entry, gridIconDp());
            cell.addView(icon, new LinearLayout.LayoutParams(gridFrame(), gridFrame()));
            TextView name = label(entry.label, gridDense ? 11 : 12, textPrimary, 400);
            if (drawer != null && search != null && search.length() > 0) {
                name.setText(highlighted(entry.label));
                if (entry == topHit()) {
                    // Enter opens this one: it says so with a soft glow behind it.
                    cell.setBackground(pill(withAlpha(accent, darkWallpaper ? 0.30f : 0.20f), 22));
                }
            }
            if (hideLabels) {
                name.setVisibility(View.INVISIBLE); // keeps the grid's rhythm; the name is still read aloud
            }
            name.setGravity(Gravity.CENTER);
            name.setSingleLine(true);
            // Laid out at the cell's own width, so a centred name never depends on scrolling into view.
            name.setHorizontallyScrolling(false);
            name.setEllipsize(TextUtils.TruncateAt.END);
            name.setPadding(0, dp(6.0f), 0, 0);
            shadowOnWallpaper(name);
            cell.addView(name, new LinearLayout.LayoutParams(-1, -2));
            String spoken = icon.getTag() == Boolean.TRUE ? getString(R.string.has_notifications, entry.label) : entry.label;
            cell.setContentDescription(entry.state == STATE_READY ? spoken : spoken + getString(R.string.list_separator) + stateName(entry.state));
            cell.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    animateLaunch(entry, view);
                }
            });
            cell.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    if (reorderMode) {
                        return view.startDragAndDrop(ClipData.newPlainText("app", entry.key), new View.DragShadowBuilder(view), entry, 0);
                    }
                    if (view.getParent() != null) {
                        view.getParent().requestDisallowInterceptTouchEvent(true); // no page swipe while it is held
                    }
                    gridHeld = entry;
                    showAppPopup(entry, icon, false);
                    return true;
                }
            });
            // Hold, then slide: the menu closes and the icon follows the finger; drop it on the dock.
            cell.setOnTouchListener((view, event) -> {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        gridTouchX = event.getRawX();
                        gridTouchY = event.getRawY();
                        gridHeld = null;
                        break;
                    case MotionEvent.ACTION_MOVE:
                        if (gridHeld == entry && Math.hypot(event.getRawX() - gridTouchX, event.getRawY() - gridTouchY) > dp(12.0f)) {
                            gridHeld = null;
                            startGridDrag(entry, cell, icon);
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        gridHeld = null;
                        break;
                    default:
                        break;
                }
                return false;
            });
            cell.setOnDragListener(new View.OnDragListener() {
                @Override
                public boolean onDrag(View view, DragEvent event) {
                    switch (event.getAction()) {
                        case DragEvent.ACTION_DRAG_STARTED:
                            return reorderMode && (event.getLocalState() instanceof AppEntry);
                        case DragEvent.ACTION_DROP:
                            cell.setBackground(null);
                            moveAppBefore((AppEntry) event.getLocalState(), entry);
                            return true;
                        case DragEvent.ACTION_DRAG_ENDED:
                        case DragEvent.ACTION_DRAG_EXITED:
                            cell.setBackground(null);
                            return true;
                        case DragEvent.ACTION_DRAG_ENTERED:
                            cell.setBackground(pill(withAlpha(accent, 0.35f), 20));
                            return true;
                        default:
                            return true;
                    }
                }
            });
            return cell;
        }
    }
}
