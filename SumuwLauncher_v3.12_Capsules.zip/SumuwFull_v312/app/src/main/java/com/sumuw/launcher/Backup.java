package com.sumuw.launcher;

import android.content.SharedPreferences;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Saves every Sara Home setting to one JSON file and reads it back, with the files that go with them:
 * the icons picked for single apps and the photo wallpaper. Caches (news, weather, matches, crests) are
 * left out; they come back by themselves.
 */
final class Backup {
    static final int FORMAT = 2;
    private static final long MOST_PHOTO = 6L * 1024 * 1024;

    private Backup() {
    }

    private static boolean skipped(String key) {
        return key.startsWith("news_") || key.equals("page") || key.startsWith("pending_") || key.startsWith("wx_")
                || key.equals("matches_json") || key.equals("matches_time") || key.endsWith("_alert_next")
                || key.equals("match_alert_id") || key.equals("system_wallpaper_stamp")
                || key.equals("match_told") || key.equals("match_watch_next") || key.startsWith("table_")
                // the moment's state: what was copied, where the car is, whether Sara silenced the phone, the children's lock
                || key.startsWith("clip_") || (key.startsWith("parking_") && !key.equals(AudioRoutes.PREF_PARKING)) || key.equals("haram_silenced") || key.equals(Kids.PREF_ON)
                || key.equals("usage_places") || key.equals("audio_devices_seen") || Permissions.isState(key);
    }

    static String export(SharedPreferences prefs) throws JSONException {
        JSONObject values = new JSONObject();
        for (Map.Entry<String, ?> entry : prefs.getAll().entrySet()) {
            if (skipped(entry.getKey())) {
                continue;
            }
            Object value = entry.getValue();
            JSONObject typed = new JSONObject();
            if (value instanceof Boolean) {
                typed.put("t", "b").put("v", value);
            } else if (value instanceof Integer) {
                typed.put("t", "i").put("v", value);
            } else if (value instanceof Long) {
                typed.put("t", "l").put("v", value);
            } else if (value instanceof Float) {
                typed.put("t", "f").put("v", ((Float) value).doubleValue());
            } else if (value instanceof String) {
                typed.put("t", "s").put("v", value);
            } else if (value instanceof Set) {
                JSONArray array = new JSONArray();
                for (Object item : (Set<?>) value) {
                    array.put(String.valueOf(item));
                }
                typed.put("t", "set").put("v", array);
            } else {
                continue;
            }
            values.put(entry.getKey(), typed);
        }
        return new JSONObject().put("app", "SumuwLauncher").put("format", FORMAT).put("values", values).toString(2);
    }

    /** Settings plus the files they need: custom icons and the photo wallpaper (base64). */
    static String exportAll(android.content.Context context, SharedPreferences prefs) throws Exception {
        JSONObject root = new JSONObject(export(prefs));
        JSONObject files = new JSONObject();
        java.io.File icons = new java.io.File(context.getFilesDir(), "icons");
        java.io.File[] list = icons.listFiles();
        if (list != null) {
            for (java.io.File file : list) {
                if (file.isFile() && file.getName().endsWith(".png") && file.length() < 512 * 1024) {
                    files.put("icons/" + file.getName(), android.util.Base64.encodeToString(read(file), android.util.Base64.NO_WRAP));
                }
            }
        }
        java.io.File photo = new java.io.File(context.getFilesDir(), Wallpapers.PHOTO_FILE);
        if (photo.isFile() && photo.length() < MOST_PHOTO) {
            files.put(Wallpapers.PHOTO_FILE, android.util.Base64.encodeToString(read(photo), android.util.Base64.NO_WRAP));
        }
        return root.put("files", files).toString();
    }

    /** Settings first, then the files that came with them. */
    static void restoreAll(android.content.Context context, SharedPreferences prefs, String json) throws Exception {
        restore(prefs, json);
        JSONObject files = new JSONObject(json).optJSONObject("files");
        if (files == null) {
            return;
        }
        Iterator<String> names = files.keys();
        while (names.hasNext()) {
            String name = names.next();
            boolean icon = name.startsWith("icons/") && name.endsWith(".png") && !name.contains("..") && name.indexOf('/', 6) < 0;
            if (!icon && !Wallpapers.PHOTO_FILE.equals(name)) {
                continue; // only the files a backup makes, never anything else
            }
            java.io.File file = new java.io.File(context.getFilesDir(), name);
            java.io.File folder = file.getParentFile();
            if (folder != null && !folder.exists() && !folder.mkdirs()) {
                continue;
            }
            try (java.io.FileOutputStream out = new java.io.FileOutputStream(file)) {
                out.write(android.util.Base64.decode(files.getString(name), android.util.Base64.DEFAULT));
            }
        }
    }

    private static byte[] read(java.io.File file) throws java.io.IOException {
        try (java.io.InputStream in = new java.io.FileInputStream(file)) {
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            byte[] chunk = new byte[16384];
            int count;
            while ((count = in.read(chunk)) > 0) {
                out.write(chunk, 0, count);
            }
            return out.toByteArray();
        }
    }

    /** Replaces the current settings with the ones in the file. Throws if the file isn't a Duo Home backup. */
    static void restore(SharedPreferences prefs, String json) throws JSONException {
        JSONObject root = new JSONObject(json);
        String app = root.optString("app");
        if (!"SumuwLauncher".equals(app) && !"SaraHome".equals(app) && !"DuoHome".equals(app)) { // older backups were made as Duo Home
            throw new JSONException("Not a Sara Home backup");
        }
        JSONObject values = root.getJSONObject("values");
        SharedPreferences.Editor editor = prefs.edit();
        for (String key : prefs.getAll().keySet()) {
            if (!skipped(key)) {
                editor.remove(key);
            }
        }
        Iterator<String> keys = values.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            if (skipped(key)) {
                continue;
            }
            JSONObject typed = values.getJSONObject(key);
            String type = typed.getString("t");
            switch (type) {
                case "b":
                    editor.putBoolean(key, typed.getBoolean("v"));
                    break;
                case "i":
                    editor.putInt(key, typed.getInt("v"));
                    break;
                case "l":
                    editor.putLong(key, typed.getLong("v"));
                    break;
                case "f":
                    editor.putFloat(key, (float) typed.getDouble("v"));
                    break;
                case "s":
                    editor.putString(key, typed.getString("v"));
                    break;
                case "set": {
                    JSONArray array = typed.getJSONArray("v");
                    HashSet<String> set = new HashSet<>();
                    for (int i = 0; i < array.length(); i++) {
                        set.add(array.getString(i));
                    }
                    editor.putStringSet(key, set);
                    break;
                }
                default:
                    break;
            }
        }
        editor.putInt("config_stamp", prefs.getInt("config_stamp", 0) + 1);
        editor.commit();
    }
}
