package com.sumuw.launcher;

import android.content.Context;
import android.graphics.Outline;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;

/**
 * Holds a card stack at a bigger or smaller size without changing what it shows: the stack is laid out at
 * its usual size and drawn scaled, so every line, number and button stays, only larger or smaller. Touches
 * reach it scaled the same way.
 *
 * So that a bigger card never squeezes its contents into a narrow column (where names would be cut), it
 * grows only as far as leaves the card at least {@link #MIN_BASE_DP} wide inside.
 */
final class ScaleFrame extends FrameLayout {
    static final float MIN_BASE_DP = 250f;
    private final float wanted;
    private float applied = 1f;

    ScaleFrame(Context context, float scale, final float radiusPx) {
        super(context);
        wanted = scale;
        setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radiusPx);
            }
        });
        setClipToOutline(true);
    }

    /** The scale in use (it may be less than asked on a narrow screen). */
    float applied() {
        return applied;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int height = MeasureSpec.getSize(heightMeasureSpec);
        float density = getResources().getDisplayMetrics().density;
        float scale = wanted;
        if (scale > 1f && width > 0) {
            scale = Math.max(1f, Math.min(scale, width / (MIN_BASE_DP * density)));
        }
        applied = scale;
        int innerWidth = Math.round(width / scale);
        int innerHeight = Math.round(height / scale);
        for (int i = 0; i < getChildCount(); i++) {
            getChildAt(i).measure(MeasureSpec.makeMeasureSpec(innerWidth, MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(innerHeight, MeasureSpec.EXACTLY));
        }
        setMeasuredDimension(width, height);
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            child.layout(0, 0, child.getMeasuredWidth(), child.getMeasuredHeight());
            child.setPivotX(0f);
            child.setPivotY(0f);
            child.setScaleX(applied);
            child.setScaleY(applied);
        }
    }
}
