package com.sumuw.launcher;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.provider.Settings;
import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * More from the search bar than apps: a sum worked out as you type ("٢٥×٤" → ١٠٠), the phone's
 * settings pages by name ("واي فاي", "البطارية"), and contacts by name or number once allowed.
 */
final class SmartSearch {
    private SmartSearch() {
    }

    // ---------------------------------------------------------------- calculator

    /** Arabic-Indic digits, the Arabic decimal mark and ×, ÷ read as plain arithmetic. */
    static String plain(String text) {
        StringBuilder out = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c >= '٠' && c <= '٩') {
                out.append((char) ('0' + (c - '٠')));
            } else if (c >= '۰' && c <= '۹') {
                out.append((char) ('0' + (c - '۰')));
            } else if (c == '٫' || c == ',') {
                out.append('.');
            } else if (c == '×' || c == 'x' || c == 'X') {
                out.append('*');
            } else if (c == '÷') {
                out.append('/');
            } else if (c == '−' || c == '–') {
                out.append('-');
            } else if (c == '٪') {
                out.append('%');
            } else if (!Character.isWhitespace(c) && c != '٬') {
                out.append(c);
            }
        }
        return out.toString();
    }

    /** The result, or null when the text isn't a sum (a lone number isn't one either). */
    static Double calculate(String text) {
        String expression = plain(text);
        if (expression.length() < 3 || !expression.matches("[0-9.+\\-*/^%()]+") || !expression.matches(".*[0-9].*[+\\-*/^%].*[0-9(].*|.*[0-9]%.*")) {
            return null;
        }
        try {
            Parser parser = new Parser(expression);
            double value = parser.sum();
            if (parser.at != expression.length() || Double.isNaN(value) || Double.isInfinite(value)) {
                return null;
            }
            return value;
        } catch (RuntimeException error) {
            return null;
        }
    }

    /** Up to ten significant digits, without a trailing ".0", in the phone's digits. */
    static String format(double value) {
        BigDecimal rounded = new BigDecimal(value).round(new MathContext(10)).stripTrailingZeros();
        String text = rounded.abs().compareTo(new BigDecimal("1e12")) >= 0 ? rounded.toString() : rounded.toPlainString();
        if (!"ar".equals(Locale.getDefault().getLanguage())) {
            return text;
        }
        StringBuilder out = new StringBuilder();
        for (char c : text.toCharArray()) {
            out.append(c >= '0' && c <= '9' ? (char) ('٠' + (c - '0')) : c == '.' ? '٫' : c);
        }
        return out.toString();
    }

    // ---------------------------------------------------------------- zakat and units

    /** A worked answer: what was asked, the result, and the plain number to copy. */
    static final class Answer {
        final String question;
        final String result;
        final String copy;

        Answer(String question, String result, String copy) {
            this.question = question;
            this.result = result;
            this.copy = copy;
        }
    }

    /** "زكاة 50000" or "زكاه ٥٠٠٠٠": a quarter of a tenth (2.5%) of money held a full year above the nisab. */
    static Answer zakat(String text) {
        String clean = plain(text.replace(",", "").replace("٬", "")).toLowerCase(Locale.ROOT).replace("ه", "ة");
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("^(?:زكاة|زكات|zakat)([0-9.]+)$").matcher(clean);
        java.util.regex.Matcher reverse = java.util.regex.Pattern.compile("^([0-9.]+)(?:زكاة|zakat)$").matcher(clean);
        String number = m.matches() ? m.group(1) : reverse.matches() ? reverse.group(1) : null;
        if (number == null) {
            return null;
        }
        try {
            double amount = Double.parseDouble(number);
            if (amount <= 0) {
                return null;
            }
            double due = amount * 0.025;
            return new Answer(grouped(amount), format(Math.round(due * 100) / 100.0), HomeActivity.plainNumber(Math.round(due * 100) / 100.0));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /** A unit, its kind, how many base units it holds, and how it is written back. */
    private static final class Unit {
        final String kind;
        final double factor;
        final boolean metric;
        final int name;

        Unit(String kind, double factor, boolean metric, int name) {
            this.kind = kind;
            this.factor = factor;
            this.metric = metric;
            this.name = name;
        }
    }

    private static final java.util.LinkedHashMap<String, Unit> UNITS = new java.util.LinkedHashMap<>();

    static {
        // Length in metres.
        unit(new Unit("length", 1000, true, R.string.unit_km), "كم", "كيلومتر", "km");
        unit(new Unit("length", 1, true, R.string.unit_m), "م", "متر", "m");
        unit(new Unit("length", 0.01, true, R.string.unit_cm), "سم", "سنتيمتر", "cm");
        unit(new Unit("length", 1609.344, false, R.string.unit_mi), "ميل", "اميال", "أميال", "mi", "mile", "miles");
        unit(new Unit("length", 0.3048, false, R.string.unit_ft), "قدم", "اقدام", "أقدام", "ft", "feet", "foot");
        unit(new Unit("length", 0.0254, false, R.string.unit_in), "انش", "إنش", "بوصة", "بوصه", "in", "inch", "inches");
        unit(new Unit("length", 0.9144, false, R.string.unit_yd), "ياردة", "يارده", "yd", "yard", "yards");
        // Weight in kilograms.
        unit(new Unit("weight", 1, true, R.string.unit_kg), "كجم", "كغ", "كيلوغرام", "كيلوجرام", "kg");
        unit(new Unit("weight", 0.001, true, R.string.unit_g), "غرام", "جرام", "جم", "g");
        unit(new Unit("weight", 0.45359237, false, R.string.unit_lb), "رطل", "باوند", "lb", "lbs", "pound", "pounds");
        unit(new Unit("weight", 0.028349523, false, R.string.unit_oz), "أوقية", "اوقية", "اونصة", "أونصة", "oz", "ounce");
        // Volume in litres.
        unit(new Unit("volume", 1, true, R.string.unit_l), "لتر", "l", "liter", "litre");
        unit(new Unit("volume", 3.785411784, false, R.string.unit_gal), "جالون", "غالون", "gal", "gallon");
        // Speed in km/h.
        unit(new Unit("speed", 1, true, R.string.unit_kmh), "كم/س", "كمس", "km/h", "kmh", "kph");
        unit(new Unit("speed", 1.609344, false, R.string.unit_mph), "ميل/س", "mph");
    }

    private static void unit(Unit unit, String... names) {
        for (String name : names) {
            UNITS.put(name.toLowerCase(Locale.ROOT), unit);
        }
    }

    /** "5 قدم" → "١٫٥٢ م"; "100 ف" → "٣٧٫٨ °م"; metric to imperial and back. */
    static Answer convert(android.content.Context context, String text) {
        String clean = text.trim().toLowerCase(Locale.ROOT);
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("^([0-9٠-٩.,٫]+)\\s*(.+)$").matcher(clean);
        if (!m.matches()) {
            return null;
        }
        double value;
        try {
            value = Double.parseDouble(plain(m.group(1).replace(",", "").replace("٬", "")));
        } catch (NumberFormatException e) {
            return null;
        }
        String name = m.group(2).trim().replace("°", "").replace(" ", "");
        // Temperature has an offset, so it isn't a factor.
        if (name.equals("ف") || name.equals("فهرنهايت") || name.equals("f")) {
            double celsius = (value - 32) * 5 / 9;
            return new Answer(format(value) + " °ف", format(Math.round(celsius * 10) / 10.0) + " °م", HomeActivity.plainNumber(Math.round(celsius * 10) / 10.0));
        }
        if (name.equals("مئوية") || name.equals("سيليزي") || name.equals("c") || name.equals("درجةمئوية")) {
            double fahrenheit = value * 9 / 5 + 32;
            return new Answer(format(value) + " °م", format(Math.round(fahrenheit * 10) / 10.0) + " °ف", HomeActivity.plainNumber(Math.round(fahrenheit * 10) / 10.0));
        }
        Unit from = UNITS.get(name);
        if (from == null) {
            return null;
        }
        // To the other system's most fitting unit.
        Unit to = null;
        double best = Double.MAX_VALUE;
        double base = value * from.factor;
        for (Unit candidate : UNITS.values()) {
            if (!candidate.kind.equals(from.kind) || candidate.metric == from.metric) {
                continue;
            }
            double amount = base / candidate.factor;
            double distance = Math.abs(Math.log10(Math.max(1e-9, amount)) - 1); // closest to tens
            if (amount >= 0.1 && distance < best) {
                best = distance;
                to = candidate;
            }
        }
        if (to == null) {
            return null;
        }
        double result = base / to.factor;
        double rounded = result >= 100 ? Math.round(result) : Math.round(result * 100) / 100.0;
        return new Answer(format(value) + " " + context.getString(from.name), format(rounded) + " " + context.getString(to.name),
                HomeActivity.plainNumber(rounded));
    }

    /** 50000 → "٥٠٬٠٠٠". */
    static String grouped(double value) {
        java.text.NumberFormat number = java.text.NumberFormat.getNumberInstance(Locale.getDefault());
        number.setMaximumFractionDigits(2);
        return number.format(value);
    }

    /** sum := term (('+'|'-') term)*; term := power (('*'|'/') power)*; power := unary ('^' power)?; unary := '-' unary | atom '%'? */
    private static final class Parser {
        final String text;
        int at;

        Parser(String text) {
            this.text = text;
        }

        double sum() {
            double value = term();
            while (at < text.length()) {
                char c = text.charAt(at);
                if (c == '+') {
                    at++;
                    value += term();
                } else if (c == '-') {
                    at++;
                    value -= term();
                } else {
                    break;
                }
            }
            return value;
        }

        double term() {
            double value = power();
            while (at < text.length()) {
                char c = text.charAt(at);
                if (c == '*') {
                    at++;
                    value *= power();
                } else if (c == '/') {
                    at++;
                    double divisor = power();
                    if (divisor == 0) {
                        throw new ArithmeticException("division by zero");
                    }
                    value /= divisor;
                } else {
                    break;
                }
            }
            return value;
        }

        double power() {
            double base = unary();
            if (at < text.length() && text.charAt(at) == '^') {
                at++;
                return Math.pow(base, power());
            }
            return base;
        }

        double unary() {
            if (at < text.length() && text.charAt(at) == '-') {
                at++;
                return -unary();
            }
            if (at < text.length() && text.charAt(at) == '+') {
                at++;
                return unary();
            }
            double value = atom();
            if (at < text.length() && text.charAt(at) == '%') {
                at++;
                value /= 100.0;
            }
            return value;
        }

        double atom() {
            if (at < text.length() && text.charAt(at) == '(') {
                at++;
                double value = sum();
                if (at >= text.length() || text.charAt(at) != ')') {
                    throw new IllegalArgumentException("missing )");
                }
                at++;
                return value;
            }
            int start = at;
            while (at < text.length() && (Character.isDigit(text.charAt(at)) || text.charAt(at) == '.')) {
                at++;
            }
            if (start == at) {
                throw new IllegalArgumentException("number expected");
            }
            return Double.parseDouble(text.substring(start, at));
        }
    }

    // ---------------------------------------------------------------- settings pages

    static final class Page {
        final int name;
        final String action;
        final int glyph;

        Page(int name, String action, int glyph) {
            this.name = name;
            this.action = action;
            this.glyph = glyph;
        }

        Intent intent() {
            return new Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
    }

    /** {words to find it by (Arabic and English)}, the page. */
    private static final Object[][] PAGES = {
            {"واي فاي وايفاي wifi wi-fi انترنت شبكه", new Page(R.string.set_wifi, Settings.ACTION_WIFI_SETTINGS, Glyphs.WIFI)},
            {"بلوتوث bluetooth سماعه", new Page(R.string.set_bluetooth, Settings.ACTION_BLUETOOTH_SETTINGS, Glyphs.BLUETOOTH)},
            {"بطاريه battery شحن طاقه", new Page(R.string.set_battery, Intent.ACTION_POWER_USAGE_SUMMARY, Glyphs.SAVER)},
            {"شاشه عرض سطوع display brightness خط", new Page(R.string.set_display, Settings.ACTION_DISPLAY_SETTINGS, Glyphs.SUN)},
            {"صوت اصوات نغمه رنين sound ringtone اهتزاز", new Page(R.string.set_sound, Settings.ACTION_SOUND_SETTINGS, Glyphs.SPEAKER_LOUD)},
            {"اشعارات تنبيهات notifications", new Page(R.string.set_notifications, "android.settings.NOTIFICATION_SETTINGS", Glyphs.BELL)},
            {"عدم الازعاج ازعاج dnd do not disturb", new Page(R.string.tile_dnd, "android.settings.ZEN_MODE_SETTINGS", Glyphs.MOON)},
            {"تطبيقات apps applications", new Page(R.string.set_apps, Settings.ACTION_APPLICATION_SETTINGS, Glyphs.ARRANGE)},
            {"موقع location gps نظام تحديد", new Page(R.string.tile_location, Settings.ACTION_LOCATION_SOURCE_SETTINGS, Glyphs.LOCATION)},
            {"تخزين ذاكره مساحه storage", new Page(R.string.set_storage, Settings.ACTION_INTERNAL_STORAGE_SETTINGS, Glyphs.FOLDER)},
            {"امان قفل بصمه وجه security fingerprint password كلمه مرور", new Page(R.string.set_security, Settings.ACTION_SECURITY_SETTINGS, Glyphs.LOCK)},
            {"خصوصيه privacy اذونات permissions", new Page(R.string.set_privacy, Settings.ACTION_PRIVACY_SETTINGS, Glyphs.EYE_OFF)},
            {"لغه language لوحه مفاتيح keyboard", new Page(R.string.set_language, Settings.ACTION_LOCALE_SETTINGS, Glyphs.SETTINGS)},
            {"تاريخ وقت ساعه date time", new Page(R.string.set_date, Settings.ACTION_DATE_SETTINGS, Glyphs.CALENDAR)},
            {"نقطه اتصال hotspot مشاركه الانترنت tethering", new Page(R.string.set_hotspot, Settings.ACTION_WIRELESS_SETTINGS, Glyphs.HOTSPOT)},
            {"وضع الطيران طيران airplane", new Page(R.string.cc_airplane, Settings.ACTION_AIRPLANE_MODE_SETTINGS, Glyphs.AIRPLANE)},
            {"بيانات الجوال data mobile شريحه sim", new Page(R.string.set_data, Settings.ACTION_DATA_ROAMING_SETTINGS, Glyphs.DATA)},
            {"nfc دفع payment", new Page(R.string.set_nfc, Settings.ACTION_NFC_SETTINGS, Glyphs.NFC)},
            {"حسابات accounts google قوقل", new Page(R.string.set_accounts, Settings.ACTION_SYNC_SETTINGS, Glyphs.SHARE)},
            {"تحديث النظام update software", new Page(R.string.set_update, "android.settings.SYSTEM_UPDATE_SETTINGS", Glyphs.SPARK)},
            {"حول الهاتف about phone معلومات", new Page(R.string.set_about, Settings.ACTION_DEVICE_INFO_SETTINGS, Glyphs.INFO)},
            {"اعدادات settings ضبط", new Page(R.string.tile_settings, Settings.ACTION_SETTINGS, Glyphs.SETTINGS)},
    };

    /** Pages whose words start with what was typed (Arabic letters folded the usual way). */
    static List<Page> pages(String query, int limit) {
        ArrayList<Page> found = new ArrayList<>();
        String typed = ArabicText.normalize(query).trim();
        if (typed.length() < 2) {
            return found;
        }
        for (Object[] page : PAGES) {
            String words = ArabicText.normalize((String) page[0]);
            boolean match = false;
            for (String word : words.split(" ")) {
                if (word.startsWith(typed) || (typed.length() >= 4 && words.contains(typed))) {
                    match = true;
                    break;
                }
            }
            if (match) {
                found.add((Page) page[1]);
                if (found.size() >= limit) {
                    break;
                }
            }
        }
        return found;
    }

    // ---------------------------------------------------------------- contacts

    static final class Contact {
        final String name;
        final Uri uri;

        Contact(String name, Uri uri) {
            this.name = name;
            this.uri = uri;
        }
    }

    static boolean contactsAllowed(Context context) {
        return context.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED;
    }

    /** Contacts whose name (or number) matches, best first. */
    static List<Contact> contacts(Context context, String query, int limit) {
        ArrayList<Contact> found = new ArrayList<>();
        if (!contactsAllowed(context) || query.trim().length() < 2) {
            return found;
        }
        Uri filter = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_FILTER_URI, Uri.encode(query.trim()));
        String[] columns = {ContactsContract.Contacts._ID, ContactsContract.Contacts.LOOKUP_KEY, ContactsContract.Contacts.DISPLAY_NAME_PRIMARY};
        try (Cursor cursor = context.getContentResolver().query(filter, columns, null, null, null)) {
            while (cursor != null && cursor.moveToNext() && found.size() < limit) {
                long id = cursor.getLong(0);
                String lookup = cursor.getString(1);
                String name = cursor.getString(2);
                if (name != null) {
                    found.add(new Contact(name, ContactsContract.Contacts.getLookupUri(id, lookup)));
                }
            }
        } catch (Exception ignored) {
        }
        return found;
    }
}
