package com.sumuw.launcher;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.UserHandle;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import java.util.HashMap;
import java.util.Map;

/**
 * Watches notifications so app icons can show a dot, like One UI's app icon badges.
 * Only counts what each app's channel allows as a badge; ongoing ones (music, downloads) are skipped.
 */
public class DotsService extends NotificationListenerService {

    interface Listener {
        void onDotsChanged();
    }

    private static final Object LOCK = new Object();
    private static final Map<String, Integer> COUNTS = new HashMap<>();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    static volatile Listener listener;
    /** Goes up only when the dots themselves change, not on every update of a notification. */
    private static volatile int version;
    /** The live lock screen redraws its clock when notifications come and go. */
    static volatile Runnable wallpaperHook;
    static volatile boolean connected;
    private static volatile DotsService instance;
    /** Tests put notifications here instead of a connected listener. */
    static StatusBarNotification[] override;

    /** Everything in the notification shade right now (empty without access). */
    static StatusBarNotification[] active() {
        if (override != null) {
            return override;
        }
        DotsService service = instance;
        if (service == null) {
            return new StatusBarNotification[0];
        }
        try {
            StatusBarNotification[] all = service.getActiveNotifications();
            return all == null ? new StatusBarNotification[0] : all;
        } catch (Exception e) {
            return new StatusBarNotification[0];
        }
    }

    static boolean ready() {
        return instance != null && connected;
    }

    /** Dismisses one notification, as swiping it away in the system shade would. */
    static void dismiss(String key) {
        DotsService service = instance;
        if (service != null) {
            try {
                service.cancelNotification(key);
            } catch (Exception ignored) {
            }
        }
    }

    /** "Clear all": only the ones the system would clear too (not music or downloads in progress). */
    static void dismissAll() {
        DotsService service = instance;
        if (service != null) {
            try {
                service.cancelAllNotifications();
            } catch (Exception ignored) {
            }
        }
    }

    static String key(String packageName, UserHandle user) {
        return packageName + "#" + (user == null ? 0 : user.hashCode());
    }

    static int version() {
        return version;
    }

    /**
     * Takes new counts; true when they differ from the old ones. Music, downloads and the like update
     * their notification many times a minute without changing any dot, and those updates must not
     * rebuild the home screen under the user's finger.
     */
    static boolean applyCounts(Map<String, Integer> next) {
        synchronized (LOCK) {
            if (COUNTS.equals(next)) {
                return false;
            }
            COUNTS.clear();
            COUNTS.putAll(next);
            version++;
            return true;
        }
    }

    static boolean has(String packageName, UserHandle user) {
        synchronized (LOCK) {
            Integer count = COUNTS.get(key(packageName, user));
            return count != null && count > 0;
        }
    }

    /** True when the user has allowed Duo Home to read notifications in system settings. */
    static boolean accessGranted(Context context) {
        ComponentName component = new ComponentName(context, DotsService.class);
        if (Build.VERSION.SDK_INT >= 27) {
            NotificationManager manager = context.getSystemService(NotificationManager.class);
            return manager != null && manager.isNotificationListenerAccessGranted(component);
        }
        String enabled = Settings.Secure.getString(context.getContentResolver(), "enabled_notification_listeners");
        return enabled != null && enabled.contains(component.flattenToString());
    }

    @Override
    public void onListenerConnected() {
        instance = this;
        connected = true;
        rebuild();
    }

    @Override
    public void onListenerDisconnected() {
        instance = null;
        connected = false;
        applyCounts(new HashMap<>());
        publish(true);
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn, RankingMap rankingMap) {
        rebuild();
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn, RankingMap rankingMap) {
        rebuild();
    }

    private void rebuild() {
        HashMap<String, Integer> next = new HashMap<>();
        try {
            StatusBarNotification[] active = getActiveNotifications();
            RankingMap ranking = getCurrentRanking();
            Ranking scratch = new Ranking();
            if (active != null) {
                for (StatusBarNotification sbn : active) {
                    Notification notification = sbn.getNotification();
                    if (sbn.isOngoing() || (notification.flags & Notification.FLAG_GROUP_SUMMARY) != 0) {
                        continue;
                    }
                    if (ranking != null && ranking.getRanking(sbn.getKey(), scratch) && !scratch.canShowBadge()) {
                        continue;
                    }
                    String key = key(sbn.getPackageName(), sbn.getUser());
                    Integer count = next.get(key);
                    next.put(key, count == null ? 1 : count + 1);
                }
            }
        } catch (Exception ignored) {
            // The service can be asked for notifications while it is being unbound.
        }
        publish(applyCounts(next));
    }

    private static void publish(final boolean countsChanged) {
        MAIN.post(new Runnable() {
            @Override
            public void run() {
                Listener current = listener;
                if (current != null) {
                    current.onDotsChanged();
                }
                Runnable hook = wallpaperHook;
                if (countsChanged && hook != null) {
                    hook.run();
                }
            }
        });
    }
}
