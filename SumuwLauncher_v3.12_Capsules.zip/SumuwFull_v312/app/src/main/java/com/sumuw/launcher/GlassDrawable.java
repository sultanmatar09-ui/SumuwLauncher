package com.sumuw.launcher;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.view.View;

/**
 * One UI 9 style glass: shows the blurred wallpaper that sits behind the view, a light frost
 * instead of a solid white layer, and a thin edge that is brighter at the top.
 */
final class GlassDrawable extends Drawable {

    /** Shared by every glass surface on the screen. */
    static final class Source {
        View root;
        Bitmap blurred;
        boolean dark = true;
        private BitmapShader shader;
        private Bitmap shaderBitmap;

        BitmapShader shader() {
            if (blurred == null) {
                return null;
            }
            if (shader == null || shaderBitmap != blurred) {
                shader = new BitmapShader(blurred, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
                shaderBitmap = blurred;
            }
            return shader;
        }
    }

    private final Source source;
    private final View host;
    private final float radius;
    private final float edge;
    private final boolean strong;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint frost = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Matrix matrix = new Matrix();
    private final RectF rect = new RectF();
    private final int[] hostLocation = new int[2];
    private final int[] rootLocation = new int[2];
    private LinearGradient rimShader;
    private float rimTop;
    private float rimBottom;
    private int rimColor;

    /** @param strong a denser frost, for small controls that sit on busy parts of the wallpaper */
    GlassDrawable(Source source, View host, float radiusPx, float edgePx, boolean strong) {
        this.source = source;
        this.host = host;
        this.radius = radiusPx;
        this.edge = edgePx;
        this.strong = strong;
        rim.setStyle(Paint.Style.STROKE);
        rim.setStrokeWidth(edgePx);
    }

    @Override
    public void draw(Canvas canvas) {
        rect.set(getBounds());
        float r = Math.min(radius, Math.min(rect.width(), rect.height()) / 2f);
        BitmapShader shader = source.shader();
        View root = source.root;
        boolean blurred = shader != null && root != null && root.getWidth() > 0 && root.getHeight() > 0;
        if (blurred) {
            host.getLocationInWindow(hostLocation);
            root.getLocationInWindow(rootLocation);
            float scaleX = root.getWidth() / (float) source.blurred.getWidth();
            float scaleY = root.getHeight() / (float) source.blurred.getHeight();
            matrix.setScale(scaleX, scaleY);
            matrix.postTranslate(rect.left - (hostLocation[0] - rootLocation[0]), rect.top - (hostLocation[1] - rootLocation[1]));
            shader.setLocalMatrix(matrix);
            fill.setShader(shader);
            canvas.drawRoundRect(rect, r, r, fill);
        }
        frost.setColor(frostColor(blurred));
        canvas.drawRoundRect(rect, r, r, frost);
        float inset = edge / 2f;
        rect.inset(inset, inset);
        int top = source.dark ? 0x7AFFFFFF : 0xD8FFFFFF;
        int bottom = source.dark ? 0x18FFFFFF : 0x48FFFFFF;
        // Diagonal specular rim gradient for crisp One UI glass depth.
        if (rimShader == null || rimTop != rect.top || rimBottom != rect.bottom || rimColor != top) {
            rimShader = new LinearGradient(rect.left, rect.top, rect.right, rect.bottom, top, bottom, Shader.TileMode.CLAMP);
            rimTop = rect.top;
            rimBottom = rect.bottom;
            rimColor = top;
        }
        rim.setShader(rimShader);
        canvas.drawRoundRect(rect, r - inset, r - inset, rim);
    }

    private int frostColor(boolean blurred) {
        if (!blurred) {
            // Device wallpaper: we can't sample it, so use a tinted veil that keeps text readable.
            return source.dark ? (strong ? 0x66000000 : 0x52000000) : (strong ? 0xCCFFFFFF : 0xB3FFFFFF);
        }
        if (source.dark) {
            return strong ? 0x33FFFFFF : 0x24FFFFFF;
        }
        return strong ? 0x8CFFFFFF : 0x6BFFFFFF;
    }

    @Override
    public void setAlpha(int alpha) {
        fill.setAlpha(alpha);
    }

    @Override
    public void setColorFilter(ColorFilter colorFilter) {
        fill.setColorFilter(colorFilter);
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }
}
