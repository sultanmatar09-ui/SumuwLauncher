package com.sumuw.launcher;

import android.content.SharedPreferences;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** The news feeds Duo Home can show. Each one can be switched on or off in settings. */
final class NewsSources {

    static final class Source {
        final String id;
        final String name;
        final String url;
        final boolean onByDefault;

        Source(String id, String name, String url, boolean onByDefault) {
            this.id = id;
            this.name = name;
            this.url = url;
            this.onByDefault = onByDefault;
        }
    }

    static final Source[] ALL = {
            new Source("hadath", "الحدث", "https://www.alhadath.net/.mrss/alhadath.xml", true),
            new Source("okaz", "عكاظ", "https://www.okaz.com.sa/rssFeed/1", true),
            new Source("aawsat", "الشرق الأوسط", "https://aawsat.com/feed", true),
            new Source("bbc", "BBC", "https://feeds.bbci.co.uk/arabic/rss.xml", true),
            new Source("jazeera", "الجزيرة", "https://www.aljazeera.net/rss", true),
            new Source("arabiya", "العربية", "https://www.alarabiya.net/.mrss/ar.xml", false),
            new Source("skynews", "سكاي نيوز عربية", "https://www.skynewsarabia.com/rss", false),
            new Source("independent", "إندبندنت عربية", "https://www.independentarabia.com/rss.xml", false),
    };

    private NewsSources() {
    }

    static Set<String> enabledIds(SharedPreferences prefs) {
        HashSet<String> ids = new HashSet<>();
        String saved = prefs.getString("news_sources", null);
        if (saved == null) {
            for (Source source : ALL) {
                if (source.onByDefault) {
                    ids.add(source.id);
                }
            }
            return ids;
        }
        for (String id : saved.split(",")) {
            if (id.length() > 0) {
                ids.add(id);
            }
        }
        return ids;
    }

    static List<Source> enabled(SharedPreferences prefs) {
        Set<String> ids = enabledIds(prefs);
        ArrayList<Source> list = new ArrayList<>();
        for (Source source : ALL) {
            if (ids.contains(source.id)) {
                list.add(source);
            }
        }
        return list;
    }

    static void save(SharedPreferences prefs, Set<String> ids) {
        prefs.edit().putString("news_sources", TextUtils.join(",", ids)).apply();
    }

    static String summary(SharedPreferences prefs) {
        ArrayList<String> names = new ArrayList<>();
        for (Source source : enabled(prefs)) {
            names.add(source.name);
        }
        return TextUtils.join("، ", names);
    }
}
