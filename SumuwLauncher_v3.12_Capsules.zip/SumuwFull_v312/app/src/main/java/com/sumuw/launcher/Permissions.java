package com.sumuw.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.Settings;

/**
 * Asking for a permission when the user taps something that needs it. Android shows its own question
 * only until the user has said no for good; after that a request returns at once and nothing would
 * happen on the tap. So: the first time, and while Android still explains, ask; once refused for good,
 * say what it's for and open Sara Home's page in the phone's settings, where it can be turned on.
 * (Android's guidance: check, explain, ask; on a permanent no, send the user to the app's details.)
 */
final class Permissions {
    private static final String ASKED = "perm_asked_";

    private Permissions() {
    }

    static boolean granted(Context context, String permission) {
        return context.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    /** {@code why}: one line on what the permission is for, shown when only the settings page can grant it now. */
    static void ask(Activity activity, String[] permissions, int requestCode, int why) {
        SharedPreferences prefs = activity.getSharedPreferences("duo_home", 0);
        boolean anyGranted = false;
        boolean askedBefore = false;
        boolean explain = false;
        for (String permission : permissions) {
            anyGranted |= granted(activity, permission);
            askedBefore |= prefs.getBoolean(ASKED + permission, false);
            explain |= activity.shouldShowRequestPermissionRationale(permission);
        }
        if (!anyGranted && askedBefore && !explain) {
            blocked(activity, why);
            return;
        }
        SharedPreferences.Editor edit = prefs.edit();
        for (String permission : permissions) {
            edit.putBoolean(ASKED + permission, true);
        }
        edit.apply();
        activity.requestPermissions(permissions, requestCode);
    }

    /** Refused for good: explain, and offer the app's page in the phone's settings. */
    static void blocked(Activity activity, int why) {
        new AlertDialog.Builder(activity)
                .setTitle(activity.getString(R.string.perm_blocked_title))
                .setMessage(activity.getString(why) + "\n\n" + activity.getString(R.string.perm_blocked_body))
                .setPositiveButton(activity.getString(R.string.perm_open_settings), (dialog, which) -> openAppSettings(activity))
                .setNegativeButton(activity.getString(R.string.cancel), null)
                .show();
    }

    static void openAppSettingsFor(Context context, String pkg) {
        try {
            context.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", pkg, null))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception ignored) {
        }
    }

    static void openAppSettings(Context context) {
        try {
            context.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", context.getPackageName(), null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception ignored) {
        }
    }

    /** Backups leave these out: what was asked on one phone says nothing about another. */
    static boolean isState(String key) {
        return key.startsWith(ASKED);
    }
}
