package com.sumuw.launcher;

import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;

/**
 * How the icons are coloured: as the apps made them, one colour (the apps' own monochrome icons, and a
 * one-colour version made for apps that have none, as Android 16 does), tinted in the wallpaper's colour
 * (as iOS 26's tinted look), or clear (frosted, letting the wallpaper show through).
 */
final class IconTint {
    static final String PREF = "icon_style";
    static final String NORMAL = "normal";
    static final String THEMED = "themed";
    static final String TINTED = "tinted";
    static final String CLEAR = "clear";
    static final String[] STYLES = {NORMAL, THEMED, TINTED, CLEAR};

    private IconTint() {
    }

    /** The saved style; "themed icons" from before 3.9 carries over. */
    static String style(android.content.SharedPreferences prefs) {
        String style = prefs.getString(PREF, null);
        if (style == null) {
            return prefs.getBoolean("themed_icons", false) ? THEMED : NORMAL;
        }
        return style;
    }

    static int name(String style) {
        switch (style) {
            case THEMED:
                return R.string.icon_style_themed;
            case TINTED:
                return R.string.icon_style_tinted;
            case CLEAR:
                return R.string.icon_style_clear;
            default:
                return R.string.icon_style_normal;
        }
    }

    static Drawable apply(Resources res, Drawable icon, String style, int accent, boolean dark) {
        if (icon == null || NORMAL.equals(style)) {
            return icon;
        }
        int tile = dark ? mix(accent, Color.BLACK, 0.68f) : mix(accent, Color.WHITE, 0.84f);
        int glyph = dark ? mix(accent, Color.WHITE, 0.72f) : mix(accent, Color.BLACK, 0.45f);
        if (THEMED.equals(style)) {
            if (Build.VERSION.SDK_INT >= 33 && icon instanceof AdaptiveIconDrawable) {
                Drawable mono = ((AdaptiveIconDrawable) icon).getMonochrome();
                if (mono != null) {
                    Drawable foreground = copy(res, mono);
                    foreground.setTint(glyph);
                    return new AdaptiveIconDrawable(new ColorDrawable(tile), foreground);
                }
            }
            // No one-colour icon of its own: its picture in one colour, on the same tile.
            if (icon instanceof AdaptiveIconDrawable && ((AdaptiveIconDrawable) icon).getForeground() != null) {
                Drawable foreground = copy(res, ((AdaptiveIconDrawable) icon).getForeground());
                foreground.setColorFilter(new ColorMatrixColorFilter(oneColour(glyph)));
                return new AdaptiveIconDrawable(new ColorDrawable(tile), foreground);
            }
            Drawable whole = copy(res, icon);
            whole.setColorFilter(new ColorMatrixColorFilter(oneColour(glyph)));
            return whole;
        }
        Drawable whole = copy(res, icon);
        whole.setColorFilter(new ColorMatrixColorFilter(TINTED.equals(style) ? tinted(accent, dark) : clear(dark)));
        return whole;
    }

    private static Drawable copy(Resources res, Drawable icon) {
        Drawable.ConstantState state = icon.getConstantState();
        return (state != null ? state.newDrawable(res) : icon).mutate();
    }

    /** Grey by brightness, then laid over the colour: light parts take the colour, dark parts stay dark. */
    static ColorMatrix tinted(int accent, boolean dark) {
        ColorMatrix grey = new ColorMatrix();
        grey.setSaturation(0f);
        float boost = dark ? 1.15f : 1.0f;
        ColorMatrix tint = new ColorMatrix(new float[]{
                Color.red(accent) / 255f * boost, 0, 0, 0, dark ? 18 : 30,
                0, Color.green(accent) / 255f * boost, 0, 0, dark ? 18 : 30,
                0, 0, Color.blue(accent) / 255f * boost, 0, dark ? 18 : 30,
                0, 0, 0, 1, 0});
        grey.postConcat(tint);
        return grey;
    }

    /** Frosted: no colour, lighter, and a little see-through. */
    static ColorMatrix clear(boolean dark) {
        ColorMatrix grey = new ColorMatrix();
        grey.setSaturation(0f);
        float lift = dark ? 60f : 90f;
        ColorMatrix frost = new ColorMatrix(new float[]{
                0.7f, 0, 0, 0, lift,
                0, 0.7f, 0, 0, lift,
                0, 0, 0.7f, 0, lift,
                0, 0, 0, 0.78f, 0});
        grey.postConcat(frost);
        return grey;
    }

    /** Every pixel the glyph colour, keeping how solid it was and a hint of its shading. */
    static ColorMatrix oneColour(int glyph) {
        float r = Color.red(glyph);
        float g = Color.green(glyph);
        float b = Color.blue(glyph);
        return new ColorMatrix(new float[]{
                0, 0, 0, 0, r,
                0, 0, 0, 0, g,
                0, 0, 0, 0, b,
                0, 0, 0, 1, 0});
    }

    static int mix(int color, int toward, float amount) {
        float keep = 1f - amount;
        return Color.rgb((int) (Color.red(color) * keep + Color.red(toward) * amount),
                (int) (Color.green(color) * keep + Color.green(toward) * amount),
                (int) (Color.blue(color) * keep + Color.blue(toward) * amount));
    }
}
