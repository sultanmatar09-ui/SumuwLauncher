package com.sumuw.launcher;

import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Days left: to the salary (the 27th by default, as Saudi government salaries; on a Friday or Saturday it
 * comes the Thursday before), and to days the user adds (a trip, a wedding, an exam).
 */
final class Countdowns {
    static final String PREF_SALARY = "salary_day";
    static final String PREF_SALARY_ON = "salary_on";
    static final String PREF_EVENTS = "countdowns";

    private Countdowns() {
    }

    /** A day to count to: a name and its date (start of day, local time). */
    static final class Event {
        final String name;
        final long day;
        final boolean salary;

        Event(String name, long day, boolean salary) {
            this.name = name;
            this.day = day;
            this.salary = salary;
        }
    }

    static int salaryDay(SharedPreferences prefs) {
        return Math.max(1, Math.min(31, prefs.getInt(PREF_SALARY, 27)));
    }

    /** The next salary day on or after {@code from}: the chosen day of the month, moved to Thursday from a weekend. */
    static long nextSalary(SharedPreferences prefs, long from) {
        Calendar today = startOfDay(from);
        for (int add = 0; add < 3; add++) {
            Calendar pay = (Calendar) today.clone();
            pay.set(Calendar.DAY_OF_MONTH, 1);
            pay.add(Calendar.MONTH, add);
            pay.set(Calendar.DAY_OF_MONTH, Math.min(salaryDay(prefs), pay.getActualMaximum(Calendar.DAY_OF_MONTH)));
            int weekday = pay.get(Calendar.DAY_OF_WEEK);
            if (weekday == Calendar.FRIDAY) {
                pay.add(Calendar.DAY_OF_MONTH, -1);
            } else if (weekday == Calendar.SATURDAY) {
                pay.add(Calendar.DAY_OF_MONTH, -2);
            }
            if (!pay.before(today)) {
                return pay.getTimeInMillis();
            }
        }
        return today.getTimeInMillis();
    }

    static int daysUntil(long day, long from) {
        return (int) Math.round((startOfDay(day).getTimeInMillis() - startOfDay(from).getTimeInMillis()) / 86400000.0);
    }

    static Calendar startOfDay(long at) {
        Calendar day = Calendar.getInstance();
        day.setTimeInMillis(at);
        day.set(Calendar.HOUR_OF_DAY, 0);
        day.set(Calendar.MINUTE, 0);
        day.set(Calendar.SECOND, 0);
        day.set(Calendar.MILLISECOND, 0);
        return day;
    }

    /** The user's own days still to come, nearest first; past ones are dropped. */
    static List<Event> events(SharedPreferences prefs, long now) {
        ArrayList<Event> list = new ArrayList<>();
        try {
            JSONArray all = new JSONArray(prefs.getString(PREF_EVENTS, "[]"));
            for (int i = 0; i < all.length(); i++) {
                JSONObject item = all.getJSONObject(i);
                long day = item.getLong("d");
                if (daysUntil(day, now) >= 0) {
                    list.add(new Event(item.getString("n"), day, false));
                }
            }
        } catch (Exception ignored) {
        }
        java.util.Collections.sort(list, (a, b) -> Long.compare(a.day, b.day));
        return list;
    }

    static void add(SharedPreferences prefs, String name, long day) {
        try {
            JSONArray all = new JSONArray(prefs.getString(PREF_EVENTS, "[]"));
            all.put(new JSONObject().put("n", name).put("d", startOfDay(day).getTimeInMillis()));
            prefs.edit().putString(PREF_EVENTS, all.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    static void remove(SharedPreferences prefs, String name, long day) {
        try {
            JSONArray all = new JSONArray(prefs.getString(PREF_EVENTS, "[]"));
            JSONArray kept = new JSONArray();
            for (int i = 0; i < all.length(); i++) {
                JSONObject item = all.getJSONObject(i);
                if (!(item.getString("n").equals(name) && item.getLong("d") == startOfDay(day).getTimeInMillis())) {
                    kept.put(item);
                }
            }
            prefs.edit().putString(PREF_EVENTS, kept.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    /** The salary (when on) and the user's days, nearest first. */
    static List<Event> all(SharedPreferences prefs, String salaryName, long now) {
        ArrayList<Event> list = new ArrayList<>();
        if (prefs.getBoolean(PREF_SALARY_ON, true)) {
            list.add(new Event(salaryName, nextSalary(prefs, now), true));
        }
        list.addAll(events(prefs, now));
        java.util.Collections.sort(list, (a, b) -> Long.compare(a.day, b.day));
        return list;
    }
}
