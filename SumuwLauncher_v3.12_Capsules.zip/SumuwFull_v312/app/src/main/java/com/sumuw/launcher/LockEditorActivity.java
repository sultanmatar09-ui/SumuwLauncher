package com.sumuw.launcher;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;

/**
 * The lock screen editor: a live picture of the locked screen on top, and under it the choices in five
 * groups (wallpaper, clock, card, tools, message). Every choice shows in the picture at once and on the
 * lock screen itself, since Sara's live wallpaper redraws when a setting changes. A tap on the clock or
 * the card in the picture opens their group. On a wide screen the picture and the choices sit side by side.
 */
public class LockEditorActivity extends Activity {
    static final String EXTRA_TAB = "tab";
    static final int TAB_WALL = 0;
    static final int TAB_CLOCK = 1;
    static final int TAB_CARD = 2;
    static final int TAB_TOOLS = 3;
    static final int TAB_MESSAGE = 4;
    private static final int[] TAB_NAMES = {R.string.locke_tab_wall, R.string.locke_tab_clock, R.string.locke_tab_card,
            R.string.locke_tab_tools, R.string.locke_tab_message};

    private static final int INK = 0xFFF4F2F8;
    private static final int SOFT = 0x99F4F2F8;
    private static final int SURFACE = 0xFF15141B;

    private SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable render = this::render;
    private int accent;
    private int screenW;
    private int screenH;
    private int previewW;
    private int previewH;
    private ImageView preview;
    private Bitmap shot;
    private LinearLayout tabs;
    private LinearLayout panel;
    private ScrollView panelScroll;
    private LinearLayout banner;
    int tab = TAB_WALL;

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Fonts.init(this);
        prefs = getSharedPreferences("duo_home", 0);
        accent = prefs.getInt("accent", Color.rgb(101, 103, 191));
        // Edge to edge (Android 15 draws every app under the bars): the dark page reaches the edges, its
        // contents keep clear of the bars, the cut-out and the keyboard, and the bars' icons are light.
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
        } else {
            getWindow().setStatusBarColor(SURFACE);
            getWindow().setNavigationBarColor(SURFACE);
        }
        int[] size = SystemWallpaper.screenSize(this);
        screenW = size[0];
        screenH = size[1];
        tab = bundle != null ? bundle.getInt(EXTRA_TAB, TAB_WALL) : getIntent().getIntExtra(EXTRA_TAB, TAB_WALL);
        build();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putInt(EXTRA_TAB, tab);
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateBanner(); // the user may have just applied the live wallpaper
        scheduleRender();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(render);
        super.onDestroy();
    }

    // ---------------------------------------------------------------- layout

    private void build() {
        float density = getResources().getDisplayMetrics().density;
        int widthDp = Math.round(getResources().getDisplayMetrics().widthPixels / density);
        int heightDp = Math.round(getResources().getDisplayMetrics().heightPixels / density);
        boolean sideBySide = widthDp >= 600 && widthDp > heightDp * 0.9f;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(SURFACE);
        if (Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                android.graphics.Insets ime = insets.getInsets(WindowInsets.Type.ime());
                // The keyboard takes the bottom when it's up (the message field stays in view above it).
                view.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, ime.bottom));
                return WindowInsets.CONSUMED;
            });
        } else {
            root.setFitsSystemWindows(true);
        }
        root.addView(topBar(), new LinearLayout.LayoutParams(-1, dp(56)));
        banner = new LinearLayout(this);
        banner.setOrientation(LinearLayout.VERTICAL);
        root.addView(banner, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(sideBySide ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1f));

        // The picture: as tall as the room allows, in the phone's own proportions.
        // Room for the picture: what's left under the bar (and the note, while the live wallpaper isn't applied),
        // keeping at least a good part of the screen for the choices when they're under it.
        int bannerDp = SaraWallpaper.onLock(this) ? 0 : 76;
        int free = heightDp - 56 - bannerDp - 44 - 32;
        int roomH = sideBySide ? free : Math.min(Math.round(heightDp * 0.46f), free - 250);
        int roomW = sideBySide ? Math.round(widthDp * 0.42f) : widthDp - 48;
        float ratio = screenW / (float) screenH;
        int hDp = Math.max(180, Math.min(roomH, Math.round(roomW / ratio)));
        int wDp = Math.round(hDp * ratio);
        previewW = dp(wDp);
        previewH = dp(hDp);
        LinearLayout side = new LinearLayout(this);
        side.setOrientation(LinearLayout.VERTICAL);
        side.setGravity(Gravity.CENTER_HORIZONTAL);
        side.setPadding(0, dp(6), 0, dp(4));
        FrameLayout frame = new FrameLayout(this);
        frame.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), dp(22));
            }
        });
        frame.setClipToOutline(true);
        GradientDrawable rim = new GradientDrawable();
        rim.setCornerRadius(dp(22));
        rim.setStroke(Math.max(1, dp(1)), 0x33FFFFFF);
        frame.setForeground(rim);
        preview = new ImageView(this);
        preview.setScaleType(ImageView.ScaleType.FIT_XY);
        preview.setContentDescription(getString(R.string.locke_preview));
        frame.addView(preview, new FrameLayout.LayoutParams(-1, -1));
        frame.setOnTouchListener(this::previewTouched);
        side.addView(frame, new LinearLayout.LayoutParams(previewW, previewH));
        TextView hint = text(getString(R.string.locke_hint), 12, SOFT, 400);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(dp(16), dp(8), dp(16), 0);
        side.addView(hint, new LinearLayout.LayoutParams(-1, -2));
        body.addView(side, sideBySide ? new LinearLayout.LayoutParams(0, -1, 0.45f) : new LinearLayout.LayoutParams(-1, -2));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        HorizontalScrollView tabScroll = new HorizontalScrollView(this);
        tabScroll.setHorizontalScrollBarEnabled(false);
        tabs = new LinearLayout(this);
        tabs.setPadding(dp(14), dp(10), dp(14), dp(6));
        tabScroll.addView(tabs);
        controls.addView(tabScroll, new LinearLayout.LayoutParams(-1, -2));
        panelScroll = new ScrollView(this);
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(6), dp(18), dp(28));
        panelScroll.addView(panel, new FrameLayout.LayoutParams(-1, -2));
        controls.addView(panelScroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        body.addView(controls, sideBySide ? new LinearLayout.LayoutParams(0, -1, 0.55f) : new LinearLayout.LayoutParams(-1, 0, 1f));

        setContentView(root);
        if (Build.VERSION.SDK_INT >= 30 && getWindow().getInsetsController() != null) {
            // Light icons on the dark page (the controller exists once the window has its content).
            getWindow().getInsetsController().setSystemBarsAppearance(0,
                    WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
        }
        updateBanner();
        selectTab(tab);
        render();
    }

    private View topBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(6), 0, dp(14), 0);
        ImageView back = new ImageView(this);
        boolean rtl = getResources().getConfiguration().getLayoutDirection() == View.LAYOUT_DIRECTION_RTL;
        back.setImageDrawable(new Glyphs(rtl ? Glyphs.CHEVRON_RIGHT : Glyphs.CHEVRON_LEFT, INK, dp(22)));
        back.setScaleType(ImageView.ScaleType.CENTER);
        back.setContentDescription(getString(R.string.done));
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));
        TextView title = text(getString(R.string.locke_title), 20, INK, 700);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(0, -2, 1f);
        titleParams.setMarginStart(dp(4));
        bar.addView(title, titleParams);
        TextView reset = chipView(getString(R.string.locke_reset), false);
        reset.setOnClickListener(v -> resetAll());
        bar.addView(reset);
        return bar;
    }

    /** Until Sara's live wallpaper is on the lock screen, none of this shows there: say so, with the way to fix it. */
    private void updateBanner() {
        if (banner == null) {
            return;
        }
        banner.removeAllViews();
        if (SaraWallpaper.onLock(this)) {
            return;
        }
        LinearLayout box = new LinearLayout(this);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(14), dp(10), dp(10), dp(10));
        box.setBackground(round(0x26FFD27A, 16));
        TextView why = text(getString(SaraWallpaper.onHome(this) ? R.string.locke_home_only : R.string.locke_not_applied), 13, 0xFFFFE2A6, 500);
        box.addView(why, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView apply = chipView(getString(R.string.lock_wallpaper_apply), true);
        apply.setOnClickListener(v -> {
            try {
                startActivity(SaraWallpaper.chooser(this));
            } catch (Exception e) {
                Toast.makeText(this, getString(R.string.lock_options_need_live), Toast.LENGTH_LONG).show();
            }
        });
        LinearLayout.LayoutParams applyParams = new LinearLayout.LayoutParams(-2, -2);
        applyParams.setMarginStart(dp(8));
        box.addView(apply, applyParams);
        LinearLayout.LayoutParams boxParams = new LinearLayout.LayoutParams(-1, -2);
        boxParams.setMargins(dp(14), 0, dp(14), dp(4));
        banner.addView(box, boxParams);
    }

    void selectTab(int which) {
        tab = Math.max(TAB_WALL, Math.min(TAB_MESSAGE, which));
        tabs.removeAllViews();
        for (int i = 0; i < TAB_NAMES.length; i++) {
            final int index = i;
            TextView name = chipView(getString(TAB_NAMES[i]), i == tab);
            name.setOnClickListener(v -> selectTab(index));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, -2);
            params.setMarginEnd(dp(8));
            tabs.addView(name, params);
        }
        fillPanel();
        panelScroll.scrollTo(0, 0);
    }

    private void fillPanel() {
        panel.removeAllViews();
        switch (tab) {
            case TAB_WALL:
                wallpaperOptions();
                break;
            case TAB_CLOCK:
                clockOptions();
                break;
            case TAB_CARD:
                cardOptions();
                break;
            case TAB_TOOLS:
                toolOptions();
                break;
            default:
                messageOptions();
                break;
        }
    }

    // ---------------------------------------------------------------- the groups

    private void wallpaperOptions() {
        LinearLayout row = group(getString(R.string.locke_wallpaper), null);
        String chosen = prefs.getString(LockScreen.WALL, LockScreen.SAME);
        String home = prefs.getString("wallpaper_style", Wallpapers.DEFAULT);
        if (Wallpapers.DEVICE.equals(home) || !Wallpapers.isKnown(home)) {
            home = Wallpapers.DEFAULT;
        }
        row.addView(wallTile(LockScreen.SAME, Wallpapers.create(this, home), getString(R.string.locke_same_as_home),
                LockScreen.SAME.equals(chosen) || !Wallpapers.isKnown(chosen)));
        for (String id : Wallpapers.IDS) {
            if (Wallpapers.DEVICE.equals(id) || Wallpapers.PHOTO.equals(id)) {
                continue;
            }
            row.addView(wallTile(id, Wallpapers.create(this, id), getString(Wallpapers.nameRes(id)), id.equals(chosen)));
        }
        int dim = LockScreen.dim(prefs);
        int dimIndex = 0;
        for (int i = 0; i < LockScreen.DIMS.length; i++) {
            if (LockScreen.DIMS[i] == dim) {
                dimIndex = i;
            }
        }
        choices(getString(R.string.locke_dim), getString(R.string.locke_dim_hint),
                new int[]{R.string.locke_dim_none, R.string.locke_dim_light, R.string.locke_dim_medium, R.string.locke_dim_strong}, dimIndex,
                which -> prefs.edit().putInt(LockScreen.DIM, LockScreen.DIMS[which]).apply());
        LinearLayout moods = group(getString(R.string.locke_ambience), getString(R.string.locke_ambience_hint));
        toggle(moods, getString(R.string.locke_amb_day), Ambience.PREF_DAY, true);
        toggle(moods, getString(R.string.locke_amb_weather), Ambience.PREF_WEATHER, true);
        toggle(moods, getString(R.string.locke_amb_occasions), Ambience.PREF_OCCASIONS, true);
    }

    private void clockOptions() {
        choices(getString(R.string.locke_clock_style), null,
                new int[]{R.string.lock_clock_off, R.string.lock_clock_stacked, R.string.lock_clock_line}, AdaptiveClock.style(prefs),
                which -> prefs.edit().putInt(AdaptiveClock.PREF, which).apply());
        choices(getString(R.string.locke_clock_size), null,
                new int[]{R.string.locke_auto, R.string.locke_small, R.string.locke_medium, R.string.locke_large}, LockScreen.clockSize(prefs),
                which -> prefs.edit().putInt(LockScreen.CLOCK_SIZE, which).apply());
        choices(getString(R.string.locke_clock_side), getString(R.string.locke_clock_side_hint),
                new int[]{R.string.locke_auto, R.string.locke_centre, R.string.locke_right, R.string.locke_left}, LockScreen.clockSide(prefs),
                which -> prefs.edit().putInt(LockScreen.CLOCK_SIDE, which).apply());
        LinearLayout colours = group(getString(R.string.locke_clock_color), null);
        int chosen = LockScreen.clockColor(prefs);
        int[] names = {R.string.locke_auto, R.string.locke_white, R.string.locke_wall_color, R.string.locke_gold, R.string.locke_rose,
                R.string.locke_turquoise};
        String id = LockScreen.wallpaper(prefs);
        for (int i = 0; i < LockScreen.CLOCK_COLORS.length; i++) {
            final int index = i;
            int colour = i == 2 ? Wallpapers.accentFor(this, id) : LockScreen.CLOCK_COLORS[i];
            colours.addView(swatch(i == 0 ? 0 : colour, i == 0, i == chosen, getString(names[i]), v -> {
                prefs.edit().putInt(LockScreen.CLOCK_COLOR, index).apply();
                fillPanel();
                scheduleRender();
            }));
        }
        LinearLayout more = group(getString(R.string.locke_clock_more), null);
        toggle(more, getString(R.string.locke_compact), AdaptiveClock.COMPACT_PREF, true);
    }

    private void cardOptions() {
        choices(getString(R.string.locke_card_style), null,
                new int[]{R.string.locke_glass, R.string.locke_dark, R.string.locke_clear, R.string.locke_no_card}, LockScreen.cardStyle(prefs),
                which -> prefs.edit().putInt(LockScreen.CARD_STYLE, which).apply());
        choices(getString(R.string.locke_card_place), null,
                new int[]{R.string.position_top, R.string.position_middle, R.string.position_bottom}, prefs.getInt(SaraWallpaper.POSITION, 2),
                which -> prefs.edit().putInt(SaraWallpaper.POSITION, which).apply());
        int[] lines = new int[LockScreen.LINES.length];
        int current = 0;
        for (int i = 0; i < lines.length; i++) {
            lines[i] = LockScreen.lineName(LockScreen.LINES[i]);
            if (LockScreen.LINES[i].equals(LockScreen.line(prefs))) {
                current = i;
            }
        }
        choices(getString(R.string.locke_line), getString(R.string.locke_line_hint), lines, current,
                which -> prefs.edit().putString(LockScreen.LINE, LockScreen.LINES[which]).apply());
    }

    private void toolOptions() {
        LinearLayout row = group(getString(R.string.locke_tools), getString(R.string.locke_tools_hint));
        row.setOrientation(LinearLayout.VERTICAL);
        List<String> chosen = LockScreen.widgets(prefs);
        LinearLayout line = null;
        int columns = getResources().getDisplayMetrics().widthPixels / getResources().getDisplayMetrics().density >= 600 ? 4 : 3;
        for (int i = 0; i < LockScreen.WIDGET_KEYS.length; i++) {
            final String key = LockScreen.WIDGET_KEYS[i];
            if (i % columns == 0) {
                line = new LinearLayout(this);
                LinearLayout.LayoutParams lineParams = new LinearLayout.LayoutParams(-1, -2);
                lineParams.bottomMargin = dp(8);
                row.addView(line, lineParams);
            }
            int order = chosen.indexOf(key);
            LinearLayout tool = new LinearLayout(this);
            tool.setOrientation(LinearLayout.VERTICAL);
            tool.setGravity(Gravity.CENTER);
            tool.setPadding(dp(6), dp(10), dp(6), dp(10));
            tool.setBackground(order >= 0 ? round(accent, 16) : outlined(16));
            ImageView glyph = new ImageView(this);
            glyph.setImageDrawable(new Glyphs(LockScreen.widgetGlyph(key), INK, dp(20)));
            tool.addView(glyph, new LinearLayout.LayoutParams(dp(20), dp(20)));
            TextView name = text((order >= 0 ? LockScreen.local(order + 1) + "  " : "") + getString(LockScreen.widgetName(key)), 13, INK,
                    order >= 0 ? 700 : 500);
            name.setGravity(Gravity.CENTER);
            name.setSingleLine(true);
            name.setPadding(0, dp(6), 0, 0);
            tool.addView(name, new LinearLayout.LayoutParams(-1, -2));
            tool.setContentDescription(getString(LockScreen.widgetName(key)) + (order >= 0 ? getString(R.string.list_separator)
                    + getString(R.string.state_on) : ""));
            tool.setOnClickListener(v -> {
                if (!LockScreen.toggleWidget(prefs, key)) {
                    Toast.makeText(this, getString(R.string.locke_tools_full), Toast.LENGTH_SHORT).show();
                    return;
                }
                fillPanel();
                scheduleRender();
            });
            LinearLayout.LayoutParams toolParams = new LinearLayout.LayoutParams(0, -2, 1f);
            toolParams.setMarginEnd(dp(8));
            line.addView(tool, toolParams);
        }
        while (line != null && line.getChildCount() < columns) {
            // A short last line keeps the columns of the lines above.
            LinearLayout.LayoutParams gapParams = new LinearLayout.LayoutParams(0, 1, 1f);
            gapParams.setMarginEnd(dp(8));
            line.addView(new View(this), gapParams);
        }
        while (line != null && line.getChildCount() < columns) {
            LinearLayout.LayoutParams fill = new LinearLayout.LayoutParams(0, 1, 1f);
            fill.setMarginEnd(dp(8));
            line.addView(new View(this), fill);
        }
        LinearLayout privacy = group(getString(R.string.locke_privacy), getString(R.string.locke_privacy_hint));
        toggle(privacy, getString(R.string.locke_hide_titles), LockScreen.PRIVATE, true);
    }

    private void messageOptions() {
        LinearLayout box = group(getString(R.string.locke_message), getString(R.string.locke_message_hint));
        box.setOrientation(LinearLayout.VERTICAL);
        final EditText field = new EditText(this);
        field.setText(prefs.getString(LockScreen.MESSAGE, ""));
        field.setHint(getString(R.string.locke_message_example));
        field.setTextColor(INK);
        field.setHintTextColor(0x66F4F2F8);
        field.setTypeface(Fonts.of(500));
        field.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        field.setBackground(round(0x1AFFFFFF, 14));
        field.setPadding(dp(14), dp(12), dp(14), dp(12));
        field.setMaxLines(3);
        field.setFilters(new InputFilter[]{new InputFilter.LengthFilter(LockScreen.MESSAGE_LENGTH)});
        box.addView(field, new LinearLayout.LayoutParams(-1, -2));
        final TextView count = text("", 11, SOFT, 400);
        count.setPadding(0, dp(4), 0, 0);
        box.addView(count, new LinearLayout.LayoutParams(-1, -2));
        Runnable counted = () -> count.setText(getString(R.string.locke_message_count,
                LockScreen.local(field.getText().length()), LockScreen.local(LockScreen.MESSAGE_LENGTH)));
        counted.run();
        field.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                prefs.edit().putString(LockScreen.MESSAGE, s.toString().trim()).apply();
                counted.run();
                scheduleRender();
            }
        });
        LinearLayout ideas = group(getString(R.string.locke_message_ideas), null);
        int[] samples = {R.string.locke_idea_found, R.string.locke_idea_dhikr, R.string.locke_idea_name};
        for (int sample : samples) {
            final String words = getString(sample);
            TextView chip = chipView(words, false);
            chip.setOnClickListener(v -> {
                field.setText(words);
                field.setSelection(field.getText().length());
                field.requestFocus();
            });
            ideas.addView(chip, chipParams());
        }
        TextView clear = chipView(getString(R.string.locke_message_clear), false);
        clear.setOnClickListener(v -> field.setText(""));
        ideas.addView(clear, chipParams());
    }

    // ---------------------------------------------------------------- the picture

    void scheduleRender() {
        handler.removeCallbacks(render);
        handler.postDelayed(render, 40L);
    }

    /** Draws the locked screen as the live wallpaper would, scaled to the picture. */
    void render() {
        if (preview == null || previewW <= 0 || previewH <= 0) {
            return;
        }
        try {
            if (shot == null || shot.getWidth() != previewW || shot.getHeight() != previewH) {
                shot = Bitmap.createBitmap(previewW, previewH, Bitmap.Config.ARGB_8888);
            }
            Canvas canvas = new Canvas(shot);
            canvas.drawColor(Color.BLACK);
            canvas.save();
            canvas.scale(previewW / (float) screenW, previewH / (float) screenH);
            int[] battery = battery();
            SaraWallpaper.paint(this, canvas, screenW, screenH, true, battery[0], battery[1] == 1);
            canvas.restore();
            preview.setImageBitmap(shot);
            preview.invalidate();
        } catch (Exception | OutOfMemoryError ignored) {
            // the picture is a help; the choices still apply
        }
    }

    private int[] battery() {
        try {
            Intent intent = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (intent == null) {
                return new int[]{-1, 0};
            }
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            return new int[]{level < 0 || scale <= 0 ? -1 : Math.round(level * 100f / scale),
                    status == BatteryManager.BATTERY_STATUS_CHARGING ? 1 : 0};
        } catch (Exception e) {
            return new int[]{-1, 0};
        }
    }

    /** A tap on the clock or the card in the picture opens its group. */
    private boolean previewTouched(View view, MotionEvent event) {
        if (event.getActionMasked() != MotionEvent.ACTION_UP) {
            return true;
        }
        float x = event.getX() * screenW / Math.max(1f, view.getWidth());
        float y = event.getY() * screenH / Math.max(1f, view.getHeight());
        AdaptiveClock.Placement clock = SaraWallpaper.lastClock;
        RectF card = SaraWallpaper.lastCard;
        if (clock != null && clock.box.contains(x, y)) {
            selectTab(TAB_CLOCK);
        } else if (card != null && card.contains(x, y)) {
            selectTab(TAB_CARD);
        } else if (y > screenH * 0.8f) {
            selectTab(TAB_MESSAGE);
        } else {
            selectTab(TAB_WALL);
        }
        view.performClick();
        return true;
    }

    private void resetAll() {
        prefs.edit().remove(LockScreen.WALL).remove(LockScreen.DIM).remove(LockScreen.CLOCK_SIZE).remove(LockScreen.CLOCK_SIDE)
                .remove(LockScreen.CLOCK_COLOR).remove(LockScreen.CARD_STYLE).remove(LockScreen.LINE).remove(LockScreen.WIDGETS)
                .remove(LockScreen.PRIVATE).remove(AdaptiveClock.PREF).remove(AdaptiveClock.COMPACT_PREF).remove(SaraWallpaper.POSITION)
                .apply();
        fillPanel();
        scheduleRender();
        Toast.makeText(this, getString(R.string.locke_reset_done), Toast.LENGTH_SHORT).show();
    }

    // ---------------------------------------------------------------- pieces

    interface Pick {
        void picked(int which);
    }

    /** A title, an optional line under it, and a row (scrolling sideways) for the options. */
    private LinearLayout group(String title, String hint) {
        TextView name = text(title, 14, INK, 700);
        name.setPadding(0, dp(14), 0, hint == null ? dp(8) : dp(2));
        panel.addView(name, new LinearLayout.LayoutParams(-1, -2));
        if (hint != null) {
            TextView under = text(hint, 12, SOFT, 400);
            under.setPadding(0, 0, 0, dp(8));
            panel.addView(under, new LinearLayout.LayoutParams(-1, -2));
        }
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setFillViewport(true);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        scroll.addView(row, new FrameLayout.LayoutParams(-1, -2));
        panel.addView(scroll, new LinearLayout.LayoutParams(-1, -2));
        return row;
    }

    private void choices(String title, String hint, int[] names, int selected, Pick pick) {
        LinearLayout row = group(title, hint);
        for (int i = 0; i < names.length; i++) {
            final int index = i;
            TextView chip = chipView(getString(names[i]), i == selected);
            chip.setOnClickListener(v -> {
                pick.picked(index);
                fillPanel();
                scheduleRender();
            });
            row.addView(chip, chipParams());
        }
    }

    private void toggle(LinearLayout row, String name, final String key, final boolean fallback) {
        boolean on = prefs.getBoolean(key, fallback);
        TextView chip = chipView((on ? "✓  " : "") + name, on);
        chip.setContentDescription(name + getString(R.string.list_separator) + getString(on ? R.string.state_on : R.string.state_off));
        chip.setOnClickListener(v -> {
            prefs.edit().putBoolean(key, !prefs.getBoolean(key, fallback)).apply();
            fillPanel();
            scheduleRender();
        });
        row.addView(chip, chipParams());
    }

    private LinearLayout.LayoutParams chipParams() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, -2);
        params.setMarginEnd(dp(8));
        return params;
    }

    private TextView chipView(String label, boolean selected) {
        TextView chip = text(label, 13, selected ? Color.WHITE : INK, selected ? 700 : 500);
        chip.setSingleLine(true);
        chip.setGravity(Gravity.CENTER);
        chip.setMinHeight(dp(38));
        chip.setPadding(dp(16), dp(8), dp(16), dp(8));
        chip.setBackground(selected ? round(accent, 19) : outlined(19));
        return chip;
    }

    private View wallTile(final String id, Drawable art, String name, boolean selected) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER_HORIZONTAL);
        FrameLayout picture = new FrameLayout(this);
        picture.setBackground(art);
        picture.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), dp(12));
            }
        });
        picture.setClipToOutline(true);
        if (selected) {
            GradientDrawable ring = new GradientDrawable();
            ring.setCornerRadius(dp(12));
            ring.setStroke(dp(3), accent);
            picture.setForeground(ring);
        }
        tile.addView(picture, new LinearLayout.LayoutParams(dp(58), dp(104)));
        TextView label = text(name, 11, selected ? INK : SOFT, selected ? 700 : 400);
        label.setGravity(Gravity.CENTER);
        label.setSingleLine(true);
        label.setPadding(0, dp(5), 0, 0);
        tile.addView(label, new LinearLayout.LayoutParams(dp(70), -2));
        tile.setContentDescription(name);
        tile.setOnClickListener(v -> {
            prefs.edit().putString(LockScreen.WALL, id).apply();
            fillPanel();
            scheduleRender();
        });
        return tile;
    }

    private View swatch(int colour, boolean automatic, boolean selected, String name, View.OnClickListener click) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        View dot = new View(this);
        GradientDrawable fill = new GradientDrawable();
        fill.setShape(GradientDrawable.OVAL);
        if (automatic) {
            fill.setOrientation(GradientDrawable.Orientation.TL_BR);
            fill.setColors(new int[]{Color.WHITE, Color.WHITE, 0xFF1C1B22, 0xFF1C1B22});
        } else {
            fill.setColor(colour);
        }
        fill.setStroke(dp(selected ? 3 : 1), selected ? accent : 0x40FFFFFF);
        dot.setBackground(fill);
        box.addView(dot, new LinearLayout.LayoutParams(dp(40), dp(40)));
        TextView label = text(name, 11, selected ? INK : SOFT, selected ? 700 : 400);
        label.setGravity(Gravity.CENTER);
        label.setSingleLine(true);
        label.setPadding(0, dp(5), 0, 0);
        box.addView(label, new LinearLayout.LayoutParams(dp(64), -2));
        box.setContentDescription(name);
        box.setOnClickListener(click);
        return box;
    }

    private TextView text(String value, float size, int color, int weight) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        view.setTextColor(color);
        Typeface face = Fonts.of(weight);
        view.setTypeface(face);
        view.setTextDirection(View.TEXT_DIRECTION_LOCALE);
        return view;
    }

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable shape = new GradientDrawable();
        shape.setCornerRadius(dp(radiusDp));
        shape.setColor(color);
        return shape;
    }

    private GradientDrawable outlined(int radiusDp) {
        GradientDrawable shape = round(0x14FFFFFF, radiusDp);
        shape.setStroke(Math.max(1, dp(1)), 0x29FFFFFF);
        return shape;
    }

    int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
