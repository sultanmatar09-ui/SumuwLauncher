package com.sumuw.launcher;

import android.app.AlertDialog;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * A month of the Umm al-Qura calendar: each day with its Hijri number and, small beneath it, the
 * Gregorian date; today ringed, the occasions marked with a dot (tap one for its name). The arrows
 * move a month at a time; the week starts on Sunday, as in Saudi Arabia.
 */
final class HijriMonth {
    private final HomeActivity home;
    private final LinearLayout box;
    private final TextView title;
    private final TextView range;
    private final LinearLayout weeks;
    private final int[] today;
    private int year;
    private int month;

    private HijriMonth(HomeActivity home) {
        this.home = home;
        today = HijriEvents.hijri(System.currentTimeMillis());
        year = today[0];
        month = today[1];
        int ink = home.nightMode() ? 0xFFF2F2F2 : 0xFF17171A;
        box = new LinearLayout(home);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(home.dp(14.0f), home.dp(14.0f), home.dp(14.0f), home.dp(6.0f));
        LinearLayout head = new LinearLayout(home);
        head.setGravity(Gravity.CENTER_VERTICAL);
        boolean rtl = home.getResources().getConfiguration().getLayoutDirection() == View.LAYOUT_DIRECTION_RTL;
        // Earlier months are behind the reader: on the right in Arabic, on the left in English.
        head.addView(arrow(rtl ? Glyphs.CHEVRON_RIGHT : Glyphs.CHEVRON_LEFT, ink, -1));
        LinearLayout titles = new LinearLayout(home);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setGravity(Gravity.CENTER);
        title = home.label("", 19, ink, 700);
        title.setGravity(Gravity.CENTER);
        titles.addView(title, new LinearLayout.LayoutParams(-1, -2));
        range = home.label("", 12, HomeActivity.withAlpha(ink, 0.6f), 400);
        range.setGravity(Gravity.CENTER);
        titles.addView(range, new LinearLayout.LayoutParams(-1, -2));
        head.addView(titles, new LinearLayout.LayoutParams(0, -2, 1f));
        head.addView(arrow(rtl ? Glyphs.CHEVRON_LEFT : Glyphs.CHEVRON_RIGHT, ink, 1));
        box.addView(head, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout names = new LinearLayout(home);
        names.setPadding(0, home.dp(12.0f), 0, home.dp(4.0f));
        Calendar sunday = Calendar.getInstance();
        sunday.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
        SimpleDateFormat shortDay = new SimpleDateFormat("EEEEE", Locale.getDefault());
        for (int i = 0; i < 7; i++) {
            TextView name = home.label(shortDay.format(sunday.getTime()), 12, HomeActivity.withAlpha(ink, 0.6f), 600);
            name.setGravity(Gravity.CENTER);
            names.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));
            sunday.add(Calendar.DAY_OF_MONTH, 1);
        }
        box.addView(names, new LinearLayout.LayoutParams(-1, -2));
        weeks = new LinearLayout(home);
        weeks.setOrientation(LinearLayout.VERTICAL);
        box.addView(weeks, new LinearLayout.LayoutParams(-1, -2));
        fill(ink);
    }

    static AlertDialog show(HomeActivity home) {
        HijriMonth month = new HijriMonth(home);
        return new AlertDialog.Builder(home)
                .setView(month.box)
                .setPositiveButton(home.getString(R.string.done), null)
                .show();
    }

    /** Previous and next month; the glyphs follow the reading direction. */
    private View arrow(int glyph, int ink, final int step) {
        ImageView button = new ImageView(home);
        button.setImageDrawable(new Glyphs(glyph, ink, home.dp(22.0f)));
        button.setScaleType(ImageView.ScaleType.CENTER);
        button.setBackground(home.pill(HomeActivity.withAlpha(ink, 0.08f), 20));
        button.setContentDescription(home.getString(step < 0 ? R.string.hijri_previous : R.string.hijri_next));
        button.setOnClickListener(v -> {
            month += step;
            if (month < 0) {
                month = 11;
                year--;
            } else if (month > 11) {
                month = 0;
                year++;
            }
            fill(home.nightMode() ? 0xFFF2F2F2 : 0xFF17171A);
        });
        button.setLayoutParams(new LinearLayout.LayoutParams(home.dp(40.0f), home.dp(40.0f)));
        return button;
    }

    private void fill(int ink) {
        title.setText(HijriEvents.monthTitle(year, month));
        int length = HijriEvents.monthLength(year, month);
        long first = HijriEvents.dayStart(year, month, 1);
        long last = HijriEvents.dayStart(year, month, length);
        Locale locale = Locale.getDefault();
        SimpleDateFormat dayMonth = new SimpleDateFormat("d MMMM", locale);
        SimpleDateFormat dayMonthYear = new SimpleDateFormat("d MMMM y", locale);
        range.setText(dayMonth.format(new Date(first)) + " – " + dayMonthYear.format(new Date(last)));
        weeks.removeAllViews();
        Calendar start = Calendar.getInstance();
        start.setTimeInMillis(first);
        int offset = start.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY;
        SimpleDateFormat gregorianDay = new SimpleDateFormat("d", locale);
        LinearLayout week = null;
        int cells = offset + length;
        int rows = (cells + 6) / 7;
        for (int i = 0; i < rows * 7; i++) {
            if (i % 7 == 0) {
                week = new LinearLayout(home);
                weeks.addView(week, new LinearLayout.LayoutParams(-1, home.dp(50.0f)));
            }
            int day = i - offset + 1;
            FrameLayout cell = new FrameLayout(home);
            if (day >= 1 && day <= length) {
                long when = HijriEvents.dayStart(year, month, day);
                boolean isToday = year == today[0] && month == today[1] && day == today[2];
                final int occasion = HijriEvents.occasionOn(month, day);
                LinearLayout stack = new LinearLayout(home);
                stack.setOrientation(LinearLayout.VERTICAL);
                stack.setGravity(Gravity.CENTER);
                if (isToday) {
                    stack.setBackground(home.pill(home.accent, 14));
                }
                int main = isToday ? Color.WHITE : ink;
                stack.addView(home.label(String.format(locale, "%d", day), 16, main, isToday ? 700 : 500));
                stack.addView(home.label(gregorianDay.format(new Date(when)), 10, HomeActivity.withAlpha(main, 0.62f), 400));
                FrameLayout.LayoutParams stackParams = new FrameLayout.LayoutParams(home.dp(40.0f), home.dp(46.0f), Gravity.CENTER);
                cell.addView(stack, stackParams);
                String spoken = String.format(locale, "%d", day) + " " + HijriEvents.monthTitle(year, month) + "، "
                        + new SimpleDateFormat("EEEE d MMMM", locale).format(new Date(when));
                if (occasion >= 0) {
                    View dot = new View(home);
                    dot.setBackground(home.pill(isToday ? Color.WHITE : home.accent, 3));
                    FrameLayout.LayoutParams dotParams = new FrameLayout.LayoutParams(home.dp(5.0f), home.dp(5.0f), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
                    dotParams.bottomMargin = home.dp(1.0f);
                    cell.addView(dot, dotParams);
                    String name = home.getString(HijriEvents.nameRes(occasion));
                    spoken += "، " + name;
                    cell.setOnClickListener(v -> Toast.makeText(home, name, Toast.LENGTH_SHORT).show());
                }
                cell.setContentDescription(spoken);
            }
            week.addView(cell, new LinearLayout.LayoutParams(0, -1, 1f));
        }
    }
}
