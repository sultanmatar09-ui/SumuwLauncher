package com.sumuw.launcher;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.service.notification.StatusBarNotification;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * "Now": the things going on at this moment, in one short row of pills on the home screen (and a line on
 * the lock screen): a call, directions, a running timer, the torch left on, missed calls, an alarm due
 * soon, a prayer about to come in, and the live updates apps promote on Android 16.
 *
 * Everything is read on the phone from what is already there: the notifications Sara can see (with
 * notification access), the next alarm Android keeps, and the torch's state. Nothing is sent anywhere.
 */
final class NowBar {
    static final int CALL = 0;
    static final int NAVIGATION = 1;
    static final int TIMER = 2;
    static final int LIVE = 3;
    static final int TORCH = 4;
    static final int MISSED = 5;
    static final int PRAYER = 6;
    static final int ALARM = 7;

    /** Android 16's Notification.FLAG_PROMOTED_ONGOING (a live update), by value: Sara builds against Android 15. */
    static final int FLAG_PROMOTED_ONGOING = 0x00040000;
    /** Alarms further off than this aren't "now". */
    static final long ALARM_WINDOW = 12 * 3600000L;

    static final class Item {
        final int kind;
        final String text;
        /** What a tap opens (the app's own screen), when there is one. */
        final PendingIntent open;
        /** For a running timer or stopwatch: the chronometer's base on the elapsed-time clock, and its direction. */
        final long chronoBase;
        final boolean countDown;
        final boolean chrono;

        Item(int kind, String text, PendingIntent open) {
            this(kind, text, open, false, 0L, false);
        }

        Item(int kind, String text, PendingIntent open, boolean chrono, long chronoBase, boolean countDown) {
            this.kind = kind;
            this.text = text;
            this.open = open;
            this.chrono = chrono;
            this.chronoBase = chronoBase;
            this.countDown = countDown;
        }

        int glyph() {
            switch (kind) {
                case CALL:
                case MISSED:
                    return Glyphs.PHONE;
                case NAVIGATION:
                    return Glyphs.NAVIGATE;
                case TIMER:
                    return Glyphs.TIMER;
                case TORCH:
                    return Glyphs.FLASH;
                case PRAYER:
                    return Glyphs.KAABA;
                case ALARM:
                    return Glyphs.ALARM;
                default:
                    return Glyphs.SPARK;
            }
        }
    }

    private NowBar() {
    }

    /** What's going on now, most pressing first. */
    static List<Item> items(Context context, long now, boolean torchOn, String prayerSoon) {
        ArrayList<Item> list = new ArrayList<>();
        int missed = 0;
        PendingIntent missedOpen = null;
        for (StatusBarNotification sbn : DotsService.active()) {
            Notification n = sbn.getNotification();
            if (n == null) {
                continue;
            }
            Bundle extras = n.extras;
            String title = text(extras, Notification.EXTRA_TITLE);
            String body = text(extras, Notification.EXTRA_TEXT);
            String category = n.category;
            boolean ongoing = (n.flags & Notification.FLAG_ONGOING_EVENT) != 0;
            if (isMissedCall(n)) {
                missed += Math.max(1, n.number);
                if (missedOpen == null) {
                    missedOpen = n.contentIntent;
                }
                continue;
            }
            if (Notification.CATEGORY_CALL.equals(category) && ongoing) {
                list.add(new Item(CALL, title != null ? title : context.getString(R.string.now_call), n.contentIntent,
                        chronometer(extras), base(n, now), false));
                continue;
            }
            if (Notification.CATEGORY_NAVIGATION.equals(category) && ongoing) {
                list.add(new Item(NAVIGATION, first(title, body, context.getString(R.string.now_navigation)), n.contentIntent));
                continue;
            }
            boolean chrono = chronometer(extras);
            if (chrono && (ongoing || Notification.CATEGORY_STOPWATCH.equals(category) || Notification.CATEGORY_ALARM.equals(category))) {
                boolean down = extras != null && extras.getBoolean(Notification.EXTRA_CHRONOMETER_COUNT_DOWN, false);
                list.add(new Item(TIMER, first(title, body, context.getString(R.string.now_timer)), n.contentIntent, true, base(n, now), down));
                continue;
            }
            if ((n.flags & FLAG_PROMOTED_ONGOING) != 0) {
                list.add(new Item(LIVE, first(title, body, sbn.getPackageName()), n.contentIntent));
            }
        }
        if (torchOn) {
            list.add(new Item(TORCH, context.getString(R.string.now_torch), null));
        }
        if (missed > 0) {
            list.add(new Item(MISSED, missed == 1 ? context.getString(R.string.now_missed_one)
                    : context.getString(R.string.now_missed_many, number(context, missed)), missedOpen));
        }
        if (prayerSoon != null) {
            list.add(new Item(PRAYER, prayerSoon.replace('\n', ' '), null));
        }

        Collections.sort(list, (a, b) -> a.kind - b.kind);
        return list;
    }

    /** A missed call: Android 11's own category, or a dialer's channel named for it. */
    static boolean isMissedCall(Notification n) {
        if ("missed_call".equals(n.category)) {
            return true;
        }
        String channel = Build.VERSION.SDK_INT >= 26 ? n.getChannelId() : null;
        return channel != null && channel.toLowerCase(Locale.ROOT).contains("missed");
    }

    private static boolean chronometer(Bundle extras) {
        return extras != null && extras.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER, false);
    }

    /** The notification's "when" on the elapsed-time clock, which a Chronometer counts from. */
    private static long base(Notification n, long now) {
        return SystemClock.elapsedRealtime() + (n.when - now);
    }

    private static String text(Bundle extras, String key) {
        if (extras == null) {
            return null;
        }
        CharSequence value = extras.getCharSequence(key);
        if (value == null) {
            return null;
        }
        String text = value.toString().trim();
        return text.isEmpty() ? null : text;
    }

    private static String first(String a, String b, String fallback) {
        return a != null ? a : b != null ? b : fallback;
    }

    static String number(Context context, int value) {
        return String.format(context.getResources().getConfiguration().getLocales().get(0), "%d", value);
    }

    /** The camera whose flash is the torch, or null. */
    static String torchCamera(Context context) {
        try {
            CameraManager cameras = context.getSystemService(CameraManager.class);
            for (String id : cameras.getCameraIdList()) {
                CameraCharacteristics info = cameras.getCameraCharacteristics(id);
                Boolean flash = info.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                Integer facing = info.get(CameraCharacteristics.LENS_FACING);
                if (Boolean.TRUE.equals(flash) && facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    return id;
                }
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    /** The one line the lock screen shows: the most pressing thing going on, or null. */
    static String lockLine(Context context, long now, boolean torchOn, String prayerSoon) {
        List<Item> all = items(context, now, torchOn, prayerSoon);
        for (Item item : all) {
            if (item.kind != CALL && item.kind != LIVE) {
                return item.text;
            }
        }
        return all.isEmpty() ? null : all.get(0).text;
    }
}
