package com.sumuw.launcher;

import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/** App folders on the home grid. Stored as JSON in settings, so backups include them. */
final class Folders {

    static final class Folder {
        final String id;
        String name;
        /** A private folder: opening it asks for fingerprint, face or the phone's PIN. */
        boolean locked;
        final ArrayList<String> keys = new ArrayList<>();

        Folder(String id, String name) {
            this.id = id;
            this.name = name;
        }
    }

    private Folders() {
    }

    static List<Folder> load(SharedPreferences prefs) {
        ArrayList<Folder> folders = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(prefs.getString("folders", "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.getJSONObject(i);
                Folder folder = new Folder(item.getString("id"), item.optString("name"));
                folder.locked = item.optBoolean("locked", false);
                JSONArray keys = item.getJSONArray("keys");
                for (int k = 0; k < keys.length(); k++) {
                    folder.keys.add(keys.getString(k));
                }
                folders.add(folder);
            }
        } catch (Exception ignored) {
            // a damaged value just means no folders
        }
        return folders;
    }

    static void save(SharedPreferences prefs, List<Folder> folders) {
        JSONArray array = new JSONArray();
        try {
            for (Folder folder : folders) {
                if (folder.keys.isEmpty()) {
                    continue; // an empty folder disappears
                }
                JSONArray keys = new JSONArray();
                for (String key : folder.keys) {
                    keys.put(key);
                }
                JSONObject item = new JSONObject().put("id", folder.id).put("name", folder.name).put("keys", keys);
                if (folder.locked) {
                    item.put("locked", true);
                }
                array.put(item);
            }
        } catch (Exception ignored) {
        }
        prefs.edit().putString("folders", array.toString()).apply();
    }

    static Folder folderOf(List<Folder> folders, String key) {
        for (Folder folder : folders) {
            if (folder.keys.contains(key)) {
                return folder;
            }
        }
        return null;
    }

    static String newId() {
        return Long.toString(System.currentTimeMillis(), 36);
    }

    /** One UI style folder icon: a frosted rounded square showing up to four app icons. */
    static final class Icon extends Drawable {
        private final List<Drawable> icons;
        private final Paint background = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();

        Icon(List<Drawable> icons, int fill, int edge) {
            this.icons = icons;
            background.setColor(fill);
            rim.setColor(edge);
            rim.setStyle(Paint.Style.STROKE);
            rim.setStrokeWidth(2f);
        }

        @Override
        public void draw(Canvas canvas) {
            Rect b = getBounds();
            rect.set(b);
            float radius = rect.width() * 0.3f;
            canvas.drawRoundRect(rect, radius, radius, background);
            canvas.drawRoundRect(rect, radius, radius, rim);
            float pad = rect.width() * 0.14f;
            float gap = rect.width() * 0.07f;
            float cell = (rect.width() - pad * 2 - gap) / 2f;
            for (int i = 0; i < Math.min(4, icons.size()); i++) {
                int col = i % 2;
                int row = i / 2;
                int left = (int) (rect.left + pad + col * (cell + gap));
                int top = (int) (rect.top + pad + row * (cell + gap));
                Drawable icon = icons.get(i);
                Rect saved = new Rect(icon.getBounds());
                icon.setBounds(left, top, (int) (left + cell), (int) (top + cell));
                icon.draw(canvas);
                icon.setBounds(saved);
            }
        }

        @Override
        public void setAlpha(int alpha) {
            background.setAlpha(alpha);
        }

        @Override
        public void setColorFilter(ColorFilter colorFilter) {
            background.setColorFilter(colorFilter);
        }

        @Override
        public int getOpacity() {
            return PixelFormat.TRANSLUCENT;
        }
    }
}
