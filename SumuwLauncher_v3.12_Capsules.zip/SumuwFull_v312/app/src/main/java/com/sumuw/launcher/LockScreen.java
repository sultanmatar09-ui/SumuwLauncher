package com.sumuw.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.PowerManager;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.View;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * What Sara's live wallpaper shows while the phone is locked, and the user's choices for it: a wallpaper
 * of its own (or Home's), how much to dim it, the clock's size, side and colour, the card's look and
 * place, its second line, up to four small tools under it (battery, weather, the next prayer…), and a
 * message for whoever finds the phone. The lock itself stays the system's (fingerprint, face, PIN).
 */
final class LockScreen {
    static final String WALL = "lock_wall";
    static final String SAME = "same";
    static final String DIM = "lock_dim";
    static final int[] DIMS = {0, 15, 30, 45};
    static final String CLOCK_SIZE = "lock_clock_size";
    static final String CLOCK_SIDE = "lock_clock_side";
    static final String CLOCK_COLOR = "lock_clock_color";
    static final String CARD_STYLE = "lock_card_style";
    static final String LINE = "lock_line";
    static final String WIDGETS = "lock_widgets";
    static final String MESSAGE = "lock_message";
    static final String PRIVATE = "lock_private";

    static final int SIZE_AUTO = 0;
    static final int SIZE_SMALL = 1;
    static final int SIZE_MEDIUM = 2;
    static final int SIZE_LARGE = 3;
    static final int SIDE_AUTO = 0;
    static final int SIDE_CENTRE = 1;
    static final int SIDE_RIGHT = 2;
    static final int SIDE_LEFT = 3;
    /** Automatic (from the picture under it), white, the wallpaper's accent, gold, rose, turquoise. */
    static final int[] CLOCK_COLORS = {0, 0xFFFFFFFF, 1, 0xFFFFD27A, 0xFFFFB8CB, 0xFF8FE8D8};
    static final int GLASS = 0;
    static final int DARK = 1;
    static final int CLEAR = 2;
    static final int HIDDEN = 3;

    static final String[] LINES = {"prayer", "date", "event", "weather", "countdown", "none"};
    static final String[] WIDGET_KEYS = {"battery", "weather", "prayer", "notifications", "now", "event", "match", "date", "hijri", "salary", "khatma"};
    static final String DEFAULT_WIDGETS = "battery,weather,notifications";
    /** Up to eight tools: four to a page, and the pages take turns every few seconds (the lock screen can't be swiped). */
    static final int MOST_WIDGETS = 8;
    static final int PER_PAGE = 4;
    static final long PAGE_MS = 8000L;
    static final int MESSAGE_LENGTH = 70;

    private LockScreen() {
    }

    // ---------------------------------------------------------------- choices

    /** The lock screen's wallpaper: its own, or Home's (never the phone's own picture, which this is drawing over). */
    static String wallpaper(SharedPreferences prefs) {
        String own = prefs.getString(WALL, SAME);
        String id = SAME.equals(own) || !Wallpapers.isKnown(own) ? prefs.getString("wallpaper_style", Wallpapers.DEFAULT) : own;
        return Wallpapers.DEVICE.equals(id) || !Wallpapers.isKnown(id) ? Wallpapers.DEFAULT : id;
    }

    static int dim(SharedPreferences prefs) {
        return Math.max(0, Math.min(60, prefs.getInt(DIM, 0)));
    }

    static int clockSize(SharedPreferences prefs) {
        return Math.max(SIZE_AUTO, Math.min(SIZE_LARGE, prefs.getInt(CLOCK_SIZE, SIZE_AUTO)));
    }

    static int clockSide(SharedPreferences prefs) {
        return Math.max(SIDE_AUTO, Math.min(SIDE_LEFT, prefs.getInt(CLOCK_SIDE, SIDE_AUTO)));
    }

    static int clockColor(SharedPreferences prefs) {
        return Math.max(0, Math.min(CLOCK_COLORS.length - 1, prefs.getInt(CLOCK_COLOR, 0)));
    }

    static int cardStyle(SharedPreferences prefs) {
        return Math.max(GLASS, Math.min(HIDDEN, prefs.getInt(CARD_STYLE, GLASS)));
    }

    static String line(SharedPreferences prefs) {
        String line = prefs.getString(LINE, "prayer");
        for (String known : LINES) {
            if (known.equals(line)) {
                return line;
            }
        }
        return "prayer";
    }

    /** True when the lock screen's tools fill more than one page, so it redraws to turn them. */
    static boolean turnsPages(SharedPreferences prefs) {
        return cardStyle(prefs) != HIDDEN && widgets(prefs).size() > PER_PAGE;
    }

    static List<String> widgets(SharedPreferences prefs) {
        ArrayList<String> list = new ArrayList<>();
        for (String key : prefs.getString(WIDGETS, DEFAULT_WIDGETS).split(",")) {
            key = key.trim();
            if (isWidget(key) && !list.contains(key) && list.size() < MOST_WIDGETS) {
                list.add(key);
            }
        }
        return list;
    }

    static boolean isWidget(String key) {
        for (String known : WIDGET_KEYS) {
            if (known.equals(key)) {
                return true;
            }
        }
        return false;
    }

    /** Adds the tool at the end, or takes it away; false when there's no room for another. */
    static boolean toggleWidget(SharedPreferences prefs, String key) {
        List<String> list = widgets(prefs);
        if (list.contains(key)) {
            list.remove(key);
        } else if (list.size() >= MOST_WIDGETS) {
            return false;
        } else {
            list.add(key);
        }
        prefs.edit().putString(WIDGETS, TextUtils.join(",", list)).apply();
        return true;
    }

    static String message(SharedPreferences prefs) {
        String text = prefs.getString(MESSAGE, "").trim();
        return text.length() > MESSAGE_LENGTH ? text.substring(0, MESSAGE_LENGTH) : text;
    }

    /** Titles of events stay off the locked screen unless the user says otherwise. */
    static boolean hidesDetails(SharedPreferences prefs) {
        return prefs.getBoolean(PRIVATE, true);
    }

    static int widgetName(String key) {
        switch (key) {
            case "battery": return R.string.lockw_battery;
            case "weather": return R.string.lockw_weather;
            case "prayer": return R.string.lockw_prayer;
            case "notifications": return R.string.lockw_notifications;
            case "event": return R.string.lockw_event;
            case "match": return R.string.lockw_match;
            case "date": return R.string.lockw_date;
            case "hijri": return R.string.lockw_hijri;
            case "salary": return R.string.lockw_salary;
            case "now": return R.string.lockw_now;
            default: return R.string.lockw_khatma;
        }
    }

    static int widgetGlyph(String key) {
        switch (key) {
            case "battery": return Glyphs.SAVER;
            case "weather": return Glyphs.SUN;
            case "prayer": return Glyphs.KAABA;
            case "notifications": return Glyphs.BELL;
            case "event": return Glyphs.CALENDAR;
            case "match": return Glyphs.TROPHY;
            case "date": return Glyphs.CALENDAR;
            case "hijri": return Glyphs.MOON;
            case "salary": return Glyphs.TIMER;
            case "now": return Glyphs.SPARK;
            default: return Glyphs.NOTE;
        }
    }

    static int lineName(String key) {
        switch (key) {
            case "prayer": return R.string.lockl_prayer;
            case "date": return R.string.lockl_date;
            case "event": return R.string.lockl_event;
            case "weather": return R.string.lockl_weather;
            case "countdown": return R.string.lockl_countdown;
            default: return R.string.lockl_none;
        }
    }

    // ---------------------------------------------------------------- what the card says

    /** The second line of the card: the user's choice, or the date when there's nothing for it now. */
    static String secondLine(Context context, SharedPreferences prefs, long now) {
        String fallback = java.text.DateFormat.getDateInstance(java.text.DateFormat.LONG).format(new Date(now));
        switch (line(prefs)) {
            case "prayer":
                return prefs.getBoolean("prayer_on", true) ? Prayers.nextText(context, prefs, now) : fallback;
            case "event": {
                Agenda.Event event = nextEvent(context, now);
                if (event == null) {
                    return context.getString(R.string.lock_no_events);
                }
                String when = event.allDay ? context.getString(R.string.agenda_all_day) : time(context, event.begin);
                return hidesDetails(prefs) ? context.getString(R.string.lock_event_hidden, when) : when + "  " + event.title;
            }
            case "weather": {
                Weather.Now weather = Weather.cached(prefs);
                if (weather == null) {
                    return fallback;
                }
                Weather.Alert alert = Weather.alertsOn(prefs) ? Weather.cachedAlert(prefs, now) : null;
                return alert != null ? Weather.alertText(context, alert)
                        : Weather.degrees(weather.temp) + "، " + context.getString(Weather.descriptionRes(weather.code));
            }
            case "countdown": {
                List<Countdowns.Event> days = Countdowns.all(prefs, context.getString(R.string.countdown_salary), now);
                if (days.isEmpty()) {
                    return fallback;
                }
                Countdowns.Event first = days.get(0);
                int left = Countdowns.daysUntil(first.day, now);
                String when = left == 0 ? context.getString(R.string.countdown_today) : left == 1 ? context.getString(R.string.countdown_tomorrow)
                        : context.getResources().getQuantityString(R.plurals.days_after, left, local(left));
                return first.name + "، " + when;
            }
            case "none":
                return null;
            default:
                return fallback;
        }
    }

    /** A small tool under the card: an icon, a value, and a word under it. */
    static final class Widget {
        final String key;
        final Drawable icon;
        final String value;
        final String sub;

        Widget(String key, Drawable icon, String value, String sub) {
            this.key = key;
            this.icon = icon;
            this.value = value;
            this.sub = sub;
        }
    }

    /** The tool now, or null when it has nothing to show (no event today, no weather yet…). */
    static Widget widget(Context context, SharedPreferences prefs, String key, long now, int battery, boolean charging, int ink, int px) {
        switch (key) {
            case "battery": {
                StatusRing ring = new StatusRing(ink, px);
                ring.setNetworkVisible(false);
                PowerManager power = context.getSystemService(PowerManager.class);
                ring.setBattery(battery, charging, power != null && power.isPowerSaveMode());
                String value = battery < 0 ? "--" : NumberFormat.getPercentInstance().format(battery / 100.0);
                return new Widget(key, ring, value, context.getString(charging ? R.string.lock_charging : R.string.lockw_battery));
            }
            case "weather": {
                Weather.Now weather = Weather.cached(prefs);
                if (weather == null) {
                    return null;
                }
                Weather.Alert alert = Weather.alertsOn(prefs) ? Weather.cachedAlert(prefs, now) : null;
                String sub = alert != null ? context.getString("dust".equals(alert.kind) ? R.string.lock_dust : R.string.lock_rain)
                        : context.getString(R.string.lock_high, Weather.degrees(weather.max));
                return new Widget(key, new Weather.Icon(Weather.iconType(weather.code, weather.day), ink, px), Weather.degrees(weather.temp), sub);
            }
            case "prayer": {
                if (!prefs.getBoolean("prayer_on", true)) {
                    return null;
                }
                long[] next = Prayers.next(prefs, now);
                return new Widget(key, new Glyphs(Glyphs.KAABA, ink, px), context.getString(Prayers.NAMES[(int) next[0]]),
                        Prayers.timeText(context, prefs, next[1]));
            }
            case "notifications": {
                int count = AdaptiveClock.waitingNotifications();
                return new Widget(key, new Glyphs(Glyphs.BELL, ink, px), local(count), context.getString(R.string.lockw_notifications));
            }
            case "event": {
                Agenda.Event event = nextEvent(context, now);
                if (event == null) {
                    return null;
                }
                String when = event.allDay ? context.getString(R.string.agenda_all_day) : time(context, event.begin);
                return new Widget(key, new Glyphs(Glyphs.CALENDAR, ink, px), when,
                        hidesDetails(prefs) ? context.getString(R.string.lockw_event) : event.title);
            }
            case "match": {
                Matches.Match match = Matches.nextFavourite(prefs, now);
                if (match == null || match.time - now > 24 * 3600000L || match.time < now - 3 * 3600000L) {
                    return null;
                }
                String value = match.hasScore() ? local(match.homeScore) + "-" + local(match.awayScore) : time(context, match.time);
                return new Widget(key, new Glyphs(Glyphs.TROPHY, ink, px), value, Matches.arabic(match.home));
            }
            case "date":
                return new Widget(key, new Glyphs(Glyphs.CALENDAR, ink, px),
                        android.text.format.DateFormat.format("d", new Date(now)).toString(),
                        android.text.format.DateFormat.format("MMMM", new Date(now)).toString());
            case "hijri": {
                String label = HijriEvents.hijriLabel(now);
                int space = label.indexOf(' ');
                if (space <= 0) {
                    return null;
                }
                return new Widget(key, new Glyphs(Glyphs.MOON, ink, px), label.substring(0, space), label.substring(space + 1));
            }
            case "salary": {
                if (!prefs.getBoolean(Countdowns.PREF_SALARY_ON, true)) {
                    return null;
                }
                int days = Countdowns.daysUntil(Countdowns.nextSalary(prefs, now), now);
                return new Widget(key, new Glyphs(Glyphs.TIMER, ink, px), days == 0 ? context.getString(R.string.countdown_today) : local(days),
                        context.getString(days == 0 ? R.string.countdown_salary : R.string.lock_to_salary));
            }
            case "now": {
                String line = NowBar.lockLine(context, now, false, null);
                if (line == null) {
                    return null;
                }
                return new Widget(key, new Glyphs(Glyphs.SPARK, ink, px), line, context.getString(R.string.lockw_now));
            }
            default: {
                if (!Khatma.active(prefs) || Khatma.doneHalves(prefs) >= 60) {
                    return null;
                }
                return new Widget(key, new Glyphs(Glyphs.NOTE, ink, px), local(Khatma.nextJuz(prefs)), context.getString(R.string.lock_juz));
            }
        }
    }

    private static Agenda.Event nextEvent(Context context, long now) {
        try {
            if (!Agenda.permitted(context)) {
                return null;
            }
            // The lock screen draws on the main thread: the calendar is read in the background, then drawn again.
            for (Agenda.Event event : Agenda.recent(context, now, 1, SaraWallpaper::redrawAll)) {
                if (event.begin - now < 16 * 3600000L) {
                    return event;
                }
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private static String time(Context context, long at) {
        return android.text.format.DateFormat.getTimeFormat(context).format(new Date(at));
    }

    static String local(long value) {
        return NumberFormat.getIntegerInstance().format(value);
    }

    static String local(String digits) {
        try {
            return local(Long.parseLong(digits.trim()));
        } catch (Exception e) {
            return digits;
        }
    }

    // ---------------------------------------------------------------- drawing

    /** Where the card sits, or null when the user turned the card off. Its height follows what's in it. */
    static RectF cardRect(Context context, SharedPreferences prefs, int width, int height) {
        if (cardStyle(prefs) == HIDDEN) {
            return null;
        }
        float density = context.getResources().getDisplayMetrics().density;
        float scaled = context.getResources().getDisplayMetrics().scaledDensity;
        float cardWidth = Math.min(width - 40 * density, 360 * density);
        float cardHeight = 16 * density + 24 * scaled + 14 * density;
        if (!"none".equals(line(prefs))) {
            cardHeight += 22 * scaled;
        }
        if (!widgets(prefs).isEmpty()) {
            cardHeight += 12 * density + 30 * density + 18 * scaled + 14 * scaled;
        }
        if (widgets(prefs).size() > PER_PAGE) {
            cardHeight += 14 * density; // the page dots
        }
        int position = prefs.getInt(SaraWallpaper.POSITION, 2);
        float centerY = height * (position == 0 ? 0.33f : position == 1 ? 0.52f : 0.70f);
        float top = Math.max(height * 0.08f, Math.min(height * 0.84f - cardHeight, centerY - cardHeight / 2f));
        float left = (width - cardWidth) / 2f;
        return new RectF(left, top, left + cardWidth, top + cardHeight);
    }

    /** The wallpaper a little darker under the clock and the card, when the user wants it. */
    static void dim(Canvas canvas, int width, int height, SharedPreferences prefs) {
        int dim = dim(prefs);
        if (dim > 0) {
            canvas.drawColor(Color.argb(Math.round(dim * 2.55f), 0, 0, 0));
        }
    }

    /** Light text on the picture underneath, or dark: the wallpaper's own darkness, and the dimming. */
    static boolean darkUnder(Context context, SharedPreferences prefs, String id) {
        return Wallpapers.isDark(context, id) || dim(prefs) >= 30;
    }

    static void drawCard(Context context, SharedPreferences prefs, Canvas canvas, RectF card, boolean darkWallpaper, int battery, boolean charging) {
        float density = context.getResources().getDisplayMetrics().density;
        float scaled = context.getResources().getDisplayMetrics().scaledDensity;
        int style = cardStyle(prefs);
        boolean dark = style == DARK || darkWallpaper;
        int ink = dark ? Color.WHITE : 0xFF1C1B22;
        int soft = dark ? 0xD9FFFFFF : 0xC21C1B22;
        float radius = 28 * density;
        if (style == GLASS || style == DARK) {
            Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
            fill.setColor(style == DARK ? 0x99000000 : dark ? 0x2EFFFFFF : 0x59FFFFFF);
            canvas.drawRoundRect(card, radius, radius, fill);
            Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
            rim.setStyle(Paint.Style.STROKE);
            rim.setStrokeWidth(Math.max(1f, density));
            rim.setColor(style == DARK ? 0x26FFFFFF : dark ? 0x40FFFFFF : 0x80FFFFFF);
            canvas.drawRoundRect(card, radius, radius, rim);
        }
        boolean shadow = dark || style == CLEAR;
        long now = System.currentTimeMillis();
        String day = android.text.format.DateFormat.format("EEEE", new Date(now)).toString();
        String hijri = HijriEvents.hijriLabel(now);
        String first = hijri.length() > 0 ? day + " " + hijri : day;
        String second = secondLine(context, prefs, now);

        boolean rtl = TextUtils.getLayoutDirectionFromLocale(Locale.getDefault()) == View.LAYOUT_DIRECTION_RTL;
        float pad = 18 * density;
        float textLeft = card.left + pad;
        float textRight = card.right - pad;
        float available = textRight - textLeft;
        TextPaint big = textPaint(ink, 18 * scaled, 700, shadow);
        TextPaint small = textPaint(soft, 15 * scaled, 500, shadow);
        big.setTextAlign(rtl ? Paint.Align.RIGHT : Paint.Align.LEFT);
        small.setTextAlign(rtl ? Paint.Align.RIGHT : Paint.Align.LEFT);
        float x = rtl ? textRight : textLeft;
        float y = card.top + 16 * density + 18 * scaled;
        CharSequence line1 = TextUtils.ellipsize(first, big, available, TextUtils.TruncateAt.END);
        canvas.drawText(line1, 0, line1.length(), x, y, big);
        if (second != null && !"none".equals(line(prefs))) {
            y += 22 * scaled;
            CharSequence line2 = TextUtils.ellipsize(second, small, available, TextUtils.TruncateAt.END);
            canvas.drawText(line2, 0, line2.length(), x, y, small);
        }
        List<String> keys = widgets(prefs);
        if (keys.isEmpty()) {
            return;
        }
        // The tools in a row under a hairline, the first on the reading side.
        float rowTop = y + 6 * scaled + 12 * density;
        Paint hair = new Paint(Paint.ANTI_ALIAS_FLAG);
        hair.setColor(dark ? 0x33FFFFFF : 0x331C1B22);
        hair.setStrokeWidth(Math.max(1f, density * 0.7f));
        canvas.drawLine(textLeft, rowTop - 6 * density, textRight, rowTop - 6 * density, hair);
        int icon = Math.round(26 * density);
        List<Widget> shown = new ArrayList<>();
        for (String key : keys) {
            Widget widget = widget(context, prefs, key, now, battery, charging, ink, icon);
            if (widget != null) {
                shown.add(widget);
            }
        }
        if (shown.isEmpty()) {
            return;
        }
        int pages = (shown.size() + PER_PAGE - 1) / PER_PAGE;
        if (pages > 1) {
            // More than four: a page at a time, turning by itself, with small dots to say which.
            int page = (int) ((now / PAGE_MS) % pages);
            Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
            float r = 2.6f * density;
            float gap = 9 * density;
            float dotsY = rowTop + icon + 4 * density + 15 * scaled + 14 * scaled + 10 * density;
            float start = card.centerX() - gap * (pages - 1) / 2f;
            for (int i = 0; i < pages; i++) {
                int at = rtl ? pages - 1 - i : i;
                dot.setColor(at == page ? ink : (dark ? 0x59FFFFFF : 0x591C1B22));
                canvas.drawCircle(start + gap * i, dotsY, r, dot);
            }
            shown = new ArrayList<>(shown.subList(page * PER_PAGE, Math.min(shown.size(), (page + 1) * PER_PAGE)));
        }
        float slot = available / shown.size();
        TextPaint value = textPaint(ink, 15 * scaled, 700, shadow);
        TextPaint sub = textPaint(soft, 11.5f * scaled, 500, shadow);
        value.setTextAlign(Paint.Align.CENTER);
        sub.setTextAlign(Paint.Align.CENTER);
        for (int i = 0; i < shown.size(); i++) {
            Widget widget = shown.get(i);
            float centre = rtl ? textRight - slot * (i + 0.5f) : textLeft + slot * (i + 0.5f);
            if (!"battery".equals(widget.key)) {
                int left = Math.round(centre - icon / 2f);
                widget.icon.setBounds(left, Math.round(rowTop), left + icon, Math.round(rowTop) + icon);
                widget.icon.draw(canvas);
            } else {
                // The ring already holds the percentage: draw it a little bigger, and no value under it.
                int ring = Math.round(icon * 1.45f);
                int left = Math.round(centre - ring / 2f);
                int top = Math.round(rowTop - (ring - icon) / 2f + 2 * density);
                widget.icon.setBounds(left, top, left + ring, top + ring);
                widget.icon.draw(canvas);
            }
            float baseline = rowTop + icon + 4 * density + 15 * scaled;
            if (!"battery".equals(widget.key)) {
                CharSequence text = TextUtils.ellipsize(widget.value, value, slot - 6 * density, TextUtils.TruncateAt.END);
                canvas.drawText(text, 0, text.length(), centre, baseline, value);
            }
            if (widget.sub != null) {
                CharSequence text = TextUtils.ellipsize(widget.sub, sub, slot - 6 * density, TextUtils.TruncateAt.END);
                canvas.drawText(text, 0, text.length(), centre, baseline + 14 * scaled, sub);
            }
        }
    }

    /** The user's words for whoever finds the phone, low on the screen, above the system's own shortcuts. */
    static void drawMessage(Context context, SharedPreferences prefs, Canvas canvas, int width, int height, boolean dark) {
        String text = message(prefs);
        if (text.isEmpty()) {
            return;
        }
        float density = context.getResources().getDisplayMetrics().density;
        float scaled = context.getResources().getDisplayMetrics().scaledDensity;
        TextPaint paint = textPaint(Color.WHITE, 13.5f * scaled, 500, true);
        int maxWidth = Math.round(Math.min(width * 0.78f, 320 * density));
        StaticLayout layout = StaticLayout.Builder.obtain(text, 0, text.length(), paint, maxWidth)
                .setAlignment(Layout.Alignment.ALIGN_CENTER).setMaxLines(2).setEllipsize(TextUtils.TruncateAt.END).build();
        float wide = 0f;
        for (int i = 0; i < layout.getLineCount(); i++) {
            wide = Math.max(wide, layout.getLineWidth(i));
        }
        float padX = 14 * density;
        float padY = 8 * density;
        float centre = height * 0.86f;
        RectF pillBox = new RectF(width / 2f - wide / 2f - padX, centre - layout.getHeight() / 2f - padY,
                width / 2f + wide / 2f + padX, centre + layout.getHeight() / 2f + padY);
        Paint pill = new Paint(Paint.ANTI_ALIAS_FLAG);
        pill.setColor(0x59000000);
        canvas.drawRoundRect(pillBox, pillBox.height() / 2f, pillBox.height() / 2f, pill);
        canvas.save();
        canvas.translate((width - maxWidth) / 2f, centre - layout.getHeight() / 2f);
        layout.draw(canvas);
        canvas.restore();
    }

    /** {hours, minutes} colours of the clock, or null for the automatic ones. */
    static int[] clockColors(Context context, SharedPreferences prefs, String id) {
        int choice = clockColor(prefs);
        if (choice == 0) {
            return null;
        }
        int base = choice == 2 ? AdaptiveClock.mix(Wallpapers.accentFor(context, id), Color.WHITE, 0.35f) : CLOCK_COLORS[choice];
        return new int[]{base, AdaptiveClock.mix(base, Color.WHITE, 0.30f)};
    }

    private static TextPaint textPaint(int color, float size, int weight, boolean shadow) {
        TextPaint paint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(color);
        paint.setTextSize(size);
        paint.setTypeface(Fonts.of(weight));
        if (shadow) {
            paint.setShadowLayer(6f, 0f, 1f, 0x55000000);
        }
        return paint;
    }
}
