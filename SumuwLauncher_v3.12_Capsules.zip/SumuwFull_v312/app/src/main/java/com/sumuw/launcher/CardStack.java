package com.sumuw.launcher;

import android.content.Context;
import android.graphics.Outline;
import android.os.Bundle;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewOutlineProvider;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import java.util.ArrayList;
import java.util.List;

/**
 * One slot of the home cards, like One UI's widget stacks: several cards in the same place, a sideways
 * swipe goes to the next one, the dots at the bottom show where you are, and holding the stack opens
 * its editor. The glass belongs to the slot, so the cards slide inside it while the glass stays put.
 */
final class CardStack extends FrameLayout {
    interface Listener {
        void onPageChanged(CardStack stack, int index);

        void onLongPress(CardStack stack);
    }

    final int slot;
    private final ArrayList<View> pages = new ArrayList<>();
    private final ArrayList<String> types = new ArrayList<>();
    private final ArrayList<Boolean> pressable = new ArrayList<>();
    private final LinearLayout dots;
    private final int slop;
    private final float density;
    private int index;
    private Listener listener;
    /** When the user last turned this stack by hand (a swipe or the accessibility actions). */
    long lastUserChange;
    /** The page the user left it on, while a smart turn shows another; -1 when none. */
    int homeIndex = -1;
    /** True while the stack turns by itself, so the listener can tell it from the user's own swipe. */
    boolean turningBySelf;
    private int dotOn = 0xFFFFFFFF;
    private int dotOff = 0x59FFFFFF;
    private float downX;
    private float downY;
    private boolean dragging;
    private boolean longPressed;
    private boolean pressedDown;
    private final Runnable longPress = new Runnable() {
        @Override
        public void run() {
            if (!hasWindowFocus()) {
                return; // something inside (a news headline) already answered the long press with a menu
            }
            held();
        }
    };

    private void held() {
        longPressed = true;
        release();
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        MotionEvent cancel = MotionEvent.obtain(0L, 0L, MotionEvent.ACTION_CANCEL, 0f, 0f, 0);
        super.dispatchTouchEvent(cancel);
        cancel.recycle();
        if (listener != null) {
            listener.onLongPress(this);
        }
    }

    CardStack(Context context, int slot, final float radiusPx) {
        super(context);
        this.slot = slot;
        density = context.getResources().getDisplayMetrics().density;
        slop = ViewConfiguration.get(context).getScaledTouchSlop();
        setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radiusPx);
            }
        });
        setClipToOutline(true);
        dots = new LinearLayout(context);
        dots.setGravity(Gravity.CENTER);
        dots.setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        LayoutParams params = new LayoutParams(-2, Math.round(10 * density), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        params.bottomMargin = Math.round(3 * density);
        addView(dots, params);
    }

    void setListener(Listener value) {
        listener = value;
    }

    private boolean verticalDots;

    /** Wide, short cards: the dots stand in a column at the end side instead of a row at the bottom. */
    void setVerticalDots(boolean vertical) {
        verticalDots = vertical;
        dots.setOrientation(vertical ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        LayoutParams params = vertical
                ? new LayoutParams(Math.round(10 * density), -2, Gravity.END | Gravity.CENTER_VERTICAL)
                : new LayoutParams(-2, Math.round(10 * density), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        if (vertical) {
            params.setMarginEnd(Math.round(4 * density));
        } else {
            params.bottomMargin = Math.round(3 * density);
        }
        dots.setLayoutParams(params);
        updateDots();
    }

    void setDotColors(int on, int off) {
        dotOn = on;
        dotOff = off;
        updateDots();
    }

    /** Adds a card; pressable cards shrink a little under the finger, like the old single cards did. */
    void addPage(String type, View page, boolean pressableCard) {
        pages.add(page);
        types.add(type);
        pressable.add(pressableCard);
        addView(page, indexOfChild(dots), new LayoutParams(-1, -1));
        page.setVisibility(pages.size() - 1 == index ? VISIBLE : INVISIBLE);
        updateDots();
    }

    int size() {
        return pages.size();
    }

    int index() {
        return index;
    }

    String currentType() {
        return types.isEmpty() ? "" : types.get(index);
    }

    List<String> types() {
        return new ArrayList<>(types);
    }

    View page(int i) {
        return pages.get(i);
    }

    /** Shows a card straight away, without the slide. */
    void setIndex(int value) {
        if (pages.isEmpty()) {
            index = 0;
            return;
        }
        index = Math.max(0, Math.min(value, pages.size() - 1));
        for (int i = 0; i < pages.size(); i++) {
            View page = pages.get(i);
            page.animate().cancel();
            page.setTranslationX(0f);
            page.setAlpha(1f);
            page.setVisibility(i == index ? VISIBLE : INVISIBLE);
        }
        updateDots();
        describe();
    }

    void next() {
        go(true);
    }

    void previous() {
        go(false);
    }

    /** The cards go round: after the last one comes the first. */
    private void go(boolean forward) {
        int count = pages.size();
        if (count < 2) {
            return;
        }
        int target = (index + (forward ? 1 : -1) + count) % count;
        boolean rtl = getLayoutDirection() == LAYOUT_DIRECTION_RTL;
        // Forward slides the card out towards the reading start: left in English, right in Arabic.
        float direction = forward == rtl ? 1f : -1f;
        slide(target, direction, pages.get(index).getTranslationX());
    }

    private void slide(int target, float direction, float from) {
        final View out = pages.get(index);
        final View in = pages.get(target);
        float width = Math.max(1, getWidth());
        index = target;
        out.animate().cancel();
        in.animate().cancel();
        out.setTranslationX(from);
        out.animate().translationX(direction * width).alpha(0f).setDuration(220L)
                .setInterpolator(new DecelerateInterpolator()).withEndAction(() -> {
                    if (pages.indexOf(out) != index) {
                        out.setVisibility(INVISIBLE);
                    }
                    out.setTranslationX(0f);
                    out.setAlpha(1f);
                }).start();
        in.setVisibility(VISIBLE);
        in.setTranslationX(-direction * width * 0.6f);
        in.setAlpha(0f);
        in.animate().translationX(0f).alpha(1f).setDuration(260L).setInterpolator(new DecelerateInterpolator()).start();
        updateDots();
        describe();
        if (listener != null) {
            listener.onPageChanged(this, index);
        }
    }

    private void snapBack() {
        View current = pages.get(index);
        current.animate().translationX(0f).alpha(1f).setDuration(180L).setInterpolator(new DecelerateInterpolator()).start();
    }

    private void updateDots() {
        dots.removeAllViews();
        int count = pages.size();
        dots.setVisibility(count > 1 ? VISIBLE : GONE);
        if (count < 2) {
            return;
        }
        for (int i = 0; i < count; i++) {
            View dot = new View(getContext());
            android.graphics.drawable.GradientDrawable shape = new android.graphics.drawable.GradientDrawable();
            shape.setCornerRadius(3 * density);
            shape.setColor(i == index ? dotOn : dotOff);
            dot.setBackground(shape);
            int length = Math.round((i == index ? 12 : 4) * density);
            int thick = Math.round(4 * density);
            LinearLayout.LayoutParams params = verticalDots ? new LinearLayout.LayoutParams(thick, length)
                    : new LinearLayout.LayoutParams(length, thick);
            int gap = Math.round(2 * density);
            if (verticalDots) {
                params.setMargins(0, gap, 0, gap);
            } else {
                params.setMargins(gap, 0, gap, 0);
            }
            dots.addView(dot, params);
        }
    }

    private void describe() {
        if (pages.isEmpty()) {
            return;
        }
        View page = pages.get(index);
        CharSequence what = page.getContentDescription();
        String position = getContext().getString(R.string.cards_position, index + 1, pages.size());
        setContentDescription(what == null ? position : what + "، " + position);
    }

    // ---------------------------------------------------------------- touch

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = event.getX();
                downY = event.getY();
                dragging = false;
                longPressed = false;
                removeCallbacks(longPress);
                postDelayed(longPress, ViewConfiguration.getLongPressTimeout() + 180L);
                if (!pressable.isEmpty() && pressable.get(index)) {
                    pressedDown = true;
                    animate().scaleX(0.97f).scaleY(0.97f).setDuration(90L).setInterpolator(new DecelerateInterpolator()).start();
                }
                break;
            case MotionEvent.ACTION_MOVE:
                if (Math.abs(event.getX() - downX) > slop || Math.abs(event.getY() - downY) > slop) {
                    removeCallbacks(longPress);
                    release();
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                removeCallbacks(longPress);
                release();
                break;
            default:
                break;
        }
        if (longPressed) {
            return true; // the editor is open; the rest of this touch belongs to nobody
        }
        return super.dispatchTouchEvent(event);
    }

    private void release() {
        if (pressedDown) {
            pressedDown = false;
            animate().scaleX(1f).scaleY(1f).setDuration(160L).setInterpolator(new DecelerateInterpolator()).start();
        }
    }

    /** Called when a card inside handled the long press itself. */
    void cancelPendingLongPress() {
        removeCallbacks(longPress);
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent event) {
        if (event.getActionMasked() == MotionEvent.ACTION_MOVE && startsDrag(event)) {
            return true;
        }
        return false;
    }

    private boolean startsDrag(MotionEvent event) {
        if (dragging || pages.size() < 2) {
            return dragging;
        }
        float dx = event.getX() - downX;
        float dy = event.getY() - downY;
        if (Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy) * 1.3f) {
            dragging = true;
            removeCallbacks(longPress);
            release();
            if (getParent() != null) {
                getParent().requestDisallowInterceptTouchEvent(true);
            }
        }
        return dragging;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                return true;
            case MotionEvent.ACTION_MOVE:
                if (startsDrag(event)) {
                    View current = pages.get(index);
                    float dx = event.getX() - downX;
                    current.setTranslationX(dx);
                    current.setAlpha(1f - Math.min(0.6f, Math.abs(dx) / Math.max(1f, getWidth())));
                }
                return true;
            case MotionEvent.ACTION_UP:
                if (dragging) {
                    dragging = false;
                    finishDrag(event.getX() - downX);
                }
                return true;
            case MotionEvent.ACTION_CANCEL:
                if (dragging) {
                    dragging = false;
                    snapBack();
                }
                return true;
            default:
                return true;
        }
    }

    private void finishDrag(float dx) {
        if (Math.abs(dx) < Math.max(36 * density, getWidth() * 0.16f)) {
            snapBack();
            return;
        }
        boolean rtl = getLayoutDirection() == LAYOUT_DIRECTION_RTL;
        boolean forward = rtl ? dx > 0 : dx < 0;
        int count = pages.size();
        int target = (index + (forward ? 1 : -1) + count) % count;
        lastUserChange = System.currentTimeMillis();
        homeIndex = -1;
        slide(target, Math.signum(dx), pages.get(index).getTranslationX());
    }

    int indexOf(String type) {
        return types.indexOf(type);
    }

    /** Smart stacks: turn to this page by itself, with the usual slide (or at once before the first layout). */
    void turnBySelf(int target) {
        if (target < 0 || target >= pages.size() || target == index) {
            return;
        }
        turningBySelf = true;
        try {
            if (getWidth() == 0 || !isAttachedToWindow()) {
                setIndex(target);
                if (listener != null) {
                    listener.onPageChanged(this, index);
                }
            } else {
                boolean rtl = getLayoutDirection() == LAYOUT_DIRECTION_RTL;
                boolean forward = target > index;
                slide(target, forward == rtl ? 1f : -1f, 0f);
            }
        } finally {
            turningBySelf = false;
        }
    }

    /** For tests: the same result as a finished sideways swipe of this distance. */
    void simulateSwipe(float dx) {
        finishDrag(dx);
    }

    /** For tests: the stack being held. */
    void simulateLongPress() {
        held();
        longPressed = false;
    }

    // ---------------------------------------------------------------- accessibility

    @Override
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo info) {
        super.onInitializeAccessibilityNodeInfo(info);
        if (pages.size() > 1) {
            info.addAction(new AccessibilityNodeInfo.AccessibilityAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD,
                    getContext().getString(R.string.cards_next)));
            info.addAction(new AccessibilityNodeInfo.AccessibilityAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD,
                    getContext().getString(R.string.cards_previous)));
        }
        info.addAction(new AccessibilityNodeInfo.AccessibilityAction(AccessibilityNodeInfo.ACTION_LONG_CLICK,
                getContext().getString(R.string.cards_edit)));
    }

    @Override
    public boolean performAccessibilityAction(int action, Bundle arguments) {
        if (action == AccessibilityNodeInfo.ACTION_SCROLL_FORWARD && pages.size() > 1) {
            lastUserChange = System.currentTimeMillis();
            homeIndex = -1;
            next();
            return true;
        }
        if (action == AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD && pages.size() > 1) {
            lastUserChange = System.currentTimeMillis();
            homeIndex = -1;
            previous();
            return true;
        }
        if (action == AccessibilityNodeInfo.ACTION_LONG_CLICK && listener != null) {
            listener.onLongPress(this);
            return true;
        }
        return super.performAccessibilityAction(action, arguments);
    }
}
