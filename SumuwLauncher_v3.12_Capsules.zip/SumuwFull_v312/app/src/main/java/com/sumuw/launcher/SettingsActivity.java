package com.sumuw.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * One UI style settings: a large title, then rounded groups of rows. Changes that affect the look
 * bump "config_stamp" so the home screen rebuilds itself when you come back.
 */
public class SettingsActivity extends Activity {
    static final String VERSION_NAME = HomeActivity.VERSION_NAME;
    private static final int REQUEST_BACKUP = 41;
    private static final int REQUEST_RESTORE = 42;
    private static final int REQUEST_PHOTO = 43;
    static final int[] ACCENTS = {Color.rgb(101, 103, 191), Color.rgb(57, 117, 183), Color.rgb(194, 91, 125), Color.rgb(58, 137, 118)};
    static final int[] ACCENT_NAMES = {R.string.accent_iris, R.string.accent_ocean, R.string.accent_rose, R.string.accent_jade};

    private SharedPreferences prefs;
    private LinearLayout content;
    private boolean night;
    private int background;
    private int surface;
    private int text;
    private int subtext;
    private int divider;
    private int accent;

    @Override
    protected void onCreate(Bundle bundle) {
        Fonts.init(this);
        setTheme(Fonts.theme(true));
        super.onCreate(bundle);
        prefs = getSharedPreferences("duo_home", 0);
        night = Build.VERSION.SDK_INT >= 29
                && (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        background = night ? 0xFF000000 : 0xFFF2F2F5;
        surface = night ? 0xFF1C1C1F : 0xFFFFFFFF;
        text = night ? 0xFFF2F2F2 : 0xFF111114;
        subtext = night ? 0xFF9C9CA3 : 0xFF6E6E76;
        divider = night ? 0x1FFFFFFF : 0x14000000;
        ScrollView scroll = new ScrollView(this);
        settingsScroll = scroll;
        scroll.setBackgroundColor(background);
        scroll.setFillViewport(true);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), 0, dp(16), dp(24));
        // A tablet or an open foldable: the settings in a column of a comfortable width in the middle.
        int widthDp = getResources().getConfiguration().screenWidthDp;
        FrameLayout.LayoutParams contentParams = new FrameLayout.LayoutParams(widthDp > 720 ? dp(680) : -1, -2,
                Gravity.CENTER_HORIZONTAL);
        scroll.addView(content, contentParams);
        scroll.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View view, WindowInsets insets) {
                if (Build.VERSION.SDK_INT >= 30) {
                    Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                    view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                } else {
                    view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                            insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
                }
                return insets;
            }
        });
        setContentView(scroll);
        Window window = getWindow();
        window.setStatusBarColor(background);
        window.setNavigationBarColor(background);
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController controller = window.getInsetsController();
            if (controller != null) {
                int light = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                controller.setSystemBarsAppearance(night ? 0 : light, light);
            }
        } else if (!night) {
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        build(); // reflects permission changes made in system settings
        // Opened from the "Settings" button of the live wallpaper's preview: straight to its options.
        if (!scrolledToLock && getIntent() != null && getIntent().getComponent() != null
                && getIntent().getComponent().getClassName().endsWith(".LockWallpaperSettings") && lockGroup != null) {
            scrolledToLock = true;
            settingsScroll.post(() -> settingsScroll.scrollTo(0, Math.max(0, lockGroup.getTop() - dp(56))));
        }
    }

    private ScrollView settingsScroll;
    private LinearLayout lockGroup;
    private boolean scrolledToLock;

    /**
     * The card, the clock and their options show only where Sara's live wallpaper is on the lock screen.
     * When it isn't, say so before changing an option that would seem to do nothing.
     */
    private void lockOption(Runnable change) {
        if (SaraWallpaper.onLock(this)) {
            change.run();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.lock_wallpaper))
                .setMessage(getString(SaraWallpaper.onHome(this) ? R.string.lock_options_home_only : R.string.lock_options_need_live))
                .setPositiveButton(getString(R.string.lock_wallpaper_apply), (dialog, which) -> openLiveWallpaper())
                .setNeutralButton(getString(R.string.lock_options_anyway), (dialog, which) -> change.run())
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void build() {
        accent = currentAccent();
        content.removeAllViews();
        TextView title = label(getString(R.string.settings_title), 32, text, 700);
        title.setGravity(Gravity.BOTTOM | Gravity.START);
        title.setPadding(dp(12), 0, dp(12), dp(20));
        content.addView(title, new LinearLayout.LayoutParams(-1, dp(150)));

        LinearLayout look = group(getString(R.string.section_look));
        String wallpaper = prefs.getString("wallpaper_style", Wallpapers.DEFAULT);
        if (!Wallpapers.isKnown(wallpaper)) {
            wallpaper = Wallpapers.DEFAULT;
        }
        row(look, getString(R.string.theme_studio), getString(R.string.theme_studio_summary), null, v -> themeStudio());
        row(look, getString(R.string.wallpapers), getString(Wallpapers.nameRes(wallpaper)), null, v -> pickWallpaper());
        row(look, getString(R.string.font_style), getString(Fonts.SYSTEM.equals(Fonts.style(prefs)) ? R.string.font_system : R.string.font_naskh),
                null, v -> pickFont());
        if (!Wallpapers.DEVICE.equals(wallpaper)) {
            toggle(look, getString(R.string.system_wallpaper), getString(R.string.system_wallpaper_summary),
                    prefs.getBoolean(SystemWallpaper.ENABLED, true), true, (button, on) -> {
                        prefs.edit().putBoolean(SystemWallpaper.ENABLED, on).apply();
                        if (on) {
                            SystemWallpaper.reset(this);
                            bumpStamp();
                        }
                    });
        }
        if (Wallpapers.PHOTO.equals(wallpaper)) {
            int blur = prefs.getInt("photo_blur", 0);
            row(look, getString(R.string.photo_blur), getString(BLUR_NAMES[Math.max(0, Math.min(3, blur))]), null, v -> pickBlur());
        }
        row(look, getString(R.string.accent_colors), prefs.getBoolean("accent_auto", false) ? getString(R.string.accent_auto)
                : getString(ACCENT_NAMES[accentIndex()]), null, v -> pickAccent());
        String pack = prefs.getString("icon_pack", "");
        String packName = pack.length() == 0 ? null : IconPack.installed(this).get(pack);
        row(look, getString(R.string.icon_pack), packName != null ? packName : getString(R.string.icon_pack_none), null, v -> pickIconPack());
        String shape = prefs.getString(IconShapes.PREF, IconShapes.SYSTEM);
        row(look, getString(R.string.icon_shape), getString(IconShapes.name(shape)), null, v -> pickShape());
        if (!Wallpapers.DEVICE.equals(wallpaper) && !Wallpapers.PHOTO.equals(wallpaper)) {
            toggle(look, getString(R.string.ambience_day), getString(R.string.ambience_day_summary),
                    prefs.getBoolean(Ambience.PREF_DAY, true), true, (button, on) -> ambience(Ambience.PREF_DAY, on));
            toggle(look, getString(R.string.ambience_weather), getString(R.string.ambience_weather_summary),
                    prefs.getBoolean(Ambience.PREF_WEATHER, true), true, (button, on) -> ambience(Ambience.PREF_WEATHER, on));
        }
        toggle(look, getString(R.string.ambience_occasions), getString(R.string.ambience_occasions_summary),
                prefs.getBoolean(Ambience.PREF_OCCASIONS, true), true, (button, on) -> ambience(Ambience.PREF_OCCASIONS, on));
        toggle(look, getString(R.string.hide_labels), getString(R.string.hide_labels_summary),
                prefs.getBoolean("hide_labels", false), true, (button, on) -> {
                    prefs.edit().putBoolean("hide_labels", on).apply();
                    bumpStamp();
                });
        row(look, getString(R.string.icon_style), getString(IconTint.name(IconTint.style(prefs))), null, v -> pickIconStyle());
        boolean granted = DotsService.accessGranted(this);
        boolean dotsOn = prefs.getBoolean("notification_dots", true);
        toggle(look, getString(R.string.notification_dots),
                getString(granted || !dotsOn ? R.string.dots_summary : R.string.dots_need_access),
                dotsOn && granted, true, (button, on) -> {
                    prefs.edit().putBoolean("notification_dots", on).apply();
                    bumpStamp();
                    if (on && !DotsService.accessGranted(this)) {
                        openNotificationAccess();
                    }
                });

        LinearLayout home = group(getString(R.string.section_home));
        toggle(home, getString(R.string.app_drawer), getString(R.string.app_drawer_summary),
                prefs.getBoolean("app_drawer", true), true, (button, on) -> {
                    prefs.edit().putBoolean("app_drawer", on).apply();
                    bumpStamp();
                });
        row(home, getString(R.string.add_favorite), getString(R.string.add_favorite_summary), null, v -> homeAction("add_favorite"));
        row(home, getString(R.string.reorder_apps), getString(R.string.reorder_summary), null, v -> homeAction("reorder"));
        row(home, getString(R.string.hidden_apps), getString(R.string.hidden_summary), null, v -> homeAction("hidden"));
        row(home, getString(R.string.sort_title), getString(HomeActivity.sortLabel(HomeActivity.sortModeFrom(prefs))), null, v -> pickSort());
        boolean scroll = "scroll".equals(prefs.getString("app_layout", "pages"));
        row(home, getString(R.string.layout_title), getString(scroll ? R.string.layout_scroll : R.string.layout_pages), null, v -> pickLayout());
        boolean dense = prefs.getBoolean("grid_dense", false);
        row(home, getString(R.string.density_title),
                getString(dense ? R.string.density_compact : R.string.density_roomy) + getString(R.string.list_separator)
                        + getString(R.string.density_hint), null, v -> pickDensity());
        toggle(home, getString(R.string.hide_dock_apps), getString(R.string.hide_dock_apps_summary),
                prefs.getBoolean("hide_dock_apps", true), true, (button, on) -> {
                    prefs.edit().putBoolean("hide_dock_apps", on).apply();
                    bumpStamp();
                });
        int dockColumns = prefs.getInt("dock_columns", 1) == 2 ? 2 : 1;
        int dockPages = Math.max(1, Math.min(3, prefs.getInt("dock_pages", 1)));
        int[] pageNames = {R.string.dock_pages_one, R.string.dock_pages_two, R.string.dock_pages_three};
        row(home, getString(R.string.dock_layout), getString(R.string.dock_layout_value,
                getString(dockColumns == 2 ? R.string.dock_two_columns : R.string.dock_one_column), getString(pageNames[dockPages - 1])),
                null, v -> pickDock());
        int watched = Breaker.apps(prefs).size();
        row(home, getString(R.string.breaker_title), watched == 0 ? getString(R.string.breaker_settings_none)
                : getString(R.string.breaker_settings_some, localNumber(watched), localNumber(Breaker.minutes(prefs))), null, v -> pickBreakerMinutes());
        toggle(home, getString(R.string.now_bar), getString(R.string.now_bar_summary),
                prefs.getBoolean("now_bar", true), true, (button, on) -> {
                    prefs.edit().putBoolean("now_bar", on).apply();
                    bumpStamp();
                });
        toggle(home, getString(R.string.dock_suggestions), getString(R.string.dock_suggestions_summary),
                prefs.getBoolean("dock_suggestions", true), true, (button, on) -> {
                    prefs.edit().putBoolean("dock_suggestions", on).apply();
                    bumpStamp();
                });
        row(home, getString(R.string.cards_settings), getString(R.string.cards_settings_summary), null, v -> homeAction("edit_cards"));
        row(home, getString(R.string.card_size), getString(HomeActivity.cardSizeName(prefs.getInt("card_size", 100))) + getString(R.string.list_separator)
                + getString(R.string.card_size_hint), null, v -> pickCardSize());
        toggle(home, getString(R.string.smart_stack), getString(R.string.smart_stack_summary),
                prefs.getBoolean("smart_stack", true), true, (button, on) -> {
                    prefs.edit().putBoolean("smart_stack", on).apply();
                    bumpStamp();
                });
        row(home, getString(R.string.card_matches), getString(R.string.match_settings_summary), null, v -> homeAction("match_settings"));
        row(home, getString(R.string.auto_folders), getString(R.string.auto_folders_summary), null, v -> homeAction("auto_folders"));
        row(home, getString(R.string.import_title), getString(R.string.import_summary), null, v -> homeAction("nova_import"));
        if (prefs.contains("folders_before_auto")) {
            row(home, getString(R.string.auto_folders_undo), null, null, v -> homeAction("undo_auto_folders"));
        }
        row(home, getString(R.string.card_countdown), getString(R.string.countdown_settings_summary,
                prefs.getBoolean(Countdowns.PREF_SALARY_ON, true) ? getString(R.string.countdown_salary_day,
                        localNumber(Countdowns.salaryDay(prefs))) : getString(R.string.countdown_salary_off)), null, v -> homeAction("countdowns"));
        row(home, getString(R.string.card_khatma), Khatma.active(prefs) ? getString(R.string.khatma_progress, localNumber(Khatma.doneHalves(prefs) / 2))
                : getString(R.string.khatma_start_hint), null, v -> homeAction("khatma"));
        row(home, getString(R.string.kids_mode), getString(R.string.kids_mode_summary), null, v -> homeAction("kids"));
        String tvMode = prefs.getString(TvHome.PREF, TvHome.AUTO);
        row(home, getString(R.string.tv_mode), getString(TvHome.ON.equals(tvMode) ? R.string.tv_mode_on
                : TvHome.OFF.equals(tvMode) ? R.string.tv_mode_off : R.string.tv_mode_auto), null, v -> pickTvMode());
        boolean isDefault = DefaultHome.isDefault(this);
        row(home, getString(R.string.set_default_home), getString(isDefault ? R.string.default_on : R.string.default_off), null,
                v -> DefaultHome.ask(this));

        LinearLayout lock = group(getString(R.string.section_lock));
        lockGroup = lock;
        row(lock, getString(R.string.lock_editor_row), getString(R.string.lock_editor_summary), null,
                v -> startActivity(new Intent(this, LockEditorActivity.class)));
        boolean onLock = SaraWallpaper.onLock(this);
        int liveState = onLock ? R.string.lock_wallpaper_on : SaraWallpaper.onHome(this) ? R.string.lock_wallpaper_home_only : R.string.lock_wallpaper_off;
        row(lock, getString(R.string.lock_wallpaper), getString(liveState), null, v -> openLiveWallpaper());
        int position = prefs.getInt(SaraWallpaper.POSITION, 2);
        row(lock, getString(R.string.lock_info_position), getString(POSITION_NAMES[Math.max(0, Math.min(2, position))]), null,
                v -> lockOption(this::pickPosition));
        int clockStyle = AdaptiveClock.style(prefs);
        row(lock, getString(R.string.lock_clock), getString(R.string.lock_clock_summary, getString(AdaptiveClock.NAMES[clockStyle])), null,
                v -> lockOption(this::pickClockStyle));
        if (clockStyle != AdaptiveClock.OFF) {
            // It counts the notifications waiting, which Sara reads with the notification access.
            String compactSummary = getString(R.string.lock_clock_compact_summary)
                    + (DotsService.accessGranted(this) ? "" : getString(R.string.list_separator) + getString(R.string.lock_clock_compact_needs));
            toggle(lock, getString(R.string.lock_clock_compact), compactSummary,
                    prefs.getBoolean(AdaptiveClock.COMPACT_PREF, true), true, (button, on) -> {
                        prefs.edit().putBoolean(AdaptiveClock.COMPACT_PREF, on).apply();
                        SaraWallpaper.redrawAll();
                    });
        }
        boolean tapOn = prefs.getBoolean("double_tap_lock", true);
        boolean serviceOn = LockService.enabled(this);
        toggle(lock, getString(R.string.double_tap_lock),
                getString(tapOn && !serviceOn ? R.string.double_tap_lock_needs : R.string.double_tap_lock_summary),
                tapOn, true, (button, on) -> {
                    prefs.edit().putBoolean("double_tap_lock", on).apply();
                    if (on && !LockService.enabled(this)) {
                        openAccessibility();
                    } else if (!on && LockService.release()) {
                        Toast.makeText(this, getString(R.string.lock_service_released), Toast.LENGTH_LONG).show();
                    }
                    build();
                });
        if (serviceOn) {
            TextView note = new TextView(this);
            note.setText(getString(R.string.lock_service_note));
            note.setTextSize(12);
            note.setTextColor(0x99888888 | 0xFF000000);
            note.setPadding(dp(16), 0, dp(16), dp(10));
            note.setTypeface(Fonts.of(400));
            lock.addView(note);
        }
        if ("samsung".equalsIgnoreCase(Build.MANUFACTURER)) {
            row(lock, getString(R.string.good_lock), getString(R.string.good_lock_summary), null, v -> openGoodLock());
        }

        LinearLayout shade = group(getString(R.string.section_shade));
        toggle(shade, getString(R.string.control_center), getString(R.string.control_center_summary),
                prefs.getBoolean("control_center", true), true, (button, on) -> {
                    prefs.edit().putBoolean("control_center", on).apply();
                });
        toggle(shade, getString(R.string.cc_handle), getString(R.string.cc_handle_summary),
                prefs.getBoolean("cc_handle", true), true, (button, on) -> {
                    prefs.edit().putBoolean("cc_handle", on).apply();
                });
        row(shade, getString(R.string.cc_edit_title), getString(R.string.cc_edit_summary), null, v -> homeAction("edit_control_center"));
        toggle(shade, getString(R.string.pull_down_notifications), getString(R.string.pull_down_summary),
                prefs.getBoolean("pull_down_notifications", true), true, (button, on) -> {
                    prefs.edit().putBoolean("pull_down_notifications", on).apply();
                });
        boolean access = DotsService.accessGranted(this);
        toggle(shade, getString(R.string.sara_shade),
                getString(access ? R.string.sara_shade_summary : R.string.sara_shade_needs_access),
                prefs.getBoolean("sara_shade", true), true, (button, on) -> {
                    prefs.edit().putBoolean("sara_shade", on).apply();
                    if (on && !DotsService.accessGranted(this)) {
                        openNotificationAccess();
                    }
                    build();
                });
        if ("samsung".equalsIgnoreCase(Build.MANUFACTURER)) {
            row(shade, getString(R.string.quickstar), getString(R.string.quickstar_summary), null, v -> openGoodLock());
        }

        LinearLayout places = group(getString(R.string.section_places));
        boolean policy = getSystemService(android.app.NotificationManager.class) != null
                && getSystemService(android.app.NotificationManager.class).isNotificationPolicyAccessGranted();
        toggle(places, getString(R.string.haram_mode), getString(R.string.haram_mode_summary),
                prefs.getBoolean(Haram.PREF, true), true, (button, on) -> {
                    prefs.edit().putBoolean(Haram.PREF, on).apply();
                    build();
                });
        if (prefs.getBoolean(Haram.PREF, true)) {
            toggle(places, getString(R.string.haram_silence), getString(policy ? R.string.haram_silence_summary : R.string.haram_silence_needs),
                    prefs.getBoolean(Haram.PREF_SILENCE, true), true, (button, on) -> {
                        prefs.edit().putBoolean(Haram.PREF_SILENCE, on).apply();
                        if (on && !policy) {
                            try {
                                startActivity(new Intent(android.provider.Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
                            } catch (Exception ignored) {
                            }
                        }
                    });
        }
        java.util.Set<String> cars = AudioRoutes.cars(prefs);
        row(places, getString(R.string.my_car), cars.isEmpty() ? getString(R.string.my_car_summary)
                : android.text.TextUtils.join(getString(R.string.list_separator), cars), null, v -> pickCars());
        toggle(places, getString(R.string.drive_mode), getString(R.string.drive_mode_summary),
                prefs.getBoolean(AudioRoutes.PREF_DRIVE, true), true, (button, on) -> prefs.edit().putBoolean(AudioRoutes.PREF_DRIVE, on).apply());
        toggle(places, getString(R.string.parking_setting), getString(R.string.parking_setting_summary),
                prefs.getBoolean(AudioRoutes.PREF_PARKING, true), true, (button, on) -> {
                    prefs.edit().putBoolean(AudioRoutes.PREF_PARKING, on).apply();
                    if (!on) {
                        AudioRoutes.clearParking(prefs);
                    }
                });

        LinearLayout check = group(getString(R.string.section_app_check));
        row(check, getString(R.string.app_check_row), getString(R.string.app_check_summary), null, v -> checkApps());

        LinearLayout privacy = group(getString(R.string.section_privacy));
        toggle(privacy, getString(R.string.privacy_mode), getString(R.string.privacy_mode_summary),
                prefs.getBoolean("privacy_mode", false), true, (button, on) -> {
                    prefs.edit().putBoolean("privacy_mode", on).apply();
                    bumpStamp();
                });
        toggle(privacy, getString(R.string.lock_hidden), getString(R.string.lock_hidden_summary),
                prefs.getBoolean("lock_hidden", true), true, (button, on) -> prefs.edit().putBoolean("lock_hidden", on).apply());

        TodaySettings.addSection(this, prefs, content, todayUi());

        LinearLayout backup = group(getString(R.string.section_backup));
        row(backup, getString(R.string.backup_save), getString(R.string.backup_save_summary), null, v -> startBackup());
        row(backup, getString(R.string.backup_restore), getString(R.string.backup_restore_summary), null, v -> startRestore());

        LinearLayout about = group(getString(R.string.about));
        row(about, getString(R.string.app_name), getString(R.string.version_label, VERSION_NAME), null, null);
    }

    private TodaySettings.Ui todayUi() {
        return new TodaySettings.Ui() {
            @Override
            public LinearLayout group(String title) {
                return SettingsActivity.this.group(title);
            }

            @Override
            public View row(LinearLayout group, String title, String summary, View.OnClickListener click) {
                return SettingsActivity.this.row(group, title, summary, null, click);
            }

            @Override
            public View toggle(LinearLayout group, String title, String summary, boolean checked, CompoundButton.OnCheckedChangeListener change) {
                return SettingsActivity.this.toggle(group, title, summary, checked, true, change);
            }

            @Override
            public void refresh() {
                build();
            }
        };
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        boolean granted = results.length > 0 && results[0] == android.content.pm.PackageManager.PERMISSION_GRANTED;
        TodaySettings.onPermissionResult(this, prefs, requestCode, granted, todayUi());
    }

    // ---------------------------------------------------------------- actions

    static final int[] BLUR_NAMES = {R.string.blur_none, R.string.blur_light, R.string.blur_medium, R.string.blur_strong};
    static final int[] POSITION_NAMES = {R.string.position_top, R.string.position_middle, R.string.position_bottom};

    private int currentAccent() {
        if (prefs.getBoolean("accent_auto", false)) {
            String id = prefs.getString("wallpaper_style", Wallpapers.DEFAULT);
            return Wallpapers.accentFor(this, Wallpapers.isKnown(id) ? id : Wallpapers.DEFAULT);
        }
        return prefs.getInt("accent", ACCENTS[0]);
    }

    private void pickBlur() {
        String[] names = new String[BLUR_NAMES.length];
        for (int i = 0; i < names.length; i++) {
            names[i] = getString(BLUR_NAMES[i]);
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.photo_blur))
                .setSingleChoiceItems(names, prefs.getInt("photo_blur", 0), (dialog, which) -> {
                    prefs.edit().putInt("photo_blur", which).apply();
                    bumpStamp();
                    dialog.dismiss();
                    build();
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void pickIconPack() {
        final java.util.Map<String, String> packs = IconPack.installed(this);
        if (packs.isEmpty()) {
            Toast.makeText(this, getString(R.string.icon_pack_none_installed), Toast.LENGTH_LONG).show();
            prefs.edit().putString("icon_pack", "").apply();
            return;
        }
        final String[] ids = new String[packs.size() + 1];
        String[] names = new String[packs.size() + 1];
        ids[0] = "";
        names[0] = getString(R.string.icon_pack_none);
        int i = 1;
        int selected = 0;
        String current = prefs.getString("icon_pack", "");
        for (java.util.Map.Entry<String, String> pack : packs.entrySet()) {
            ids[i] = pack.getKey();
            names[i] = pack.getValue();
            if (pack.getKey().equals(current)) {
                selected = i;
            }
            i++;
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.icon_pack))
                .setSingleChoiceItems(names, selected, (dialog, which) -> {
                    prefs.edit().putString("icon_pack", ids[which]).apply();
                    bumpStamp();
                    dialog.dismiss();
                    build();
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void openLiveWallpaper() {
        try {
            startActivity(SaraWallpaper.chooser(this));
        } catch (Exception e) {
            try {
                startActivity(new Intent(android.app.WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER));
            } catch (Exception ignored) {
            }
        }
    }

    private String localNumber(int value) {
        return java.text.NumberFormat.getInstance().format(value);
    }

    private void ambience(String key, boolean on) {
        prefs.edit().putBoolean(key, on).apply();
        bumpStamp();
        SaraWallpaper.redrawAll();
    }

    // ---------------------------------------------------------------- theme studio

    void themeStudio() {
        final List<ThemeStudio.Theme> themes = new java.util.ArrayList<>(ThemeStudio.builtIn(this));
        themes.addAll(ThemeStudio.saved(prefs));
        String[] names = new String[themes.size() + 2];
        for (int i = 0; i < themes.size(); i++) {
            ThemeStudio.Theme theme = themes.get(i);
            names[i] = theme.builtIn ? getString(R.string.theme_ready, theme.name) : theme.name;
        }
        names[themes.size()] = getString(R.string.theme_save_current);
        names[themes.size() + 1] = getString(R.string.theme_import);
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.theme_studio))
                .setItems(names, (dialog, which) -> {
                    if (which < themes.size()) {
                        themeOptions(themes.get(which));
                    } else if (which == themes.size()) {
                        saveTheme();
                    } else {
                        importTheme();
                    }
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void themeOptions(final ThemeStudio.Theme theme) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle(theme.name)
                .setMessage(getString(R.string.theme_apply_message))
                .setPositiveButton(getString(R.string.theme_apply), (d, w) -> applyTheme(theme))
                .setNeutralButton(getString(R.string.theme_share), (d, w) -> shareTheme(theme));
        if (!theme.builtIn) {
            builder.setNegativeButton(getString(R.string.theme_delete), (d, w) -> {
                ThemeStudio.delete(prefs, theme.name);
                Toast.makeText(this, getString(R.string.theme_deleted, theme.name), Toast.LENGTH_SHORT).show();
            });
        }
        builder.show();
    }

    void applyTheme(ThemeStudio.Theme theme) {
        ThemeStudio.apply(prefs, theme.values);
        Toast.makeText(this, getString(R.string.theme_applied, theme.name), Toast.LENGTH_SHORT).show();
        build();
    }

    private void saveTheme() {
        final EditText name = new EditText(this);
        name.setSingleLine(true);
        name.setHint(getString(R.string.theme_name_hint));
        name.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(40)});
        FrameLayout box = new FrameLayout(this);
        box.setPadding(dp(22), dp(8), dp(22), 0);
        box.addView(name);
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.theme_save_current))
                .setView(box)
                .setPositiveButton(getString(R.string.theme_save), (d, w) -> {
                    String text = name.getText().toString().trim();
                    if (text.isEmpty()) {
                        text = getString(R.string.theme_mine);
                    }
                    ThemeStudio.save(prefs, text, ThemeStudio.capture(prefs));
                    Toast.makeText(this, getString(R.string.theme_saved, text), Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void shareTheme(ThemeStudio.Theme theme) {
        String text = getString(R.string.theme_share_text, theme.name) + "\n" + ThemeStudio.code(theme.name, theme.values);
        Intent send = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text);
        try {
            startActivity(Intent.createChooser(send, getString(R.string.theme_share)));
        } catch (Exception ignored) {
        }
    }

    /** Paste a code (what's on the clipboard is filled in when it holds one). */
    void importTheme() {
        final EditText code = new EditText(this);
        code.setHint(getString(R.string.theme_paste_hint));
        code.setMaxLines(4);
        try {
            android.content.ClipboardManager clip = getSystemService(android.content.ClipboardManager.class);
            if (clip != null && clip.hasPrimaryClip() && clip.getPrimaryClip().getItemCount() > 0) {
                CharSequence pasted = clip.getPrimaryClip().getItemAt(0).getText();
                if (pasted != null && pasted.toString().contains(ThemeStudio.PREFIX)) {
                    code.setText(pasted);
                }
            }
        } catch (Exception ignored) {
        }
        FrameLayout box = new FrameLayout(this);
        box.setPadding(dp(22), dp(8), dp(22), 0);
        box.addView(code);
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.theme_import))
                .setView(box)
                .setPositiveButton(getString(R.string.theme_apply), (d, w) -> {
                    ThemeStudio.Theme theme = ThemeStudio.read(code.getText().toString());
                    if (theme == null) {
                        Toast.makeText(this, getString(R.string.theme_bad_code), Toast.LENGTH_LONG).show();
                        return;
                    }
                    String name = theme.name.isEmpty() ? getString(R.string.theme_imported) : theme.name;
                    ThemeStudio.save(prefs, name, theme.values);
                    applyTheme(new ThemeStudio.Theme(name, theme.values, false));
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void pickTvMode() {
        final String[] modes = {TvHome.AUTO, TvHome.ON, TvHome.OFF};
        String[] names = {getString(R.string.tv_mode_auto), getString(R.string.tv_mode_on), getString(R.string.tv_mode_off)};
        int selected = java.util.Arrays.asList(modes).indexOf(prefs.getString(TvHome.PREF, TvHome.AUTO));
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.tv_mode))
                .setSingleChoiceItems(names, Math.max(0, selected), (dialog, which) -> {
                    prefs.edit().putString(TvHome.PREF, modes[which]).apply();
                    bumpStamp();
                    dialog.dismiss();
                    build();
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void pickCardSize() {
        int[] sizes = HomeActivity.CARD_SIZES;
        String[] names = new String[sizes.length];
        int selected = 1;
        for (int i = 0; i < sizes.length; i++) {
            names[i] = getString(HomeActivity.cardSizeName(sizes[i]));
            if (sizes[i] == prefs.getInt("card_size", 100)) {
                selected = i;
            }
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.card_size))
                .setSingleChoiceItems(names, selected, (dialog, which) -> {
                    prefs.edit().putInt("card_size", sizes[which]).apply();
                    bumpStamp();
                    dialog.dismiss();
                    build();
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void pickBreakerMinutes() {
        String[] names = new String[Breaker.MINUTE_CHOICES.length];
        int selected = 0;
        for (int i = 0; i < names.length; i++) {
            names[i] = getString(R.string.breaker_minutes_n, localNumber(Breaker.MINUTE_CHOICES[i]));
            if (Breaker.MINUTE_CHOICES[i] == Breaker.minutes(prefs)) {
                selected = i;
            }
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.breaker_minutes_title))
                .setSingleChoiceItems(names, selected, (dialog, which) -> {
                    prefs.edit().putInt(Breaker.MINUTES, Breaker.MINUTE_CHOICES[which]).apply();
                    dialog.dismiss();
                    build();
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    /** Columns first, then pages: two short questions. */
    private void pickDock() {
        String[] columns = {getString(R.string.dock_one_column), getString(R.string.dock_two_columns)};
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.dock_columns_title))
                .setSingleChoiceItems(columns, prefs.getInt("dock_columns", 1) == 2 ? 1 : 0, (dialog, which) -> {
                    prefs.edit().putInt("dock_columns", which + 1).apply();
                    dialog.dismiss();
                    String[] pages = {getString(R.string.dock_pages_one), getString(R.string.dock_pages_two), getString(R.string.dock_pages_three)};
                    new AlertDialog.Builder(this)
                            .setTitle(getString(R.string.dock_pages_title))
                            .setSingleChoiceItems(pages, Math.max(0, Math.min(2, prefs.getInt("dock_pages", 1) - 1)), (d2, page) -> {
                                prefs.edit().putInt("dock_pages", page + 1).putInt("dock_page", 0).apply();
                                bumpStamp();
                                d2.dismiss();
                                build();
                            })
                            .setNegativeButton(getString(R.string.cancel), (d2, w2) -> {
                                bumpStamp();
                                build();
                            })
                            .show();
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void pickIconStyle() {
        String current = IconTint.style(prefs);
        String[] names = new String[IconTint.STYLES.length];
        int selected = 0;
        for (int i = 0; i < names.length; i++) {
            names[i] = getString(IconTint.name(IconTint.STYLES[i]));
            if (IconTint.STYLES[i].equals(current)) {
                selected = i;
            }
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.icon_style))
                .setSingleChoiceItems(names, selected, (dialog, which) -> {
                    prefs.edit().putString(IconTint.PREF, IconTint.STYLES[which])
                            .putBoolean("themed_icons", IconTint.THEMED.equals(IconTint.STYLES[which])).apply();
                    bumpStamp();
                    dialog.dismiss();
                    build();
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void pickShape() {
        String current = prefs.getString(IconShapes.PREF, IconShapes.SYSTEM);
        String[] names = new String[IconShapes.SHAPES.length];
        int selected = 0;
        for (int i = 0; i < names.length; i++) {
            names[i] = getString(IconShapes.name(IconShapes.SHAPES[i]));
            if (IconShapes.SHAPES[i].equals(current)) {
                selected = i;
            }
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.icon_shape))
                .setSingleChoiceItems(names, selected, (dialog, which) -> {
                    prefs.edit().putString(IconShapes.PREF, IconShapes.SHAPES[which]).apply();
                    bumpStamp();
                    dialog.dismiss();
                    build();
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    /** The Bluetooth devices seen so far; the ticked ones are the car (names with "car", "Toyota"... are found by themselves). */
    private void pickCars() {
        final java.util.ArrayList<String> devices = new java.util.ArrayList<>(AudioRoutes.seen(prefs));
        if (devices.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle(getString(R.string.my_car))
                    .setMessage(getString(R.string.my_car_none))
                    .setPositiveButton(getString(R.string.done), null)
                    .show();
            return;
        }
        String[] names = devices.toArray(new String[0]);
        boolean[] checked = new boolean[names.length];
        for (int i = 0; i < names.length; i++) {
            checked[i] = AudioRoutes.isCar(prefs, names[i]);
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.my_car))
                .setMultiChoiceItems(names, checked, (dialog, which, on) -> AudioRoutes.markCar(prefs, devices.get(which), on))
                .setPositiveButton(getString(R.string.done), (dialog, which) -> build())
                .show();
    }

    /**
     * Looks, on the phone itself, for what makes apps seem frozen from the launcher: apps paused (Digital
     * Wellbeing, focus or bedtime modes, a parental or "freezer" app), archived (Android 15), work apps
     * turned off, and an accessibility service left on. Tapping an app opens its page in the settings.
     */
    void checkApps() {
        final android.content.pm.LauncherApps launcher = getSystemService(android.content.pm.LauncherApps.class);
        final android.os.UserManager users = getSystemService(android.os.UserManager.class);
        new Thread(() -> {
            final java.util.ArrayList<String> names = new java.util.ArrayList<>();
            final java.util.ArrayList<Runnable> actions = new java.util.ArrayList<>();
            int paused = 0;
            int archived = 0;
            int off = 0;
            try {
                for (android.os.UserHandle user : launcher.getProfiles()) {
                    boolean quiet = !user.equals(android.os.Process.myUserHandle()) && users.isQuietModeEnabled(user);
                    for (android.content.pm.LauncherActivityInfo info : launcher.getActivityList(null, user)) {
                        android.content.pm.ApplicationInfo app = info.getApplicationInfo();
                        int state = quiet ? HomeActivity.STATE_PROFILE_OFF : HomeActivity.archived(app) ? HomeActivity.STATE_ARCHIVED
                                : app != null && (app.flags & android.content.pm.ApplicationInfo.FLAG_SUSPENDED) != 0 ? HomeActivity.STATE_PAUSED
                                : HomeActivity.STATE_READY;
                        if (state == HomeActivity.STATE_READY) {
                            continue;
                        }
                        if (state == HomeActivity.STATE_PAUSED) {
                            paused++;
                        } else if (state == HomeActivity.STATE_ARCHIVED) {
                            archived++;
                        } else {
                            off++;
                        }
                        final String pkg = info.getComponentName().getPackageName();
                        int why = state == HomeActivity.STATE_PAUSED ? R.string.app_state_paused
                                : state == HomeActivity.STATE_ARCHIVED ? R.string.app_state_archived : R.string.app_state_profile_off;
                        names.add(info.getLabel() + getString(R.string.list_separator) + getString(why));
                        actions.add(() -> Permissions.openAppSettingsFor(this, pkg));
                    }
                }
            } catch (Exception ignored) {
            }
            final boolean service = LockService.enabled(this);
            final String summary = paused + archived + off == 0 ? getString(R.string.app_check_none)
                    : getString(R.string.app_check_found, java.text.NumberFormat.getIntegerInstance().format(paused + archived + off));
            runOnUiThread(() -> {
                if (isFinishing()) {
                    return;
                }
                if (service) {
                    names.add(getString(R.string.app_check_service));
                    actions.add(() -> {
                        prefs.edit().putBoolean("double_tap_lock", false).apply();
                        if (!LockService.release()) {
                            openAccessibility();
                        }
                        build();
                    });
                }
                AlertDialog.Builder dialog = new AlertDialog.Builder(this).setTitle(getString(R.string.app_check_row))
                        .setPositiveButton(getString(R.string.done), null);
                if (names.isEmpty()) {
                    dialog.setMessage(summary + "\n\n" + getString(R.string.app_check_tip));
                } else {
                    dialog.setItems(names.toArray(new String[0]), (d, which) -> actions.get(which).run());
                    dialog.setTitle(getString(R.string.app_check_row) + getString(R.string.list_separator) + summary);
                }
                dialog.show();
            });
        }, "app-check").start();
    }

    private void pickFont() {
        final String[] styles = {Fonts.NASKH, Fonts.SYSTEM};
        String[] names = {getString(R.string.font_naskh), getString(R.string.font_system)};
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.font_style))
                .setSingleChoiceItems(names, Fonts.SYSTEM.equals(Fonts.style(prefs)) ? 1 : 0, (dialog, which) -> {
                    prefs.edit().putString(Fonts.PREF, styles[which]).apply();
                    Fonts.init(this);
                    bumpStamp(); // Home rebuilds itself in the new font
                    dialog.dismiss();
                    recreate();
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void pickClockStyle() {
        String[] names = new String[AdaptiveClock.NAMES.length];
        for (int i = 0; i < names.length; i++) {
            names[i] = getString(AdaptiveClock.NAMES[i]);
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.lock_clock))
                .setSingleChoiceItems(names, AdaptiveClock.style(prefs), (dialog, which) -> {
                    prefs.edit().putInt(AdaptiveClock.PREF, which).apply();
                    SaraWallpaper.redrawAll();
                    dialog.dismiss();
                    build();
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void pickPosition() {
        String[] names = new String[POSITION_NAMES.length];
        for (int i = 0; i < names.length; i++) {
            names[i] = getString(POSITION_NAMES[i]);
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.lock_info_position))
                .setSingleChoiceItems(names, prefs.getInt(SaraWallpaper.POSITION, 2), (dialog, which) -> {
                    prefs.edit().putInt(SaraWallpaper.POSITION, which).apply();
                    SaraWallpaper.redrawAll();
                    dialog.dismiss();
                    build();
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void openAccessibility() {
        try {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        } catch (Exception ignored) {
        }
    }

    /** Opens Good Lock if it's installed, otherwise its page in the Galaxy Store. */
    private void openGoodLock() {
        String pkg = "com.samsung.android.goodlock";
        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        try {
            if (launch != null) {
                startActivity(launch);
            } else {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("samsungapps://ProductDetail/" + pkg)));
            }
        } catch (Exception e) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://galaxystore.samsung.com/detail/" + pkg)));
            } catch (Exception ignored) {
            }
        }
    }

    private int accentIndex() {
        for (int i = 0; i < ACCENTS.length; i++) {
            if (ACCENTS[i] == accent) {
                return i;
            }
        }
        return 0;
    }

    void bumpStamp() {
        prefs.edit().putInt("config_stamp", prefs.getInt("config_stamp", 0) + 1).apply();
    }

    /** The wallpapers as small pictures, three to a row, so you see them before choosing. */
    private void pickWallpaper() {
        final java.util.ArrayList<String> ids = new java.util.ArrayList<>(java.util.Arrays.asList(Wallpapers.IDS));
        ids.remove(Wallpapers.DEVICE);
        if (Wallpapers.hasPhoto(this)) {
            ids.add(Wallpapers.PHOTO);
        }
        ids.add(Wallpapers.DEVICE);
        ids.add(""); // pick a picture from the phone
        String current = prefs.getString("wallpaper_style", Wallpapers.DEFAULT);
        ScrollView scroll = new ScrollView(this);
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        grid.setPadding(dp(14), dp(6), dp(14), dp(6));
        scroll.addView(grid);
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(getString(R.string.wallpapers))
                .setView(scroll)
                .setNegativeButton(getString(R.string.cancel), null)
                .create();
        LinearLayout row = null;
        for (int i = 0; i < ids.size(); i++) {
            if (i % 3 == 0) {
                row = new LinearLayout(this);
                LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1, -2);
                rowParams.topMargin = dp(8);
                grid.addView(row, rowParams);
            }
            final String id = ids.get(i);
            View tile = wallpaperTile(id, id.equals(current), () -> {
                dialog.dismiss();
                if (id.isEmpty()) {
                    Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*");
                    try {
                        startActivityForResult(pick, REQUEST_PHOTO);
                    } catch (Exception ignored) {
                    }
                    return;
                }
                prefs.edit().putString("wallpaper_style", id).apply();
                bumpStamp();
                build();
            });
            LinearLayout.LayoutParams tileParams = new LinearLayout.LayoutParams(0, -2, 1f);
            tileParams.setMargins(dp(4), 0, dp(4), 0);
            row.addView(tile, tileParams);
        }
        while (row != null && row.getChildCount() < 3) {
            row.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f)); // keeps the last row's tiles the same width
        }
        dialog.show();
    }

    /** One choice: the wallpaper drawn small with rounded corners, its name under it, a ring when chosen. */
    private View wallpaperTile(String id, boolean chosen, Runnable choose) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER_HORIZONTAL);
        tile.setPadding(0, dp(4), 0, dp(4));
        FrameLayout frame = new FrameLayout(this);
        int width = dp(84);
        int height = dp(150);
        ImageView picture = new ImageView(this);
        picture.setScaleType(ImageView.ScaleType.CENTER_CROP);
        if (id.isEmpty() || Wallpapers.DEVICE.equals(id)) {
            android.graphics.drawable.GradientDrawable plain = new android.graphics.drawable.GradientDrawable();
            plain.setColor(night ? 0xFF2A2A30 : 0xFFE9E9EF);
            plain.setCornerRadius(dp(14));
            picture.setBackground(plain);
            TextView sign = label(id.isEmpty() ? "+" : "▢", id.isEmpty() ? 34 : 26, subtext, 400);
            sign.setGravity(Gravity.CENTER);
            frame.addView(picture, new FrameLayout.LayoutParams(width, height));
            frame.addView(sign, new FrameLayout.LayoutParams(width, height));
        } else {
            android.graphics.Bitmap small = android.graphics.Bitmap.createBitmap(width, height, android.graphics.Bitmap.Config.ARGB_8888);
            android.graphics.drawable.Drawable art = Wallpapers.create(this, id);
            art.setBounds(0, 0, width, height);
            art.draw(new android.graphics.Canvas(small));
            picture.setImageBitmap(small);
            picture.setClipToOutline(true);
            picture.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(View view, android.graphics.Outline outline) {
                    outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), dp(14));
                }
            });
            frame.addView(picture, new FrameLayout.LayoutParams(width, height));
        }
        if (chosen) {
            View ring = new View(this);
            android.graphics.drawable.GradientDrawable outline = new android.graphics.drawable.GradientDrawable();
            outline.setCornerRadius(dp(16));
            outline.setStroke(dp(3), accent);
            ring.setBackground(outline);
            FrameLayout.LayoutParams ringParams = new FrameLayout.LayoutParams(width + dp(6), height + dp(6));
            ringParams.setMargins(-dp(3), -dp(3), -dp(3), -dp(3));
            frame.addView(ring, ringParams);
            frame.setClipChildren(false);
            tile.setClipChildren(false);
        }
        tile.addView(frame, new LinearLayout.LayoutParams(width, height));
        String name = id.isEmpty() ? getString(R.string.wallpaper_pick_photo) : getString(Wallpapers.nameRes(id));
        TextView caption = label(name, 12, chosen ? accent : text, chosen ? 700 : 400);
        caption.setGravity(Gravity.CENTER);
        caption.setMaxLines(2);
        caption.setPadding(0, dp(6), 0, 0);
        tile.addView(caption, new LinearLayout.LayoutParams(-1, -2));
        tile.setContentDescription(name + (chosen ? getString(R.string.list_separator) + getString(R.string.state_on) : ""));
        tile.setOnClickListener(v -> choose.run());
        tile.setBackground(new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(0x22000000), null,
                new android.graphics.drawable.ColorDrawable(Color.WHITE)));
        return tile;
    }

    private void pickAccent() {
        String[] names = new String[ACCENTS.length + 1];
        names[0] = getString(R.string.accent_auto);
        for (int i = 0; i < ACCENTS.length; i++) {
            names[i + 1] = getString(ACCENT_NAMES[i]);
        }
        int selected = prefs.getBoolean("accent_auto", false) ? 0 : accentIndex() + 1;
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.accent_colors))
                .setSingleChoiceItems(names, selected, (dialog, which) -> {
                    if (which == 0) {
                        prefs.edit().putBoolean("accent_auto", true).apply();
                    } else {
                        prefs.edit().putBoolean("accent_auto", false).putInt("accent", ACCENTS[which - 1]).apply();
                    }
                    bumpStamp();
                    dialog.dismiss();
                    build();
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void pickSort() {
        final String[] modes = HomeActivity.SORT_MODES;
        String current = HomeActivity.sortModeFrom(prefs);
        String[] names = new String[modes.length];
        int selected = 0;
        for (int i = 0; i < modes.length; i++) {
            names[i] = getString(HomeActivity.sortLabel(modes[i]));
            if (modes[i].equals(current)) {
                selected = i;
            }
        }
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.sort_title))
                .setSingleChoiceItems(names, selected, (dialog, which) -> {
                    prefs.edit().putString("sort_mode", modes[which]).putInt("page", 0).apply();
                    bumpStamp();
                    dialog.dismiss();
                    build();
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void pickLayout() {
        String[] names = {getString(R.string.layout_pages), getString(R.string.layout_scroll)};
        int selected = "scroll".equals(prefs.getString("app_layout", "pages")) ? 1 : 0;
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.layout_title))
                .setSingleChoiceItems(names, selected, (dialog, which) -> {
                    prefs.edit().putString("app_layout", which == 1 ? "scroll" : "pages").putInt("page", 0).apply();
                    bumpStamp();
                    dialog.dismiss();
                    build();
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    private void pickDensity() {
        String[] names = {getString(R.string.density_roomy), getString(R.string.density_compact)};
        int selected = prefs.getBoolean("grid_dense", false) ? 1 : 0;
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.density_title))
                .setSingleChoiceItems(names, selected, (dialog, which) -> {
                    prefs.edit().putBoolean("grid_dense", which == 1).apply();
                    bumpStamp();
                    dialog.dismiss();
                    build();
                })
                .setNegativeButton(getString(R.string.cancel), null)
                .show();
    }

    /** Asks the home screen to do something that needs its app list, then returns to it. */
    private void homeAction(String action) {
        prefs.edit().putString("pending_action", action).apply();
        finish();
    }

    private void openNotificationAccess() {
        Intent intent;
        if (Build.VERSION.SDK_INT >= 30) {
            intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS)
                    .putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME, new ComponentName(this, DotsService.class).flattenToString());
        } else {
            intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
        }
        try {
            startActivity(intent);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
            } catch (Exception ignored) {
            }
        }
    }

    private void startBackup() {
        String date = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE)
                .setType("application/json")
                .putExtra(Intent.EXTRA_TITLE, "SaraHome-" + date + ".json");
        try {
            startActivityForResult(intent, REQUEST_BACKUP);
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.backup_failed), Toast.LENGTH_LONG).show();
        }
    }

    private void startRestore() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
        try {
            startActivityForResult(intent, REQUEST_RESTORE);
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.backup_failed), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == DefaultHome.REQUEST) {
            if (!DefaultHome.isDefault(this)) {
                DefaultHome.openSettings(this);
            }
            build();
            return;
        }
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            return;
        }
        final Uri uri = data.getData();
        if (requestCode == REQUEST_PHOTO) {
            new Thread(() -> {
                boolean ok = Wallpapers.importPhoto(this, uri);
                runOnUiThread(() -> {
                    if (ok) {
                        prefs.edit().putString("wallpaper_style", Wallpapers.PHOTO).apply();
                        bumpStamp();
                        build();
                    } else {
                        Toast.makeText(this, getString(R.string.photo_failed), Toast.LENGTH_LONG).show();
                    }
                });
            }).start();
            return;
        }
        if (requestCode == REQUEST_BACKUP) {
            try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                out.write(Backup.exportAll(this, prefs).getBytes(StandardCharsets.UTF_8));
                Toast.makeText(this, getString(R.string.backup_saved), Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, getString(R.string.backup_failed), Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == REQUEST_RESTORE) {
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                byte[] chunk = new byte[8192];
                int read;
                while ((read = in.read(chunk)) > 0 && buffer.size() < 12_000_000) {
                    buffer.write(chunk, 0, read);
                }
                Backup.restoreAll(this, prefs, new String(buffer.toByteArray(), StandardCharsets.UTF_8));
                ReminderReceiver.schedule(this);
                Toast.makeText(this, getString(R.string.backup_restored), Toast.LENGTH_SHORT).show();
                build();
            } catch (Exception e) {
                Toast.makeText(this, getString(R.string.backup_failed), Toast.LENGTH_LONG).show();
            }
        }
    }

    // ---------------------------------------------------------------- building blocks

    LinearLayout group(String title) {
        if (!TextUtils.isEmpty(title)) {
            TextView header = label(title, 14, accent, 600);
            header.setPadding(dp(14), dp(18), dp(14), dp(8));
            content.addView(header);
        }
        LinearLayout group = new LinearLayout(this);
        group.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(surface);
        shape.setCornerRadius(dp(24));
        group.setBackground(shape);
        group.setClipToOutline(true);
        content.addView(group, new LinearLayout.LayoutParams(-1, -2));
        return group;
    }

    View row(LinearLayout group, String title, String summary, View end, View.OnClickListener click) {
        if (group.getChildCount() > 0) {
            View line = new View(this);
            line.setBackgroundColor(divider);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, Math.max(1, dp(0.6f)));
            params.setMarginStart(dp(20));
            params.setMarginEnd(dp(20));
            group.addView(line, params);
        }
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setMinimumHeight(dp(64));
        row.setPadding(dp(20), dp(12), dp(16), dp(12));
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.addView(label(title, 17, text, 400));
        if (!TextUtils.isEmpty(summary)) {
            TextView sub = label(summary, 13, end == null && click != null ? accent : subtext, 400);
            sub.setPadding(0, dp(2), 0, 0);
            texts.addView(sub);
        }
        row.addView(texts, new LinearLayout.LayoutParams(0, -2, 1f));
        if (end != null) {
            row.addView(end);
        }
        if (click != null) {
            row.setBackground(new RippleDrawable(ColorStateList.valueOf(night ? 0x22FFFFFF : 0x14000000), null, null));
            row.setOnClickListener(click);
        }
        group.addView(row, new LinearLayout.LayoutParams(-1, -2));
        return row;
    }

    View toggle(LinearLayout group, String title, String summary, boolean checked, boolean enabled,
                CompoundButton.OnCheckedChangeListener change) {
        final Switch toggle = new Switch(this);
        toggle.setChecked(checked);
        toggle.setEnabled(enabled);
        toggle.setOnCheckedChangeListener(change);
        View row = row(group, title, summary, toggle, enabled ? v -> toggle.toggle() : null);
        row.setAlpha(enabled ? 1f : 0.5f);
        return row;
    }

    TextView label(String value, int sizeSp, int color, int weight) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sizeSp);
        view.setTextColor(color);
        view.setTypeface(Fonts.of(weight));
        return view;
    }

    int textColor() {
        return text;
    }

    int subtextColor() {
        return subtext;
    }

    int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
