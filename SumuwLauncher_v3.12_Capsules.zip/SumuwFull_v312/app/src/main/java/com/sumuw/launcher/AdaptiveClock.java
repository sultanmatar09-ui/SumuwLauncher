package com.sumuw.launcher;

import android.app.Notification;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.service.notification.StatusBarNotification;
import android.text.TextPaint;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * The adaptive clock of the live lock screen. It looks at the wallpaper for the calmest open space (few
 * edges, little detail), so it sits beside a face or a building instead of over it, and takes the biggest
 * size that space allows: large and light over an empty sky, smaller and bolder over a busy photo. Its
 * colour follows the brightness underneath, the minutes take the wallpaper's own accent, and it shrinks
 * towards the top when notifications are waiting, so they have room below it.
 */
final class AdaptiveClock {
    static final String PREF = "lock_clock";
    static final String COMPACT_PREF = "lock_clock_compact";
    static final int OFF = 0;
    static final int STACKED = 1;
    static final int LINE = 2;
    static final int[] NAMES = {R.string.lock_clock_off, R.string.lock_clock_stacked, R.string.lock_clock_line};

    /** Mean edge strength under which a spot counts as open space. */
    static final float CALM = 0.045f;
    /** A cell this busy is part of something (a face, a branch, a building), not open space. */
    private static final float DETAIL = 0.08f;
    private static final float GAP = 0.18f; // between the hours and the minutes, in digit heights

    static final class Placement {
        final RectF box;
        final float textSize;
        final int align; // -1 left, 0 centre, 1 right
        final int weight;
        final boolean light;
        final float busy;
        final float fraction; // width of the clock against the screen

        Placement(RectF box, float textSize, int align, int weight, boolean light, float busy, float fraction) {
            this.box = box;
            this.textSize = textSize;
            this.align = align;
            this.weight = weight;
            this.light = light;
            this.busy = busy;
            this.fraction = fraction;
        }
    }

    // The wallpaper is read once per picture and size, then kept: summed-area tables of edge strength and brightness.
    private static String cachedKey;
    private static int gridW;
    private static int gridH;
    private static float[] busySum;
    private static float[] lightSum;
    private static float[] detailSum;

    private AdaptiveClock() {
    }

    static int style(SharedPreferences prefs) {
        return Math.max(OFF, Math.min(LINE, prefs.getInt(PREF, STACKED)));
    }

    /** Notifications the lock screen would list (not ongoing ones like music or downloads). */
    static int waitingNotifications() {
        int count = 0;
        for (StatusBarNotification sbn : DotsService.active()) {
            Notification notification = sbn.getNotification();
            if (sbn.isOngoing() || !sbn.isClearable() || notification == null) {
                continue;
            }
            if ((notification.flags & Notification.FLAG_GROUP_SUMMARY) != 0) {
                continue;
            }
            count++;
        }
        return count;
    }

    static String[] timeParts(Context context, long now) {
        Locale locale = Locale.getDefault();
        boolean h24 = android.text.format.DateFormat.is24HourFormat(context);
        Date date = new Date(now);
        // No leading zero on the hour: "٣" over "٤٧" reads better than a lone dot of a zero.
        return new String[]{new SimpleDateFormat(h24 ? "H" : "h", locale).format(date), new SimpleDateFormat("mm", locale).format(date)};
    }

    static TextPaint paint(float size, int weight) {
        TextPaint paint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        paint.setTextSize(size);
        paint.setTypeface(Fonts.of(weight));
        return paint;
    }

    // ---------------------------------------------------------------- reading the wallpaper

    private static String key(Context context, String id, int width, int height) {
        String key = id + "/" + width + "x" + height;
        if (Wallpapers.PHOTO.equals(id)) {
            File file = new File(context.getFilesDir(), Wallpapers.PHOTO_FILE);
            key += "/" + file.lastModified() + "/" + context.getSharedPreferences("duo_home", 0).getInt("photo_blur", 0);
        }
        return key;
    }

    static synchronized void analyse(Context context, String id, int width, int height) {
        String key = key(context, id, width, height);
        if (key.equals(cachedKey)) {
            return;
        }
        int w = 48;
        int h = Math.max(24, Math.round(w * height / (float) Math.max(1, width)));
        // Drawn at twice the grid and folded down, so thin details (stars, branches) still count.
        int sw = w * 2;
        int sh = h * 2;
        Bitmap small = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(small);
        Drawable art = Wallpapers.create(context, id);
        art.setBounds(0, 0, sw, sh);
        art.draw(canvas);
        int[] px = new int[sw * sh];
        small.getPixels(px, 0, sw, 0, 0, sw, sh);
        small.recycle();
        float[] busy = new float[w * h];
        float[] light = new float[w * h];
        for (int y = 0; y < sh; y++) {
            for (int x = 0; x < sw; x++) {
                int c = px[y * sw + x];
                int right = px[y * sw + Math.min(sw - 1, x + 1)];
                int down = px[Math.min(sh - 1, y + 1) * sw + x];
                float edge = (channelGap(c, right) + channelGap(c, down)) / 255f;
                int cell = (y / 2) * w + (x / 2);
                busy[cell] += edge / 4f;
                light[cell] += luminance(c) / 4f;
            }
        }
        float[] detail = new float[w * h];
        for (int i = 0; i < detail.length; i++) {
            detail[i] = busy[i] > DETAIL ? 1f : 0f;
        }
        busySum = integral(busy, w, h);
        lightSum = integral(light, w, h);
        detailSum = integral(detail, w, h);
        gridW = w;
        gridH = h;
        cachedKey = key;
    }

    private static int channelGap(int a, int b) {
        return Math.max(Math.abs(Color.red(a) - Color.red(b)),
                Math.max(Math.abs(Color.green(a) - Color.green(b)), Math.abs(Color.blue(a) - Color.blue(b))));
    }

    private static float luminance(int c) {
        return (0.2126f * Color.red(c) + 0.7152f * Color.green(c) + 0.0722f * Color.blue(c)) / 255f;
    }

    private static float[] integral(float[] values, int w, int h) {
        float[] sum = new float[(w + 1) * (h + 1)];
        for (int y = 0; y < h; y++) {
            float row = 0f;
            for (int x = 0; x < w; x++) {
                row += values[y * w + x];
                sum[(y + 1) * (w + 1) + x + 1] = sum[y * (w + 1) + x + 1] + row;
            }
        }
        return sum;
    }

    /** Mean of a table over a box in screen pixels. */
    private static float mean(float[] sum, RectF box, int width, int height) {
        int x0 = clamp((int) Math.floor(box.left / width * gridW), 0, gridW - 1);
        int x1 = clamp((int) Math.ceil(box.right / width * gridW), x0 + 1, gridW);
        int y0 = clamp((int) Math.floor(box.top / height * gridH), 0, gridH - 1);
        int y1 = clamp((int) Math.ceil(box.bottom / height * gridH), y0 + 1, gridH);
        int stride = gridW + 1;
        float total = sum[y1 * stride + x1] - sum[y0 * stride + x1] - sum[y1 * stride + x0] + sum[y0 * stride + x0];
        return total / ((x1 - x0) * (y1 - y0));
    }

    private static int clamp(int value, int low, int high) {
        return Math.max(low, Math.min(high, value));
    }

    // ---------------------------------------------------------------- choosing the spot

    /**
     * Where the clock goes on a screen of this size: tries the biggest size first and keeps it if some
     * spot of the wallpaper is calm enough for it, otherwise steps down. {@code avoid} is the info card.
     */
    static synchronized Placement place(Context context, String id, int width, int height, int style, String hours, String minutes,
                                        RectF avoid, boolean compact) {
        return place(context, id, width, height, style, hours, minutes, avoid, compact, LockScreen.SIZE_AUTO, LockScreen.SIDE_AUTO);
    }

    /** The same, with the user's size (automatic, small, medium, large) and side (automatic, centre, right, left). */
    static synchronized Placement place(Context context, String id, int width, int height, int style, String hours, String minutes,
                                        RectF avoid, boolean compact, int size, int sideChoice) {
        analyse(context, id, width, height);
        float[] all = style == LINE
                ? (compact ? new float[]{0.50f, 0.43f, 0.36f} : new float[]{0.80f, 0.70f, 0.60f, 0.50f, 0.42f})
                : (compact ? new float[]{0.34f, 0.29f, 0.24f} : new float[]{0.58f, 0.50f, 0.43f, 0.36f, 0.30f});
        float[] tiers = sized(all, size);
        int firstAlign = sideChoice == LockScreen.SIDE_CENTRE ? 0 : sideChoice == LockScreen.SIDE_LEFT ? 1
                : sideChoice == LockScreen.SIDE_RIGHT ? 2 : 0;
        int lastAlign = sideChoice == LockScreen.SIDE_AUTO ? 2 : firstAlign;
        float top = height * 0.085f;
        float bottom = height * (compact ? 0.40f : 0.78f);
        float margin = width * 0.05f;
        float step = Math.max(2f, height / (float) gridH * 1.5f);
        Placement best = null;
        float bestScore = Float.MAX_VALUE;
        for (int t = 0; t < tiers.length; t++) {
            int weight = weightFor(tiers[t], all[0], all[all.length - 1]);
            float[] block = block(style, hours, minutes, weight);
            float boxW = tiers[t] * width;
            float boxH = boxW * block[1] / block[0];
            if (boxH > bottom - top) {
                continue;
            }
            Placement tierBest = null;
            float tierScore = Float.MAX_VALUE;
            float tierCrowded = 1f;
            for (float y = top; y + boxH <= bottom; y += step) {
                for (int align = firstAlign; align <= lastAlign; align++) {
                    int side = align == 0 ? 0 : align == 1 ? -1 : 1;
                    float x = side == 0 ? (width - boxW) / 2f : side < 0 ? margin : width - margin - boxW;
                    RectF box = new RectF(x, y, x + boxW, y + boxH);
                    if (avoid != null && RectF.intersects(box, avoid)) {
                        continue;
                    }
                    // A little padding around the digits counts too: they shouldn't touch the subject.
                    RectF around = new RectF(box);
                    around.inset(-boxW * 0.06f, -boxH * 0.06f);
                    float busy = mean(busySum, around, width, height);
                    float crowded = mean(detailSum, around, width, height);
                    float score = busy + 2f * crowded + 0.03f * ((y + boxH / 2f) / height) + (side == 0 ? 0f : 0.008f);
                    if (score < tierScore) {
                        tierScore = score;
                        tierBest = new Placement(box, 100f * boxW / block[0], side, weight,
                                mean(lightSum, box, width, height) > 0.62f, busy, tiers[t]);
                        tierCrowded = crowded;
                    }
                }
            }
            if (tierBest == null) {
                continue;
            }
            if (tierBest.busy <= CALM && tierCrowded <= 0.003f) {
                return tierBest;
            }
            // Busy everywhere at this size: remember the best spot, but a smaller clock may find calm.
            float penalised = tierScore - 0.004f * t;
            if (penalised < bestScore) {
                bestScore = penalised;
                best = tierBest;
            }
        }
        if (best != null) {
            return best;
        }
        // Nothing fits around the card: a small clock at the top, on the chosen side.
        float boxW = tiers[tiers.length - 1] * width;
        int weight = weightFor(tiers[tiers.length - 1], all[0], all[all.length - 1]);
        float[] block = block(style, hours, minutes, weight);
        int edge = sideChoice == LockScreen.SIDE_LEFT ? -1 : sideChoice == LockScreen.SIDE_RIGHT ? 1 : 0;
        float x = edge == 0 ? (width - boxW) / 2f : edge < 0 ? margin : width - margin - boxW;
        RectF box = new RectF(x, top, x + boxW, top + boxW * block[1] / block[0]);
        return new Placement(box, 100f * boxW / block[0], edge, weight, mean(lightSum, box, width, height) > 0.62f,
                mean(busySum, box, width, height), tiers[tiers.length - 1]);
    }

    /** All sizes for automatic; otherwise the biggest two, the middle ones, or the smallest two. */
    static float[] sized(float[] all, int size) {
        int n = all.length;
        switch (size) {
            case LockScreen.SIZE_LARGE:
                return java.util.Arrays.copyOfRange(all, 0, Math.min(2, n));
            case LockScreen.SIZE_MEDIUM:
                return java.util.Arrays.copyOfRange(all, Math.max(0, n / 2 - 1), Math.min(n, n / 2 + 1));
            case LockScreen.SIZE_SMALL:
                return java.util.Arrays.copyOfRange(all, Math.max(0, n - 2), n);
            default:
                return all;
        }
    }

    /** Thin when the clock is big, bolder as it gets smaller, so it reads the same at every size. */
    static int weightFor(float tier, float biggest, float smallest) {
        float t = biggest == smallest ? 0.5f : (tier - smallest) / (biggest - smallest);
        return Math.round((560f - 300f * t) / 50f) * 50;
    }

    /** Width and height of the clock's text at size 100. */
    private static float[] block(int style, String hours, String minutes, int weight) {
        TextPaint paint = paint(100f, weight);
        if (style == LINE) {
            String text = hours + ":" + minutes;
            return new float[]{paint.measureText(text), digitHeight(paint, hours + minutes)};
        }
        float width = Math.max(paint.measureText(hours), paint.measureText(minutes));
        float digit = digitHeight(paint, hours + minutes);
        return new float[]{width, digit * (2f + GAP)};
    }

    private static float digitHeight(Paint paint, String text) {
        Rect bounds = new Rect();
        paint.getTextBounds(text, 0, text.length(), bounds);
        return Math.max(1f, -bounds.top);
    }

    // ---------------------------------------------------------------- drawing

    static void draw(Canvas canvas, Placement place, int style, String hours, String minutes, int accent) {
        draw(canvas, place, style, hours, minutes, accent, null);
    }

    /** {@code colors}: the user's hours and minutes colours, or null to follow the picture underneath. */
    static void draw(Canvas canvas, Placement place, int style, String hours, String minutes, int accent, int[] colors) {
        int ink = colors != null ? colors[0] : place.light ? 0xFF15141B : Color.WHITE;
        int second = colors != null ? colors[1] : place.light ? mix(accent, Color.BLACK, 0.30f) : mix(accent, Color.WHITE, 0.50f);
        TextPaint first = paint(place.textSize, place.weight);
        TextPaint other = paint(place.textSize, place.weight);
        first.setColor(ink);
        other.setColor(second);
        if (!place.light || colors != null) {
            first.setShadowLayer(place.textSize * 0.05f, 0f, place.textSize * 0.012f, 0x38000000);
            other.setShadowLayer(place.textSize * 0.05f, 0f, place.textSize * 0.012f, 0x38000000);
        }
        RectF box = place.box;
        if (style == LINE) {
            String colon = ":";
            float total = first.measureText(hours) + first.measureText(colon) + other.measureText(minutes);
            float x = place.align == 0 ? box.centerX() - total / 2f : place.align < 0 ? box.left : box.right - total;
            float baseline = box.top + digitHeight(first, hours + minutes);
            first.setTextAlign(Paint.Align.LEFT);
            other.setTextAlign(Paint.Align.LEFT);
            canvas.drawText(hours, x, baseline, first);
            x += first.measureText(hours);
            TextPaint dots = paint(place.textSize, place.weight);
            dots.setColor(withAlpha(ink, 0.7f));
            dots.setShadowLayer(first.getShadowLayerRadius(), 0f, first.getShadowLayerDy(), first.getShadowLayerColor());
            canvas.drawText(colon, x, baseline, dots);
            x += first.measureText(colon);
            canvas.drawText(minutes, x, baseline, other);
            return;
        }
        Paint.Align align = place.align == 0 ? Paint.Align.CENTER : place.align < 0 ? Paint.Align.LEFT : Paint.Align.RIGHT;
        float x = place.align == 0 ? box.centerX() : place.align < 0 ? box.left : box.right;
        first.setTextAlign(align);
        other.setTextAlign(align);
        float digit = digitHeight(first, hours + minutes);
        canvas.drawText(hours, x, box.top + digit, first);
        canvas.drawText(minutes, x, box.top + digit * (2f + GAP), other);
    }

    static int mix(int color, int toward, float amount) {
        float keep = 1f - amount;
        return Color.rgb(Math.round(Color.red(color) * keep + Color.red(toward) * amount),
                Math.round(Color.green(color) * keep + Color.green(toward) * amount),
                Math.round(Color.blue(color) * keep + Color.blue(toward) * amount));
    }

    private static int withAlpha(int color, float alpha) {
        return (Math.round(Color.alpha(color) * alpha) << 24) | (color & 0x00FFFFFF);
    }
}
