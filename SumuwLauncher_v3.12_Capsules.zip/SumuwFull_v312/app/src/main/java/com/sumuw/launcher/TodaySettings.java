package com.sumuw.launcher;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Build;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Toast;
import java.util.HashSet;
import java.util.Set;

/** The "Today" group in settings: prayer times, location, weather, reminders and news sources. */
final class TodaySettings {
    static final int REQUEST_LOCATION = 51;
    static final int REQUEST_WEATHER_LOCATION = 53;
    static final int REQUEST_NOTIFICATIONS = 52;

    interface Ui {
        LinearLayout group(String title);

        View row(LinearLayout group, String title, String summary, View.OnClickListener click);

        View toggle(LinearLayout group, String title, String summary, boolean checked, CompoundButton.OnCheckedChangeListener change);

        void refresh();
    }

    private TodaySettings() {
    }

    static int methodName(String method) {
        switch (method) {
            case "mwl":
                return R.string.method_mwl;
            case "egypt":
                return R.string.method_egypt;
            case "karachi":
                return R.string.method_karachi;
            case "isna":
                return R.string.method_isna;
            default:
                return R.string.method_umm_al_qura;
        }
    }

    private static void bump(SharedPreferences prefs) {
        prefs.edit().putInt("config_stamp", prefs.getInt("config_stamp", 0) + 1).apply();
    }

    static void addSection(final Activity activity, final SharedPreferences prefs, LinearLayout content, final Ui ui) {
        LinearLayout group = ui.group(activity.getString(R.string.section_today));
        ui.toggle(group, activity.getString(R.string.prayer_times), activity.getString(R.string.prayer_toggle_summary),
                prefs.getBoolean("prayer_on", true), (button, on) -> {
                    prefs.edit().putBoolean("prayer_on", on).apply();
                    bump(prefs);
                });
        boolean prayerGps = prefs.getBoolean(Places.PREF_PRAYER_GPS, true) && !Places.usesGps(prefs);
        String prayerWhere;
        if (!prayerGps) {
            prayerWhere = activity.getString(R.string.prayer_gps_off);
        } else if (!Places.permitted(activity)) {
            prayerWhere = activity.getString(R.string.prayer_gps_need, Places.city(prefs).name);
        } else if (!Places.hasFix(prefs)) {
            prayerWhere = activity.getString(R.string.locating);
        } else {
            prayerWhere = activity.getString(R.string.prayer_gps_now, Places.fixName(activity, prefs));
        }
        if (!Places.usesGps(prefs)) {
            ui.toggle(group, activity.getString(R.string.prayer_gps), prayerWhere, prayerGps && Places.permitted(activity), (button, on) -> {
                prefs.edit().putBoolean(Places.PREF_PRAYER_GPS, on).remove("loc_time").apply();
                if (on && !Places.permitted(activity)) {
                    Permissions.ask(activity, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_WEATHER_LOCATION, R.string.perm_why_location);
                    return;
                }
                bump(prefs);
                ReminderReceiver.schedulePrayer(activity);
                Places.refresh(activity, prefs, () -> {
                    bump(prefs);
                    ReminderReceiver.schedulePrayer(activity);
                    ui.refresh();
                });
                ui.refresh();
            });
        }
        ui.row(group, activity.getString(prayerGps ? R.string.city_fallback : R.string.city),
                Places.usesGps(prefs) ? Places.name(activity, prefs) : Places.city(prefs).name, v -> pickCity(activity, prefs, ui));
        String method = prefs.getString("prayer_method", "auto");
        String methodText = "auto".equals(method)
                ? activity.getString(R.string.method_auto_now, activity.getString(methodName(Prayers.method(prefs))))
                : activity.getString(methodName(method));
        ui.row(group, activity.getString(R.string.calc_method), methodText, v -> pickMethod(activity, prefs, ui));
        boolean hanafi = prefs.getBoolean("asr_hanafi", false);
        ui.row(group, activity.getString(R.string.asr_method), activity.getString(hanafi ? R.string.asr_hanafi : R.string.asr_standard),
                v -> pickAsr(activity, prefs, ui));
        int alert = prefs.getInt("prayer_alert_min", 0);
        ui.row(group, activity.getString(R.string.prayer_alert),
                alert <= 0 ? activity.getString(R.string.prayer_alert_off) : activity.getString(R.string.prayer_alert_minutes, alert),
                v -> pickPrayerAlert(activity, prefs, ui));
        if (alert > 0 && Build.VERSION.SDK_INT >= 31) {
            android.app.AlarmManager alarms = activity.getSystemService(android.app.AlarmManager.class);
            if (alarms != null && !alarms.canScheduleExactAlarms()) {
                ui.row(group, activity.getString(R.string.exact_alarm), activity.getString(R.string.exact_alarm_summary), v -> {
                    try {
                        activity.startActivity(new android.content.Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                                android.net.Uri.parse("package:" + activity.getPackageName())));
                    } catch (Exception ignored) {
                    }
                });
            }
        }
        String ramadan = prefs.getString("ramadan_mode", "auto");
        ui.row(group, activity.getString(R.string.ramadan_mode), activity.getString(ramadanName(ramadan)) + activity.getString(R.string.list_separator)
                + activity.getString(R.string.ramadan_mode_summary), v -> pickRamadan(activity, prefs, ui));
        ui.toggle(group, activity.getString(R.string.calendar_on), activity.getString(R.string.calendar_summary),
                prefs.getBoolean("calendar_on", true), (button, on) -> {
                    prefs.edit().putBoolean("calendar_on", on).apply();
                    bump(prefs);
                });
        ui.toggle(group, activity.getString(R.string.weather), activity.getString(R.string.weather_summary),
                prefs.getBoolean("weather_on", true), (button, on) -> {
                    prefs.edit().putBoolean("weather_on", on).apply();
                    bump(prefs);
                });
        boolean follows = Places.weatherGps(prefs);
        String where;
        if (!follows) {
            where = activity.getString(R.string.weather_gps_off, Places.name(activity, prefs));
        } else if (!Places.permitted(activity)) {
            where = activity.getString(R.string.weather_gps_need);
        } else if (!Places.hasFix(prefs)) {
            where = activity.getString(R.string.locating);
        } else {
            where = activity.getString(R.string.weather_gps_now, Places.fixName(activity, prefs),
                    android.text.format.DateUtils.getRelativeTimeSpanString(prefs.getLong("loc_time", 0L), System.currentTimeMillis(),
                            android.text.format.DateUtils.MINUTE_IN_MILLIS));
        }
        ui.toggle(group, activity.getString(R.string.weather_gps), where, follows && Places.permitted(activity), (button, on) -> {
            prefs.edit().putBoolean(Places.PREF_WEATHER_GPS, on).remove("loc_time").apply();
            if (on && !Places.permitted(activity)) {
                Permissions.ask(activity, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_WEATHER_LOCATION, R.string.perm_why_location);
                return;
            }
            prefs.edit().remove("wx_time").apply();
            bump(prefs);
            Places.refresh(activity, prefs, () -> {
                prefs.edit().remove("wx_time").apply();
                bump(prefs);
                ui.refresh();
            });
            ui.refresh();
        });
        ui.toggle(group, activity.getString(R.string.weather_alerts), activity.getString(R.string.weather_alerts_summary),
                Weather.alertsOn(prefs), (button, on) -> {
                    prefs.edit().putBoolean("weather_alerts", on).apply();
                    if (!on) {
                        Weather.storeAlert(prefs, null);
                    } else if (!ReminderReceiver.canNotify(activity) && Build.VERSION.SDK_INT >= 33) {
                        Permissions.ask(activity, new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS, R.string.perm_why_notifications);
                    }
                    ReminderReceiver.scheduleWeather(activity);
                    bump(prefs);
                });
        boolean remindersOn = ReminderReceiver.enabled(prefs);
        boolean canNotify = ReminderReceiver.canNotify(activity);
        ui.toggle(group, activity.getString(R.string.reminders),
                activity.getString(remindersOn && !canNotify ? R.string.reminders_need_permission : R.string.reminders_summary),
                remindersOn && canNotify, (button, on) -> {
                    prefs.edit().putBoolean("reminders_on", on).apply();
                    if (on && !ReminderReceiver.canNotify(activity) && Build.VERSION.SDK_INT >= 33) {
                        Permissions.ask(activity, new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS, R.string.perm_why_notifications);
                    }
                    ReminderReceiver.schedule(activity);
                });
        ui.row(group, activity.getString(R.string.news_sources), NewsSources.summary(prefs), v -> pickSources(activity, prefs, ui));
    }

    static final String[] RAMADAN_MODES = {"auto", "on", "off"};

    static int ramadanName(String mode) {
        switch (mode) {
            case "on":
                return R.string.ramadan_on;
            case "off":
                return R.string.ramadan_off;
            default:
                return R.string.ramadan_auto;
        }
    }

    private static void pickRamadan(final Activity activity, final SharedPreferences prefs, final Ui ui) {
        String[] names = new String[RAMADAN_MODES.length];
        int selected = 0;
        String current = prefs.getString("ramadan_mode", "auto");
        for (int i = 0; i < names.length; i++) {
            names[i] = activity.getString(ramadanName(RAMADAN_MODES[i]));
            if (RAMADAN_MODES[i].equals(current)) {
                selected = i;
            }
        }
        new AlertDialog.Builder(activity)
                .setTitle(activity.getString(R.string.ramadan_mode))
                .setSingleChoiceItems(names, selected, (dialog, which) -> {
                    prefs.edit().putString("ramadan_mode", RAMADAN_MODES[which]).apply();
                    bump(prefs);
                    dialog.dismiss();
                    ui.refresh();
                })
                .setNegativeButton(activity.getString(R.string.cancel), null)
                .show();
    }

    static final int[] ALERT_MINUTES = {0, 5, 10, 15, 30};

    private static void pickPrayerAlert(final Activity activity, final SharedPreferences prefs, final Ui ui) {
        String[] names = new String[ALERT_MINUTES.length];
        int current = prefs.getInt("prayer_alert_min", 0);
        int selected = 0;
        for (int i = 0; i < ALERT_MINUTES.length; i++) {
            names[i] = ALERT_MINUTES[i] == 0 ? activity.getString(R.string.prayer_alert_off)
                    : activity.getString(R.string.prayer_alert_minutes, ALERT_MINUTES[i]);
            if (ALERT_MINUTES[i] == current) {
                selected = i;
            }
        }
        new AlertDialog.Builder(activity)
                .setTitle(activity.getString(R.string.prayer_alert))
                .setSingleChoiceItems(names, selected, (dialog, which) -> {
                    prefs.edit().putInt("prayer_alert_min", ALERT_MINUTES[which]).apply();
                    if (ALERT_MINUTES[which] > 0 && !ReminderReceiver.canNotify(activity) && Build.VERSION.SDK_INT >= 33) {
                        Permissions.ask(activity, new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS, R.string.perm_why_notifications);
                    }
                    ReminderReceiver.schedulePrayer(activity);
                    dialog.dismiss();
                    ui.refresh();
                })
                .setNegativeButton(activity.getString(R.string.cancel), null)
                .show();
    }

    private static void pickCity(final Activity activity, final SharedPreferences prefs, final Ui ui) {
        final PrayerTimes.City[] cities = PrayerTimes.CITIES;
        String[] names = new String[cities.length + 1];
        names[0] = activity.getString(R.string.use_my_location);
        String current = prefs.getString("prayer_city", "riyadh");
        int selected = 0;
        for (int i = 0; i < cities.length; i++) {
            names[i + 1] = cities[i].name;
            if (cities[i].id.equals(current)) {
                selected = i + 1;
            }
        }
        new AlertDialog.Builder(activity)
                .setTitle(activity.getString(R.string.city))
                .setSingleChoiceItems(names, selected, (dialog, which) -> {
                    dialog.dismiss();
                    if (which == 0) {
                        if (Places.permitted(activity)) {
                            useGps(activity, prefs, ui);
                        } else {
                            Permissions.ask(activity, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_LOCATION, R.string.perm_why_location);
                        }
                        return;
                    }
                    prefs.edit().putString("prayer_city", cities[which - 1].id).remove("wx_time").apply();
                    bump(prefs);
                    ui.refresh();
                })
                .setNegativeButton(activity.getString(R.string.cancel), null)
                .show();
    }

    private static void useGps(final Activity activity, final SharedPreferences prefs, final Ui ui) {
        prefs.edit().putString("prayer_city", Places.GPS).remove("loc_time").remove("wx_time").apply();
        bump(prefs);
        ui.refresh();
        Places.refresh(activity, prefs, () -> {
            prefs.edit().remove("wx_time").apply();
            bump(prefs);
            ui.refresh();
        });
    }

    /** Called by SettingsActivity when the user answers a permission request we made. */
    static void onPermissionResult(Activity activity, SharedPreferences prefs, int requestCode, boolean granted, Ui ui) {
        if (requestCode == REQUEST_LOCATION) {
            if (granted) {
                useGps(activity, prefs, ui);
            } else {
                Toast.makeText(activity, activity.getString(R.string.location_denied), Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == REQUEST_WEATHER_LOCATION) {
            if (Places.permitted(activity)) {
                prefs.edit().remove("wx_time").apply();
                Places.refresh(activity, prefs, () -> {
                    prefs.edit().remove("wx_time").apply();
                    bump(prefs);
                    ReminderReceiver.schedulePrayer(activity);
                    ui.refresh();
                });
            } else {
                prefs.edit().putBoolean(Places.PREF_WEATHER_GPS, false).putBoolean(Places.PREF_PRAYER_GPS, false).apply();
                Toast.makeText(activity, activity.getString(R.string.weather_gps_denied, Places.name(activity, prefs)), Toast.LENGTH_LONG).show();
            }
            bump(prefs);
            ui.refresh();
        } else if (requestCode == REQUEST_NOTIFICATIONS) {
            ReminderReceiver.schedule(activity);
            ui.refresh();
        }
    }

    private static void pickMethod(final Activity activity, final SharedPreferences prefs, final Ui ui) {
        final String[] methods = new String[PrayerTimes.METHODS.length + 1];
        methods[0] = "auto";
        System.arraycopy(PrayerTimes.METHODS, 0, methods, 1, PrayerTimes.METHODS.length);
        String[] names = new String[methods.length];
        String current = prefs.getString("prayer_method", "auto");
        int selected = 0;
        for (int i = 0; i < methods.length; i++) {
            names[i] = i == 0 ? activity.getString(R.string.method_auto) : activity.getString(methodName(methods[i]));
            if (methods[i].equals(current)) {
                selected = i;
            }
        }
        new AlertDialog.Builder(activity)
                .setTitle(activity.getString(R.string.calc_method))
                .setSingleChoiceItems(names, selected, (dialog, which) -> {
                    prefs.edit().putString("prayer_method", methods[which]).apply();
                    bump(prefs);
                    ReminderReceiver.schedulePrayer(activity);
                    dialog.dismiss();
                    ui.refresh();
                })
                .setNegativeButton(activity.getString(R.string.cancel), null)
                .show();
    }

    private static void pickAsr(final Activity activity, final SharedPreferences prefs, final Ui ui) {
        String[] names = {activity.getString(R.string.asr_standard), activity.getString(R.string.asr_hanafi)};
        new AlertDialog.Builder(activity)
                .setTitle(activity.getString(R.string.asr_method))
                .setSingleChoiceItems(names, prefs.getBoolean("asr_hanafi", false) ? 1 : 0, (dialog, which) -> {
                    prefs.edit().putBoolean("asr_hanafi", which == 1).apply();
                    bump(prefs);
                    dialog.dismiss();
                    ui.refresh();
                })
                .setNegativeButton(activity.getString(R.string.cancel), null)
                .show();
    }

    private static void pickSources(final Activity activity, final SharedPreferences prefs, final Ui ui) {
        final NewsSources.Source[] all = NewsSources.ALL;
        Set<String> enabled = NewsSources.enabledIds(prefs);
        String[] names = new String[all.length];
        final boolean[] checked = new boolean[all.length];
        for (int i = 0; i < all.length; i++) {
            names[i] = all[i].name;
            checked[i] = enabled.contains(all[i].id);
        }
        new AlertDialog.Builder(activity)
                .setTitle(activity.getString(R.string.news_sources))
                .setMultiChoiceItems(names, checked, (dialog, which, isChecked) -> checked[which] = isChecked)
                .setPositiveButton(activity.getString(R.string.done), (dialog, which) -> {
                    HashSet<String> ids = new HashSet<>();
                    for (int i = 0; i < all.length; i++) {
                        if (checked[i]) {
                            ids.add(all[i].id);
                        }
                    }
                    if (ids.isEmpty()) {
                        Toast.makeText(activity, activity.getString(R.string.news_sources_empty), Toast.LENGTH_SHORT).show();
                        return;
                    }
                    NewsSources.save(prefs, ids);
                    bump(prefs);
                    ui.refresh();
                })
                .setNegativeButton(activity.getString(R.string.cancel), null)
                .show();
    }
}
