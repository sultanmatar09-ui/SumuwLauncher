package com.sumuw.launcher;

import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;

/**
 * Makkah and Madinah: a card of the supplications for the place, and the phone silenced inside the two
 * Holy Mosques (with Do Not Disturb, when Sara has that access), then back as it was on leaving.
 * Judged from the location Sara takes while Home is open, so it follows within a quarter of an hour.
 */
final class Haram {
    static final String PREF = "haram_mode";
    static final String PREF_SILENCE = "haram_silence";
    static final String MAKKAH = "makkah";
    static final String MADINAH = "madinah";

    /** The Kaaba, and the Prophet's Mosque. */
    static final double[] KAABA = {21.42250, 39.82620};
    static final double[] NABAWI = {24.46720, 39.61110};
    /** Inside the mosque and its courtyards. */
    static final double MOSQUE_KM_MAKKAH = 0.75;
    static final double MOSQUE_KM_MADINAH = 0.55;
    /** In the city: the card shows. */
    static final double CITY_KM_MAKKAH = 18.0;
    static final double CITY_KM_MADINAH = 14.0;

    private Haram() {
    }

    static boolean on(SharedPreferences prefs) {
        return prefs.getBoolean(PREF, true);
    }

    /** MAKKAH, MADINAH or null: the holy city the phone is in. */
    static String city(double lat, double lng) {
        if (Places.distanceKm(lat, lng, KAABA[0], KAABA[1]) <= CITY_KM_MAKKAH) {
            return MAKKAH;
        }
        if (Places.distanceKm(lat, lng, NABAWI[0], NABAWI[1]) <= CITY_KM_MADINAH) {
            return MADINAH;
        }
        return null;
    }

    /** Inside al-Masjid al-Haram or al-Masjid an-Nabawi. */
    static boolean inMosque(double lat, double lng) {
        return Places.distanceKm(lat, lng, KAABA[0], KAABA[1]) <= MOSQUE_KM_MAKKAH
                || Places.distanceKm(lat, lng, NABAWI[0], NABAWI[1]) <= MOSQUE_KM_MADINAH;
    }

    /** The holy city of the current fix, if the fix is fresh (two hours) and the mode is on. */
    static String here(SharedPreferences prefs) {
        if (!on(prefs) || !Places.hasFix(prefs) || System.currentTimeMillis() - prefs.getLong("loc_time", 0L) > 2 * 3600000L) {
            return null;
        }
        return city(prefs.getFloat("loc_lat", 0f), prefs.getFloat("loc_lng", 0f));
    }

    /**
     * After each new fix: silence the phone on entering the mosque, and give the sound back on leaving,
     * but only if it was Sara that silenced it. Returns true when it changed something.
     */
    static boolean check(Context context, SharedPreferences prefs) {
        if (!Places.hasFix(prefs)) {
            return false;
        }
        boolean inside = on(prefs) && prefs.getBoolean(PREF_SILENCE, true)
                && inMosque(prefs.getFloat("loc_lat", 0f), prefs.getFloat("loc_lng", 0f));
        boolean silenced = prefs.getBoolean("haram_silenced", false);
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (manager == null || !manager.isNotificationPolicyAccessGranted()) {
            return false;
        }
        try {
            if (inside && !silenced) {
                int prevFilter = manager.getCurrentInterruptionFilter();
                prefs.edit().putInt("haram_prev_filter", prevFilter).putBoolean("haram_silenced", true).apply();
                if (prevFilter == NotificationManager.INTERRUPTION_FILTER_ALL) {
                    manager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY);
                }
                return true;
            }
            if (!inside && silenced) {
                int prevFilter = prefs.getInt("haram_prev_filter", NotificationManager.INTERRUPTION_FILTER_ALL);
                if (manager.getCurrentInterruptionFilter() == NotificationManager.INTERRUPTION_FILTER_PRIORITY
                        && prevFilter != NotificationManager.INTERRUPTION_FILTER_PRIORITY) {
                    manager.setInterruptionFilter(prevFilter);
                }
                prefs.edit().remove("haram_prev_filter").putBoolean("haram_silenced", false).apply();
                return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    /** A supplication or reminder: when it is said, the text, and where it is narrated. */
    static final class Dua {
        final int when;
        final String text;
        final int source;

        Dua(int when, String text, int source) {
            this.when = when;
            this.text = text;
            this.source = source;
        }
    }

    /**
     * Texts checked letter by letter against the books: the talbiyah (al-Bukhari 1549, Muslim 1184),
     * between the two corners (Abu Dawud 1892), on as-Safa (Muslim 1218), entering the mosque (Muslim
     * 713), and the prayer in the Prophet's Mosque (al-Bukhari 1190, Muslim 1394).
     */
    static Dua[] duas(String city) {
        Dua enter = new Dua(R.string.haram_enter, "اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ", R.string.haram_src_muslim);
        if (MADINAH.equals(city)) {
            return new Dua[]{
                    enter,
                    new Dua(R.string.haram_nabawi, "صَلَاةٌ فِي مَسْجِدِي هَذَا خَيْرٌ مِنْ أَلْفِ صَلَاةٍ فِيمَا سِوَاهُ، إِلَّا الْمَسْجِدَ الْحَرَامَ",
                            R.string.haram_src_both),
            };
        }
        return new Dua[]{
                new Dua(R.string.haram_talbiyah, "لَبَّيْكَ اللَّهُمَّ لَبَّيْكَ، لَبَّيْكَ لَا شَرِيكَ لَكَ لَبَّيْكَ، إِنَّ الْحَمْدَ وَالنِّعْمَةَ لَكَ وَالْمُلْكَ، لَا شَرِيكَ لَكَ",
                        R.string.haram_src_both),
                enter,
                new Dua(R.string.haram_corners, "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ",
                        R.string.haram_src_abudawud),
                new Dua(R.string.haram_safa, "أَبْدَأُ بِمَا بَدَأَ اللهُ بِهِ… لَا إِلَهَ إِلَّا اللهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، لَا إِلَهَ إِلَّا اللهُ وَحْدَهُ، أَنْجَزَ وَعْدَهُ، وَنَصَرَ عَبْدَهُ، وَهَزَمَ الْأَحْزَابَ وَحْدَهُ",
                        R.string.haram_src_muslim),
        };
    }
}
