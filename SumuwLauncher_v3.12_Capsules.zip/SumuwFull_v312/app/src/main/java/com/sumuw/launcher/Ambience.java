package com.sumuw.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import java.util.Calendar;
import java.util.Random;

/**
 * What lies over the wallpaper, drawn in code so any built-in wallpaper takes it:
 * <ul>
 * <li>the light of the hour, by the day's own prayer times (dawn rose, golden afternoon, sunset, night);</li>
 * <li>the weather: a dusty haze, and rain drops on the lock screen's glass;</li>
 * <li>the occasions: a green glow on National Day, gold and Sadu on Founding Day, gold stars at the Eids.</li>
 * </ul>
 */
final class Ambience {
    static final String PREF_DAY = "ambience_day";
    static final String PREF_WEATHER = "ambience_weather";
    static final String PREF_OCCASIONS = "ambience_occasions";

    static final String NATIONAL = "national";
    static final String FOUNDING = "founding";
    static final String EID_FITR = "eid_fitr";
    static final String EID_ADHA = "eid_adha";

    private Ambience() {
    }

    /** All that is over the wallpaper at one moment. */
    static final class State {
        /** The hour's colour, laid over the art (alpha included). */
        int tint;
        /** 0 for clear air, up to 1 for a thick dust haze. */
        float haze;
        /** 0 for clear sky, up to 1 for overcast/fog. */
        float clouds;
        boolean rain;
        boolean storm;
        boolean stars;
        /** NATIONAL, FOUNDING, EID_FITR, EID_ADHA or null. */
        String occasion;
        /** Light wallpapers (dark text) get a lighter touch, so the text stays easy to read. */
        boolean light;

        boolean animated() {
            return rain || storm || haze > 0f || clouds > 0f || stars;
        }

        /** Changes only when something visible changes, to know when to blur the glass again. */
        String stamp() {
            return Integer.toHexString(tint & 0xF0F0F0F0) + "/" + Math.round(haze * 4) + "/"
                    + Math.round(clouds * 4) + "/" + rain + "/" + storm + "/" + stars + "/" + occasion + "/" + light;
        }
    }

    static State now(Context context, SharedPreferences prefs, long at, boolean lightWallpaper) {
        State state = new State();
        state.light = lightWallpaper;
        if (prefs.getBoolean(PREF_DAY, true)) {
            try {
                long[] times = Prayers.timesFor(prefs, at);
                state.tint = dayTint(times, at, lightWallpaper);
                state.stars = !lightWallpaper && (at >= times[PrayerTimes.ISHA] + 30 * 60000L
                        || at <= times[PrayerTimes.FAJR] - 20 * 60000L);
            } catch (Exception ignored) {
            }
        }
        if (prefs.getBoolean(PREF_WEATHER, true)) {
            Weather.Alert alert = Weather.alertsOn(prefs) ? Weather.cachedAlert(prefs, at) : null;
            if (alert != null && alert.from <= at) {
                if ("dust".equals(alert.kind)) {
                    state.haze = Math.min(1f, Math.max(0.45f, alert.level / 600f));
                } else {
                    state.rain = true;
                }
            }
            Weather.Now weather = Weather.cached(prefs);
            if (weather != null && at - weather.time < 2 * 3600000L) {
                if (Weather.rainy(weather.code)) {
                    state.rain = true;
                }
                if (weather.code >= 95) {
                    state.storm = true;
                } else if (weather.code == 2) {
                    state.clouds = 0.45f;
                } else if (weather.code == 3 || weather.code == 45 || weather.code == 48) {
                    state.clouds = 0.85f;
                }
            }
        }
        if (prefs.getBoolean(PREF_OCCASIONS, true)) {
            state.occasion = occasion(at);
        }
        return state;
    }

    // ---------------------------------------------------------------- the light of the hour

    /** The tint at a moment, blended over forty minutes around each turn of the day. */
    static int dayTint(long[] times, long at, boolean light) {
        long fajr = times[PrayerTimes.FAJR];
        long sunrise = times[PrayerTimes.SUNRISE];
        long dhuhr = times[PrayerTimes.DHUHR];
        long asr = times[PrayerTimes.ASR];
        long maghrib = times[PrayerTimes.MAGHRIB];
        long isha = times[PrayerTimes.ISHA];
        long minute = 60000L;
        // Turning points and the colour that holds from each.
        long[] marks = {fajr - 30 * minute, sunrise + 30 * minute, dhuhr, asr + 30 * minute, maghrib - 40 * minute, maghrib + 10 * minute,
                isha + 40 * minute};
        int[] colours = {
                0x30FF8F9E, // dawn: rose and lilac
                0x00FFFFFF, // morning: the wallpaper as it is
                0x10FFF1C8, // noon: a little brighter
                0x22FFB04A, // afternoon: golden
                0x34FF6A3A, // sunset: orange-red
                0x2E6A3C8C, // dusk: violet
                0x3A050B26, // night: deep blue
        };
        int index = -1;
        for (int i = 0; i < marks.length; i++) {
            if (at >= marks[i]) {
                index = i;
            }
        }
        int current = index < 0 ? colours[colours.length - 1] : colours[index];
        long nextMark = index + 1 < marks.length ? marks[index + 1] : marks[0] + 24 * 60 * minute;
        int next = colours[(index + 1) % colours.length];
        long blend = 40 * minute;
        int tint = current;
        if (nextMark - at < blend) {
            tint = mix(current, next, 1f - (nextMark - at) / (float) blend);
        }
        if (light) {
            // Darker hours would make a light wallpaper muddy under dark text: half the strength.
            tint = Color.argb(Color.alpha(tint) / 2, Color.red(tint), Color.green(tint), Color.blue(tint));
        }
        return tint;
    }

    static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        return Color.argb(Math.round(Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * t),
                Math.round(Color.red(a) + (Color.red(b) - Color.red(a)) * t),
                Math.round(Color.green(a) + (Color.green(b) - Color.green(a)) * t),
                Math.round(Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t));
    }

    // ---------------------------------------------------------------- occasions

    /** Saudi National Day (23 September), Founding Day (22 February), and the two Eids; a day either side for the national days. */
    static String occasion(long at) {
        Calendar day = Calendar.getInstance();
        day.setTimeInMillis(at);
        int month = day.get(Calendar.MONTH);
        int date = day.get(Calendar.DAY_OF_MONTH);
        if (month == Calendar.SEPTEMBER && date >= 22 && date <= 24) {
            return NATIONAL;
        }
        if (month == Calendar.FEBRUARY && date >= 21 && date <= 23) {
            return FOUNDING;
        }
        try {
            int[] hijri = HijriEvents.hijri(at);
            if (hijri[1] == android.icu.util.IslamicCalendar.SHAWWAL && hijri[2] <= 3) {
                return EID_FITR;
            }
            if (hijri[1] == android.icu.util.IslamicCalendar.DHU_AL_HIJJAH && hijri[2] >= 10 && hijri[2] <= 13) {
                return EID_ADHA;
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    /** "اليوم الوطني السعودي ٩٦"، "يوم التأسيس، ٣٠٠ عام"، "عيد فطر مبارك"… for Today and the morning card. */
    static String greeting(Context context, String occasion, long at) {
        if (occasion == null) {
            return null;
        }
        Calendar day = Calendar.getInstance();
        day.setTimeInMillis(at);
        java.text.NumberFormat number = java.text.NumberFormat.getIntegerInstance();
        switch (occasion) {
            case NATIONAL:
                return context.getString(R.string.occasion_national, number.format(day.get(Calendar.YEAR) - 1930));
            case FOUNDING:
                return context.getString(R.string.occasion_founding, number.format(day.get(Calendar.YEAR) - 1727));
            case EID_FITR:
                return context.getString(R.string.occasion_eid_fitr);
            default:
                return context.getString(R.string.occasion_eid_adha);
        }
    }

    // ---------------------------------------------------------------- drawing

    /** Lays the state over a wallpaper already drawn on the canvas. Rain drops on the glass only on the lock screen ({@code glass}). */
    static void draw(Canvas canvas, int w, int h, State state, boolean glass) {
        draw(canvas, w, h, state, glass, 0f, 0f, 0f);
    }

    /** Animated weather & sky overlay with parallax offset for SaraWallpaper. */
    static void draw(Canvas canvas, int w, int h, State state, boolean glass, float phase, float tiltX, float tiltY) {
        if (state == null) {
            return;
        }
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        if (Color.alpha(state.tint) > 0) {
            paint.setColor(state.tint);
            canvas.drawRect(0, 0, w, h, paint);
        }
        if (state.stars && !state.rain && state.haze < 0.35f && state.clouds < 0.7f) {
            drawStars(canvas, w, h, paint, phase, tiltX * 0.4f, tiltY * 0.4f);
        }
        if (state.clouds > 0f) {
            drawClouds(canvas, w, h, state.clouds, state.light, paint, phase, tiltX * 0.7f);
        }
        if (state.occasion != null) {
            drawOccasion(canvas, w, h, state.occasion, state.light, paint);
        }
        if (state.haze > 0f) {
            // Dust: a warm, flat haze, thicker low down where the dust hangs.
            int top = Color.argb(Math.round(70 * state.haze), 196, 160, 110);
            int bottom = Color.argb(Math.round(130 * state.haze), 186, 146, 96);
            paint.setColor(Color.BLACK);
            paint.setShader(new LinearGradient(0, 0, 0, h, top, bottom, Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, paint);
            paint.setShader(null);
            Random random = new Random(17);
            for (int i = 0; i < 160; i++) {
                float speed = 0.3f + random.nextFloat() * 0.7f;
                float px = ((random.nextFloat() + phase * 0.04f * speed) % 1f) * w + tiltX * 0.5f;
                float py = random.nextFloat() * h;
                paint.setColor(Color.argb((int) (18 + random.nextFloat() * 30 * state.haze), 230, 205, 160));
                canvas.drawCircle((px + w) % w, py, w * (0.002f + random.nextFloat() * 0.004f), paint);
            }
        }
        if (state.rain) {
            drawFallingRain(canvas, w, h, paint, phase, tiltX, state.storm);
            if (glass) {
                drawDrops(canvas, w, h, paint);
            }
        }
    }

    private static void drawStars(Canvas canvas, int w, int h, Paint paint, float phase, float px, float py) {
        Random random = new Random(7);
        for (int i = 0; i < 55; i++) {
            float x = (random.nextFloat() * w + px + w) % w;
            float y = (random.nextFloat() * h * 0.62f + py + h) % (h * 0.65f);
            float twinkle = 0.45f + 0.55f * (float) Math.sin(phase * 1.8f + i * 1.3f);
            int alpha = Math.round((70 + random.nextInt(130)) * twinkle);
            paint.setColor(Color.argb(alpha, 240, 244, 255));
            canvas.drawCircle(x, y, w * (0.0015f + random.nextFloat() * 0.0025f), paint);
        }
    }

    private static void drawClouds(Canvas canvas, int w, int h, float density, boolean light, Paint paint, float phase, float px) {
        Random random = new Random(41);
        int count = Math.round(7 * density) + 2;
        for (int i = 0; i < count; i++) {
            float speed = 0.015f + random.nextFloat() * 0.02f;
            float cx = ((random.nextFloat() + phase * speed) % 1.3f - 0.15f) * w + px;
            float cy = h * (0.08f + random.nextFloat() * 0.38f);
            float r = w * (0.18f + random.nextFloat() * 0.18f);
            int alpha = Math.round((light ? 34 : 26) * density);
            int col = Color.argb(alpha, 235, 242, 255);
            paint.setShader(new RadialGradient(cx, cy, r, col, 0x00FFFFFF, Shader.TileMode.CLAMP));
            canvas.drawCircle(cx, cy, r, paint);
        }
        paint.setShader(null);
    }

    private static void drawFallingRain(Canvas canvas, int w, int h, Paint paint, float phase, float tiltX, boolean storm) {
        if (storm) {
            float pulse = (phase * 0.7f) % 7f;
            if (pulse < 0.18f) {
                int flashAlpha = Math.round(42 * (1f - pulse / 0.18f));
                paint.setColor(Color.argb(flashAlpha, 225, 235, 255));
                canvas.drawRect(0, 0, w, h, paint);
            }
        }
        Random random = new Random(53);
        paint.setStyle(Paint.Style.STROKE);
        int drops = storm ? 68 : 42;
        for (int i = 0; i < drops; i++) {
            float speed = 0.65f + random.nextFloat() * 0.7f;
            float x = ((random.nextFloat() * w + tiltX + phase * w * 0.08f) % w + w) % w;
            float y = ((random.nextFloat() + phase * 0.55f * speed) % 1.15f - 0.1f) * h;
            float len = h * (0.028f + random.nextFloat() * 0.032f);
            paint.setStrokeWidth(Math.max(1f, w * 0.0022f));
            paint.setColor(Color.argb(45 + random.nextInt(55), 220, 235, 255));
            canvas.drawLine(x, y, x - len * 0.14f, y + len, paint);
        }
        paint.setStyle(Paint.Style.FILL);
    }

    /** Drops resting on glass: a soft body, a darker rim below and a bright glint above. */
    private static void drawDrops(Canvas canvas, int w, int h, Paint paint) {
        Random random = new Random(29);
        for (int i = 0; i < 70; i++) {
            float x = random.nextFloat() * w;
            float y = random.nextFloat() * h;
            float r = w * (0.006f + random.nextFloat() * random.nextFloat() * 0.022f);
            float stretch = 1f + random.nextFloat() * 0.5f;
            paint.setShader(new RadialGradient(x, y - r * 0.2f, r * 1.2f, new int[]{0x18FFFFFF, 0x30FFFFFF, 0x10000000}, new float[]{0f, 0.75f, 1f},
                    Shader.TileMode.CLAMP));
            canvas.drawOval(x - r, y - r * stretch, x + r, y + r, paint);
            paint.setShader(null);
            paint.setColor(0x26000000);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(1f, r * 0.12f));
            canvas.drawArc(x - r, y - r * stretch, x + r, y + r, 20, 140, false, paint);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0x80FFFFFF);
            canvas.drawCircle(x - r * 0.35f, y - r * stretch * 0.45f, r * 0.18f, paint);
        }
        // A few drops that ran down, leaving a trail.
        paint.setStyle(Paint.Style.STROKE);
        for (int i = 0; i < 8; i++) {
            float x = random.nextFloat() * w;
            float y = random.nextFloat() * h * 0.8f;
            float length = h * (0.04f + random.nextFloat() * 0.08f);
            paint.setStrokeWidth(w * 0.004f);
            paint.setShader(new LinearGradient(x, y, x, y + length, 0x00FFFFFF, 0x2EFFFFFF, Shader.TileMode.CLAMP));
            Path trail = new Path();
            trail.moveTo(x, y);
            trail.quadTo(x + w * 0.006f, y + length * 0.5f, x - w * 0.002f, y + length);
            canvas.drawPath(trail, paint);
        }
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
    }

    private static void drawOccasion(Canvas canvas, int w, int h, String occasion, boolean light, Paint paint) {
        Random random = new Random(occasion.hashCode());
        if (NATIONAL.equals(occasion)) {
            // A green glow from the top and green and white confetti, light enough to keep the art.
            paint.setColor(Color.BLACK);
            paint.setShader(new RadialGradient(w * 0.5f, -h * 0.05f, h * 0.6f, new int[]{light ? 0x4000A86B : 0x6600A86B, 0x2200A86B, 0x0000A86B},
                    new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, paint);
            paint.setShader(null);
            for (int i = 0; i < 46; i++) {
                float x = random.nextFloat() * w;
                float y = random.nextFloat() * h * 0.45f;
                float size = w * (0.006f + random.nextFloat() * 0.010f);
                paint.setColor(random.nextBoolean() ? Color.argb(150, 0, 168, 107) : Color.argb(120, 255, 255, 255));
                canvas.save();
                canvas.rotate(random.nextFloat() * 180f, x, y);
                canvas.drawRoundRect(x - size, y - size * 0.4f, x + size, y + size * 0.4f, size * 0.3f, size * 0.3f, paint);
                canvas.restore();
            }
        } else if (FOUNDING.equals(occasion)) {
            // Warm gold light, and a band in the Sadu weave's diamonds and triangles along the top.
            paint.setColor(Color.BLACK);
            paint.setShader(new LinearGradient(0, 0, 0, h * 0.5f, light ? 0x40B07A3C : 0x669C6A35, 0x00A0703A, Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, paint);
            paint.setShader(null);
            float band = w * 0.05f;
            float top = h * 0.012f;
            int[] weave = {0xB08B2E2E, 0xB0E8D3A8, 0xB03D2A20, 0xB0C08A3E};
            for (int i = 0; i * band < w + band; i++) {
                float x = i * band;
                Path diamond = new Path();
                diamond.moveTo(x + band / 2f, top);
                diamond.lineTo(x + band, top + band / 2f);
                diamond.lineTo(x + band / 2f, top + band);
                diamond.lineTo(x, top + band / 2f);
                diamond.close();
                paint.setColor(weave[i % weave.length]);
                canvas.drawPath(diamond, paint);
                Path tooth = new Path();
                tooth.moveTo(x, top + band * 1.15f);
                tooth.lineTo(x + band / 2f, top + band * 1.55f);
                tooth.lineTo(x + band, top + band * 1.15f);
                tooth.close();
                paint.setColor(weave[(i + 2) % weave.length]);
                canvas.drawPath(tooth, paint);
            }
        } else {
            // The Eids: a soft gold glow and twinkling stars at the top.
            paint.setColor(Color.BLACK);
            paint.setShader(new RadialGradient(w * 0.8f, h * 0.08f, h * 0.45f, new int[]{light ? 0x40FFD27A : 0x60FFD27A, 0x00FFD27A},
                    null, Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, paint);
            paint.setShader(null);
            for (int i = 0; i < 26; i++) {
                float x = random.nextFloat() * w;
                float y = random.nextFloat() * h * 0.42f;
                float size = w * (0.008f + random.nextFloat() * 0.016f);
                paint.setColor(Color.argb(170 + random.nextInt(80), 255, 214, 120));
                Path star = new Path();
                for (int k = 0; k < 8; k++) {
                    double angle = Math.PI / 4 * k - Math.PI / 2;
                    float radius = k % 2 == 0 ? size : size * 0.28f;
                    float px = x + (float) Math.cos(angle) * radius;
                    float py = y + (float) Math.sin(angle) * radius;
                    if (k == 0) {
                        star.moveTo(px, py);
                    } else {
                        star.lineTo(px, py);
                    }
                }
                star.close();
                canvas.drawPath(star, paint);
            }
        }
    }

    /** The overlay as a drawable, to lay over the wallpaper art on Home. */
    static final class Layer extends Drawable {
        State state;
        final boolean glass;

        Layer(State state, boolean glass) {
            this.state = state;
            this.glass = glass;
        }

        @Override
        public void draw(Canvas canvas) {
            Rect b = getBounds();
            canvas.save();
            canvas.translate(b.left, b.top);
            Ambience.draw(canvas, b.width(), b.height(), state, glass);
            canvas.restore();
        }

        @Override
        public void setAlpha(int alpha) {
        }

        @Override
        public void setColorFilter(ColorFilter filter) {
        }

        @Override
        public int getOpacity() {
            return PixelFormat.TRANSLUCENT;
        }
    }
}
