package com.sumuw.launcher;

import android.app.AlertDialog;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * A match inside Sara Home: both clubs, the score or the kick-off, the league, channel and ground, then
 * the goals and cards minute by minute and the main numbers side by side (possession, shots, corners...).
 * The details come from ESPN's match summary; the league table is a tap away.
 */
final class MatchPage {
    static final class Event {
        final String minute;
        final String player;
        final String kind; // goal, own, penalty, yellow, red
        final boolean home;

        Event(String minute, String player, String kind, boolean home) {
            this.minute = minute;
            this.player = player;
            this.kind = kind;
            this.home = home;
        }
    }

    static final class Stat {
        final int label;
        final String home;
        final String away;
        final boolean percent;

        Stat(int label, String home, String away, boolean percent) {
            this.label = label;
            this.home = home;
            this.away = away;
            this.percent = percent;
        }
    }

    static final class Details {
        String venue = "";
        final List<Event> events = new ArrayList<>();
        final List<Stat> stats = new ArrayList<>();
    }

    private static final String[][] STATS = {
            {"possessionPct", "%"}, {"totalShots", ""}, {"shotsOnTarget", ""}, {"wonCorners", ""}, {"foulsCommitted", ""},
            {"offsides", ""}, {"yellowCards", ""}, {"redCards", ""}, {"saves", ""},
    };
    private static final int[] STAT_NAMES = {
            R.string.stat_possession, R.string.stat_shots, R.string.stat_on_target, R.string.stat_corners, R.string.stat_fouls,
            R.string.stat_offsides, R.string.stat_yellow, R.string.stat_red, R.string.stat_saves,
    };

    private MatchPage() {
    }

    static Details parse(String json, Matches.Match match) throws Exception {
        Details details = new Details();
        JSONObject root = new JSONObject(json);
        JSONObject info = root.optJSONObject("gameInfo");
        if (info != null && info.optJSONObject("venue") != null) {
            details.venue = info.getJSONObject("venue").optString("fullName", "");
        }
        JSONArray events = root.optJSONArray("keyEvents");
        for (int i = 0; events != null && i < events.length(); i++) {
            JSONObject event = events.getJSONObject(i);
            JSONObject type = event.optJSONObject("type");
            String kind = type == null ? "" : type.optString("type", "");
            String what;
            if (event.optBoolean("scoringPlay")) {
                what = kind.contains("own") ? "own" : kind.contains("penalty") ? "penalty" : "goal";
            } else if (kind.contains("red-card")) {
                what = "red";
            } else if (kind.contains("yellow-card")) {
                what = "yellow";
            } else {
                continue;
            }
            JSONObject team = event.optJSONObject("team");
            String teamId = team == null ? "" : team.optString("id", "");
            String player = "";
            JSONArray people = event.optJSONArray("participants");
            if (people != null && people.length() > 0 && people.getJSONObject(0).optJSONObject("athlete") != null) {
                player = people.getJSONObject(0).getJSONObject("athlete").optString("displayName", "");
            }
            String minute = event.optJSONObject("clock") == null ? "" : event.getJSONObject("clock").optString("displayValue", "");
            details.events.add(new Event(minute, player, what, teamId.equals(match.homeId)));
        }
        JSONObject box = root.optJSONObject("boxscore");
        JSONArray teams = box == null ? null : box.optJSONArray("teams");
        JSONObject homeStats = null;
        JSONObject awayStats = null;
        for (int i = 0; teams != null && i < teams.length(); i++) {
            JSONObject side = teams.getJSONObject(i);
            JSONObject team = side.optJSONObject("team");
            boolean home = "home".equals(side.optString("homeAway")) || (team != null && match.homeId.equals(team.optString("id")));
            JSONObject values = new JSONObject();
            JSONArray stats = side.optJSONArray("statistics");
            for (int s = 0; stats != null && s < stats.length(); s++) {
                JSONObject stat = stats.getJSONObject(s);
                values.put(stat.optString("name"), stat.optString("displayValue", ""));
            }
            if (home) {
                homeStats = values;
            } else {
                awayStats = values;
            }
        }
        if (homeStats != null && awayStats != null) {
            for (int i = 0; i < STATS.length; i++) {
                String h = homeStats.optString(STATS[i][0], "");
                String a = awayStats.optString(STATS[i][0], "");
                if (h.length() > 0 && a.length() > 0) {
                    details.stats.add(new Stat(STAT_NAMES[i], h, a, STATS[i][1].length() > 0));
                }
            }
        }
        return details;
    }

    // ---------------------------------------------------------------- the page

    static AlertDialog show(final HomeActivity home, final Matches.Match match) {
        final int ink = home.nightMode() ? 0xFFF2F2F2 : 0xFF17171A;
        final int soft = HomeActivity.withAlpha(ink, 0.6f);
        ScrollView scroll = new ScrollView(home);
        final LinearLayout box = new LinearLayout(home);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(home.dp(18.0f), home.dp(18.0f), home.dp(18.0f), home.dp(8.0f));
        scroll.addView(box);
        String channel = Matches.channel(match.league);
        TextView league = home.label(Matches.leagueName(match.league) + (channel.isEmpty() ? "" : home.getString(R.string.list_separator) + channel),
                13, soft, 600);
        league.setGravity(Gravity.CENTER);
        box.addView(league, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout row = new LinearLayout(home);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, home.dp(14.0f), 0, home.dp(6.0f));
        row.addView(side(home, match.homeId, match.home, ink), new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout middle = new LinearLayout(home);
        middle.setOrientation(LinearLayout.VERTICAL);
        middle.setGravity(Gravity.CENTER);
        long now = System.currentTimeMillis();
        if (match.hasScore()) {
            LinearLayout score = new LinearLayout(home);
            score.setGravity(Gravity.CENTER);
            score.addView(home.label(home.localDigits(match.homeScore), 34, ink, 700));
            TextView dash = home.label("–", 24, soft, 500);
            dash.setPadding(home.dp(8.0f), 0, home.dp(8.0f), 0);
            score.addView(dash);
            score.addView(home.label(home.localDigits(match.awayScore), 34, ink, 700));
            middle.addView(score);
            middle.addView(home.label(match.live ? home.matchClock(match.clock) : home.getString(R.string.match_full_time), 13,
                    match.live ? 0xFFE5484D : soft, 700));
        } else {
            middle.addView(home.label(android.text.format.DateFormat.getTimeFormat(home).format(new Date(match.time)), 24, ink, 700));
            long left = match.time - now;
            middle.addView(home.label(left > 0 && left < 3 * 3600000L ? home.shortCountdown(left) : home.matchDay(match.time, now), 13, soft, 600));
        }
        row.addView(middle, new LinearLayout.LayoutParams(-2, -2));
        row.addView(side(home, match.awayId, match.away, ink), new LinearLayout.LayoutParams(0, -2, 1f));
        box.addView(row, new LinearLayout.LayoutParams(-1, -2));

        final TextView venue = home.label("", 12, soft, 400);
        venue.setGravity(Gravity.CENTER);
        venue.setVisibility(View.GONE);
        box.addView(venue, new LinearLayout.LayoutParams(-1, -2));
        final TextView loading = home.label(home.getString("pre".equals(match.state) ? R.string.match_not_started : R.string.match_loading), 13, soft, 400);
        loading.setGravity(Gravity.CENTER);
        loading.setPadding(0, home.dp(18.0f), 0, home.dp(10.0f));
        box.addView(loading, new LinearLayout.LayoutParams(-1, -2));
        final LinearLayout body = new LinearLayout(home);
        body.setOrientation(LinearLayout.VERTICAL);
        box.addView(body, new LinearLayout.LayoutParams(-1, -2));
        box.setContentDescription(Matches.arabic(match.home) + " × " + Matches.arabic(match.away));

        AlertDialog.Builder builder = new AlertDialog.Builder(home)
                .setView(scroll)
                .setPositiveButton(home.getString(R.string.done), null)
                .setNeutralButton(home.getString(R.string.match_google), (d, w) -> home.searchMatch(match));
        if (Standings.hasTable(match.league)) {
            builder.setNegativeButton(home.getString(R.string.table_title), (d, w) -> showTable(home, match.league));
        }
        final AlertDialog dialog = builder.show();

        home.background(() -> {
            Details found = null;
            try {
                found = parse(Matches.get("https://site.api.espn.com/apis/site/v2/sports/soccer/" + match.league + "/summary?event=" + match.id), match);
            } catch (Exception ignored) {
            }
            final Details details = found;
            home.runOnUiThread(() -> {
                if (!dialog.isShowing()) {
                    return;
                }
                fillDetails(home, match, details, venue, loading, body, ink, soft);
            });
        });
        return dialog;
    }

    static void fillDetails(HomeActivity home, Matches.Match match, Details details, TextView venue, TextView loading, LinearLayout body,
                            int ink, int soft) {
        body.removeAllViews();
        if (details == null) {
            loading.setText(home.getString(R.string.match_details_failed));
            return;
        }
        if (!details.venue.isEmpty()) {
            venue.setText(details.venue);
            venue.setVisibility(View.VISIBLE);
        }
        if (details.events.isEmpty() && details.stats.isEmpty()) {
            loading.setText(home.getString("pre".equals(match.state) ? R.string.match_not_started : R.string.match_no_details));
            return;
        }
        loading.setVisibility(View.GONE);
        if (!details.events.isEmpty()) {
            body.addView(section(home, home.getString(R.string.match_events), ink));
            for (Event event : details.events) {
                LinearLayout line = new LinearLayout(home);
                line.setGravity(Gravity.CENTER_VERTICAL | (event.home ? Gravity.START : Gravity.END));
                line.setPadding(0, home.dp(5.0f), 0, home.dp(5.0f));
                String mark = event.kind.equals("yellow") ? "🟨" : event.kind.equals("red") ? "🟥" : "⚽";
                String note = event.kind.equals("own") ? " " + home.getString(R.string.match_own_goal)
                        : event.kind.equals("penalty") ? " " + home.getString(R.string.match_penalty) : "";
                TextView minute = home.label("⁦" + home.localDigits(event.minute) + "⁩", 12, soft, 700);
                TextView text = home.label(mark + " " + event.player + note, 14, ink, event.kind.startsWith("goal") || event.kind.equals("penalty") ? 600 : 400);
                if (event.home) {
                    line.addView(minute);
                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, -2);
                    params.setMarginStart(home.dp(8.0f));
                    line.addView(text, params);
                } else {
                    line.addView(text);
                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, -2);
                    params.setMarginStart(home.dp(8.0f));
                    line.addView(minute, params);
                }
                body.addView(line, new LinearLayout.LayoutParams(-1, -2));
            }
        }
        if (!details.stats.isEmpty()) {
            body.addView(section(home, home.getString(R.string.match_stats), ink));
            for (Stat stat : details.stats) {
                body.addView(statRow(home, stat, ink, soft), new LinearLayout.LayoutParams(-1, -2));
            }
        }
    }

    private static View side(HomeActivity home, String teamId, String name, int ink) {
        LinearLayout side = new LinearLayout(home);
        side.setOrientation(LinearLayout.VERTICAL);
        side.setGravity(Gravity.CENTER);
        ImageView crest = new ImageView(home);
        crest.setImageDrawable(home.crestFor(teamId, Matches.arabic(name), home.dp(54.0f)));
        side.addView(crest, new LinearLayout.LayoutParams(home.dp(54.0f), home.dp(54.0f)));
        TextView label = home.label(Matches.arabic(name), 14, ink, 600);
        label.setGravity(Gravity.CENTER);
        label.setMaxLines(2);
        label.setPadding(0, home.dp(6.0f), 0, 0);
        side.addView(label, new LinearLayout.LayoutParams(-1, -2));
        return side;
    }

    private static View section(HomeActivity home, String title, int ink) {
        TextView label = home.label(title, 14, ink, 700);
        label.setPadding(0, home.dp(18.0f), 0, home.dp(6.0f));
        return label;
    }

    /** Both numbers with a bar in two colours between them, home's share from the start. */
    private static View statRow(HomeActivity home, Stat stat, int ink, int soft) {
        LinearLayout row = new LinearLayout(home);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(0, home.dp(6.0f), 0, home.dp(6.0f));
        LinearLayout numbers = new LinearLayout(home);
        numbers.setGravity(Gravity.CENTER_VERTICAL);
        String suffix = stat.percent ? "٪" : "";
        numbers.addView(home.label(home.localDigits(trim(stat.home)) + suffix, 14, ink, 700), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView name = home.label(home.getString(stat.label), 13, soft, 500);
        name.setGravity(Gravity.CENTER);
        numbers.addView(name, new LinearLayout.LayoutParams(-2, -2));
        TextView away = home.label(home.localDigits(trim(stat.away)) + suffix, 14, ink, 700);
        away.setGravity(Gravity.END);
        numbers.addView(away, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(numbers, new LinearLayout.LayoutParams(-1, -2));
        double h = number(stat.home);
        double a = number(stat.away);
        double total = h + a;
        LinearLayout bar = new LinearLayout(home);
        bar.setPadding(0, home.dp(4.0f), 0, 0);
        View left = new View(home);
        left.setBackground(home.pill(home.accent, 2));
        View right = new View(home);
        right.setBackground(home.pill(HomeActivity.withAlpha(ink, 0.25f), 2));
        float share = total <= 0 ? 0.5f : (float) (h / total);
        LinearLayout.LayoutParams leftParams = new LinearLayout.LayoutParams(0, home.dp(4.0f), Math.max(0.001f, share));
        leftParams.setMarginEnd(home.dp(2.0f));
        bar.addView(left, leftParams);
        bar.addView(right, new LinearLayout.LayoutParams(0, home.dp(4.0f), Math.max(0.001f, 1f - share)));
        row.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        row.setContentDescription(home.getString(stat.label) + "، " + trim(stat.home) + suffix + " " + home.getString(R.string.match_to) + " " + trim(stat.away) + suffix);
        return row;
    }

    private static String trim(String value) {
        return value.endsWith(".0") ? value.substring(0, value.length() - 2) : value;
    }

    private static double number(String value) {
        try {
            return Double.parseDouble(value.replace("%", ""));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    // ---------------------------------------------------------------- league table

    static AlertDialog showTable(final HomeActivity home, final String league) {
        final int ink = home.nightMode() ? 0xFFF2F2F2 : 0xFF17171A;
        final int soft = HomeActivity.withAlpha(ink, 0.6f);
        ScrollView scroll = new ScrollView(home);
        final LinearLayout box = new LinearLayout(home);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(home.dp(16.0f), home.dp(16.0f), home.dp(16.0f), home.dp(8.0f));
        scroll.addView(box);
        final AlertDialog dialog = new AlertDialog.Builder(home)
                .setTitle(home.getString(R.string.table_of, Matches.leagueName(league)))
                .setView(scroll)
                .setPositiveButton(home.getString(R.string.done), null)
                .show();
        final android.content.SharedPreferences prefs = home.getSharedPreferences("duo_home", 0);
        fillTable(home, box, Standings.cached(prefs, league), Matches.teamIds(prefs), ink, soft);
        if (Standings.stale(prefs, league, System.currentTimeMillis()) || Standings.cached(prefs, league).isEmpty()) {
            home.background(() -> {
                List<Standings.Row> rows = null;
                try {
                    rows = Standings.fetch(league);
                    Standings.store(prefs, league, rows, System.currentTimeMillis());
                } catch (Exception ignored) {
                }
                final List<Standings.Row> found = rows;
                home.runOnUiThread(() -> {
                    if (dialog.isShowing() && found != null) {
                        fillTable(home, box, found, Matches.teamIds(prefs), ink, soft);
                    }
                });
            });
        }
        return dialog;
    }

    static void fillTable(HomeActivity home, LinearLayout box, List<Standings.Row> rows, Set<String> favourites, int ink, int soft) {
        box.removeAllViews();
        if (rows.isEmpty()) {
            box.addView(home.label(home.getString(R.string.match_loading), 14, soft, 400));
            return;
        }
        box.addView(tableRow(home, "#", null, home.getString(R.string.table_team), home.getString(R.string.table_played),
                home.getString(R.string.table_difference), home.getString(R.string.table_points), soft, false, 600));
        for (Standings.Row row : rows) {
            boolean mine = favourites.contains(row.teamId);
            View line = tableRow(home, home.localDigits(String.valueOf(row.rank)), row, Matches.arabic(row.name),
                    home.localDigits(String.valueOf(row.played)), "⁦" + home.localDigits(row.difference) + "⁩",
                    home.localDigits(String.valueOf(row.points)), ink, mine, mine ? 700 : 500);
            box.addView(line);
        }
    }

    private static View tableRow(HomeActivity home, String rank, Standings.Row row, String name, String played, String difference,
                                 String points, int color, boolean highlight, int weight) {
        LinearLayout line = new LinearLayout(home);
        line.setGravity(Gravity.CENTER_VERTICAL);
        line.setPadding(home.dp(6.0f), home.dp(7.0f), home.dp(6.0f), home.dp(7.0f));
        if (highlight) {
            line.setBackground(home.pill(HomeActivity.withAlpha(home.accent, 0.22f), 10));
        }
        TextView r = home.label(rank, 13, color, weight);
        r.setGravity(Gravity.CENTER);
        line.addView(r, new LinearLayout.LayoutParams(home.dp(26.0f), -2));
        FrameLayout crestBox = new FrameLayout(home);
        if (row != null) {
            ImageView crest = new ImageView(home);
            crest.setImageDrawable(home.crestFor(row.teamId, Matches.arabic(row.name), home.dp(22.0f)));
            crestBox.addView(crest, new FrameLayout.LayoutParams(home.dp(22.0f), home.dp(22.0f), Gravity.CENTER));
        }
        line.addView(crestBox, new LinearLayout.LayoutParams(home.dp(28.0f), home.dp(22.0f)));
        TextView n = home.label(name, 14, color, weight);
        n.setSingleLine(true);
        n.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams nameParams = new LinearLayout.LayoutParams(0, -2, 1f);
        nameParams.setMarginStart(home.dp(6.0f));
        line.addView(n, nameParams);
        String[] values = {played, difference, points};
        for (int i = 0; i < values.length; i++) {
            TextView cell = home.label(values[i], 13, color, i == 2 ? 700 : weight);
            cell.setGravity(Gravity.CENTER);
            line.addView(cell, new LinearLayout.LayoutParams(home.dp(38.0f), -2));
        }
        line.setContentDescription(rank + "، " + name + "، " + home.getString(R.string.table_points) + " " + points);
        return line;
    }
}
