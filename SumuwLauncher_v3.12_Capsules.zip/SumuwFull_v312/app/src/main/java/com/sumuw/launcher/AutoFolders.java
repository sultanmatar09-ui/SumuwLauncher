package com.sumuw.launcher;

import android.content.pm.ApplicationInfo;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Sorts apps into ready-made folders (government, banks, social, …) from the package name, the
 * app's name and the category the app declares. Unsure apps stay where they are.
 */
final class AutoFolders {
    static final String ISLAMIC = "islamic";
    static final String GOV = "gov";
    static final String MONEY = "money";
    static final String SOCIAL = "social";
    static final String SHOP = "shop";
    static final String FUN = "fun";
    static final String PHOTOS = "photos";
    static final String GAMES = "games";
    static final String NEWS = "news";
    static final String TRAVEL = "travel";
    static final String WORK = "work";
    static final String SAMSUNG = "samsung";
    static final String GOOGLE = "google";

    /** The order folders are offered in. */
    static final String[] ORDER = {GOV, MONEY, SOCIAL, ISLAMIC, SHOP, TRAVEL, FUN, PHOTOS, NEWS, WORK, GAMES, SAMSUNG, GOOGLE};

    private AutoFolders() {
    }

    static int nameRes(String id) {
        switch (id) {
            case ISLAMIC:
                return R.string.auto_islamic;
            case GOV:
                return R.string.auto_gov;
            case MONEY:
                return R.string.auto_money;
            case SOCIAL:
                return R.string.auto_social;
            case SHOP:
                return R.string.auto_shop;
            case FUN:
                return R.string.auto_fun;
            case PHOTOS:
                return R.string.auto_photos;
            case GAMES:
                return R.string.auto_games;
            case NEWS:
                return R.string.auto_news;
            case TRAVEL:
                return R.string.auto_travel;
            case WORK:
                return R.string.auto_work;
            case SAMSUNG:
                return R.string.auto_samsung;
            default:
                return R.string.auto_google;
        }
    }

    // Package-name pieces (between the dots) and whole package names.
    private static final Set<String> ISLAMIC_PKG = set("quran", "koran", "muslim", "muslimpro", "athan", "adhan", "azan",
            "salat", "salah", "prayer", "prayertimes", "qibla", "hisn", "hisnmuslim", "azkar", "adhkar", "athkar", "islam",
            "islamic", "hadith", "tafsir", "mushaf", "ayah", "dua");
    private static final Set<String> GOV_PKG = set("absher", "tawakkalna", "twkhayat", "nafath", "sehhaty", "najiz", "balady",
            "muqeem", "qiwa", "madrasati", "gosi", "musaned", "ejar", "etimad", "nusuk", "tabaud", "wasel", "moi", "mawid");
    private static final Set<String> MONEY_PKG = set("bank", "banking", "alrajhi", "rajhi", "alrajhiretailapp", "alahli", "snb",
            "riyadbank", "alinma", "albilad", "bilad", "sabb", "aljazira", "anb", "stcpay", "urpay", "barq", "wallet", "paypal",
            "tadawul", "derayah", "tamara", "tabby", "mada", "tiqmo", "meem", "d360", "spay", "walletnfcrel", "alawwal",
            "saib", "bsf", "fransi", "enjaz", "sadad", "binance", "sahm");
    private static final Set<String> SOCIAL_PKG = set("com.whatsapp", "com.whatsapp.w4b", "com.facebook.katana",
            "com.facebook.orca", "com.facebook.lite", "com.facebook.mlite", "com.instagram.android", "com.instagram.barcelona",
            "com.twitter.android", "com.snapchat.android", "org.telegram.messenger", "org.thunderdog.challegram",
            "com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.linkedin.android", "com.discord",
            "com.reddit.frontpage", "com.pinterest", "org.thoughtcrime.securesms", "jp.naver.line.android", "com.viber.voip",
            "com.skype.raider", "com.imo.android.imoim", "com.tencent.mm", "com.tumblr", "com.bereal.ft", "com.tinder");
    private static final Set<String> GAMES_PKG = set("game", "games", "supercell", "gameloft", "playrix", "zynga", "rovio",
            "miniclip", "king", "roblox", "mojang", "pubg", "freefireth", "freefiremax", "subwaysurf", "innersloth",
            "callofduty", "garena", "moonactive", "voodoo", "ketchapp", "netmarble", "nianticlabs");
    private static final Set<String> NEWS_PKG = set("news", "aljazeera", "alarabiya", "alhadath", "sabq", "okaz", "aawsat",
            "bbc", "cnn", "skynews", "independentarabia", "argaam", "almadina", "alyaum", "alwatan");
    private static final Set<String> FUN_PKG = set("youtube", "netflix", "mediaclient", "shahid", "spotify", "anghami", "osn",
            "osnplus", "starzplay", "disney", "avod", "twitch", "soundcloud", "deezer", "tod", "watchit", "jawwy", "vlc",
            "mxtech", "podcasts", "audible", "kindle", "storytel");
    private static final Set<String> SHOP_PKG = set("amazon", "mshop", "noon", "shein", "zzkko", "aliexpress", "aliexpresshd",
            "namshi", "jarir", "temu", "trendyol", "ikea", "jahez", "hungerstation", "mrsool", "talabat", "toyou", "keeta",
            "ninja", "nana", "tamimi", "panda", "danube", "carrefour", "lulu", "ounass", "sivvi", "styli", "nahdi", "aldawaa",
            "bindawood", "eats", "deliveroo", "dukan", "salla", "haraj", "opensooq", "dubizzle", "goldenscent", "centrepoint");
    private static final Set<String> TRAVEL_PKG = set("maps", "waze", "ubercab", "uber", "careem", "acma", "jeeny", "mtakso",
            "bolt", "flynas", "flyadeal", "saudia", "almosafer", "tajawal", "booking", "airbnb", "agoda", "expedia", "trivago",
            "skyscanner", "wego", "gathern", "darb", "sar", "kayak", "emirates", "qatarairways", "rentalcars", "theeb", "yelo");
    private static final Set<String> WORK_PKG = set("office", "word", "excel", "powerpoint", "outlook", "teams", "onedrive",
            "onenote", "docs", "editors", "sheets", "slides", "keep", "notion", "zoom", "videomeetings", "slack", "trello",
            "asana", "evernote", "dropbox", "reader", "camscanner", "pdf", "notes", "gm", "todo", "wps", "scanner", "translate",
            "lens", "authenticator");
    /** The everyday apps a phone comes with stay loose even when grouping by maker. */
    private static final Set<String> CORE_PKG = set("camera", "gallery", "gallery3d", "dialer", "contacts", "messaging", "mms",
            "settings", "clock", "clockpackage", "deskclock", "calendar", "calculator", "popupcalculator", "myfiles", "vending",
            "photos", "googlecamera", "launcher", "documentsui", "phone", "incallui", "googlequicksearchbox");

    // Whole words of the app's name, after ArabicText.normalize (so أ إ آ → ا, ة → ه, ى → ي).
    private static final Set<String> ISLAMIC_WORDS = set("قران", "مصحف", "اذان", "صلاتي", "صلاه", "اذكار", "حصن", "تفسير",
            "حديث", "قبله", "دعاء", "ادعيه", "رقيه", "تلاوه", "ختمه", "مسلم", "اسلام", "quran", "muslim", "athan", "adhan",
            "azkar", "hadith", "qibla", "prayer");
    private static final Set<String> GOV_WORDS = set("ابشر", "توكلنا", "نفاذ", "صحتي", "ناجز", "بلدي", "مقيم", "قوي",
            "مدرستي", "تامينات", "مساند", "ايجار", "اعتماد", "نسك", "وزاره", "هيئه", "حكومي", "موعد", "absher", "tawakkalna",
            "nafath", "sehhaty");
    private static final Set<String> MONEY_WORDS = set("بنك", "مصرف", "راجحي", "اهلي", "انماء", "بلاد", "محفظه", "تداول",
            "تمارا", "تابي", "باي", "سداد", "bank", "pay", "wallet");
    private static final Set<String> SHOP_WORDS = set("نون", "امازون", "نمشي", "جرير", "اكسترا", "جاهز", "هنقرستيشن",
            "مرسول", "طلبات", "تويو", "كيتا", "نينجا", "نعناع", "تميمي", "بنده", "دانوب", "كارفور", "نهدي", "دواء", "تيمو",
            "ايكيا", "حراج", "noon", "amazon", "shein", "temu");
    private static final Set<String> FUN_WORDS = set("يوتيوب", "نتفليكس", "شاهد", "انغامي", "سبوتيفاي", "youtube",
            "netflix", "shahid", "spotify", "anghami");
    private static final Set<String> NEWS_WORDS = set("اخبار", "جزيره", "حدث", "سبق", "عكاظ", "ارقام", "news");
    private static final Set<String> TRAVEL_WORDS = set("خرائط", "اوبر", "كريم", "جيني", "طيران", "مسافر", "بولت",
            "maps", "uber", "careem", "booking");

    /** The folder an app belongs in, or null when unsure. */
    static String categorize(String pkg, String label, int appCategory) {
        String lower = pkg == null ? "" : pkg.toLowerCase(Locale.ROOT);
        String[] parts = lower.split("\\.");
        String[] words = ArabicText.normalize(label).split(" ");
        if (any(parts, ISLAMIC_PKG) || anyWord(words, ISLAMIC_WORDS)) {
            return ISLAMIC;
        }
        if (lower.startsWith("sa.gov.") || any(parts, GOV_PKG) || anyWord(words, GOV_WORDS)) {
            return GOV;
        }
        if (any(parts, MONEY_PKG) || payPart(parts) || anyWord(words, MONEY_WORDS)) {
            return MONEY;
        }
        if (SOCIAL_PKG.contains(lower) || appCategory == ApplicationInfo.CATEGORY_SOCIAL) {
            return SOCIAL;
        }
        if (any(parts, NEWS_PKG) || anyWord(words, NEWS_WORDS) || appCategory == ApplicationInfo.CATEGORY_NEWS) {
            return NEWS;
        }
        if (any(parts, FUN_PKG) || anyWord(words, FUN_WORDS)
                || appCategory == ApplicationInfo.CATEGORY_VIDEO || appCategory == ApplicationInfo.CATEGORY_AUDIO) {
            return FUN;
        }
        if (any(parts, SHOP_PKG) || anyWord(words, SHOP_WORDS)) {
            return SHOP;
        }
        if (any(parts, TRAVEL_PKG) || anyWord(words, TRAVEL_WORDS) || appCategory == ApplicationInfo.CATEGORY_MAPS) {
            return TRAVEL;
        }
        if (appCategory == ApplicationInfo.CATEGORY_GAME || any(parts, GAMES_PKG)) {
            return GAMES;
        }
        if (appCategory == ApplicationInfo.CATEGORY_IMAGE) {
            return PHOTOS;
        }
        boolean core = any(parts, CORE_PKG);
        if (!core && (any(parts, WORK_PKG) || appCategory == ApplicationInfo.CATEGORY_PRODUCTIVITY)) {
            return WORK;
        }
        if (core) {
            return null;
        }
        if (lower.startsWith("com.samsung.") || lower.startsWith("com.sec.")) {
            return SAMSUNG;
        }
        if (lower.startsWith("com.google.")) {
            return GOOGLE;
        }
        return null;
    }

    private static Set<String> set(String... values) {
        return new HashSet<>(Arrays.asList(values));
    }

    private static boolean any(String[] parts, Set<String> known) {
        for (int i = 1; i < parts.length; i++) { // skip "com", "org", "sa"…
            if (known.contains(parts[i])) {
                return true;
            }
        }
        return false;
    }

    /** stcpay, urpay, spay, payit…, but not "play" or "display". */
    private static boolean payPart(String[] parts) {
        for (int i = 1; i < parts.length; i++) {
            String part = parts[i];
            if (part.equals("pay") || (part.length() <= 8 && part.endsWith("pay")) || part.startsWith("payit")) {
                return true;
            }
        }
        return false;
    }

    private static boolean anyWord(String[] words, Set<String> known) {
        for (String word : words) {
            if (word.isEmpty()) {
                continue;
            }
            if (known.contains(word)) {
                return true;
            }
            // Arabic names often start with "ال" (القرآن، الراجحي): compare without it too.
            if (word.length() > 3 && word.startsWith("ال") && known.contains(word.substring(2))) {
                return true;
            }
        }
        return false;
    }
}
