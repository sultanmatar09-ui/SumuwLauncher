package com.sumuw.launcher;

import android.content.Context;
import android.icu.util.IslamicCalendar;
import android.icu.util.ULocale;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Upcoming Islamic occasions on the Umm al-Qura calendar, with how many days remain. */
final class HijriEvents {
    static final int NEW_YEAR = 0;
    static final int ASHURA = 1;
    static final int RAMADAN = 2;
    static final int EID_FITR = 3;
    static final int ARAFAH = 4;
    static final int EID_ADHA = 5;
    static final int WHITE_DAYS = 6;

    static final class Occasion {
        final int kind;
        final long start;
        final int daysLeft;
        final int hijriMonth;
        final int hijriDay;

        Occasion(int kind, long start, int daysLeft, int hijriMonth, int hijriDay) {
            this.kind = kind;
            this.start = start;
            this.daysLeft = daysLeft;
            this.hijriMonth = hijriMonth;
            this.hijriDay = hijriDay;
        }

        /** Fasting is recommended on these, so they get an evening-before reminder that says so. */
        boolean fasting() {
            return kind == ASHURA || kind == ARAFAH || kind == WHITE_DAYS;
        }
    }

    private HijriEvents() {
    }

    private static IslamicCalendar calendar() {
        IslamicCalendar calendar = new IslamicCalendar(new ULocale("ar@calendar=islamic-umalqura"));
        calendar.setCalculationType(IslamicCalendar.CalculationType.ISLAMIC_UMALQURA);
        return calendar;
    }

    /** {year, month (0 = Muharram), day} of this moment in the Umm al-Qura calendar. */
    static int[] hijri(long when) {
        IslamicCalendar calendar = calendar();
        calendar.setTimeInMillis(when);
        return new int[]{calendar.get(IslamicCalendar.EXTENDED_YEAR), calendar.get(IslamicCalendar.MONTH), calendar.get(IslamicCalendar.DAY_OF_MONTH)};
    }

    /** Midnight (local) of a Hijri date. */
    static long dayStart(int year, int month, int day) {
        return gregorianStart(year, month, day);
    }

    static int monthLength(int year, int month) {
        IslamicCalendar calendar = calendar();
        calendar.clear();
        calendar.set(year, month, 1);
        return calendar.getActualMaximum(IslamicCalendar.DAY_OF_MONTH);
    }

    /** "رمضان ١٤٤٨". */
    static String monthTitle(int year, int month) {
        try {
            IslamicCalendar calendar = calendar();
            calendar.clear();
            calendar.set(year, month, 1);
            android.icu.text.DateFormat format = android.icu.text.DateFormat.getPatternInstance(calendar, "MMMM y", new ULocale("ar@calendar=islamic-umalqura"));
            return format.format(calendar);
        } catch (Throwable error) {
            return (month + 1) + "/" + year;
        }
    }

    /** The occasion on a Hijri day, or -1. */
    static int occasionOn(int month, int day) {
        if (month == IslamicCalendar.MUHARRAM && day == 1) {
            return NEW_YEAR;
        }
        if (month == IslamicCalendar.MUHARRAM && day == 10) {
            return ASHURA;
        }
        if (month == IslamicCalendar.RAMADAN && day == 1) {
            return RAMADAN;
        }
        if (month == IslamicCalendar.SHAWWAL && day == 1) {
            return EID_FITR;
        }
        if (month == IslamicCalendar.DHU_AL_HIJJAH && day == 9) {
            return ARAFAH;
        }
        if (month == IslamicCalendar.DHU_AL_HIJJAH && day == 10) {
            return EID_ADHA;
        }
        if (day >= 13 && day <= 15 && month != IslamicCalendar.RAMADAN && month != IslamicCalendar.DHU_AL_HIJJAH) {
            return WHITE_DAYS;
        }
        return -1;
    }

    static boolean isRamadan(long when) {
        try {
            IslamicCalendar calendar = calendar();
            calendar.setTimeInMillis(when);
            return calendar.get(IslamicCalendar.MONTH) == IslamicCalendar.RAMADAN;
        } catch (Throwable error) {
            return false;
        }
    }

    private static long startOfDay(long when) {
        Calendar day = Calendar.getInstance();
        day.setTimeInMillis(when);
        day.set(Calendar.HOUR_OF_DAY, 0);
        day.set(Calendar.MINUTE, 0);
        day.set(Calendar.SECOND, 0);
        day.set(Calendar.MILLISECOND, 0);
        return day.getTimeInMillis();
    }

    private static long gregorianStart(int year, int month, int day) {
        IslamicCalendar calendar = calendar();
        calendar.clear();
        calendar.set(year, month, day);
        return startOfDay(calendar.getTimeInMillis());
    }

    /** The next {@code limit} occasions from today (today included), soonest first. */
    static List<Occasion> upcoming(long now, int limit) {
        ArrayList<Occasion> all = new ArrayList<>();
        try {
            IslamicCalendar calendar = calendar();
            calendar.setTimeInMillis(now);
            int year = calendar.get(IslamicCalendar.EXTENDED_YEAR);
            int month = calendar.get(IslamicCalendar.MONTH);
            long today = startOfDay(now);
            int[][] fixed = {
                    {NEW_YEAR, IslamicCalendar.MUHARRAM, 1},
                    {ASHURA, IslamicCalendar.MUHARRAM, 10},
                    {RAMADAN, IslamicCalendar.RAMADAN, 1},
                    {EID_FITR, IslamicCalendar.SHAWWAL, 1},
                    {ARAFAH, IslamicCalendar.DHU_AL_HIJJAH, 9},
                    {EID_ADHA, IslamicCalendar.DHU_AL_HIJJAH, 10},
            };
            for (int y = year; y <= year + 1; y++) {
                for (int[] event : fixed) {
                    add(all, event[0], y, event[1], event[2], today);
                }
            }
            // The white days (13th-15th) every month, except Ramadan (already fasting) and
            // Dhu al-Hijjah, whose 13th is a day of Tashreeq when fasting is not allowed.
            for (int i = 0; i < 13; i++) {
                int m = (month + i) % 12;
                int y = year + (month + i) / 12;
                if (m != IslamicCalendar.RAMADAN && m != IslamicCalendar.DHU_AL_HIJJAH) {
                    add(all, WHITE_DAYS, y, m, 13, today);
                }
            }
        } catch (Throwable error) {
            return all;
        }
        Collections.sort(all, new Comparator<Occasion>() {
            @Override
            public int compare(Occasion a, Occasion b) {
                return Long.compare(a.start, b.start);
            }
        });
        while (all.size() > limit) {
            all.remove(all.size() - 1);
        }
        return all;
    }

    private static void add(List<Occasion> list, int kind, int year, int month, int day, long today) {
        long start = gregorianStart(year, month, day);
        // A white-days run is still "current" on the 14th and 15th.
        long end = kind == WHITE_DAYS ? start + 2L * 86400000L : start;
        if (end < today) {
            return;
        }
        int days = (int) Math.max(0, Math.round((start - today) / 86400000.0));
        list.add(new Occasion(kind, start, days, month, day));
    }

    static int nameRes(int kind) {
        switch (kind) {
            case NEW_YEAR:
                return R.string.occ_new_year;
            case ASHURA:
                return R.string.occ_ashura;
            case RAMADAN:
                return R.string.occ_ramadan;
            case EID_FITR:
                return R.string.occ_eid_fitr;
            case ARAFAH:
                return R.string.occ_arafah;
            case EID_ADHA:
                return R.string.occ_eid_adha;
            default:
                return R.string.occ_white_days;
        }
    }

    /** "اليوم"، "غداً"، "بعد يومين"، "بعد ٣ أيام"، "بعد ١٢ يوماً" with correct Arabic agreement. */
    static String whenText(Context context, int days) {
        if (days <= 0) {
            return context.getString(R.string.occ_today);
        }
        if (days == 1) {
            return context.getString(R.string.occ_tomorrow);
        }
        if (days == 2) {
            return context.getString(R.string.occ_two_days);
        }
        if (days <= 10) {
            return context.getString(R.string.occ_few_days, days);
        }
        return context.getString(R.string.occ_many_days, days);
    }

    /** The Hijri date of an occasion, e.g. "١٣ جمادى الآخرة". */
    static String hijriLabel(long when) {
        try {
            ULocale locale = new ULocale("ar@calendar=islamic-umalqura");
            IslamicCalendar calendar = new IslamicCalendar(locale);
            calendar.setCalculationType(IslamicCalendar.CalculationType.ISLAMIC_UMALQURA);
            android.icu.text.SimpleDateFormat format = new android.icu.text.SimpleDateFormat("d MMMM", locale);
            format.setCalendar(calendar);
            return format.format(new java.util.Date(when + 12L * 3600000L));
        } catch (Throwable error) {
            return "";
        }
    }
}
