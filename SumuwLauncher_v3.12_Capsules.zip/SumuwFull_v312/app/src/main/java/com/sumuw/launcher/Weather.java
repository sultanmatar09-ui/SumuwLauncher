package com.sumuw.launcher;

import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

/** Current weather from Open-Meteo (free, no account), cached so the home screen never waits for it. */
final class Weather {
    static final long REFRESH_MS = 30L * 60000L;

    static final int SUN = 0;
    static final int MOON = 1;
    static final int PARTLY = 2;
    static final int CLOUD = 3;
    static final int FOG = 4;
    static final int RAIN = 5;
    static final int SNOW = 6;
    static final int STORM = 7;

    static final class Now {
        final double temp;
        final double max;
        final double min;
        final int code;
        final boolean day;
        final long time;
        /** The coming hours, soonest first (may be empty). */
        List<Hour> hours = new ArrayList<>();

        Now(double temp, double max, double min, int code, boolean day, long time) {
            this.temp = temp;
            this.max = max;
            this.min = min;
            this.code = code;
            this.day = day;
            this.time = time;
        }
    }

    /** One hour of the forecast. */
    static final class Hour {
        final long time;
        final double temp;
        final int code;
        final boolean day;
        /** Chance of rain in percent, -1 when not known. */
        final int rain;

        Hour(long time, double temp, int code, boolean day) {
            this(time, temp, code, day, -1);
        }

        Hour(long time, double temp, int code, boolean day, int rain) {
            this.time = time;
            this.temp = temp;
            this.code = code;
            this.day = day;
            this.rain = rain;
        }
    }

    /** Rain or dust on the way: when it starts, until when, and how much (percent of rain, µg/m³ of dust). */
    static final class Alert {
        final String kind;
        final long from;
        final long until;
        final int level;

        Alert(String kind, long from, long until, int level) {
            this.kind = kind;
            this.from = from;
            this.until = until;
            this.level = level;
        }
    }

    /** Dust levels this high (µg/m³) are what the forecasts and the met services call a dusty day. */
    static final int DUST_LEVEL = 150;
    static final int PM10_LEVEL = 300;
    static final int RAIN_CHANCE = 60;

    static boolean alertsOn(SharedPreferences prefs) {
        return prefs.getBoolean("weather_alerts", true);
    }

    static boolean rainy(int code) {
        return (code >= 51 && code <= 67) || (code >= 80 && code <= 82) || code >= 95;
    }

    /**
     * The first rain or dust of the coming twelve hours, or null. {@code dust} rows are {time, pm10, dust};
     * when both come, the earlier one wins, and dust when they start in the same hour.
     */
    static Alert alert(Now now, List<double[]> dust, long at) {
        Alert rain = null;
        if (now != null) {
            long from = 0L;
            long until = 0L;
            int most = 0;
            for (Hour hour : now.hours) {
                if (hour.time + 3600000L <= at || hour.time > at + 12 * 3600000L) {
                    continue;
                }
                boolean wet = hour.rain >= RAIN_CHANCE || (hour.rain < 0 && rainy(hour.code)) || (rainy(hour.code) && hour.rain >= 40);
                if (wet) {
                    if (from == 0L) {
                        from = hour.time;
                    }
                    until = hour.time + 3600000L;
                    most = Math.max(most, Math.max(hour.rain, 0));
                } else if (from != 0L) {
                    break;
                }
            }
            if (from != 0L) {
                rain = new Alert("rain", from, until, most);
            }
        }
        Alert dusty = null;
        if (dust != null) {
            long from = 0L;
            long until = 0L;
            int most = 0;
            for (double[] row : dust) {
                long time = (long) row[0];
                if (time + 3600000L <= at || time > at + 12 * 3600000L) {
                    continue;
                }
                boolean thick = row[2] >= DUST_LEVEL || row[1] >= PM10_LEVEL;
                if (thick) {
                    if (from == 0L) {
                        from = time;
                    }
                    until = time + 3600000L;
                    most = (int) Math.max(most, Math.max(row[1], row[2]));
                } else if (from != 0L) {
                    break;
                }
            }
            if (from != 0L) {
                dusty = new Alert("dust", from, until, most);
            }
        }
        if (rain == null) {
            return dusty;
        }
        if (dusty == null) {
            return rain;
        }
        return dusty.from <= rain.from ? dusty : rain;
    }

    static void storeAlert(SharedPreferences prefs, Alert alert) {
        if (alert == null) {
            prefs.edit().remove("wx_alert").apply();
        } else {
            prefs.edit().putString("wx_alert", alert.kind + "," + alert.from + "," + alert.until + "," + alert.level).apply();
        }
    }

    /** The saved alert while it still matters. */
    static Alert cachedAlert(SharedPreferences prefs, long at) {
        String[] f = prefs.getString("wx_alert", "").split(",");
        if (f.length != 4) {
            return null;
        }
        try {
            Alert alert = new Alert(f[0], Long.parseLong(f[1]), Long.parseLong(f[2]), Integer.parseInt(f[3]));
            return alert.until > at ? alert : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /** "أمطار متوقعة الساعة ٤ م (٧٠٪)", "غبار الآن حتى ٩ م"… */
    static String alertText(android.content.Context context, Alert alert) {
        long now = System.currentTimeMillis();
        String from = android.text.format.DateFormat.getTimeFormat(context).format(new java.util.Date(alert.from));
        String until = android.text.format.DateFormat.getTimeFormat(context).format(new java.util.Date(alert.until));
        if (alert.kind.equals("dust")) {
            return alert.from <= now ? context.getString(R.string.wx_alert_dust_now, until)
                    : context.getString(R.string.wx_alert_dust_at, from);
        }
        if (alert.level > 0) {
            String chance = String.format(Locale.getDefault(), "%d", alert.level);
            return alert.from <= now ? context.getString(R.string.wx_alert_rain_now_chance, until, chance)
                    : context.getString(R.string.wx_alert_rain_at_chance, from, chance);
        }
        return alert.from <= now ? context.getString(R.string.wx_alert_rain_now, until) : context.getString(R.string.wx_alert_rain_at, from);
    }

    /** Hourly dust and PM10 from Open-Meteo's air-quality forecast: rows of {time, pm10, dust}. Network. */
    static List<double[]> fetchDust(double lat, double lng) throws Exception {
        String url = String.format(Locale.US,
                "https://air-quality-api.open-meteo.com/v1/air-quality?latitude=%.4f&longitude=%.4f&hourly=pm10,dust&forecast_hours=12&timezone=auto",
                lat, lng);
        return parseDust(download(url));
    }

    static List<double[]> parseDust(String json) throws Exception {
        JSONObject root = new JSONObject(json);
        ArrayList<double[]> rows = new ArrayList<>();
        JSONObject hourly = root.optJSONObject("hourly");
        if (hourly == null) {
            return rows;
        }
        JSONArray times = hourly.optJSONArray("time");
        JSONArray pm10 = hourly.optJSONArray("pm10");
        JSONArray dust = hourly.optJSONArray("dust");
        java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US);
        format.setTimeZone(new java.util.SimpleTimeZone(root.optInt("utc_offset_seconds", 0) * 1000, "place"));
        for (int i = 0; times != null && i < times.length(); i++) {
            try {
                long time = format.parse(times.getString(i)).getTime();
                double p = pm10 == null ? 0 : pm10.optDouble(i, 0);
                double d = dust == null ? 0 : dust.optDouble(i, 0);
                rows.add(new double[] {time, Double.isNaN(p) ? 0 : p, Double.isNaN(d) ? 0 : d});
            } catch (Exception ignored) {
            }
        }
        return rows;
    }

    private static String download(String url) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
        try {
            connection.setConnectTimeout(9000);
            connection.setReadTimeout(11000);
            connection.setRequestProperty("User-Agent", "SaraHome/" + HomeActivity.VERSION_NAME);
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            try (InputStream in = connection.getInputStream()) {
                byte[] chunk = new byte[4096];
                int read;
                while ((read = in.read(chunk)) > 0 && buffer.size() < 200_000) {
                    buffer.write(chunk, 0, read);
                }
            }
            return new String(buffer.toByteArray(), StandardCharsets.UTF_8);
        } finally {
            connection.disconnect();
        }
    }

    private Weather() {
    }

    /** The hours of the forecast that haven't started yet, at most {@code limit}. */
    static List<Hour> upcoming(Now now, long at, int limit) {
        ArrayList<Hour> result = new ArrayList<>();
        if (now == null) {
            return result;
        }
        for (Hour hour : now.hours) {
            if (hour.time > at && result.size() < limit) {
                result.add(hour);
            }
        }
        return result;
    }

    static Now cached(SharedPreferences prefs) {
        long time = prefs.getLong("wx_time", 0L);
        if (time == 0L) {
            return null;
        }
        Now now = new Now(prefs.getFloat("wx_temp", 0f), prefs.getFloat("wx_max", 0f), prefs.getFloat("wx_min", 0f),
                prefs.getInt("wx_code", 0), prefs.getBoolean("wx_day", true), time);
        for (String part : prefs.getString("wx_hours", "").split(";")) {
            String[] f = part.split(",");
            if (f.length == 4 || f.length == 5) {
                try {
                    now.hours.add(new Hour(Long.parseLong(f[0]), Double.parseDouble(f[1]), Integer.parseInt(f[2]), "1".equals(f[3]),
                            f.length == 5 ? Integer.parseInt(f[4]) : -1));
                } catch (NumberFormatException ignored) {
                }
            }
        }
        return now;
    }

    /** Where the stored reading is for, so a move of a few km brings a new one. */
    static void storePlace(SharedPreferences prefs, double lat, double lng) {
        prefs.edit().putFloat("wx_lat", (float) lat).putFloat("wx_lng", (float) lng).apply();
    }

    static boolean placeMoved(SharedPreferences prefs, double lat, double lng) {
        if (!prefs.contains("wx_lat")) {
            return prefs.contains("wx_time"); // a reading from before 3.5.4: we don't know where it was for
        }
        return Places.distanceKm(lat, lng, prefs.getFloat("wx_lat", 0f), prefs.getFloat("wx_lng", 0f)) > Places.MOVED_KM;
    }

    static void store(SharedPreferences prefs, Now now) {
        prefs.edit().putFloat("wx_temp", (float) now.temp).putFloat("wx_max", (float) now.max).putFloat("wx_min", (float) now.min)
                .putInt("wx_code", now.code).putBoolean("wx_day", now.day).putLong("wx_time", now.time)
                .putString("wx_hours", hoursText(now.hours)).apply();
    }

    private static String hoursText(List<Hour> hours) {
        StringBuilder text = new StringBuilder();
        for (Hour hour : hours) {
            if (text.length() > 0) {
                text.append(';');
            }
            text.append(hour.time).append(',').append(String.format(Locale.US, "%.1f", hour.temp)).append(',')
                    .append(hour.code).append(',').append(hour.day ? '1' : '0').append(',').append(hour.rain);
        }
        return text.toString();
    }

    /** Network call; run it off the main thread. */
    static Now fetch(double lat, double lng) throws Exception {
        String url = String.format(Locale.US,
                "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f&current=temperature_2m,weather_code,is_day"
                        + "&hourly=temperature_2m,weather_code,is_day,precipitation_probability&forecast_hours=12"
                        + "&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1", lat, lng);
        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
        try {
            connection.setConnectTimeout(9000);
            connection.setReadTimeout(11000);
            connection.setRequestProperty("User-Agent", "SaraHome/" + HomeActivity.VERSION_NAME);
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            try (InputStream in = connection.getInputStream()) {
                byte[] chunk = new byte[4096];
                int read;
                while ((read = in.read(chunk)) > 0 && buffer.size() < 200_000) {
                    buffer.write(chunk, 0, read);
                }
            }
            return parse(new String(buffer.toByteArray(), StandardCharsets.UTF_8), System.currentTimeMillis());
        } finally {
            connection.disconnect();
        }
    }

    /** Reads Open-Meteo's answer; the hours come in the place's own time, given with its UTC offset. */
    static Now parse(String json, long fetched) throws Exception {
        JSONObject root = new JSONObject(json);
        JSONObject current = root.getJSONObject("current");
        JSONObject daily = root.getJSONObject("daily");
        Now now = new Now(current.getDouble("temperature_2m"),
                daily.getJSONArray("temperature_2m_max").getDouble(0),
                daily.getJSONArray("temperature_2m_min").getDouble(0),
                current.getInt("weather_code"), current.optInt("is_day", 1) == 1, fetched);
        JSONObject hourly = root.optJSONObject("hourly");
        if (hourly != null) {
            JSONArray times = hourly.optJSONArray("time");
            JSONArray temps = hourly.optJSONArray("temperature_2m");
            JSONArray codes = hourly.optJSONArray("weather_code");
            JSONArray days = hourly.optJSONArray("is_day");
            JSONArray chances = hourly.optJSONArray("precipitation_probability");
            java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US);
            format.setTimeZone(new java.util.SimpleTimeZone(root.optInt("utc_offset_seconds", 0) * 1000, "place"));
            for (int i = 0; times != null && temps != null && codes != null && i < times.length(); i++) {
                try {
                    long time = format.parse(times.getString(i)).getTime();
                    boolean day = days == null || days.optInt(i, 1) == 1;
                    int chance = chances == null || chances.isNull(i) ? -1 : chances.optInt(i, -1);
                    now.hours.add(new Hour(time, temps.getDouble(i), codes.getInt(i), day, chance));
                } catch (Exception ignored) {
                }
            }
        }
        return now;
    }

    /** Arabic description for a WMO weather code. */
    static int descriptionRes(int code) {
        if (code == 0) {
            return R.string.wx_clear;
        }
        if (code <= 2) {
            return R.string.wx_partly;
        }
        if (code == 3) {
            return R.string.wx_cloudy;
        }
        if (code == 45 || code == 48) {
            return R.string.wx_fog;
        }
        if (code >= 51 && code <= 57) {
            return R.string.wx_drizzle;
        }
        if (code >= 61 && code <= 67) {
            return R.string.wx_rain;
        }
        if ((code >= 71 && code <= 77) || code == 85 || code == 86) {
            return R.string.wx_snow;
        }
        if (code >= 80 && code <= 82) {
            return R.string.wx_showers;
        }
        if (code >= 95) {
            return R.string.wx_storm;
        }
        return R.string.wx_cloudy;
    }

    static int iconType(int code, boolean day) {
        if (code == 0) {
            return day ? SUN : MOON;
        }
        if (code <= 2) {
            return PARTLY;
        }
        if (code == 45 || code == 48) {
            return FOG;
        }
        if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) {
            return RAIN;
        }
        if ((code >= 71 && code <= 77) || code == 85 || code == 86) {
            return SNOW;
        }
        if (code >= 95) {
            return STORM;
        }
        return CLOUD;
    }

    /** "٢٨°" in the user's digits. */
    static String degrees(double value) {
        return String.format(Locale.getDefault(), "%d°", Math.round(value));
    }

    /** Weather symbol drawn in code: sun, moon, clouds, rain, snow, fog, storm. */
    static final class Icon extends Drawable {
        private final int type;
        private final int size;
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final RectF oval = new RectF();

        Icon(int type, int color, int sizePx) {
            this.type = type;
            this.size = sizePx;
            stroke.setColor(color);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeCap(Paint.Cap.ROUND);
            stroke.setStrokeWidth(Math.max(1.5f, sizePx * 0.075f));
            fill.setColor(color);
        }

        @Override
        public void draw(Canvas c) {
            Rect b = getBounds();
            float s = Math.min(b.width(), b.height());
            c.save();
            c.translate(b.left + (b.width() - s) / 2f, b.top + (b.height() - s) / 2f);
            float u = s / 24f;
            switch (type) {
                case SUN:
                    sun(c, 12 * u, 12 * u, u);
                    break;
                case MOON: {
                    Path moon = new Path();
                    moon.addCircle(12 * u, 12 * u, 7.5f * u, Path.Direction.CW);
                    Path bite = new Path();
                    bite.addCircle(16 * u, 9 * u, 6.5f * u, Path.Direction.CW);
                    moon.op(bite, Path.Op.DIFFERENCE);
                    c.drawPath(moon, fill);
                    break;
                }
                case PARTLY:
                    sun(c, 8.5f * u, 8.5f * u, u * 0.8f);
                    cloud(c, 13.5f * u, 14.5f * u, u);
                    break;
                case FOG:
                    for (int i = 0; i < 3; i++) {
                        float y = (8 + i * 4) * u;
                        c.drawLine((4 + i) * u, y, (20 - i) * u, y, stroke);
                    }
                    break;
                case RAIN:
                    cloud(c, 12 * u, 9.5f * u, u);
                    for (int i = 0; i < 3; i++) {
                        float x = (8 + i * 4) * u;
                        c.drawLine(x, 16 * u, x - 1.5f * u, 20.5f * u, stroke);
                    }
                    break;
                case SNOW:
                    cloud(c, 12 * u, 9.5f * u, u);
                    for (int i = 0; i < 3; i++) {
                        c.drawCircle((8 + i * 4) * u, (18 + (i % 2) * 2) * u, 1.1f * u, fill);
                    }
                    break;
                case STORM:
                    cloud(c, 12 * u, 9 * u, u);
                    path.reset();
                    path.moveTo(13 * u, 14 * u);
                    path.lineTo(10 * u, 18.5f * u);
                    path.lineTo(13 * u, 18.5f * u);
                    path.lineTo(11 * u, 22.5f * u);
                    c.drawPath(path, stroke);
                    break;
                default:
                    cloud(c, 12 * u, 12 * u, u);
                    break;
            }
            c.restore();
        }

        private void sun(Canvas c, float cx, float cy, float u) {
            c.drawCircle(cx, cy, 4 * u, fill);
            for (int i = 0; i < 8; i++) {
                double a = Math.PI / 4 * i;
                c.drawLine((float) (cx + Math.cos(a) * 6.5 * u), (float) (cy + Math.sin(a) * 6.5 * u),
                        (float) (cx + Math.cos(a) * 9 * u), (float) (cy + Math.sin(a) * 9 * u), stroke);
            }
        }

        private void cloud(Canvas c, float cx, float cy, float u) {
            path.reset();
            oval.set(cx - 8 * u, cy - 2 * u, cx + 8 * u, cy + 5 * u);
            path.addRoundRect(oval, 3.5f * u, 3.5f * u, Path.Direction.CW);
            path.addCircle(cx - 3 * u, cy - 1.5f * u, 4 * u, Path.Direction.CW);
            path.addCircle(cx + 2.5f * u, cy - 3 * u, 5 * u, Path.Direction.CW);
            c.drawPath(path, fill);
        }

        @Override
        public int getIntrinsicWidth() {
            return size;
        }

        @Override
        public int getIntrinsicHeight() {
            return size;
        }

        @Override
        public void setAlpha(int alpha) {
            stroke.setAlpha(alpha);
            fill.setAlpha(alpha);
        }

        @Override
        public void setColorFilter(ColorFilter colorFilter) {
            stroke.setColorFilter(colorFilter);
            fill.setColorFilter(colorFilter);
        }

        @Override
        public int getOpacity() {
            return PixelFormat.TRANSLUCENT;
        }
    }
}
