package com.sumuw.launcher;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Sara on a television: the remote's arrows and OK do everything, nothing needs a touch.
 *
 * At the top the time, the Hijri and Gregorian dates, the weather and the next prayer; under them the
 * day's prayer times and a line of news; then the favourite apps, then every app, as wide tiles (the
 * banner a TV app comes with, or its icon on a tile). A tile grows and gets a ring when it has focus.
 *
 * TVs are nearly all 960 x 540 dp whatever their resolution (720p, 1080p and 4K differ only in density),
 * but some boxes report other sizes: everything here is measured against 960 x 540 and scaled, so it
 * fills the screen the same way on each. A margin of 5% on every side keeps clear of the edges older
 * TVs cut off (overscan).
 */
final class TvHome {
    static final String PREF = "tv_mode";
    static final String AUTO = "auto";
    static final String ON = "on";
    static final String OFF = "off";
    /** Five tiles across, as on Google TV's own rows. */
    static final int COLUMNS = 5;

    final HomeActivity home;
    final FrameLayout view;
    final ScrollView scroll;
    final LinearLayout column;
    /** How much bigger than a 960 x 540 dp screen this one is. */
    final float scale;
    final int padX;
    final int padY;
    final int contentWidth;
    final GridLayout grid;
    final LinearLayout favorites;
    final TextView favoritesHint;
    final TextView clock;
    final TextView date;
    final TextView weather;
    final TextView prayer;
    final LinearLayout prayers;
    final TextView news;
    final View settingsButton;
    final List<View> tiles = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private int newsIndex;
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            refreshInfo();
            long now = System.currentTimeMillis();
            handler.postDelayed(this, 60000L - now % 60000L + 50L);
        }
    };
    private final Runnable newsTurn = new Runnable() {
        @Override
        public void run() {
            newsIndex++;
            showNews();
            handler.postDelayed(this, 8000L);
        }
    };

    /** A TV: Android says so (the TV UI mode, or the leanback feature every Android TV has). */
    static boolean isTv(Context context) {
        int type = context.getResources().getConfiguration().uiMode & Configuration.UI_MODE_TYPE_MASK;
        PackageManager pm = context.getPackageManager();
        return type == Configuration.UI_MODE_TYPE_TELEVISION || pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
                || pm.hasSystemFeature("android.software.leanback_only");
    }

    /** The TV layout: on a TV unless turned off, or anywhere when turned on (a TV box that says it's a tablet). */
    static boolean wanted(Context context, SharedPreferences prefs) {
        String mode = prefs.getString(PREF, AUTO);
        if (ON.equals(mode)) {
            return true;
        }
        return !OFF.equals(mode) && isTv(context);
    }

    TvHome(HomeActivity home) {
        this.home = home;
        Configuration config = home.getResources().getConfiguration();
        float widthDp = config.screenWidthDp > 0 ? config.screenWidthDp : 960f;
        float heightDp = config.screenHeightDp > 0 ? config.screenHeightDp : 540f;
        scale = Math.max(0.7f, Math.min(3f, Math.min(widthDp / 960f, heightDp / 540f)));
        float density = home.getResources().getDisplayMetrics().density;
        padX = Math.round(widthDp * 0.05f * density);
        padY = Math.round(heightDp * 0.05f * density);
        contentWidth = Math.round(widthDp * density) - 2 * padX;

        view = new FrameLayout(home);
        Drawable art = Wallpapers.create(home, home.wallpaperForTv());
        GradientDrawable shade = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x66000000, 0x33000000, 0xAA000000});
        view.setBackground(new LayerDrawable(new Drawable[]{art, shade}));
        scroll = new ScrollView(home);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setSmoothScrollingEnabled(true);
        scroll.setFocusable(false); // focus goes to the tiles and buttons, never the page itself
        column = new LinearLayout(home);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setLayoutDirection(View.LAYOUT_DIRECTION_LOCALE);
        column.setPadding(padX, padY, padX, padY);
        scroll.addView(column, new FrameLayout.LayoutParams(-1, -2));
        view.addView(scroll, new FrameLayout.LayoutParams(-1, -1));

        // The top: the time on the reading side; the weather, the prayer and the buttons on the other.
        LinearLayout top = new LinearLayout(home);
        top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout when = new LinearLayout(home);
        when.setOrientation(LinearLayout.VERTICAL);
        clock = text("", 56, Color.WHITE, 700);
        clock.setIncludeFontPadding(false);
        when.addView(clock);
        date = text("", 18, 0xE6FFFFFF, 500);
        when.addView(date);
        top.addView(when, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout side = new LinearLayout(home);
        side.setOrientation(LinearLayout.VERTICAL);
        side.setGravity(Gravity.END);
        weather = text("", 22, Color.WHITE, 600);
        side.addView(weather);
        prayer = text("", 18, 0xE6FFFFFF, 500);
        side.addView(prayer);
        top.addView(side, new LinearLayout.LayoutParams(-2, -2));
        settingsButton = roundButton(Glyphs.SETTINGS, home.getString(R.string.settings_title));
        settingsButton.setOnClickListener(v -> home.startActivity(new Intent(home, SettingsActivity.class)));
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(px(52), px(52));
        buttonParams.setMarginStart(px(20));
        top.addView(settingsButton, buttonParams);
        column.addView(top, new LinearLayout.LayoutParams(-1, -2));

        prayers = new LinearLayout(home);
        prayers.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams prayerParams = new LinearLayout.LayoutParams(-1, px(64));
        prayerParams.topMargin = px(18);
        column.addView(prayers, prayerParams);

        news = text("", 16, 0xD9FFFFFF, 500);
        news.setSingleLine(true);
        news.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams newsParams = new LinearLayout.LayoutParams(-1, -2);
        newsParams.topMargin = px(14);
        column.addView(news, newsParams);

        column.addView(title(home.getString(R.string.tv_favorites)), titleParams());
        HorizontalScrollView favScroll = new HorizontalScrollView(home);
        favScroll.setHorizontalScrollBarEnabled(false);
        favScroll.setClipToPadding(false);
        favScroll.setClipChildren(false);
        favorites = new LinearLayout(home);
        favorites.setClipChildren(false);
        favorites.setPadding(0, px(10), 0, px(10));
        favScroll.addView(favorites, new FrameLayout.LayoutParams(-2, -2));
        column.addView(favScroll, new LinearLayout.LayoutParams(-1, -2));
        favoritesHint = text(home.getString(R.string.tv_favorites_hint), 15, 0xB3FFFFFF, 500);
        column.addView(favoritesHint, new LinearLayout.LayoutParams(-1, -2));

        column.addView(title(home.getString(R.string.tv_all_apps)), titleParams());
        grid = new GridLayout(home);
        grid.setColumnCount(COLUMNS);
        grid.setClipChildren(false);
        grid.setUseDefaultMargins(false);
        LinearLayout.LayoutParams gridParams = new LinearLayout.LayoutParams(-1, -2);
        gridParams.topMargin = px(6);
        column.addView(grid, gridParams);
        column.setClipChildren(false);
        refreshInfo();
    }

    /** Lengths are given for a 960 x 540 dp TV and grow with the screen. */
    int px(float dp) {
        return Math.round(dp * scale * home.getResources().getDisplayMetrics().density);
    }

    private TextView text(String value, float sizeDp, int color, int weight) {
        TextView view = home.label(value, 14, color, weight);
        view.setTextSize(TypedValue.COMPLEX_UNIT_PX, sizeDp * scale * home.getResources().getDisplayMetrics().scaledDensity);
        return view;
    }

    private TextView title(String value) {
        TextView view = text(value, 20, Color.WHITE, 700);
        view.setPadding(0, 0, 0, 0);
        return view;
    }

    private LinearLayout.LayoutParams titleParams() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = px(22);
        return params;
    }

    private View roundButton(int glyph, String name) {
        FrameLayout button = new FrameLayout(home);
        ImageView image = new ImageView(home);
        image.setImageDrawable(new Glyphs(glyph, Color.WHITE, px(26)));
        image.setScaleType(ImageView.ScaleType.CENTER);
        button.addView(image, new FrameLayout.LayoutParams(-1, -1));
        button.setBackground(home.pill(0x33FFFFFF, Math.round(26 * scale)));
        button.setFocusable(true);
        button.setClickable(true);
        button.setContentDescription(name);
        focusGrow(button, 1.12f);
        return button;
    }

    /** The width of a tile: five across the space between the margins, with gaps. */
    int tileWidth() {
        int gap = px(16);
        return (contentWidth - gap * (COLUMNS - 1)) / COLUMNS;
    }

    int tileHeight() {
        return tileWidth() * 9 / 16;
    }

    /** The apps came in (or changed): the favourites row and the grid again, keeping focus where it was. */
    void appsChanged() {
        View focused = view.findFocus();
        Object focusedKey = focused == null ? null : focused.getTag();
        favorites.removeAllViews();
        grid.removeAllViews();
        tiles.clear();
        List<HomeActivity.AppEntry> favs = home.tvFavorites();
        for (HomeActivity.AppEntry entry : favs) {
            View tile = tile(entry, "fav:");
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(tileWidth(), tileHeight());
            params.setMarginEnd(px(16));
            favorites.addView(tile, params);
        }
        favoritesHint.setVisibility(favs.isEmpty() ? View.VISIBLE : View.GONE);
        int gap = px(16);
        int index = 0;
        for (HomeActivity.AppEntry entry : home.tvApps()) {
            View tile = tile(entry, "app:");
            GridLayout.LayoutParams params = new GridLayout.LayoutParams(GridLayout.spec(index / COLUMNS), GridLayout.spec(index % COLUMNS));
            params.width = tileWidth();
            params.height = tileHeight();
            params.setMarginEnd(index % COLUMNS == COLUMNS - 1 ? 0 : gap);
            params.bottomMargin = gap;
            grid.addView(tile, params);
            index++;
        }
        View again = focusedKey == null ? null : view.findViewWithTag(focusedKey);
        if (again != null) {
            again.requestFocusFromTouch();
        } else {
            focusFirst();
        }
    }

    /** Focus on the first app. From touch mode too (a TV box with a mouse, or the layout forced on a tablet). */
    void focusFirst() {
        final View target = tiles.isEmpty() ? settingsButton : tiles.get(0);
        if (!target.isAttachedToWindow()) {
            // The apps can be ready before the screen is: focus once it is shown.
            view.post(() -> {
                View now = view.findFocus();
                if (now == null || !tiles.contains(now)) {
                    focusFirst();
                }
            });
            return;
        }
        if (!target.requestFocusFromTouch()) {
            target.requestFocus();
        }
    }

    /** One app: its TV banner, or its icon and name on a tile. */
    View tile(final HomeActivity.AppEntry entry, String place) {
        FrameLayout tile = new FrameLayout(home);
        tile.setTag(place + entry.key); // the same app in the favourites and the grid: two tiles, told apart
        tile.setFocusable(true);
        tile.setClickable(true);
        tile.setLongClickable(true);
        final float radius = px(12);
        tile.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
            }
        });
        tile.setClipToOutline(true);
        tile.setBackground(home.pill(0x40FFFFFF, Math.round(12 * scale)));
        if (entry.banner != null) {
            ImageView banner = new ImageView(home);
            banner.setImageDrawable(entry.banner);
            banner.setScaleType(ImageView.ScaleType.CENTER_CROP);
            tile.addView(banner, new FrameLayout.LayoutParams(-1, -1));
        } else {
            LinearLayout inside = new LinearLayout(home);
            inside.setOrientation(LinearLayout.VERTICAL);
            inside.setGravity(Gravity.CENTER);
            ImageView icon = new ImageView(home);
            icon.setImageDrawable(home.shownIcon(entry));
            inside.addView(icon, new LinearLayout.LayoutParams(Math.round(tileHeight() * 0.46f), Math.round(tileHeight() * 0.46f)));
            TextView name = text(entry.label, 14, Color.WHITE, 600);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.END);
            name.setGravity(Gravity.CENTER);
            name.setPadding(px(8), px(6), px(8), 0);
            inside.addView(name, new LinearLayout.LayoutParams(-1, -2));
            tile.addView(inside, new FrameLayout.LayoutParams(-1, -1));
        }
        tile.setContentDescription(entry.label);
        tile.setOnClickListener(v -> home.launch(entry, v));
        tile.setOnLongClickListener(v -> {
            options(entry);
            return true;
        });
        tile.setOnKeyListener((v, keyCode, event) -> {
            if (keyCode == KeyEvent.KEYCODE_MENU && event.getAction() == KeyEvent.ACTION_UP) {
                options(entry); // the remote's menu key, where it has one
                return true;
            }
            return false;
        });
        focusGrow(tile, 1.08f);
        tiles.add(tile);
        return tile;
    }

    /** Focus makes a tile a little bigger, lifted, with a white ring; the name is said aloud by TalkBack. */
    private void focusGrow(final View target, final float grown) {
        final GradientDrawable ring = new GradientDrawable();
        ring.setColor(Color.TRANSPARENT);
        ring.setCornerRadius(px(12));
        ring.setStroke(Math.max(2, px(3)), Color.WHITE);
        target.setOnFocusChangeListener((v, focused) -> {
            float to = focused ? grown : 1f;
            AnimatorSet set = new AnimatorSet();
            set.playTogether(ObjectAnimator.ofFloat(v, "scaleX", to), ObjectAnimator.ofFloat(v, "scaleY", to));
            set.setDuration(150);
            set.start();
            v.setElevation(focused ? px(10) : 0);
            v.setForeground(focused ? ring : null);
            if (focused && v.getParent() instanceof ViewGroup) {
                ((ViewGroup) v.getParent()).invalidate(); // drawn over its neighbours by its elevation
            }
        });
    }

    /** OK held, or the menu key: favourite, app info, uninstall, hide. */
    void options(final HomeActivity.AppEntry entry) {
        final boolean favorite = home.tvIsFavorite(entry);
        final ArrayList<String> names = new ArrayList<>();
        final ArrayList<Runnable> actions = new ArrayList<>();
        names.add(home.getString(favorite ? R.string.tv_unfavorite : R.string.tv_favorite));
        actions.add(() -> home.tvSetFavorite(entry, !favorite));
        names.add(home.getString(R.string.app_info));
        actions.add(() -> home.tvAppInfo(entry));
        if (!entry.system) {
            names.add(home.getString(R.string.uninstall));
            actions.add(() -> home.tvUninstall(entry));
        }
        names.add(home.getString(R.string.hide_app));
        actions.add(() -> home.tvHide(entry));
        home.tvDialog = new AlertDialog.Builder(home)
                .setTitle(entry.label)
                .setItems(names.toArray(new String[0]), (dialog, which) -> actions.get(which).run())
                .setNegativeButton(home.getString(R.string.cancel), null)
                .show();
    }

    /** The time, the dates, the weather, the next prayer and the day's prayer times. */
    void refreshInfo() {
        long now = System.currentTimeMillis();
        SharedPreferences prefs = home.prefs;
        clock.setText(android.text.format.DateFormat.getTimeFormat(home).format(new Date(now)));
        String day = android.text.format.DateFormat.format("EEEE d MMMM", new Date(now)).toString();
        String hijri = HijriEvents.hijriLabel(now);
        date.setText(hijri.isEmpty() ? day : day + home.getString(R.string.list_separator) + hijri);
        Weather.Now now2 = Weather.cached(prefs);
        weather.setText(now2 == null ? "" : Weather.degrees(now2.temp));
        weather.setVisibility(now2 == null ? View.GONE : View.VISIBLE);
        if (now2 != null) {
            Drawable icon = new Weather.Icon(Weather.iconType(now2.code, now2.day), Color.WHITE, px(30));
            icon.setBounds(0, 0, px(30), px(30));
            weather.setCompoundDrawablesRelative(null, null, icon, null);
            weather.setCompoundDrawablePadding(px(8));
            weather.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        }
        boolean prayerOn = prefs.getBoolean("prayer_on", true);
        prayer.setVisibility(prayerOn ? View.VISIBLE : View.GONE);
        prayers.setVisibility(prayerOn ? View.VISIBLE : View.GONE);
        if (prayerOn) {
            prayer.setText(Prayers.nextText(home, prefs, now));
            fillPrayers(now);
        }
        showNews();
    }

    private void fillPrayers(long now) {
        prayers.removeAllViews();
        long[] times = Prayers.timesFor(home.prefs, now);
        long[] next = Prayers.next(home.prefs, now);
        for (int i = 0; i < times.length && i < Prayers.NAMES.length; i++) {
            boolean coming = i == next[0] && next[1] == times[i];
            LinearLayout box = new LinearLayout(home);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setGravity(Gravity.CENTER);
            box.setBackground(home.pill(coming ? HomeActivity.withAlpha(home.accent, 0.9f) : 0x26FFFFFF, Math.round(14 * scale)));
            box.addView(text(home.getString(Prayers.NAMES[i]), 14, 0xE6FFFFFF, 500));
            box.addView(text(Prayers.timeText(home, home.prefs, times[i]), 18, Color.WHITE, 700));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, -1, 1f);
            if (i > 0) {
                params.setMarginStart(px(10));
            }
            prayers.addView(box, params);
        }
    }

    /** The latest headlines from the news Sara already keeps, one at a time. */
    private void showNews() {
        List<String> lines = new ArrayList<>();
        SharedPreferences prefs = home.prefs;
        for (NewsSources.Source source : NewsSources.enabled(prefs)) {
            for (int i = 0; i < 3; i++) {
                String title = prefs.getString("news_" + source.id + "_" + i + "_title", null);
                if (title != null && !title.isEmpty()) {
                    lines.add(title + home.getString(R.string.list_separator) + source.name);
                }
            }
        }
        news.setVisibility(lines.isEmpty() ? View.GONE : View.VISIBLE);
        if (!lines.isEmpty()) {
            news.setText(lines.get(Math.abs(newsIndex) % lines.size()));
        }
    }

    void resume() {
        refreshInfo();
        handler.removeCallbacks(tick);
        handler.removeCallbacks(newsTurn);
        long now = System.currentTimeMillis();
        handler.postDelayed(tick, 60000L - now % 60000L + 50L);
        handler.postDelayed(newsTurn, 8000L);
        View focused = view.findFocus();
        if (focused == null || (focused != settingsButton && !tiles.contains(focused))) {
            focusFirst();
        }
    }

    void pause() {
        handler.removeCallbacks(tick);
        handler.removeCallbacks(newsTurn);
    }

    /** Home pressed again: back to the top and the first tile. */
    void home() {
        scroll.smoothScrollTo(0, 0);
        focusFirst();
    }

    /** Back: to the top first; at the top, nothing (a home screen has nothing behind it). */
    void back() {
        View focused = view.findFocus();
        if (focused != null && !tiles.isEmpty() && focused != tiles.get(0)) {
            home();
        }
    }
}
