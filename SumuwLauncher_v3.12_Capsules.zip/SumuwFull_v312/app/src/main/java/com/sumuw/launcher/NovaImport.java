package com.sumuw.launcher;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Reads a home screen layout saved by Nova Launcher (a .novabackup file, which is a zip) or by another
 * launcher built on Android's Launcher3, which keep the layout in a SQLite table called "favorites": the
 * dock (the "hotseat"), the folders with their apps, and the order of the icons on the home pages.
 *
 * Only that table is read; Nova's own settings, icons and widgets aren't. The file is read on the phone
 * and the copy made to read it is deleted straight away.
 */
final class NovaImport {
    /** Launcher3's numbers: where an item sits, and what it is. */
    static final int CONTAINER_DESKTOP = -100;
    static final int CONTAINER_HOTSEAT = -101;
    static final int ITEM_APP = 0;
    static final int ITEM_SHORTCUT = 1;
    static final int ITEM_FOLDER = 2;

    static final class Layout {
        final List<ComponentName> dock = new ArrayList<>();
        final List<ComponentName> desktop = new ArrayList<>();
        final LinkedHashMap<String, List<ComponentName>> folders = new LinkedHashMap<>();

        boolean isEmpty() {
            return dock.isEmpty() && desktop.isEmpty() && folders.isEmpty();
        }
    }

    private NovaImport() {
    }

    /** The layout in the file, or null when it holds no launcher layout Sara can read. */
    static Layout read(Context context, Uri uri) {
        File copy = new File(context.getCacheDir(), "import-layout.db");
        try (InputStream raw = context.getContentResolver().openInputStream(uri)) {
            if (raw == null) {
                return null;
            }
            BufferedInputStream in = new BufferedInputStream(raw);
            in.mark(16);
            byte[] head = new byte[16];
            int got = in.read(head);
            in.reset();
            if (got >= 2 && head[0] == 'P' && head[1] == 'K') {
                // A zip: try each database inside until one has the layout table.
                ZipInputStream zip = new ZipInputStream(in);
                ZipEntry entry;
                while ((entry = zip.getNextEntry()) != null) {
                    String name = entry.getName().toLowerCase(java.util.Locale.ROOT);
                    if (entry.isDirectory() || name.contains("..") || !(name.endsWith(".db") || name.endsWith(".sqlite"))) {
                        continue;
                    }
                    if (!save(zip, copy)) {
                        continue;
                    }
                    Layout layout = readDatabase(copy);
                    if (layout != null) {
                        return layout;
                    }
                }
                return null;
            }
            if (got >= 15 && new String(head, 0, 15, java.nio.charset.StandardCharsets.US_ASCII).equals("SQLite format 3")) {
                return save(in, copy) ? readDatabase(copy) : null;
            }
            return null;
        } catch (Exception e) {
            return null;
        } finally {
            //noinspection ResultOfMethodCallIgnored
            copy.delete();
            new File(copy.getPath() + "-journal").delete();
        }
    }

    /** Copies at most 64 MB: a layout database is far smaller, and a huge file isn't one. */
    private static boolean save(InputStream in, File to) {
        try (OutputStream out = new FileOutputStream(to)) {
            byte[] buffer = new byte[16384];
            long total = 0;
            int n;
            while ((n = in.read(buffer)) > 0) {
                total += n;
                if (total > 64L * 1024 * 1024) {
                    return false;
                }
                out.write(buffer, 0, n);
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    static Layout readDatabase(File file) {
        SQLiteDatabase db = null;
        try {
            db = SQLiteDatabase.openDatabase(file.getPath(), null, SQLiteDatabase.OPEN_READONLY);
            Layout layout = new Layout();
            Map<Long, String> folderNames = new LinkedHashMap<>();
            try (Cursor folders = db.rawQuery("SELECT _id, title FROM favorites WHERE itemType = " + ITEM_FOLDER
                    + " ORDER BY container, screen, cellY, cellX", null)) {
                while (folders.moveToNext()) {
                    String title = folders.isNull(1) ? "" : folders.getString(1).trim();
                    folderNames.put(folders.getLong(0), title);
                }
            }
            Map<Long, List<ComponentName>> folderApps = new LinkedHashMap<>();
            try (Cursor items = db.rawQuery("SELECT intent, container FROM favorites WHERE itemType IN (" + ITEM_APP + ", " + ITEM_SHORTCUT
                    + ") ORDER BY container, screen, cellY, cellX, rank", null)) {
                while (items.moveToNext()) {
                    ComponentName component = component(items.isNull(0) ? null : items.getString(0));
                    if (component == null) {
                        continue;
                    }
                    long container = items.getLong(1);
                    if (container == CONTAINER_HOTSEAT) {
                        addOnce(layout.dock, component);
                    } else if (container == CONTAINER_DESKTOP) {
                        addOnce(layout.desktop, component);
                    } else if (folderNames.containsKey(container)) {
                        List<ComponentName> list = folderApps.get(container);
                        if (list == null) {
                            list = new ArrayList<>();
                            folderApps.put(container, list);
                        }
                        addOnce(list, component);
                    }
                }
            } catch (Exception noRank) {
                return readWithoutRank(db, folderNames);
            }
            putFolders(layout, folderNames, folderApps);
            return layout;
        } catch (Exception e) {
            return null;
        } finally {
            if (db != null) {
                db.close();
            }
        }
    }

    /** Older tables have no "rank" column. */
    private static Layout readWithoutRank(SQLiteDatabase db, Map<Long, String> folderNames) {
        Layout layout = new Layout();
        Map<Long, List<ComponentName>> folderApps = new LinkedHashMap<>();
        try (Cursor items = db.rawQuery("SELECT intent, container FROM favorites WHERE itemType IN (" + ITEM_APP + ", " + ITEM_SHORTCUT
                + ") ORDER BY container, screen, cellY, cellX", null)) {
            while (items.moveToNext()) {
                ComponentName component = component(items.isNull(0) ? null : items.getString(0));
                if (component == null) {
                    continue;
                }
                long container = items.getLong(1);
                if (container == CONTAINER_HOTSEAT) {
                    addOnce(layout.dock, component);
                } else if (container == CONTAINER_DESKTOP) {
                    addOnce(layout.desktop, component);
                } else if (folderNames.containsKey(container)) {
                    List<ComponentName> list = folderApps.get(container);
                    if (list == null) {
                        list = new ArrayList<>();
                        folderApps.put(container, list);
                    }
                    addOnce(list, component);
                }
            }
        }
        putFolders(layout, folderNames, folderApps);
        return layout;
    }

    private static void putFolders(Layout layout, Map<Long, String> names, Map<Long, List<ComponentName>> apps) {
        int unnamed = 0;
        for (Map.Entry<Long, String> folder : names.entrySet()) {
            List<ComponentName> list = apps.get(folder.getKey());
            if (list == null || list.isEmpty()) {
                continue;
            }
            String name = folder.getValue();
            if (name.isEmpty()) {
                name = "#" + (++unnamed);
            }
            while (layout.folders.containsKey(name)) {
                name = name + " ";
            }
            layout.folders.put(name, list);
        }
    }

    private static void addOnce(List<ComponentName> list, ComponentName component) {
        if (!list.contains(component)) {
            list.add(component);
        }
    }

    /** The app an item opens, from the intent Launcher3 stores as text. */
    static ComponentName component(String intent) {
        if (intent == null || intent.isEmpty()) {
            return null;
        }
        try {
            Intent parsed = Intent.parseUri(intent, 0);
            if (parsed.getComponent() != null) {
                return parsed.getComponent();
            }
            if (parsed.getPackage() != null) {
                return new ComponentName(parsed.getPackage(), "");
            }
        } catch (Exception ignored) {
        }
        return null;
    }
}
