package com.sumuw.launcher;

import android.app.ActivityOptions;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.provider.Settings;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;
import android.text.format.DateUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Sara Home's own notification panel, in the launcher's glass style: quick toggles, brightness, music
 * controls, and notifications grouped by app with replies, actions and swipe to dismiss. It reads
 * notifications through the same access as the icon dots (DotsService). Android doesn't let an app
 * restyle the system's own shade, so that one stays a tap away (the button at the top).
 */
final class NotificationPanel {
    private final HomeActivity home;
    final ScrollView view;
    private final LinearLayout content;
    private final List<View> glass = new ArrayList<>();
    private final HashSet<String> expanded = new HashSet<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean open;
    /** A card is under the finger, or a reply is being typed: rebuilding now would pull it away. */
    private boolean touching;
    private boolean dirty;
    private String replyKey;
    private boolean askedForBrightness;
    private CameraManager camera;
    private String torchId;
    private boolean torchOn;
    private final CameraManager.TorchCallback torchCallback = new CameraManager.TorchCallback() {
        @Override
        public void onTorchModeChanged(String cameraId, boolean enabled) {
            if (cameraId.equals(torchId) && enabled != torchOn) {
                torchOn = enabled;
                refresh();
            }
        }
    };

    NotificationPanel(HomeActivity home) {
        this.home = home;
        view = new ScrollView(home);
        view.setVisibility(View.GONE);
        view.setFillViewport(true);
        view.setVerticalScrollBarEnabled(false);
        view.setOverScrollMode(View.OVER_SCROLL_NEVER);
        view.setBackgroundColor(home.darkWallpaper ? 0x80000000 : 0x66FFFFFF);
        view.setOnApplyWindowInsetsListener((v, insets) -> {
            home.padForSystemBars(v, insets);
            return insets;
        });
        view.setOnScrollChangeListener((v, x, y, oldX, oldY) -> {
            for (View glassView : glass) {
                glassView.invalidate(); // keep the frosted wallpaper lined up while scrolling
            }
        });
        // Swipe up (at the end of the list) closes, like pushing the shade back up.
        view.setOnTouchListener(new View.OnTouchListener() {
            private float startX;
            private float startY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    startX = event.getX();
                    startY = event.getY();
                } else if (event.getActionMasked() == MotionEvent.ACTION_UP) {
                    float dx = event.getX() - startX;
                    float dy = event.getY() - startY;
                    if (-dy > home.dp(90.0f) && Math.abs(dy) > Math.abs(dx) * 1.5f && !view.canScrollVertically(1)) {
                        close();
                        return true;
                    }
                }
                return false;
            }
        });
        content = new LinearLayout(home);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setLayoutDirection(View.LAYOUT_DIRECTION_LOCALE);
        content.setPadding(home.dp(16.0f), home.dp(8.0f), home.dp(16.0f), home.dp(24.0f));
        view.addView(content, new FrameLayout.LayoutParams(-1, -2));
    }

    boolean isOpen() {
        return open;
    }

    void open() {
        if (open) {
            return;
        }
        pulling = false;
        open = true;
        watchTorch(true);
        fillIfStale();
        view.scrollTo(0, 0);
        view.setVisibility(View.VISIBLE);
        view.setAlpha(0f);
        view.setTranslationY(-home.dp(56.0f));
        view.animate().alpha(1f).translationY(0f).setDuration(240L).setInterpolator(new DecelerateInterpolator()).withLayer().start();
        home.fadeHome(true);
    }

    // ---------------------------------------------------------------- following the finger

    private boolean pulling;
    /** The content was built while closed and nothing changed since: a pull can show it at once. */
    private boolean stale = true;
    private long filledAt;

    /** Notifications changed while the panel is closed: build again on the next pull. */
    void markStale() {
        stale = true;
    }

    private void fillIfStale() {
        // The cards say "قبل ٥ د", so a build older than half a minute is out of date too.
        if (stale || System.currentTimeMillis() - filledAt > 30000L || content.getChildCount() == 0) {
            fill();
        }
    }

    /** How far the finger has to pull for the panel to be all there. */
    private float pullRange() {
        return home.dp(200.0f);
    }

    /** The finger started pulling down at the top of Home: the panel comes in with it. */
    void beginPull() {
        if (open || pulling) {
            return;
        }
        pulling = true;
        view.animate().cancel();
        fillIfStale();
        view.scrollTo(0, 0);
        view.setAlpha(0f);
        view.setTranslationY(-home.dp(56.0f));
        view.setVisibility(View.VISIBLE);
        view.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        home.homeLayers(true);
    }

    void pullTo(float dy) {
        if (!pulling) {
            beginPull();
        }
        float progress = Math.max(0f, Math.min(1f, dy / pullRange()));
        // A little resistance at the start, so a small wobble doesn't flash the panel.
        float shown = progress * progress * (3f - 2f * progress);
        view.setAlpha(shown);
        view.setTranslationY(-home.dp(56.0f) * (1f - shown));
        home.homeAlpha(1f - shown);
    }

    /** The finger let go: open if it pulled far enough or flicked down, otherwise go back. */
    void endPull(float dy, float velocityY) {
        if (!pulling) {
            return;
        }
        pulling = false;
        home.homeLayers(false); // the fade below puts them on a layer for its own length
        float progress = Math.max(0f, Math.min(1f, dy / pullRange()));
        boolean flickDown = velocityY > home.dp(450.0f);
        boolean flickUp = velocityY < -home.dp(450.0f);
        if (!flickUp && (flickDown || progress > 0.4f)) {
            open = true;
            watchTorch(true);
            long left = (long) (220L * (1f - view.getAlpha())) + 80L;
            view.animate().alpha(1f).translationY(0f).setDuration(left).setInterpolator(new DecelerateInterpolator())
                    .withEndAction(() -> view.setLayerType(View.LAYER_TYPE_NONE, null)).start();
            home.fadeHome(true);
        } else {
            view.animate().alpha(0f).translationY(-home.dp(56.0f)).setDuration(160L).setInterpolator(new DecelerateInterpolator())
                    .withEndAction(() -> {
                        view.setLayerType(View.LAYER_TYPE_NONE, null);
                        if (!open && !pulling) {
                            view.setVisibility(View.GONE);
                        }
                    }).start();
            home.fadeHome(false);
        }
    }

    boolean isPulling() {
        return pulling;
    }

    void close() {
        if (!open) {
            return;
        }
        open = false;
        replyKey = null;
        touching = false;
        watchTorch(false);
        InputMethodManager keyboard = home.getSystemService(InputMethodManager.class);
        if (keyboard != null) {
            keyboard.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
        view.animate().alpha(0f).translationY(-home.dp(40.0f)).setDuration(200L).withLayer().withEndAction(() -> {
            if (!open && !pulling) {
                view.setVisibility(View.GONE);
            }
        }).start();
        home.fadeHome(false);
    }

    /** Notifications changed: rebuild, unless a card is under the finger or a reply is being typed. */
    void refresh() {
        if (!open) {
            stale = true;
            return;
        }
        if (touching || replyKey != null) {
            dirty = true;
            return;
        }
        fill();
    }

    private void refreshSoon() {
        handler.postDelayed(this::refresh, 350L);
    }

    // ---------------------------------------------------------------- building

    void fill() {
        dirty = false;
        stale = false;
        filledAt = System.currentTimeMillis();
        home.forgetGlass(glass);
        content.removeAllViews();
        addHeader();
        // The switches, brightness and the rest of the controls live in the control centre that comes up
        // from the bottom; pulled from the top, the panel is for notifications only. With the control
        // centre turned off, the switches come back here so they are still somewhere.
        if (!home.getSharedPreferences("duo_home", 0).getBoolean("control_center", true)) {
            addToggles();
        }
        if (!DotsService.accessGranted(home)) {
            addAccessCard();
            addHandle();
            return;
        }
        List<StatusBarNotification> shown = visibleNotifications();
        ArrayList<StatusBarNotification> media = new ArrayList<>();
        ArrayList<StatusBarNotification> rest = new ArrayList<>();
        for (StatusBarNotification sbn : shown) {
            if (mediaToken(sbn) != null) {
                media.add(sbn);
            } else {
                rest.add(sbn);
            }
        }
        for (StatusBarNotification sbn : media) {
            addMediaCard(sbn);
        }
        addNotificationsHeader(rest);
        if (rest.isEmpty()) {
            TextView none = home.label(home.getString(R.string.notif_none), 15, home.textSecondary, 400);
            none.setGravity(Gravity.CENTER);
            none.setPadding(0, home.dp(28.0f), 0, home.dp(28.0f));
            content.addView(none, new LinearLayout.LayoutParams(-1, -2));
        } else {
            for (Map.Entry<String, List<StatusBarNotification>> group : byApp(rest).entrySet()) {
                addGroup(group.getKey(), group.getValue());
            }
        }
        addHandle();
    }

    private LinearLayout card() {
        LinearLayout card = new LinearLayout(home);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(home.dp(16.0f), home.dp(14.0f), home.dp(16.0f), home.dp(12.0f));
        home.glassTracked(card, 26, false, glass);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = home.dp(12.0f);
        content.addView(card, params);
        return card;
    }

    private ImageView roundButton(int glyph, String description, View.OnClickListener click) {
        ImageView button = new ImageView(home);
        button.setImageDrawable(new Glyphs(glyph, home.textPrimary, home.dp(20.0f)));
        button.setScaleType(ImageView.ScaleType.CENTER);
        button.setContentDescription(description);
        home.glassTracked(button, 20, true, glass);
        button.setOnClickListener(click);
        return button;
    }

    private void addHeader() {
        LinearLayout header = new LinearLayout(home);
        header.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout texts = new LinearLayout(home);
        texts.setOrientation(LinearLayout.VERTICAL);
        long now = System.currentTimeMillis();
        TextView clock = home.label(android.text.format.DateFormat.getTimeFormat(home).format(new Date(now)), 34, home.textPrimary, 600);
        home.shadowOnWallpaper(clock);
        texts.addView(clock);
        String day = android.text.format.DateFormat.format("EEEE d MMMM", new Date(now)).toString();
        String hijri = HijriEvents.hijriLabel(now);
        TextView date = home.label(hijri.isEmpty() ? day : day + home.getString(R.string.list_separator) + hijri, 13, home.textSecondary, 400);
        texts.addView(date);
        header.addView(texts, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(home.dp(40.0f), home.dp(40.0f));
        buttonParams.setMarginStart(home.dp(8.0f));
        header.addView(roundButton(Glyphs.SHADE, home.getString(R.string.notif_system_shade), v -> {
            close();
            home.expandNotifications();
        }), buttonParams);
        LinearLayout.LayoutParams closeParams = new LinearLayout.LayoutParams(home.dp(40.0f), home.dp(40.0f));
        closeParams.setMarginStart(home.dp(8.0f));
        header.addView(roundButton(Glyphs.CLOSE, home.getString(R.string.close), v -> close()), closeParams);
        content.addView(header, new LinearLayout.LayoutParams(-1, home.dp(76.0f)));
    }

    // ---------------------------------------------------------------- quick toggles

    private interface Action {
        void run();
    }

    private void addToggles() {
        LinearLayout card = card();
        card.setPadding(home.dp(10.0f), home.dp(14.0f), home.dp(10.0f), home.dp(10.0f));
        LinearLayout first = new LinearLayout(home);
        LinearLayout second = new LinearLayout(home);
        card.addView(first, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams secondParams = new LinearLayout.LayoutParams(-1, -2);
        secondParams.topMargin = home.dp(10.0f);
        card.addView(second, secondParams);
        tile(first, Glyphs.WIFI, R.string.tile_wifi, home.wifiOn, () -> {
            close();
            home.startSafely(Build.VERSION.SDK_INT >= 29 ? new Intent(Settings.Panel.ACTION_WIFI) : new Intent(Settings.ACTION_WIFI_SETTINGS));
        });
        tile(first, Glyphs.BLUETOOTH, R.string.tile_bluetooth, bluetoothOn(), () -> {
            close();
            home.startSafely(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
        });
        tile(first, Glyphs.FLASH, R.string.tile_torch, torchId == null ? null : torchOn, this::toggleTorch);
        tile(first, Glyphs.MOON, R.string.tile_dnd, dndOn(), this::toggleDnd);
        tile(second, Glyphs.VIBRATE, R.string.tile_vibrate, vibrateOn(), this::toggleVibrate);
        tile(second, Glyphs.LOCATION, R.string.tile_location, locationOn(), () -> {
            close();
            home.startSafely(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
        });
        tile(second, Glyphs.SETTINGS, R.string.tile_settings, null, () -> {
            close();
            home.startSafely(new Intent(Settings.ACTION_SETTINGS));
        });
        tile(second, Glyphs.EYE_OFF, R.string.privacy_mode, home.isPrivacyMode(), () -> {
            home.setPrivacyMode(!home.isPrivacyMode());
            fill();
        });
        addBrightness(card);
    }

    /** One toggle: a round button (filled with the accent colour when on) and its name. */
    private void tile(LinearLayout row, int glyph, int name, final Boolean on, final Action action) {
        LinearLayout tile = new LinearLayout(home);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER_HORIZONTAL);
        FrameLayout circle = new FrameLayout(home);
        boolean active = on != null && on;
        circle.setBackground(new RippleDrawable(ColorStateList.valueOf(HomeActivity.withAlpha(home.textPrimary, 0.25f)),
                home.pill(active ? home.accent : HomeActivity.withAlpha(home.textPrimary, 0.12f), 26), null));
        ImageView icon = new ImageView(home);
        icon.setImageDrawable(new Glyphs(glyph, active ? Color.WHITE : home.textPrimary, home.dp(24.0f)));
        circle.addView(icon, new FrameLayout.LayoutParams(home.dp(24.0f), home.dp(24.0f), Gravity.CENTER));
        tile.addView(circle, new LinearLayout.LayoutParams(home.dp(52.0f), home.dp(52.0f)));
        TextView label = home.label(home.getString(name), 11, home.textPrimary, 500);
        label.setSingleLine(true);
        label.setEllipsize(TextUtils.TruncateAt.END);
        label.setGravity(Gravity.CENTER);
        label.setPadding(home.dp(2.0f), home.dp(6.0f), home.dp(2.0f), 0);
        tile.addView(label, new LinearLayout.LayoutParams(-1, -2));
        String state = on == null ? "" : home.getString(R.string.list_separator) + home.getString(active ? R.string.state_on : R.string.state_off);
        circle.setContentDescription(home.getString(name) + state);
        circle.setOnClickListener(v -> action.run());
        row.addView(tile, new LinearLayout.LayoutParams(0, -2, 1f));
    }

    private void addBrightness(LinearLayout card) {
        LinearLayout row = new LinearLayout(home);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(home.dp(8.0f), home.dp(14.0f), home.dp(8.0f), home.dp(4.0f));
        ImageView sun = new ImageView(home);
        sun.setImageDrawable(new Glyphs(Glyphs.SUN, home.textPrimary, home.dp(22.0f)));
        sun.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        row.addView(sun, new LinearLayout.LayoutParams(home.dp(22.0f), home.dp(22.0f)));
        SeekBar bar = new SeekBar(home);
        bar.setMax(255);
        bar.setProgress(Settings.System.getInt(home.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 128));
        bar.setProgressTintList(ColorStateList.valueOf(home.accent));
        bar.setThumbTintList(ColorStateList.valueOf(home.accent));
        bar.setProgressBackgroundTintList(ColorStateList.valueOf(HomeActivity.withAlpha(home.textPrimary, 0.5f)));
        bar.setContentDescription(home.getString(R.string.tile_brightness));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) {
                    return;
                }
                // The screen follows the finger at once; the phone's setting changes when allowed.
                android.view.WindowManager.LayoutParams attributes = home.getWindow().getAttributes();
                attributes.screenBrightness = Math.max(0.02f, progress / 255f);
                home.getWindow().setAttributes(attributes);
                if (Settings.System.canWrite(home)) {
                    try {
                        Settings.System.putInt(home.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE,
                                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                        Settings.System.putInt(home.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, progress);
                    } catch (Exception ignored) {
                    }
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                touching = true;
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                touching = false;
                // Hand the brightness back to the phone's setting once it can be saved there.
                android.view.WindowManager.LayoutParams attributes = home.getWindow().getAttributes();
                if (Settings.System.canWrite(home)) {
                    attributes.screenBrightness = android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;
                    home.getWindow().setAttributes(attributes);
                } else if (!askedForBrightness) {
                    askedForBrightness = true;
                    Toast.makeText(home, home.getString(R.string.brightness_permission), Toast.LENGTH_LONG).show();
                    home.startSafely(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + home.getPackageName())));
                }
                if (dirty) {
                    fill();
                }
            }
        });
        LinearLayout.LayoutParams barParams = new LinearLayout.LayoutParams(0, home.dp(40.0f), 1f);
        barParams.setMarginStart(home.dp(6.0f));
        row.addView(bar, barParams);
        card.addView(row, new LinearLayout.LayoutParams(-1, -2));
    }

    private Boolean bluetoothOn() {
        try {
            BluetoothManager manager = home.getSystemService(BluetoothManager.class);
            BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
            return adapter == null ? null : adapter.isEnabled();
        } catch (Exception e) {
            return null;
        }
    }

    private void watchTorch(boolean watch) {
        try {
            if (camera == null) {
                camera = home.getSystemService(CameraManager.class);
                if (camera != null) {
                    for (String id : camera.getCameraIdList()) {
                        CameraCharacteristics features = camera.getCameraCharacteristics(id);
                        Boolean flash = features.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                        Integer facing = features.get(CameraCharacteristics.LENS_FACING);
                        if (flash != null && flash && facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                            torchId = id;
                            break;
                        }
                    }
                }
            }
            if (camera != null && torchId != null) {
                if (watch) {
                    camera.registerTorchCallback(torchCallback, handler);
                } else {
                    camera.unregisterTorchCallback(torchCallback);
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void toggleTorch() {
        if (camera == null || torchId == null) {
            return;
        }
        try {
            camera.setTorchMode(torchId, !torchOn);
            torchOn = !torchOn;
            fill();
        } catch (Exception e) {
            Toast.makeText(home, home.getString(R.string.torch_busy), Toast.LENGTH_SHORT).show();
        }
    }

    private Boolean dndOn() {
        NotificationManager manager = home.getSystemService(NotificationManager.class);
        if (manager == null) {
            return null;
        }
        int filter = manager.getCurrentInterruptionFilter();
        return filter != NotificationManager.INTERRUPTION_FILTER_ALL && filter != NotificationManager.INTERRUPTION_FILTER_UNKNOWN;
    }

    /** Do not disturb: switched here directly when Sara Home may (notification access includes it). */
    private void toggleDnd() {
        NotificationManager manager = home.getSystemService(NotificationManager.class);
        if (manager == null) {
            return;
        }
        if (!manager.isNotificationPolicyAccessGranted()) {
            close();
            home.startSafely(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
            return;
        }
        Boolean on = dndOn();
        manager.setInterruptionFilter(on != null && on ? NotificationManager.INTERRUPTION_FILTER_ALL : NotificationManager.INTERRUPTION_FILTER_PRIORITY);
        refreshSoon();
    }

    private Boolean vibrateOn() {
        AudioManager audio = home.getSystemService(AudioManager.class);
        return audio == null ? null : audio.getRingerMode() == AudioManager.RINGER_MODE_VIBRATE;
    }

    private void toggleVibrate() {
        AudioManager audio = home.getSystemService(AudioManager.class);
        if (audio == null) {
            return;
        }
        try {
            boolean vibrate = audio.getRingerMode() == AudioManager.RINGER_MODE_VIBRATE;
            audio.setRingerMode(vibrate ? AudioManager.RINGER_MODE_NORMAL : AudioManager.RINGER_MODE_VIBRATE);
            fill();
        } catch (Exception e) {
            close();
            home.startSafely(new Intent(Settings.ACTION_SOUND_SETTINGS));
        }
    }

    private Boolean locationOn() {
        if (Build.VERSION.SDK_INT < 28) {
            return null;
        }
        LocationManager location = home.getSystemService(LocationManager.class);
        return location == null ? null : location.isLocationEnabled();
    }

    // ---------------------------------------------------------------- notifications

    private void addAccessCard() {
        LinearLayout card = card();
        TextView text = home.label(home.getString(R.string.notif_need_access), 15, home.textPrimary, 400);
        card.addView(text);
        TextView allow = home.label(home.getString(R.string.notif_allow), 15, Color.WHITE, 600);
        allow.setGravity(Gravity.CENTER);
        allow.setPadding(home.dp(18.0f), home.dp(10.0f), home.dp(18.0f), home.dp(10.0f));
        allow.setBackground(home.pill(home.accent, 20));
        allow.setOnClickListener(v -> {
            close();
            home.startSafely(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
        });
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, -2);
        params.topMargin = home.dp(12.0f);
        card.addView(allow, params);
    }

    /** Everything worth showing, newest first; a group's summary is dropped when its messages are there. */
    List<StatusBarNotification> visibleNotifications() {
        StatusBarNotification[] all = DotsService.active();
        HashSet<String> groupsWithChildren = new HashSet<>();
        for (StatusBarNotification sbn : all) {
            Notification n = sbn.getNotification();
            if ((n.flags & Notification.FLAG_GROUP_SUMMARY) == 0 && n.getGroup() != null) {
                groupsWithChildren.add(sbn.getPackageName() + "/" + n.getGroup());
            }
        }
        ArrayList<StatusBarNotification> list = new ArrayList<>();
        for (StatusBarNotification sbn : all) {
            Notification n = sbn.getNotification();
            if (sbn.getPackageName().equals(home.getPackageName())) {
                continue;
            }
            if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0 && n.getGroup() != null
                    && groupsWithChildren.contains(sbn.getPackageName() + "/" + n.getGroup())) {
                continue;
            }
            if (mediaToken(sbn) == null && TextUtils.isEmpty(title(sbn)) && TextUtils.isEmpty(text(sbn))) {
                continue;
            }
            list.add(sbn);
        }
        Collections.sort(list, (a, b) -> Long.compare(b.getPostTime(), a.getPostTime()));
        return list;
    }

    private static LinkedHashMap<String, List<StatusBarNotification>> byApp(List<StatusBarNotification> list) {
        LinkedHashMap<String, List<StatusBarNotification>> groups = new LinkedHashMap<>();
        for (StatusBarNotification sbn : list) {
            String key = sbn.getPackageName() + "#" + sbn.getUser().hashCode();
            List<StatusBarNotification> group = groups.get(key);
            if (group == null) {
                group = new ArrayList<>();
                groups.put(key, group);
            }
            group.add(sbn);
        }
        return groups;
    }

    static CharSequence title(StatusBarNotification sbn) {
        Bundle extras = sbn.getNotification().extras;
        CharSequence title = extras.getCharSequence(Notification.EXTRA_TITLE_BIG);
        return TextUtils.isEmpty(title) ? extras.getCharSequence(Notification.EXTRA_TITLE) : title;
    }

    /** The message: the newest chat line when it's a conversation, otherwise the long or short text. */
    static CharSequence text(StatusBarNotification sbn) {
        Bundle extras = sbn.getNotification().extras;
        if (Build.VERSION.SDK_INT >= 28) {
            Parcelable[] messages = extras.getParcelableArray(Notification.EXTRA_MESSAGES);
            if (messages != null && messages.length > 0) {
                List<Notification.MessagingStyle.Message> list = Notification.MessagingStyle.Message.getMessagesFromBundleArray(messages);
                if (!list.isEmpty()) {
                    Notification.MessagingStyle.Message last = list.get(list.size() - 1);
                    CharSequence sender = last.getSenderPerson() != null ? last.getSenderPerson().getName() : null;
                    boolean group = extras.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false);
                    return group && !TextUtils.isEmpty(sender) ? sender + ": " + last.getText() : last.getText();
                }
            }
        }
        CharSequence big = extras.getCharSequence(Notification.EXTRA_BIG_TEXT);
        return TextUtils.isEmpty(big) ? extras.getCharSequence(Notification.EXTRA_TEXT) : big;
    }

    private static MediaSession.Token mediaToken(StatusBarNotification sbn) {
        Parcelable token = sbn.getNotification().extras.getParcelable(Notification.EXTRA_MEDIA_SESSION);
        return token instanceof MediaSession.Token ? (MediaSession.Token) token : null;
    }

    /** Content stays hidden in privacy mode, and for apps in a private folder that hasn't been opened. */
    private boolean hidden(StatusBarNotification sbn) {
        if (home.isPrivacyMode()) {
            return true;
        }
        if (home.isPrivateUnlocked()) {
            return false;
        }
        for (String key : home.lockedKeys()) {
            if (key.startsWith(sbn.getPackageName() + "/")) {
                return true;
            }
        }
        return false;
    }

    private HomeActivity.AppEntry appFor(StatusBarNotification sbn) {
        HomeActivity.AppEntry other = null;
        for (HomeActivity.AppEntry entry : home.apps) {
            if (entry.pkg.equals(sbn.getPackageName())) {
                if (entry.user.equals(sbn.getUser())) {
                    return entry;
                }
                other = entry;
            }
        }
        return other;
    }

    private String appName(StatusBarNotification sbn) {
        HomeActivity.AppEntry entry = appFor(sbn);
        if (entry != null) {
            return entry.label;
        }
        try {
            PackageManager pm = home.getPackageManager();
            return pm.getApplicationLabel(pm.getApplicationInfo(sbn.getPackageName(), 0)).toString();
        } catch (Exception e) {
            return sbn.getPackageName();
        }
    }

    private Drawable appIcon(StatusBarNotification sbn) {
        HomeActivity.AppEntry entry = appFor(sbn);
        if (entry != null) {
            Drawable icon = home.shownIcon(entry);
            return icon.getConstantState() != null ? icon.getConstantState().newDrawable(home.getResources()).mutate() : icon;
        }
        try {
            Drawable small = sbn.getNotification().getSmallIcon().loadDrawable(home);
            if (small != null) {
                small.mutate().setTint(home.textPrimary);
            }
            return small;
        } catch (Exception e) {
            return null;
        }
    }

    private String timeText(long when) {
        long now = System.currentTimeMillis();
        if (now - when < 60000L) {
            return home.getString(R.string.notif_now);
        }
        return DateUtils.getRelativeTimeSpanString(when, now, DateUtils.MINUTE_IN_MILLIS, DateUtils.FORMAT_ABBREV_RELATIVE).toString();
    }

    private void addNotificationsHeader(List<StatusBarNotification> list) {
        LinearLayout header = new LinearLayout(home);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(home.dp(6.0f), home.dp(18.0f), home.dp(6.0f), 0);
        TextView title = home.label(home.getString(R.string.notif_title), 17, home.textPrimary, 600);
        home.shadowOnWallpaper(title);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        boolean clearable = false;
        for (StatusBarNotification sbn : list) {
            clearable |= sbn.isClearable();
        }
        if (clearable) {
            TextView clear = home.label(home.getString(R.string.notif_clear_all), 14, Color.WHITE, 600);
            clear.setPadding(home.dp(14.0f), home.dp(6.0f), home.dp(14.0f), home.dp(7.0f));
            clear.setBackground(home.pill(home.accent, 16));
            clear.setOnClickListener(v -> {
                DotsService.dismissAll();
                refreshSoon();
            });
            header.addView(clear);
        }
        content.addView(header, new LinearLayout.LayoutParams(-1, -2));
    }

    private void addGroup(String groupKey, List<StatusBarNotification> list) {
        LinearLayout card = card();
        StatusBarNotification latest = list.get(0);
        LinearLayout header = new LinearLayout(home);
        header.setGravity(Gravity.CENTER_VERTICAL);
        ImageView icon = new ImageView(home);
        icon.setImageDrawable(appIcon(latest));
        header.addView(icon, new LinearLayout.LayoutParams(home.dp(20.0f), home.dp(20.0f)));
        String name = appName(latest);
        TextView app = home.label(list.size() > 1 ? home.getString(R.string.notif_app_count, name, list.size()) : name, 13, home.textPrimary, 600);
        app.setSingleLine(true);
        app.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams appParams = new LinearLayout.LayoutParams(0, -2, 1f);
        appParams.setMarginStart(home.dp(8.0f));
        header.addView(app, appParams);
        header.addView(home.label(timeText(latest.getPostTime()), 12, home.textSecondary, 400));
        card.addView(header, new LinearLayout.LayoutParams(-1, -2));
        boolean open = expanded.contains(groupKey);
        int limit = open ? list.size() : Math.min(3, list.size());
        for (int i = 0; i < limit; i++) {
            if (i > 0) {
                View line = new View(home);
                line.setBackgroundColor(HomeActivity.withAlpha(home.textPrimary, 0.12f));
                LinearLayout.LayoutParams lineParams = new LinearLayout.LayoutParams(-1, Math.max(1, home.dp(0.6f)));
                lineParams.topMargin = home.dp(2.0f);
                card.addView(line, lineParams);
            }
            card.addView(notificationRow(list.get(i), name), new LinearLayout.LayoutParams(-1, -2));
        }
        if (list.size() > limit) {
            TextView more = home.label(home.getString(R.string.notif_more, list.size() - limit), 13, home.accentOnWallpaper(), 600);
            more.setPadding(0, home.dp(8.0f), 0, home.dp(2.0f));
            more.setOnClickListener(v -> {
                expanded.add(groupKey);
                fill();
            });
            card.addView(more, new LinearLayout.LayoutParams(-1, -2));
        }
    }

    private View notificationRow(final StatusBarNotification sbn, String appName) {
        final Notification n = sbn.getNotification();
        final boolean secret = hidden(sbn);
        LinearLayout row = new LinearLayout(home);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(0, home.dp(10.0f), 0, home.dp(8.0f));
        LinearLayout top = new LinearLayout(home);
        top.setGravity(Gravity.CENTER_VERTICAL);
        CharSequence title = secret ? appName : title(sbn);
        CharSequence body = secret ? home.getString(R.string.notif_hidden) : text(sbn);
        if (!secret && n.getLargeIcon() != null) {
            try {
                Drawable large = n.getLargeIcon().loadDrawable(home);
                if (large != null) {
                    ImageView avatar = new ImageView(home);
                    avatar.setImageDrawable(large);
                    avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    avatar.setClipToOutline(true);
                    avatar.setBackground(home.pill(Color.TRANSPARENT, 20));
                    LinearLayout.LayoutParams avatarParams = new LinearLayout.LayoutParams(home.dp(40.0f), home.dp(40.0f));
                    avatarParams.setMarginEnd(home.dp(12.0f));
                    top.addView(avatar, avatarParams);
                }
            } catch (Exception ignored) {
            }
        }
        LinearLayout texts = new LinearLayout(home);
        texts.setOrientation(LinearLayout.VERTICAL);
        if (!TextUtils.isEmpty(title)) {
            TextView titleView = home.label(title.toString(), 15, home.textPrimary, 600);
            titleView.setSingleLine(true);
            titleView.setEllipsize(TextUtils.TruncateAt.END);
            texts.addView(titleView);
        }
        if (!TextUtils.isEmpty(body)) {
            TextView bodyView = home.label(body.toString(), 14, home.textSecondary, 400);
            bodyView.setMaxLines(3);
            bodyView.setEllipsize(TextUtils.TruncateAt.END);
            texts.addView(bodyView);
        }
        top.addView(texts, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(top, new LinearLayout.LayoutParams(-1, -2));
        if (!secret && n.actions != null && n.actions.length > 0) {
            addActions(row, sbn, n.actions);
        }
        row.setContentDescription(appName + "، " + (title == null ? "" : title) + "، " + (body == null ? "" : body));
        row.setBackground(new RippleDrawable(ColorStateList.valueOf(HomeActivity.withAlpha(home.textPrimary, 0.14f)), null,
                home.pill(Color.WHITE, 14)));
        row.setOnClickListener(v -> openNotification(sbn));
        row.setOnLongClickListener(v -> {
            Intent settings = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, sbn.getPackageName());
            close();
            home.startSafely(settings);
            return true;
        });
        if (sbn.isClearable()) {
            swipeAway(row, sbn);
        }
        return row;
    }

    private void addActions(LinearLayout row, final StatusBarNotification sbn, Notification.Action[] actions) {
        LinearLayout buttons = new LinearLayout(home);
        buttons.setPadding(0, home.dp(8.0f), 0, 0);
        Notification.Action reply = null;
        int count = 0;
        for (final Notification.Action action : actions) {
            if (count >= 3 || action == null || action.actionIntent == null || TextUtils.isEmpty(action.title)) {
                continue;
            }
            boolean replies = action.getRemoteInputs() != null && action.getRemoteInputs().length > 0;
            if (replies) {
                reply = action;
            }
            TextView button = home.label(action.title.toString(), 13, home.textPrimary, 600);
            button.setPadding(home.dp(14.0f), home.dp(7.0f), home.dp(14.0f), home.dp(7.0f));
            button.setBackground(home.pill(HomeActivity.withAlpha(home.textPrimary, 0.16f), 15));
            button.setOnClickListener(v -> {
                if (replies) {
                    replyKey = sbn.getKey();
                    fill();
                } else {
                    send(action.actionIntent, null);
                    refreshSoon();
                }
            });
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, -2);
            params.setMarginEnd(home.dp(8.0f));
            buttons.addView(button, params);
            count++;
        }
        if (count > 0) {
            row.addView(buttons, new LinearLayout.LayoutParams(-1, -2));
        }
        if (reply != null && sbn.getKey().equals(replyKey)) {
            addReplyBox(row, sbn, reply);
        }
    }

    /** Reply in place, as from the system shade; the app gets the text the same way. */
    private void addReplyBox(LinearLayout row, final StatusBarNotification sbn, final Notification.Action action) {
        LinearLayout box = new LinearLayout(home);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(home.dp(14.0f), 0, home.dp(4.0f), 0);
        box.setBackground(home.pill(HomeActivity.withAlpha(home.textPrimary, 0.12f), 22));
        final EditText input = new EditText(home);
        input.setBackground(null);
        input.setHint(action.getRemoteInputs()[0].getLabel() != null ? action.getRemoteInputs()[0].getLabel() : home.getString(R.string.notif_reply_hint));
        input.setHintTextColor(home.textSecondary);
        input.setTextColor(home.textPrimary);
        input.setTextSize(15.0f);
        input.setMaxLines(4);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        box.addView(input, new LinearLayout.LayoutParams(0, -2, 1f));
        ImageView sendButton = new ImageView(home);
        sendButton.setImageDrawable(new Glyphs(Glyphs.SEND, home.accentOnWallpaper(), home.dp(22.0f)));
        sendButton.setScaleType(ImageView.ScaleType.CENTER);
        sendButton.setContentDescription(home.getString(R.string.notif_send));
        if (content.getLayoutDirection() == View.LAYOUT_DIRECTION_RTL) {
            sendButton.setScaleX(-1f); // the paper plane points the way the text runs
        }
        box.addView(sendButton, new LinearLayout.LayoutParams(home.dp(44.0f), home.dp(44.0f)));
        Runnable submit = () -> {
            String text = input.getText().toString().trim();
            if (text.isEmpty()) {
                return;
            }
            RemoteInput[] inputs = action.getRemoteInputs();
            Intent fillIn = new Intent();
            Bundle results = new Bundle();
            for (RemoteInput remote : inputs) {
                results.putCharSequence(remote.getResultKey(), text);
            }
            RemoteInput.addResultsToIntent(inputs, fillIn, results);
            if (Build.VERSION.SDK_INT >= 28) {
                RemoteInput.setResultsSource(fillIn, RemoteInput.SOURCE_FREE_FORM_INPUT);
            }
            boolean sent = send(action.actionIntent, fillIn);
            Toast.makeText(home, home.getString(sent ? R.string.notif_sent : R.string.notif_send_failed), Toast.LENGTH_SHORT).show();
            replyKey = null;
            InputMethodManager keyboard = home.getSystemService(InputMethodManager.class);
            if (keyboard != null) {
                keyboard.hideSoftInputFromWindow(input.getWindowToken(), 0);
            }
            refreshSoon();
        };
        sendButton.setOnClickListener(v -> submit.run());
        input.setOnEditorActionListener((v, id, event) -> {
            submit.run();
            return true;
        });
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = home.dp(8.0f);
        row.addView(box, params);
        input.requestFocus();
        input.post(() -> {
            InputMethodManager keyboard = home.getSystemService(InputMethodManager.class);
            if (keyboard != null) {
                keyboard.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
            }
        });
    }

    private void addMediaCard(final StatusBarNotification sbn) {
        MediaController controller;
        try {
            controller = new MediaController(home, mediaToken(sbn));
        } catch (Exception e) {
            return;
        }
        LinearLayout card = card();
        LinearLayout top = new LinearLayout(home);
        top.setGravity(Gravity.CENTER_VERTICAL);
        MediaMetadata meta = controller.getMetadata();
        CharSequence title = meta != null ? meta.getText(MediaMetadata.METADATA_KEY_TITLE) : null;
        CharSequence artist = meta != null ? meta.getText(MediaMetadata.METADATA_KEY_ARTIST) : null;
        if (TextUtils.isEmpty(title)) {
            title = title(sbn);
        }
        if (TextUtils.isEmpty(artist)) {
            artist = text(sbn);
        }
        Bitmap art = null;
        if (meta != null) {
            art = meta.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
            if (art == null) {
                art = meta.getBitmap(MediaMetadata.METADATA_KEY_ART);
            }
            if (art == null) {
                art = meta.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
            }
        }
        ImageView cover = new ImageView(home);
        cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
        cover.setClipToOutline(true);
        cover.setBackground(home.pill(HomeActivity.withAlpha(home.textPrimary, 0.12f), 14));
        if (art != null) {
            cover.setImageDrawable(new BitmapDrawable(home.getResources(), art));
        } else {
            cover.setImageDrawable(appIcon(sbn));
        }
        top.addView(cover, new LinearLayout.LayoutParams(home.dp(56.0f), home.dp(56.0f)));
        LinearLayout texts = new LinearLayout(home);
        texts.setOrientation(LinearLayout.VERTICAL);
        TextView name = home.label(title == null ? "" : title.toString(), 16, home.textPrimary, 600);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.END);
        texts.addView(name);
        TextView by = home.label((artist == null ? "" : artist + home.getString(R.string.list_separator)) + appName(sbn), 13, home.textSecondary, 400);
        by.setSingleLine(true);
        by.setEllipsize(TextUtils.TruncateAt.END);
        texts.addView(by);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(0, -2, 1f);
        textParams.setMarginStart(home.dp(12.0f));
        top.addView(texts, textParams);
        card.addView(top, new LinearLayout.LayoutParams(-1, -2));
        top.setOnClickListener(v -> openNotification(sbn));

        PlaybackState state = controller.getPlaybackState();
        final boolean playing = state != null && state.getState() == PlaybackState.STATE_PLAYING;
        final MediaController.TransportControls controls = controller.getTransportControls();
        LinearLayout buttons = new LinearLayout(home);
        buttons.setGravity(Gravity.CENTER);
        buttons.setLayoutDirection(View.LAYOUT_DIRECTION_LTR); // previous on the left, next on the right, as on every player
        buttons.setPadding(0, home.dp(10.0f), 0, 0);
        buttons.addView(mediaButton(Glyphs.PREV, R.string.media_previous, false, () -> controls.skipToPrevious()));
        buttons.addView(mediaButton(playing ? Glyphs.PAUSE : Glyphs.PLAY, playing ? R.string.media_pause : R.string.media_play, true,
                () -> {
                    if (playing) {
                        controls.pause();
                    } else {
                        controls.play();
                    }
                }));
        buttons.addView(mediaButton(Glyphs.NEXT, R.string.media_next, false, () -> controls.skipToNext()));
        card.addView(buttons, new LinearLayout.LayoutParams(-1, -2));
    }

    private View mediaButton(int glyph, int description, boolean main, final Action action) {
        FrameLayout button = new FrameLayout(home);
        int size = home.dp(main ? 52.0f : 44.0f);
        button.setBackground(new RippleDrawable(ColorStateList.valueOf(HomeActivity.withAlpha(home.textPrimary, 0.25f)),
                main ? home.pill(home.accent, 26) : null, main ? null : home.pill(Color.WHITE, 22)));
        ImageView icon = new ImageView(home);
        icon.setImageDrawable(new Glyphs(glyph, main ? Color.WHITE : home.textPrimary, home.dp(main ? 26.0f : 24.0f)));
        button.addView(icon, new FrameLayout.LayoutParams(home.dp(main ? 26.0f : 24.0f), home.dp(main ? 26.0f : 24.0f), Gravity.CENTER));
        button.setContentDescription(home.getString(description));
        button.setOnClickListener(v -> {
            action.run();
            refreshSoon();
        });
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(size, size);
        params.setMargins(home.dp(14.0f), 0, home.dp(14.0f), 0);
        button.setLayoutParams(params);
        return button;
    }

    private void addHandle() {
        LinearLayout handle = new LinearLayout(home);
        handle.setGravity(Gravity.CENTER);
        handle.setPadding(home.dp(18.0f), home.dp(8.0f), home.dp(18.0f), home.dp(8.0f));
        home.glassTracked(handle, 20, true, glass);
        ImageView up = new ImageView(home);
        up.setImageDrawable(new Glyphs(Glyphs.CHEVRON_UP, home.textPrimary, home.dp(20.0f)));
        handle.addView(up, new LinearLayout.LayoutParams(home.dp(20.0f), home.dp(20.0f)));
        TextView text = home.label(home.getString(R.string.close), 13, home.textPrimary, 500);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(-2, -2);
        textParams.setMarginStart(home.dp(6.0f));
        handle.addView(text, textParams);
        handle.setOnClickListener(v -> close());
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, home.dp(40.0f));
        params.gravity = Gravity.CENTER_HORIZONTAL;
        params.topMargin = home.dp(18.0f);
        content.addView(handle, params);
    }

    // ---------------------------------------------------------------- acting on notifications

    private void openNotification(StatusBarNotification sbn) {
        Notification n = sbn.getNotification();
        boolean opened = n.contentIntent != null && send(n.contentIntent, null);
        if (!opened) {
            Intent launch = home.getPackageManager().getLaunchIntentForPackage(sbn.getPackageName());
            if (launch != null) {
                home.startSafely(launch);
            }
        }
        if ((n.flags & Notification.FLAG_AUTO_CANCEL) != 0) {
            DotsService.dismiss(sbn.getKey());
        }
        close();
    }

    /** Fires an app's PendingIntent from the home screen, which is in front, so the app may open. */
    private boolean send(PendingIntent intent, Intent fillIn) {
        try {
            Bundle options = null;
            if (Build.VERSION.SDK_INT >= 34) {
                options = ActivityOptions.makeBasic()
                        .setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
                        .toBundle();
            }
            intent.send(home, 0, fillIn, null, null, null, options);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Slide a notification sideways to dismiss it; let go early and it springs back. */
    private void swipeAway(final View row, final StatusBarNotification sbn) {
        final int slop = ViewConfiguration.get(home).getScaledTouchSlop();
        row.setOnTouchListener(new View.OnTouchListener() {
            private float downX;
            private float downY;
            private boolean dragging;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = event.getRawX();
                        downY = event.getRawY();
                        dragging = false;
                        return false;
                    case MotionEvent.ACTION_MOVE: {
                        float dx = event.getRawX() - downX;
                        float dy = event.getRawY() - downY;
                        if (!dragging && Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy) * 1.5f) {
                            dragging = true;
                            touching = true;
                            if (v.getParent() != null) {
                                v.getParent().requestDisallowInterceptTouchEvent(true);
                            }
                            v.cancelLongPress();
                            v.setPressed(false);
                        }
                        if (dragging) {
                            v.setTranslationX(dx);
                            v.setAlpha(1f - Math.min(0.9f, Math.abs(dx) / Math.max(1, v.getWidth())));
                            return true;
                        }
                        return false;
                    }
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL: {
                        if (!dragging) {
                            return false;
                        }
                        dragging = false;
                        float dx = event.getRawX() - downX;
                        if (event.getActionMasked() == MotionEvent.ACTION_UP && Math.abs(dx) > v.getWidth() * 0.35f) {
                            v.animate().translationX(Math.signum(dx) * v.getWidth()).alpha(0f).setDuration(160L).withEndAction(() -> {
                                touching = false;
                                DotsService.dismiss(sbn.getKey());
                                refreshSoon();
                            }).start();
                        } else {
                            v.animate().translationX(0f).alpha(1f).setDuration(160L).withEndAction(() -> {
                                touching = false;
                                if (dirty) {
                                    fill();
                                }
                            }).start();
                        }
                        return true;
                    }
                    default:
                        return false;
                }
            }
        });
    }

    /** For tests: whether a reply box is showing. */
    boolean replying() {
        return replyKey != null;
    }
}
