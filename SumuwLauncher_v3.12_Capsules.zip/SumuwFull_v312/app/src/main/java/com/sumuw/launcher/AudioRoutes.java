package com.sumuw.launcher;

import android.content.SharedPreferences;
import android.media.AudioDeviceInfo;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Headphones and the car, from where the phone's sound goes (no Bluetooth permission needed: Android
 * tells every app about its audio outputs). A Bluetooth output is the car when the user marked it so,
 * or when its name sounds like one (a car maker, "car", "سيارة"…); any other headset is headphones.
 */
final class AudioRoutes {
    static final String PREF_CARS = "car_devices";
    static final String PREF_SEEN = "audio_devices_seen";
    static final String PREF_DRIVE = "drive_mode";
    static final String PREF_PARKING = "parking_on";

    /** Words in a car's Bluetooth name. */
    private static final String[] CAR_WORDS = {"car", "auto", "carplay", "sync", "uconnect", "mbux", "mylink", "entune", "navi", "multimedia",
            "toyota", "lexus", "hyundai", "kia", "nissan", "infiniti", "honda", "acura", "mazda", "ford", "lincoln", "chevrolet", "chevy",
            "gmc", "cadillac", "dodge", "jeep", "chrysler", "ram", "bmw", "mini", "mercedes", "benz", "audi", "volkswagen", "vw", "porsche",
            "volvo", "peugeot", "renault", "mg ", "geely", "chery", "changan", "haval", "jetour", "byd", "tesla", "lucid", "land rover",
            "range rover", "jaguar", "mitsubishi", "subaru", "suzuki", "isuzu", "سيارة", "سيارتي"};

    private AudioRoutes() {
    }

    static boolean bluetooth(int type) {
        return type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO
                || type == 26 /* TYPE_BLE_HEADSET */ || type == 27 /* TYPE_BLE_SPEAKER */;
    }

    static boolean wired(int type) {
        return type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || type == AudioDeviceInfo.TYPE_WIRED_HEADSET
                || type == AudioDeviceInfo.TYPE_USB_HEADSET;
    }

    /** Sounds like a car: by name, or marked by the user. */
    static boolean isCar(SharedPreferences prefs, String name) {
        if (name == null || name.trim().isEmpty()) {
            return false;
        }
        String clean = name.trim();
        if (cars(prefs).contains(clean)) {
            return true;
        }
        if (prefs.getString("not_cars", "").contains("|" + clean + "|")) {
            return false;
        }
        String lower = " " + clean.toLowerCase(Locale.ROOT) + " ";
        for (String word : CAR_WORDS) {
            if (lower.contains(word.startsWith("mg") ? " " + word : word)) {
                return true;
            }
        }
        return false;
    }

    static Set<String> cars(SharedPreferences prefs) {
        return split(prefs.getString(PREF_CARS, ""));
    }

    static Set<String> seen(SharedPreferences prefs) {
        return split(prefs.getString(PREF_SEEN, ""));
    }

    /** Remembers a Bluetooth output's name, for choosing "this is my car" in the settings. */
    static void remember(SharedPreferences prefs, String name) {
        if (name == null || name.trim().isEmpty()) {
            return;
        }
        LinkedHashSet<String> all = new LinkedHashSet<>(seen(prefs));
        if (all.add(name.trim())) {
            while (all.size() > 12) {
                all.remove(all.iterator().next());
            }
            prefs.edit().putString(PREF_SEEN, join(all)).apply();
        }
    }

    /** Marks or unmarks a device as the car (the opposite is remembered too, so a name guess can be undone). */
    static void markCar(SharedPreferences prefs, String name, boolean car) {
        LinkedHashSet<String> marked = new LinkedHashSet<>(cars(prefs));
        String notCars = prefs.getString("not_cars", "");
        if (car) {
            marked.add(name);
            notCars = notCars.replace("|" + name + "|", "");
        } else {
            marked.remove(name);
            if (!notCars.contains("|" + name + "|")) {
                notCars = notCars + "|" + name + "|";
            }
        }
        prefs.edit().putString(PREF_CARS, join(marked)).putString("not_cars", notCars).apply();
    }

    private static Set<String> split(String saved) {
        LinkedHashSet<String> set = new LinkedHashSet<>();
        for (String part : saved.split("\\n")) {
            if (!part.trim().isEmpty()) {
                set.add(part.trim());
            }
        }
        return set;
    }

    private static String join(Set<String> set) {
        StringBuilder out = new StringBuilder();
        for (String item : set) {
            if (out.length() > 0) {
                out.append('\n');
            }
            out.append(item);
        }
        return out.toString();
    }

    // ---------------------------------------------------------------- where the car is

    static boolean hasParking(SharedPreferences prefs) {
        return prefs.contains("parking_lat") && System.currentTimeMillis() - prefs.getLong("parking_time", 0L) < 24 * 3600000L;
    }

    static void park(SharedPreferences prefs, double lat, double lng, long at) {
        prefs.edit().putFloat("parking_lat", (float) lat).putFloat("parking_lng", (float) lng).putLong("parking_time", at)
                .remove("parking_pending").apply();
    }

    static void clearParking(SharedPreferences prefs) {
        prefs.edit().remove("parking_lat").remove("parking_lng").remove("parking_time").remove("parking_pending").apply();
    }
}
