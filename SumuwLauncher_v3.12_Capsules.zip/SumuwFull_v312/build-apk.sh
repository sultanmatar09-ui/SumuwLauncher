#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SDK="${ANDROID_HOME:-$ROOT/../.android-sdk}"
BT="$SDK/build-tools/35.0.0"
PLATFORM="$SDK/platforms/android-35"
OUT="$ROOT/app/build/manual"
VERSION_CODE=44
VERSION_NAME=3.12
ECJ_VERSION=3.39.0

for required in "$BT/aapt2" "$BT/d8" "$BT/zipalign" "$BT/apksigner" "$PLATFORM/android.jar"; do
  if [[ ! -e "$required" ]]; then
    echo "Missing: $required" >&2
    echo "Install Android SDK Platform 35 and Build Tools 35.0.0, then set ANDROID_HOME to the SDK folder." >&2
    exit 1
  fi
done

rm -rf "$OUT/classes" "$OUT/generated" "$OUT/dex"
mkdir -p "$OUT/classes" "$OUT/generated" "$OUT/dex"
"$BT/aapt2" compile -o "$OUT/resources.zip" --dir "$ROOT/app/src/main/res"
"$BT/aapt2" link -o "$OUT/unsigned.apk" \
  --manifest "$ROOT/app/src/main/AndroidManifest.xml" \
  -I "$PLATFORM/android.jar" --java "$OUT/generated" \
  --min-sdk-version 26 --target-sdk-version 35 \
  --version-code "$VERSION_CODE" --version-name "$VERSION_NAME" --replace-version \
  "$OUT/resources.zip"

ECJ="$ROOT/tools/ecj.jar"
if [[ ! -f "$ECJ" ]]; then
  mkdir -p "$ROOT/tools"
  ECJ_URL="https://repo.maven.apache.org/maven2/org/eclipse/jdt/ecj/$ECJ_VERSION/ecj-$ECJ_VERSION.jar"
  curl -L --fail --silent --show-error "$ECJ_URL" -o "$ECJ.part"
  # Check the download against the checksum Maven Central publishes for it.
  EXPECTED_SHA1="$(curl -L --fail --silent --show-error "$ECJ_URL.sha1" | tr -d '[:space:]' | cut -c1-40)"
  ACTUAL_SHA1="$(python3 -c 'import hashlib,sys; print(hashlib.sha1(open(sys.argv[1],"rb").read()).hexdigest())' "$ECJ.part")"
  if [[ "$EXPECTED_SHA1" != "$ACTUAL_SHA1" ]]; then
    rm -f "$ECJ.part"
    echo "ecj.jar checksum mismatch (expected $EXPECTED_SHA1, got $ACTUAL_SHA1)" >&2
    exit 1
  fi
  mv "$ECJ.part" "$ECJ"
fi

find "$ROOT/app/src/main/java" "$OUT/generated" -name '*.java' > "$OUT/sources.txt"
# core-lambda-stubs.jar supplies java.lang.invoke for lambdas (Gradle adds it the same way); d8 desugars them.
java -jar "$ECJ" -encoding UTF-8 -source 1.8 -target 1.8 -nowarn \
  -bootclasspath "$PLATFORM/android.jar:$BT/core-lambda-stubs.jar" -d "$OUT/classes" @"$OUT/sources.txt"
python3 - "$OUT/classes" "$OUT/classes.jar" <<'PY'
import os, sys, zipfile
base, target = sys.argv[1:]
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk(base):
        dirs.sort()
        for name in sorted(files):
            path = os.path.join(root, name)
            z.write(path, os.path.relpath(path, base))
PY
"$BT/d8" --min-api 26 --lib "$PLATFORM/android.jar" --output "$OUT/dex" "$OUT/classes.jar"
cp "$OUT/unsigned.apk" "$OUT/unsigned-with-dex.apk"
# d8 writes classes2.dex, classes3.dex... once the app grows past one dex file; ship all of them.
(cd "$OUT/dex" && zip -q -j "$OUT/unsigned-with-dex.apk" ./*.dex)
"$BT/zipalign" -f 4 "$OUT/unsigned-with-dex.apk" "$OUT/aligned.apk"
if [[ -n "${KEYSTORE_BASE64:-}" ]]; then
  echo "$KEYSTORE_BASE64" | base64 --decode > "$OUT/release.keystore"
  "$BT/apksigner" sign --ks "$OUT/release.keystore" \
    --ks-pass "pass:${KEYSTORE_PASSWORD}" --key-pass "pass:${KEY_PASSWORD}" --ks-key-alias "${KEY_ALIAS}" \
    --out "$ROOT/app/build/SumuwLauncher-v3.12.apk" "$OUT/aligned.apk"
else
  if [[ ! -f "$OUT/debug.keystore" ]]; then
    keytool -genkeypair -keystore "$OUT/debug.keystore" -storepass android -keypass android \
      -alias androiddebugkey -dname 'CN=Android Debug,O=Android,C=US' -keyalg RSA -keysize 2048 -validity 10000 >/dev/null
  fi
  "$BT/apksigner" sign --ks "$OUT/debug.keystore" --ks-pass pass:android --key-pass pass:android \
    --out "$ROOT/app/build/SumuwLauncher-v3.12.apk" "$OUT/aligned.apk"
fi
"$BT/apksigner" verify --verbose "$ROOT/app/build/SumuwLauncher-v3.12.apk"
echo "APK: $ROOT/app/build/SaraHome-debug.apk (version $VERSION_NAME, code $VERSION_CODE)"
