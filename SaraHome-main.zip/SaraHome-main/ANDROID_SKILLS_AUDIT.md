# مراجعة سارة هوم بمهارات أندرويد الرسمية (android/skills)

النسخة: 3.8.1 (code 36). المصدر: https://github.com/android/skills (آخر تحديث للمستودع 9 نوفمبر 2026).

اللانشر مكتوب بـ Java وواجهات View، ويُبنى بلا Gradle ولا AndroidX. لذلك طُبّقت مبادئ كل مهارة على هذا النوع من الكود، ولم تُنقل أمثلتها المكتوبة بـ Kotlin وCompose كما هي.

## المهارات المستعملة

| المهارة | ما فُعل |
|---|---|
| security/android-intent-security | مراجعة المكونات المكشوفة والنوايا والـ PendingIntent والمستقبِلات |
| security/android-permissions-security | مراجعة الأذونات وتدفق طلبها وقت التشغيل |
| system/edge-to-edge | مراجعة الهوامش مع أشرطة النظام ولوحة المفاتيح (targetSdk 35) |
| performance/anr-audit-and-fix | تدقيق ثابت لمخاطر تعليق الخيط الرئيسي، وتشغيل الاختبارات بفرض خيط الواجهة |
| jetpack-compose/adaptive | قاعدة «لا configChanges لمنع إعادة الإنشاء ولا قفل الاتجاه» |

ولم تُستعمل هذه المهارات لعدم انطباقها:
- مهارات Compose وNavigation 3 وGlance وWear وTV وXR وCameraX وLiteRT وCredentials: لا يستعمل اللانشر شيئًا من هذه الأدوات.
- مهارتا R8 وترقية AGP 9: البناء بـ d8 بلا R8 ولا Gradle.
- مهارة Play Policy Insights: التطبيق ليس على Google Play (com.example). تُستعمل قبل النشر.

---

### Security hardening and alignment update: Dynamic receiver export

*   **Improvement Description:** مستقبِلا البث المسجلان أثناء التشغيل (البطارية والشبكة في الرئيسية، والوقت والشاشة في الخلفية الحية) يسمعان بث النظام فقط. صارا مغلقين أمام التطبيقات الأخرى بـ `RECEIVER_NOT_EXPORTED` على أندرويد 13 وما بعده.
*   **Priority Level:** Medium
*   **Alignment Action:** `registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)` على API 33+.

#### Files modified
*   `app/src/main/java/com/example/duohome/HomeActivity.java`
*   `app/src/main/java/com/example/duohome/SaraWallpaper.java`

#### Testing and verification
1.  الاختبارات القائمة للبطارية والوقت في الخلفية الحية ما زالت تنجح.

### Security hardening and alignment update: Outside links

*   **Improvement Description:** روابط الأخبار (من خلاصات RSS قد يضيفها المستخدم) وروابط الحافظة كانت تُفتح بأي مخطط. صارت تُفتح فقط إن كانت http أو https ولها مضيف، وبـ `CATEGORY_BROWSABLE` حتى لا يفتحها إلا تطبيق يفتح صفحات الويب. ولا يُفتح أي رابط file: أو content: أو intent: أو javascript:.
*   **Priority Level:** Medium
*   **Alignment Action:** دالة `ClipSuggest.web()` تتحقق من الرابط ويستعملها `openNews` و`ClipSuggest.open`.

#### Files modified
*   `app/src/main/java/com/example/duohome/ClipSuggest.java`
*   `app/src/main/java/com/example/duohome/HomeActivity.java`

#### Testing and verification
1.  `securityAndPermissionsFollowAndroidGuidance`: يُرفض file: وintent: وjavascript: وcontent:، ويُقبل https مع BROWSABLE.

### Security hardening and alignment update: Runtime permission flow

*   **Improvement Description:** بعد الرفض النهائي لا يسأل أندرويد مرة أخرى، فكان الضغط على «اسمح بقراءة التقويم» وأمثاله لا يفعل شيئًا. صار الطلب يمر بثلاث حالات: تحقق، ثم سؤال، فإن كان الرفض نهائيًا ظهر شرح لفائدة الإذن وزر يفتح صفحة سارة هوم في الإعدادات.
*   **Priority Level:** Medium (تجربة المستخدم)
*   **Alignment Action:** صنف جديد `Permissions.ask()` يُستعمل للتقويم وجهات الاتصال والموقع والإشعارات عند الضغط. وحالة «سُئل من قبل» لا تدخل النسخ الاحتياطية.

#### Files modified
*   `app/src/main/java/com/example/duohome/Permissions.java` (جديد)
*   `app/src/main/java/com/example/duohome/HomeActivity.java`
*   `app/src/main/java/com/example/duohome/TodaySettings.java`
*   `app/src/main/java/com/example/duohome/Backup.java`

#### Testing and verification
1.  `securityAndPermissionsFollowAndroidGuidance`: الطلب الأول يسأل، والثاني بعد الرفض يعرض الحوار، وزره يفتح `ACTION_APPLICATION_DETAILS_SETTINGS`.

### نتائج مراجعة النوايا التي لم تحتج تعديلًا
- كل الـ PendingIntent غير قابلة للتعديل (`FLAG_IMMUTABLE`) وصريحة الهدف.
- `ReminderReceiver` غير مكشوف ويستقبل بث النظام المحمي فقط.
- `HomeActivity` مكشوف لأنه شاشة رئيسية (HOME)، ولا يقرأ أي extras من النوايا الواردة. أوامر الإعدادات تمر عبر التفضيلات الخاصة لا عبر النوايا، و`onNewIntent` يستدعي `setIntent`.
- الاسم البديل `LockWallpaperSettings` لا بد أن يكون مكشوفًا ليفتحه منتقي الخلفيات في النظام. والقيمة الوحيدة التي يقرؤها (رقم التبويب) محصورة في مداها.
- خدمة الإشعارات والخلفية الحية محميتان بأذونات الربط من النظام (BIND_*). خدمة الإتاحة غير مكشوفة.
- لا يوجد ContentProvider ولا بث لزج.

---

## edge-to-edge

- محرر شاشة القفل يرسم الآن تحت أشرطة النظام، ويطبّق هوامش الأشرطة وفتحة الكاميرا ولوحة المفاتيح بنفسه، فيبقى حقل الرسالة ظاهرًا فوق لوحة المفاتيح، مع `adjustResize`. أيقونات الشريطين فاتحة على خلفيته الداكنة.
- كشفت الاختبارات أثناء هذا التعديل أن استدعاء `getInsetsController()` قبل `setContentView` يوقف المحرر عند فتحه، لأن نافذة `PhoneWindow` لم تُنشئ واجهتها بعد. فنُقل الاستدعاء إلى ما بعد إنشاء المحتوى. هذا الخطأ لم يكن في 3.8، بل ظهر أثناء التعديل نفسه.
- الرئيسية والإعدادات كانتا تطبقان هوامش `systemBars | displayCutout` من قبل.

## adaptive

- أُزيل `configChanges` من محرر شاشة القفل. صار يُعاد إنشاؤه عند التدوير والطي كما توصي المهارة، والتبويب محفوظ في `onSaveInstanceState` والاختيارات تُحفظ فورًا.
- اتجاه الرئيسية غير مقفل (`unspecified`).

## ANR audit

ANR risk: yes (MEDIUM) — أُصلح.

| الموضع | الخيط | لماذا يعلّق | الدرجة | الإصلاح |
|---|---|---|---|---|
| `Agenda.upcoming` من بطاقة المواعيد وبطاقة صباح الخير و«اليوم» والرزمة الذكية (`HomeActivity`) | الرئيسي (محدّثات البطاقات كل دقيقة، `fillToday`) | `ContentResolver.query` على مزوّد التقويم: استدعاء عبر العمليات | MEDIUM | `Agenda.recent()`: آخر قراءة (دقيقة على الأكثر)، والقراءة في خيط خلفي ثم إعادة رسم على الرئيسي |
| `LockScreen.nextEvent` (شاشة القفل) | الرئيسي (رسم محرك الخلفية في عملية اللانشر نفسها) | الاستعلام نفسه، مرتين في كل رسم | MEDIUM | `Agenda.recent()` ثم `SaraWallpaper.redrawAll()` |

مرشحون استُبعدوا:
- `SmartSearch.contacts`: يعمل في خيط خلفي (`background`) ويعيد النتيجة بـ `runOnUiThread`.
- `CustomIcons.load` وحزم الأيقونات: داخل `appExecutor` عند تحميل التطبيقات.
- `crestFor` (فك صور الشعارات): ملفات صغيرة تُفك مرة ثم تُحفظ في الذاكرة. خطر منخفض بلا تعليق يُذكر.
- صورة الخلفية الشخصية: تُفك مرة ثم تُحفظ مع ختم التعديل. خطر منخفض.
- `Backup` و`commit()`: استعادة يدوية يطلبها المستخدم لملف صغير. انتظار محدود.
- كل المهام الخلفية (الأخبار والمباريات والطقس والأيقونات والصور) تعيد تعديل الواجهة إلى الخيط الرئيسي. وشُغّلت الاختبارات كلها بـ `-Drobolectric.enforceViewMethodsCalledOnMainThread=true` كما توصي المهارة، فلم تظهر أي مخالفة لخيط الواجهة (خطر Sync Barrier Leak).

---

## الفرق الكامل مقارنة بـ 3.8

```diff
diff -ruN -x '*.png' -x strings.xml /tmp/old38/SaraHome-source/app/src/main/AndroidManifest.xml app/src/main/AndroidManifest.xml
--- /tmp/old38/SaraHome-source/app/src/main/AndroidManifest.xml	2026-11-15 00:43:54.000000000 +0300
+++ app/src/main/AndroidManifest.xml	2026-11-15 08:45:42.390838025 +0300
@@ -64,7 +64,7 @@
       android:exported="false"
       android:label="@string/locke_title"
       android:theme="@style/SettingsTheme"
-      android:configChanges="orientation|screenSize|screenLayout|smallestScreenSize"
+      android:windowSoftInputMode="adjustResize"
       android:taskAffinity=""
       android:excludeFromRecents="true"/>
     <!-- The "Settings" button in the live wallpaper's system preview opens the lock screen editor. -->
diff -ruN -x '*.png' -x strings.xml /tmp/old38/SaraHome-source/app/src/main/java/com/example/duohome/Agenda.java app/src/main/java/com/example/duohome/Agenda.java
--- /tmp/old38/SaraHome-source/app/src/main/java/com/example/duohome/Agenda.java	2026-11-15 00:43:54.000000000 +0300
+++ app/src/main/java/com/example/duohome/Agenda.java	2026-11-15 08:46:04.696819825 +0300
@@ -85,6 +85,66 @@
         return events;
     }
 
+    // ---------------------------------------------------------------- read off the main thread
+
+    private static final java.util.concurrent.ExecutorService READER = java.util.concurrent.Executors.newSingleThreadExecutor(work -> {
+        Thread thread = new Thread(work, "sara-agenda");
+        thread.setDaemon(true);
+        return thread;
+    });
+    private static final android.os.Handler MAIN = new android.os.Handler(android.os.Looper.getMainLooper());
+    private static List<Event> cache = new ArrayList<>();
+    private static long cachedAt;
+    private static boolean reading;
+    private static boolean cachedPermitted;
+
+    /**
+     * The calendar is another app's database: reading it is a call across processes that can take a while,
+     * so the cards and the lock screen never read it on the main thread. They take what was read last
+     * (at most a minute old) and, when that's stale, a read starts in the background; when it ends,
+     * {@code changed} runs on the main thread so the caller can draw again.
+     */
+    static List<Event> recent(Context context, long now, int limit, Runnable changed) {
+        ArrayList<Event> out = new ArrayList<>();
+        boolean allowed = permitted(context);
+        synchronized (Agenda.class) {
+            if (!allowed) {
+                cache = new ArrayList<>();
+                cachedPermitted = false;
+                return out;
+            }
+            boolean stale = !cachedPermitted || now - cachedAt > 60000L || now < cachedAt;
+            if (stale && !reading) {
+                reading = true;
+                final Context app = context.getApplicationContext();
+                READER.execute(() -> {
+                    List<Event> fresh = upcoming(app, System.currentTimeMillis(), 8);
+                    synchronized (Agenda.class) {
+                        cache = fresh;
+                        cachedAt = System.currentTimeMillis();
+                        cachedPermitted = true;
+                        reading = false;
+                    }
+                    if (changed != null) {
+                        MAIN.post(changed);
+                    }
+                });
+            }
+            for (Event event : cache) {
+                if (event.end > now && out.size() < limit) {
+                    out.add(event);
+                }
+            }
+        }
+        return out;
+    }
+
+    /** Read again on the next look (an event added, the permission just granted). */
+    static synchronized void forget() {
+        cachedAt = 0L;
+        cachedPermitted = false;
+    }
+
     private static long localMidnight(long utcMidnight) {
         Calendar utc = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
         utc.setTimeInMillis(utcMidnight);
diff -ruN -x '*.png' -x strings.xml /tmp/old38/SaraHome-source/app/src/main/java/com/example/duohome/Backup.java app/src/main/java/com/example/duohome/Backup.java
--- /tmp/old38/SaraHome-source/app/src/main/java/com/example/duohome/Backup.java	2026-11-15 00:43:54.000000000 +0300
+++ app/src/main/java/com/example/duohome/Backup.java	2026-11-15 08:45:20.001439531 +0300
@@ -28,7 +28,7 @@
                 || key.equals("match_told") || key.equals("match_watch_next") || key.startsWith("table_")
                 // the moment's state: what was copied, where the car is, whether Sara silenced the phone, the children's lock
                 || key.startsWith("clip_") || (key.startsWith("parking_") && !key.equals(AudioRoutes.PREF_PARKING)) || key.equals("haram_silenced") || key.equals(Kids.PREF_ON)
-                || key.equals("usage_places") || key.equals("audio_devices_seen");
+                || key.equals("usage_places") || key.equals("audio_devices_seen") || Permissions.isState(key);
     }
 
     static String export(SharedPreferences prefs) throws JSONException {
diff -ruN -x '*.png' -x strings.xml /tmp/old38/SaraHome-source/app/src/main/java/com/example/duohome/ClipSuggest.java app/src/main/java/com/example/duohome/ClipSuggest.java
--- /tmp/old38/SaraHome-source/app/src/main/java/com/example/duohome/ClipSuggest.java	2026-11-15 00:43:54.000000000 +0300
+++ app/src/main/java/com/example/duohome/ClipSuggest.java	2026-11-15 08:45:32.250662483 +0300
@@ -94,7 +94,25 @@
     }
 
     static Intent open(String link) {
-        return new Intent(Intent.ACTION_VIEW, Uri.parse(link.startsWith("http") ? link : "https://" + link));
+        String lower = link.toLowerCase(java.util.Locale.ROOT);
+        Intent web = web(lower.startsWith("http://") || lower.startsWith("https://") ? link : "https://" + link);
+        return web != null ? web : new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(link)));
+    }
+
+    /**
+     * A web page to open from text that came from outside (a feed, the clipboard): only http and https,
+     * and only by apps that open web links (browsable), never a file, an app's private page or a script.
+     */
+    static Intent web(String link) {
+        if (link == null) {
+            return null;
+        }
+        Uri uri = Uri.parse(link.trim());
+        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(java.util.Locale.ROOT);
+        if (!(scheme.equals("http") || scheme.equals("https")) || uri.getHost() == null || uri.getHost().isEmpty()) {
+            return null;
+        }
+        return new Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE);
     }
 
     static Intent email(String address) {
diff -ruN -x '*.png' -x strings.xml /tmp/old38/SaraHome-source/app/src/main/java/com/example/duohome/HomeActivity.java app/src/main/java/com/example/duohome/HomeActivity.java
--- /tmp/old38/SaraHome-source/app/src/main/java/com/example/duohome/HomeActivity.java	2026-11-15 00:43:54.000000000 +0300
+++ app/src/main/java/com/example/duohome/HomeActivity.java	2026-11-15 08:51:54.420565250 +0300
@@ -123,7 +123,7 @@
 import org.xmlpull.v1.XmlPullParser;
 
 public class HomeActivity extends Activity {
-    static final String VERSION_NAME = "3.8";
+    static final String VERSION_NAME = "3.8.1";
     private static final int[] PRAYER_NAMES = {R.string.prayer_fajr, R.string.prayer_sunrise, R.string.prayer_dhuhr,
             R.string.prayer_asr, R.string.prayer_maghrib, R.string.prayer_isha};
     private static final long NEWS_INTERVAL_MS = 60000L;
@@ -501,6 +501,7 @@
         if (appsLoaded && SORT_USAGE.equals(sortMode()) && !isSearchOpen()) {
             applyFilter(currentQuery());
         }
+        Agenda.forget(); // back from the calendar app, perhaps with a new event
         refreshWeather(false);
         followLocation(false);
         updateUsagePlace();
@@ -1768,11 +1769,11 @@
         if (!Agenda.permitted(this)) {
             TextView ask = label(getString(R.string.agenda_allow), 14, accentOnWallpaper(), 600);
             ask.setPadding(0, dp(4.0f), 0, dp(4.0f));
-            ask.setOnClickListener(view -> requestPermissions(new String[]{android.Manifest.permission.READ_CALENDAR}, REQUEST_CALENDAR));
+            ask.setOnClickListener(view -> Permissions.ask(this, new String[]{android.Manifest.permission.READ_CALENDAR}, REQUEST_CALENDAR, R.string.perm_why_calendar));
             card.addView(ask, new LinearLayout.LayoutParams(-1, -2));
             return;
         }
-        List<Agenda.Event> events = Agenda.upcoming(this, now, 5);
+        List<Agenda.Event> events = Agenda.recent(this, now, 5, this::agendaRead);
         if (events.isEmpty()) {
             card.addView(label(getString(R.string.agenda_empty), 14, textSecondary, 400));
             return;
@@ -1811,6 +1812,9 @@
     @Override
     public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
         super.onRequestPermissionsResult(requestCode, permissions, results);
+        if (requestCode == REQUEST_CALENDAR) {
+            Agenda.forget();
+        }
         if (requestCode == REQUEST_CALENDAR && todayOpen) {
             fillToday();
         }
@@ -2055,7 +2059,7 @@
                 });
             } else if (text.length() >= 3 && !prefs.getBoolean("contacts_search_off", false)) {
                 View ask = smartRow(new Glyphs(Glyphs.SHARE, textSecondary, dp(18.0f)), null, getString(R.string.search_contacts_allow), null,
-                        v -> requestPermissions(new String[] {android.Manifest.permission.READ_CONTACTS}, REQUEST_CONTACTS));
+                        v -> Permissions.ask(this, new String[]{android.Manifest.permission.READ_CONTACTS}, REQUEST_CONTACTS, R.string.perm_why_contacts));
                 ask.setOnLongClickListener(v -> {
                     prefs.edit().putBoolean("contacts_search_off", true).apply();
                     smartQuery = "";
@@ -3203,6 +3207,19 @@
         prefs.edit().putString("cards_" + slot, TextUtils.join(",", types)).apply();
     }
 
+    /** The calendar was read in the background: show what it holds. */
+    void agendaRead() {
+        if (isFinishing() || isDestroyed()) {
+            return;
+        }
+        runCardUpdater("agenda");
+        runCardUpdater("morning");
+        if (todayOpen || twoPane) {
+            fillToday();
+        }
+        SaraWallpaper.redrawAll();
+    }
+
     /** Under 600dp of height (small phones, phones on their side) one card stack instead of two. */
     boolean singleStack() {
         return getResources().getConfiguration().screenHeightDp < 600;
@@ -4152,7 +4169,7 @@
             }
             try {
                 if (Agenda.permitted(this)) {
-                    for (Agenda.Event event : Agenda.upcoming(this, now, 1)) {
+                    for (Agenda.Event event : Agenda.recent(this, now, 1, this::agendaRead)) {
                         if (event.begin - now > 16 * 3600000L) {
                             continue; // not today
                         }
@@ -4586,7 +4603,7 @@
             eventsCheckedAt = now;
             eventSoon = false;
             try {
-                for (Agenda.Event event : Agenda.upcoming(this, now, 3)) {
+                for (Agenda.Event event : Agenda.recent(this, now, 3, this::agendaRead)) {
                     if (!event.allDay && event.begin > now && event.begin - now <= window) {
                         eventSoon = true;
                         break;
@@ -5146,7 +5163,7 @@
                         boolean on = !ReminderReceiver.goalAlerts(prefs);
                         prefs.edit().putBoolean("match_goal_alerts", on).apply();
                         if (on && Build.VERSION.SDK_INT >= 33 && !ReminderReceiver.canNotify(this)) {
-                            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 7305);
+                            Permissions.ask(this, new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 7305, R.string.perm_why_notifications);
                         }
                         if (on && Matches.teamIds(prefs).isEmpty()) {
                             Toast.makeText(this, getString(R.string.match_alert_needs_team), Toast.LENGTH_LONG).show();
@@ -5185,7 +5202,7 @@
                     prefs.edit().putInt(Matches.PREF_ALERT, choices[which]).apply();
                     dialog.dismiss();
                     if (choices[which] > 0 && Build.VERSION.SDK_INT >= 33 && !ReminderReceiver.canNotify(this)) {
-                        requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 7305);
+                        Permissions.ask(this, new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 7305, R.string.perm_why_notifications);
                     }
                     if (choices[which] > 0 && Matches.teamIds(prefs).isEmpty()) {
                         Toast.makeText(this, getString(R.string.match_alert_needs_team), Toast.LENGTH_LONG).show();
@@ -5468,13 +5485,13 @@
                 TextView allow = cardLine(getString(R.string.card_agenda_allow), 13, accentOnWallpaper(), 700);
                 allow.setPadding(0, dp(2.0f), 0, 0);
                 ask.addView(allow);
-                ask.setOnClickListener(view -> requestPermissions(new String[]{android.Manifest.permission.READ_CALENDAR}, REQUEST_CALENDAR));
+                ask.setOnClickListener(view -> Permissions.ask(this, new String[]{android.Manifest.permission.READ_CALENDAR}, REQUEST_CALENDAR, R.string.perm_why_calendar));
                 list.addItem(ask);
                 card.setContentDescription(getString(R.string.card_agenda) + "، " + why.getText());
                 return;
             }
             long now = System.currentTimeMillis();
-            List<Agenda.Event> events = Agenda.upcoming(this, now, 4);
+            List<Agenda.Event> events = Agenda.recent(this, now, 4, this::agendaRead);
             if (events.isEmpty()) {
                 TextView empty = cardLine(getString(R.string.agenda_empty), 13, textSecondary, 400);
                 list.addItem(empty);
@@ -7036,8 +7053,12 @@
     }
 
     private void openNews(NewsItem item) {
+        Intent web = ClipSuggest.web(item.link);
+        if (web == null) {
+            return; // a feed's link that isn't a web page (file:, intent:, javascript:) is never opened
+        }
         try {
-            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(item.link)));
+            startActivity(web);
         } catch (Exception ignored) {
         }
     }
@@ -8148,7 +8169,9 @@
         filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
         filter.addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED);
         try {
-            Intent sticky = registerReceiver(batteryReceiver, filter);
+            // System broadcasts only (battery, Wi-Fi, network): closed to other apps on Android 13+.
+            Intent sticky = Build.VERSION.SDK_INT >= 33 ? registerReceiver(batteryReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
+                    : registerReceiver(batteryReceiver, filter);
             batteryRegistered = true;
             updateBattery(sticky);
         } catch (Exception ignored) {
diff -ruN -x '*.png' -x strings.xml /tmp/old38/SaraHome-source/app/src/main/java/com/example/duohome/LockEditorActivity.java app/src/main/java/com/example/duohome/LockEditorActivity.java
--- /tmp/old38/SaraHome-source/app/src/main/java/com/example/duohome/LockEditorActivity.java	2026-11-15 00:43:54.000000000 +0300
+++ app/src/main/java/com/example/duohome/LockEditorActivity.java	2026-11-15 08:48:29.345054073 +0300
@@ -4,7 +4,6 @@
 import android.content.Intent;
 import android.content.IntentFilter;
 import android.content.SharedPreferences;
-import android.content.res.Configuration;
 import android.graphics.Bitmap;
 import android.graphics.Canvas;
 import android.graphics.Color;
@@ -14,6 +13,7 @@
 import android.graphics.drawable.Drawable;
 import android.graphics.drawable.GradientDrawable;
 import android.os.BatteryManager;
+import android.os.Build;
 import android.os.Bundle;
 import android.os.Handler;
 import android.os.Looper;
@@ -26,6 +26,8 @@
 import android.view.View;
 import android.view.ViewGroup;
 import android.view.ViewOutlineProvider;
+import android.view.WindowInsets;
+import android.view.WindowInsetsController;
 import android.widget.EditText;
 import android.widget.FrameLayout;
 import android.widget.HorizontalScrollView;
@@ -78,8 +80,14 @@
         Fonts.init(this);
         prefs = getSharedPreferences("duo_home", 0);
         accent = prefs.getInt("accent", Color.rgb(101, 103, 191));
-        getWindow().setStatusBarColor(SURFACE);
-        getWindow().setNavigationBarColor(SURFACE);
+        // Edge to edge (Android 15 draws every app under the bars): the dark page reaches the edges, its
+        // contents keep clear of the bars, the cut-out and the keyboard, and the bars' icons are light.
+        if (Build.VERSION.SDK_INT >= 30) {
+            getWindow().setDecorFitsSystemWindows(false);
+        } else {
+            getWindow().setStatusBarColor(SURFACE);
+            getWindow().setNavigationBarColor(SURFACE);
+        }
         int[] size = SystemWallpaper.screenSize(this);
         screenW = size[0];
         screenH = size[1];
@@ -101,12 +109,6 @@
     }
 
     @Override
-    public void onConfigurationChanged(Configuration config) {
-        super.onConfigurationChanged(config);
-        build();
-    }
-
-    @Override
     protected void onDestroy() {
         handler.removeCallbacks(render);
         super.onDestroy();
@@ -123,7 +125,17 @@
         LinearLayout root = new LinearLayout(this);
         root.setOrientation(LinearLayout.VERTICAL);
         root.setBackgroundColor(SURFACE);
-        root.setFitsSystemWindows(true);
+        if (Build.VERSION.SDK_INT >= 30) {
+            root.setOnApplyWindowInsetsListener((view, insets) -> {
+                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
+                android.graphics.Insets ime = insets.getInsets(WindowInsets.Type.ime());
+                // The keyboard takes the bottom when it's up (the message field stays in view above it).
+                view.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, ime.bottom));
+                return WindowInsets.CONSUMED;
+            });
+        } else {
+            root.setFitsSystemWindows(true);
+        }
         root.addView(topBar(), new LinearLayout.LayoutParams(-1, dp(56)));
         banner = new LinearLayout(this);
         banner.setOrientation(LinearLayout.VERTICAL);
@@ -190,6 +202,11 @@
         body.addView(controls, sideBySide ? new LinearLayout.LayoutParams(0, -1, 0.55f) : new LinearLayout.LayoutParams(-1, 0, 1f));
 
         setContentView(root);
+        if (Build.VERSION.SDK_INT >= 30 && getWindow().getInsetsController() != null) {
+            // Light icons on the dark page (the controller exists once the window has its content).
+            getWindow().getInsetsController().setSystemBarsAppearance(0,
+                    WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
+        }
         updateBanner();
         selectTab(tab);
         render();
diff -ruN -x '*.png' -x strings.xml /tmp/old38/SaraHome-source/app/src/main/java/com/example/duohome/LockScreen.java app/src/main/java/com/example/duohome/LockScreen.java
--- /tmp/old38/SaraHome-source/app/src/main/java/com/example/duohome/LockScreen.java	2026-11-15 00:43:54.000000000 +0300
+++ app/src/main/java/com/example/duohome/LockScreen.java	2026-11-15 08:46:04.700782329 +0300
@@ -329,7 +329,8 @@
             if (!Agenda.permitted(context)) {
                 return null;
             }
-            for (Agenda.Event event : Agenda.upcoming(context, now, 1)) {
+            // The lock screen draws on the main thread: the calendar is read in the background, then drawn again.
+            for (Agenda.Event event : Agenda.recent(context, now, 1, SaraWallpaper::redrawAll)) {
                 if (event.begin - now < 16 * 3600000L) {
                     return event;
                 }
diff -ruN -x '*.png' -x strings.xml /tmp/old38/SaraHome-source/app/src/main/java/com/example/duohome/Permissions.java app/src/main/java/com/example/duohome/Permissions.java
--- /tmp/old38/SaraHome-source/app/src/main/java/com/example/duohome/Permissions.java	1970-01-01 03:00:00.000000000 +0300
+++ app/src/main/java/com/example/duohome/Permissions.java	2026-11-15 08:45:19.936489472 +0300
@@ -0,0 +1,74 @@
+package com.example.duohome;
+
+import android.app.Activity;
+import android.app.AlertDialog;
+import android.content.Context;
+import android.content.Intent;
+import android.content.SharedPreferences;
+import android.content.pm.PackageManager;
+import android.net.Uri;
+import android.provider.Settings;
+
+/**
+ * Asking for a permission when the user taps something that needs it. Android shows its own question
+ * only until the user has said no for good; after that a request returns at once and nothing would
+ * happen on the tap. So: the first time, and while Android still explains, ask; once refused for good,
+ * say what it's for and open Sara Home's page in the phone's settings, where it can be turned on.
+ * (Android's guidance: check, explain, ask; on a permanent no, send the user to the app's details.)
+ */
+final class Permissions {
+    private static final String ASKED = "perm_asked_";
+
+    private Permissions() {
+    }
+
+    static boolean granted(Context context, String permission) {
+        return context.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
+    }
+
+    /** {@code why}: one line on what the permission is for, shown when only the settings page can grant it now. */
+    static void ask(Activity activity, String[] permissions, int requestCode, int why) {
+        SharedPreferences prefs = activity.getSharedPreferences("duo_home", 0);
+        boolean anyGranted = false;
+        boolean askedBefore = false;
+        boolean explain = false;
+        for (String permission : permissions) {
+            anyGranted |= granted(activity, permission);
+            askedBefore |= prefs.getBoolean(ASKED + permission, false);
+            explain |= activity.shouldShowRequestPermissionRationale(permission);
+        }
+        if (!anyGranted && askedBefore && !explain) {
+            blocked(activity, why);
+            return;
+        }
+        SharedPreferences.Editor edit = prefs.edit();
+        for (String permission : permissions) {
+            edit.putBoolean(ASKED + permission, true);
+        }
+        edit.apply();
+        activity.requestPermissions(permissions, requestCode);
+    }
+
+    /** Refused for good: explain, and offer the app's page in the phone's settings. */
+    static void blocked(Activity activity, int why) {
+        new AlertDialog.Builder(activity)
+                .setTitle(activity.getString(R.string.perm_blocked_title))
+                .setMessage(activity.getString(why) + "\n\n" + activity.getString(R.string.perm_blocked_body))
+                .setPositiveButton(activity.getString(R.string.perm_open_settings), (dialog, which) -> openAppSettings(activity))
+                .setNegativeButton(activity.getString(R.string.cancel), null)
+                .show();
+    }
+
+    static void openAppSettings(Context context) {
+        try {
+            context.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
+                    Uri.fromParts("package", context.getPackageName(), null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
+        } catch (Exception ignored) {
+        }
+    }
+
+    /** Backups leave these out: what was asked on one phone says nothing about another. */
+    static boolean isState(String key) {
+        return key.startsWith(ASKED);
+    }
+}
diff -ruN -x '*.png' -x strings.xml /tmp/old38/SaraHome-source/app/src/main/java/com/example/duohome/SaraWallpaper.java app/src/main/java/com/example/duohome/SaraWallpaper.java
--- /tmp/old38/SaraHome-source/app/src/main/java/com/example/duohome/SaraWallpaper.java	2026-11-15 00:43:54.000000000 +0300
+++ app/src/main/java/com/example/duohome/SaraWallpaper.java	2026-11-15 08:45:32.247535450 +0300
@@ -206,7 +206,9 @@
             filter.addAction(Intent.ACTION_USER_PRESENT);
             filter.addAction(Intent.ACTION_BATTERY_CHANGED);
             try {
-                readBattery(registerReceiver(receiver, filter));
+                // System broadcasts only: no other app may send to this receiver (Android 13+ flag).
+                readBattery(Build.VERSION.SDK_INT >= 33 ? registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
+                        : registerReceiver(receiver, filter));
                 registered = true;
             } catch (Exception ignored) {
             }
diff -ruN -x '*.png' -x strings.xml /tmp/old38/SaraHome-source/app/src/main/java/com/example/duohome/TodaySettings.java app/src/main/java/com/example/duohome/TodaySettings.java
--- /tmp/old38/SaraHome-source/app/src/main/java/com/example/duohome/TodaySettings.java	2026-11-15 00:43:54.000000000 +0300
+++ app/src/main/java/com/example/duohome/TodaySettings.java	2026-11-15 08:45:20.001160626 +0300
@@ -72,8 +72,7 @@
             ui.toggle(group, activity.getString(R.string.prayer_gps), prayerWhere, prayerGps && Places.permitted(activity), (button, on) -> {
                 prefs.edit().putBoolean(Places.PREF_PRAYER_GPS, on).remove("loc_time").apply();
                 if (on && !Places.permitted(activity)) {
-                    activity.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
-                            REQUEST_WEATHER_LOCATION);
+                    Permissions.ask(activity, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_WEATHER_LOCATION, R.string.perm_why_location);
                     return;
                 }
                 bump(prefs);
@@ -141,8 +140,7 @@
         ui.toggle(group, activity.getString(R.string.weather_gps), where, follows && Places.permitted(activity), (button, on) -> {
             prefs.edit().putBoolean(Places.PREF_WEATHER_GPS, on).remove("loc_time").apply();
             if (on && !Places.permitted(activity)) {
-                activity.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
-                        REQUEST_WEATHER_LOCATION);
+                Permissions.ask(activity, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_WEATHER_LOCATION, R.string.perm_why_location);
                 return;
             }
             prefs.edit().remove("wx_time").apply();
@@ -160,7 +158,7 @@
                     if (!on) {
                         Weather.storeAlert(prefs, null);
                     } else if (!ReminderReceiver.canNotify(activity) && Build.VERSION.SDK_INT >= 33) {
-                        activity.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
+                        Permissions.ask(activity, new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS, R.string.perm_why_notifications);
                     }
                     ReminderReceiver.scheduleWeather(activity);
                     bump(prefs);
@@ -172,7 +170,7 @@
                 remindersOn && canNotify, (button, on) -> {
                     prefs.edit().putBoolean("reminders_on", on).apply();
                     if (on && !ReminderReceiver.canNotify(activity) && Build.VERSION.SDK_INT >= 33) {
-                        activity.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
+                        Permissions.ask(activity, new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS, R.string.perm_why_notifications);
                     }
                     ReminderReceiver.schedule(activity);
                 });
@@ -232,7 +230,7 @@
                 .setSingleChoiceItems(names, selected, (dialog, which) -> {
                     prefs.edit().putInt("prayer_alert_min", ALERT_MINUTES[which]).apply();
                     if (ALERT_MINUTES[which] > 0 && !ReminderReceiver.canNotify(activity) && Build.VERSION.SDK_INT >= 33) {
-                        activity.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
+                        Permissions.ask(activity, new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS, R.string.perm_why_notifications);
                     }
                     ReminderReceiver.schedulePrayer(activity);
                     dialog.dismiss();
@@ -262,7 +260,7 @@
                         if (Places.permitted(activity)) {
                             useGps(activity, prefs, ui);
                         } else {
-                            activity.requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_LOCATION);
+                            Permissions.ask(activity, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_LOCATION, R.string.perm_why_location);
                         }
                         return;
                     }
```
